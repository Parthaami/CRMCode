﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;
using System.Web.Http;

namespace SMSService.Controllers
{

    public class Parameter
    {
        public string MobileNumber { get; set; }

        public string SMSMessage { get; set; }

        public string IsServiceEnabled { get; set; }

    }
    public class SMSController : ApiController
    {

        public SMSController()
        {
            if (!EventLog.SourceExists("SMSService"))
                EventLog.CreateEventSource("SMSService", "Application");
        }
        
       /// <summary>
       /// 
       /// </summary>
       /// <param name="sMobileNo"></param>
       /// <param name="sMessage"></param>
       /// <returns></returns>
        [HttpPost, Route("sms/{SendSMS}"), ActionName("SendSMS")]
        public string SendSMS([FromBody] Parameter Param)
        {
            string responseString = string.Empty; 
            
            try
            {
                if (Param.IsServiceEnabled.ToLower() == "yes")
                    responseString = sendSMSMessage(Param.MobileNumber, Param.SMSMessage);
                else
                    responseString = "SMS Service is not enabled.";
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry("SMSService", ex.ToString(), EventLogEntryType.Error);
            }

            return responseString;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sMobileNo"></param>
        /// <param name="sMessage"></param>
        /// <returns></returns>
        [NonAction]
        private string sendSMSMessage(string sMobileNo, string sMessage)
        {
            string responseStatus = string.Empty;
            try
            {
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["Domain"].ToString();
                string PrintLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string URL = ConfigurationManager.AppSettings["URL"].ToString();
                string OueryString =  ConfigurationManager.AppSettings["OueryString"].ToString();
                                   

                string sendData = string.Empty;
                OueryString = OueryString.Replace(" ", "+");
                sendData = sendData + OueryString;
                sendData = sendData.Replace("Desc", sMessage);
                sendData = sendData.Replace("MobileNumber", sMobileNo); 

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
                request.Credentials = new NetworkCredential(UserName, Password, Domain);
             
                request.Method = "POST";
                byte[] byteArray = Encoding.UTF8.GetBytes(sendData);
                request.ContentLength = byteArray.Length;
                request.ContentType = "application/x-www-form-urlencoded";
                Stream IOStream = request.GetRequestStream();
                IOStream.Write(byteArray, 0, byteArray.Length);
                IOStream.Close();
                request.AllowAutoRedirect = true;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                
                StreamReader ResponseStream = new StreamReader(response.GetResponseStream());
                responseStatus = ResponseStream.ReadToEnd();
                if (PrintLog.ToLower() == "yes")
                    EventLog.WriteEntry("SMSService", "SMS Url: " + URL + sendData + "Responce: " + responseStatus,EventLogEntryType.Information);

                ResponseStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry("SMSService" , ex.ToString().ToString() + " - " + sMobileNo + " " + sMessage, EventLogEntryType.Error);
            }
            return responseStatus;
        }
    }
}
