﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Newtonsoft.Json;



namespace WCF_BD_Apps
{
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class WCF_BD_Apps : IWCF_BD_Apps
    {
        public static Logger oLogger;
        public static string _organizationName = ConfigurationManager.AppSettings["OrgName"].ToString();
        public static string _loggerPath = ConfigurationManager.AppSettings["LoggerPath"].ToString();
        public static string _dbConnectionString = ConfigurationManager.ConnectionStrings["SQLDBConnectionString"].ConnectionString;
        public static string NetworkUser = ConfigurationManager.AppSettings["NetworkUser"];
        public static string NetworkPassword = ConfigurationManager.AppSettings["NetworkPassword"];
        public static string NetworkDomain = ConfigurationManager.AppSettings["NetworkDomain"];
        public static string CRMOrgServiceUrl = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
        private IOrganizationService service;

        #region GetConfigurationData
        private void GetConfigurationData()
        {
            try
            {
                oLogger = new Logger(_organizationName, _loggerPath);
            }
            catch (Exception ex)
            {
                oLogger.Log("WCF_BD_Apps", "GetConfigurationData", "Exception: " + ex.ToString(), "Problem while fetching ConfigData");
            }
        }
        #endregion

        #region GetService (IOrganizationService) 
        private IOrganizationService GetService()
        {
            IOrganizationService service;
            try
            {
                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
                service = (IOrganizationService)orgService;
                return service;
            }
            catch (Exception ex)
            {
                oLogger.Log("WCF_BD_Apps", "GetService()", ex.Message, ex.Source);
                throw ex;
            }
        }
        #endregion

        #region CE Monitoring Report In HTML Output
        public Stream CEMonitoringReport(string OutputType = "html")
        {
            byte[] resultBytes = Encoding.UTF8.GetBytes("");
            GetConfigurationData();
            DataTable dtA = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {

                    conn.Open();
                    string query_text = @"exec SP_HTML_CEMonitoringReport;";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                }
                int RecordCount = dtA.Rows.Count;
                /*---------------------------------------------------*/
                string html = "";
                if (OutputType.Trim().ToLower() != "xl")
                {
                    html = "<html><table border='0'><tr><td><a href='";
                    html += "http://14.141.228.221:6506/WCF_BD_Apps.svc/CEMonitoringReport/xl";
                    html += "'><img alt='Export To EXCEL' width='45px' height='45px' src='http://14.141.228.221:6506/ExcelIcon.png'></a>";
                    html += "</td><td><a href='";
                    html += "http://14.141.228.221:6506/WCF_BD_Apps.svc/CEMonitoringReport/xl";
                    html += "'><img alt='Export To PDF' width='45px' height='45px' src='http://14.141.228.221:6506/PdfIcon.jpg'></a>";
                    html += "</td></tr></table><br><hr></html> ";
                }
                foreach (DataRow dr in dtA.Rows)
                {
                    foreach (DataColumn dc in dr.Table.Columns)
                    {
                        html += "" + dr[dc];
                    }
                }
                if (RecordCount > 0)
                {
                    resultBytes = Encoding.UTF8.GetBytes(html);
                    if (OutputType.Trim().Equals("xl", StringComparison.CurrentCultureIgnoreCase))
                    {
                        String headerInfo = "attachment; filename=" + "CEMonitoringReport" + "." + "xls";
                        WebOperationContext.Current.OutgoingResponse.Headers["Content-Disposition"] = headerInfo;
                        WebOperationContext.Current.OutgoingResponse.ContentType = "application/octet-stream";
                        WebOperationContext.Current.OutgoingResponse.Headers["Content-Length"] = resultBytes.Length.ToString();
                    }
                    else
                    {
                        WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
                    }
                }
                else
                {
                    oLogger.Log("WCF_BD_Apps", "CEMonitoringReport", "No Record Found", "No Record Found");
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WCF_BD_Apps", "CEMonitoringReport", "Exception: " + ex.ToString(), "Problem while fetching data forCEMonitoringReport");
            }

            return new MemoryStream(resultBytes);
        }
        #endregion

        #region GetLeadDetailData
        public List<LeadDetailData> GetLeadDetailData(string Lid)
        {
            GetConfigurationData();
            List<LeadDetailData> objListOutuput = new List<LeadDetailData>();
            DataTable TableRecords = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_GetLeadDetailData @LeadID = '" + Lid + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableRecords.Load(reader);
                    objListOutuput = (from DataRow dr in TableRecords.Rows
                                      select new LeadDetailData()
                                      {
                                          LeadGUID = "" + dr["LeadGUID"],
                                          LeadId = "" + dr["LeadId"],
                                          Salutation = "" + dr["Salutation"],
                                          FirstName = "" + dr["FirstName"],
                                          Lastname = "" + dr["Lastname"],
                                          PrimaryNo = "" + dr["PrimaryNo"],
                                          AlternateContactNo = "" + dr["AlternateContactNo"],
                                          HomePhone = "" + dr["HomePhone"],
                                          Email = "" + dr["Email"],
                                          Street1 = "" + dr["Street1"],
                                          Street2 = "" + dr["Street2"],
                                          Street3 = "" + dr["Street3"],
                                          PinCode = "" + dr["PinCode"],
                                          City = "" + dr["City"],
                                          State = "" + dr["State"],
                                          LeadType = "" + dr["LeadType"],
                                          LeadStatus = "" + dr["LeadStatus"],
                                          LeadSource = "" + dr["LeadSource"],
                                          LeadOpportunity = "" + dr["LeadOpportunity"],
                                          PaintingType = "" + dr["PaintingType"],
                                          Depot = "" + dr["Depot"],
                                          DealerCode = "" + dr["DealerCode"],
                                          CarpetArea = "" + dr["CarpetArea"],
                                          Interior = "" + dr["Interior"],
                                          Exterior = "" + dr["Exterior"],
                                          Wood = "" + dr["Wood"],
                                          CC = "" + dr["CC"],
                                          StartDate = "" + dr["StartDate"],
                                          EndDate = "" + dr["EndDate"],
                                          FinalJobValue = "" + dr["FinalJobValue"],
                                          StateCode = "" + dr["StateCode"],
                                          AppointmentDate = "" + dr["AppointmentDate"],
                                          Description = "" + dr["Description"],
                                          CaptureJobCompletedDate = "" + dr["CaptureJobCompletedDate"],
                                          TotalValue = "" + dr["TotalValue"],
                                          MaterialValue = "" + dr["MaterialValue"],
                                          LabourValue = "" + dr["LabourValue"],
                                          DgName = "" + dr["DgName"],
                                          DgMobileNo = "" + dr["DgMobileNo"]
                                      }
                            ).ToList();

                    int RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "GetLeadDetailData", "No Record Found for LeadId " + Lid + " from CRM", "No Record Found");
                    }
                }

                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "GetLeadDetailData", "Exception: " + ex.ToString(), "Problem while fetching LeadSummaryData for LeadId" + Lid + " from CRM");
                }
            }

            return objListOutuput;
        }
        #endregion

        #region BDDGValidation
        public List<BDDGValidtion> BDDGValidation(string MobileNo)
        {
            GetConfigurationData();
            List<BDDGValidtion> objListOutuput = new List<BDDGValidtion>();
            DataTable TableDG = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_BDDGValidation @MobileNo = '" + MobileNo.Trim() + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableDG.Load(reader);
                    objListOutuput = (from DataRow dr in TableDG.Rows
                                      select new BDDGValidtion()
                                      {
                                          GUID = "" + dr["GUID"],
                                          Deopot_Code = "" + dr["Deopot_Code"],
                                          DG_Name = "" + dr["DG_Name"]
                                      }).ToList();
                    int RecordCount = 0;
                    RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "BDDGValidation", "No Record Found for MobileNo : " + MobileNo, "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "BDDGValidation", "Exception: " + ex.ToString(), "Problem while fetching info for  Mobile-No : " + MobileNo);
                }
            }

            return objListOutuput;
        }
        #endregion

        #region BDDealerListByDG
        public List<BDDealerListByDG> BDDealerListByDG(string DgGuId)
        {
            GetConfigurationData();
            List<BDDealerListByDG> objListOutuput = new List<BDDealerListByDG>();
            DataTable TableRecords = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_BDDealerListByDG @DgGuId = '" + DgGuId.Trim() + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableRecords.Load(reader);
                    objListOutuput = (from DataRow dr in TableRecords.Rows
                                      select new BDDealerListByDG()
                                      {
                                          DepotCode = "" + dr["DepotCode"],
                                          DealerCode = "" + dr["DealerCode"]
                                      }).ToList();
                    int RecordCount = 0;
                    RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "BDDealerListByDG", "No Record Found for DgGuId : " + DgGuId, "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "BDDealerListByDG", "Exception: " + ex.ToString(), "Problem while fetching info for DgGuId : " + DgGuId);
                }
            }

            return objListOutuput;
        }
        #endregion

        #region BDGetNewLead
        public List<BDGetNewLead> BDGetNewLead(string DgGuId)
        {
            GetConfigurationData();
            List<BDGetNewLead> objListOutuput = new List<BDGetNewLead>();
            DataTable TableRecords = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_BDGetNewLead @DgGuId = '" + DgGuId.Trim() + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableRecords.Load(reader);
                    objListOutuput = (from DataRow dr in TableRecords.Rows
                                      select new BDGetNewLead()
                                      {
                                          City = "" + dr["City"],
                                          DealerCode = "" + dr["DealerCode"],
                                          Depot = "" + dr["Depot"],
                                          Description = "" + dr["Description"],
                                          DgGUID = "" + dr["DgGUID"],
                                          Email = "" + dr["Email"],
                                          FirstName = "" + dr["FirstName"],
                                          Lastname = "" + dr["Lastname"],
                                          HomePhone = "" + dr["HomePhone"],
                                          LeadId = "" + dr["LeadId"],
                                          LeadGUID = "" + dr["LeadGUID"],
                                          LeadOpportunity = "" + dr["LeadOpportunity"],
                                          LeadSourceCode = "" + dr["LeadSourceCode"],
                                          LeadStatus = "" + dr["LeadStatus"],
                                          PaintingType = "" + dr["PaintingType"],
                                          PinCode = "" + dr["PinCode"],
                                          PrimaryNo = "" + dr["PrimaryNo"],
                                          Salutation = "" + dr["Salutation"],
                                          StartDate = "" + dr["StartDate"],
                                          State = "" + dr["State"]
                                      }).ToList();

                    int RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "BDGetNewLead", "No Record Found for DgGuId : " + DgGuId, "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "BDGetNewLead", "Exception: " + ex.ToString(), "Problem while fetching info for DgGuId : " + DgGuId);
                }
            }
            return objListOutuput;
        }
        #endregion

        #region BDGetLeadListByDG
        public List<BDGetLeadListByDG> BDGetLeadListByDG(string DgGuId, string LeadStatus)
        {
            GetConfigurationData();
            List<BDGetLeadListByDG> objListOutuput = new List<BDGetLeadListByDG>();
            DataTable TableRecords = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_BDGetLeadListByDG @DgGuId = '" + DgGuId.Trim() + "', @StatusCodes = '" + LeadStatus + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableRecords.Load(reader);
                    objListOutuput = (from DataRow dr in TableRecords.Rows
                                      select new BDGetLeadListByDG()
                                      {
                                          City = "" + dr["City"],
                                          DealerCode = "" + dr["DealerCode"],
                                          Depot = "" + dr["Depot"],
                                          Description = "" + dr["Description"],
                                          DgGUID = "" + dr["DgGUID"],
                                          Email = "" + dr["Email"],
                                          FirstName = "" + dr["FirstName"],
                                          Lastname = "" + dr["Lastname"],
                                          HomePhone = "" + dr["HomePhone"],
                                          LeadId = "" + dr["LeadId"],
                                          LeadGUID = "" + dr["LeadGUID"],
                                          LeadOpportunity = "" + dr["LeadOpportunity"],
                                          LeadSourceCode = "" + dr["LeadSourceCode"],
                                          LeadStatus = "" + dr["LeadStatus"],
                                          PaintingType = "" + dr["PaintingType"],
                                          PinCode = "" + dr["PinCode"],
                                          PrimaryNo = "" + dr["PrimaryNo"],
                                          Salutation = "" + dr["Salutation"],
                                          StartDate = "" + dr["StartDate"],
                                          State = "" + dr["State"],
                                          DealerName = "" + dr["DealerName"],
                                          PainterName = "" + dr["PainterName"],
                                          PainterMobile = "" + dr["PainterMobile"]
                                      }).ToList();

                    int RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "BDGetLeadListByDG", "No Record Found for DgGuId : " + DgGuId, "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "BDGetLeadListByDG", "Exception: " + ex.ToString(), "Problem while fetching info for DgGuId : " + DgGuId);
                }
            }
            return objListOutuput;
        }
        #endregion

        #region BDLeadUpcomingAppointmentInfo
        public List<BDLeadUpcomingAppointmentInfo> BDLeadUpcomingAppointmentInfo(string DgGuId, string Date)
        {
            GetConfigurationData();
            List<BDLeadUpcomingAppointmentInfo> objListOutuput = new List<BDLeadUpcomingAppointmentInfo>();
            DataTable TableRecords = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_BDLeadUpcomingAppointmentInfo @DgGuId = '" + DgGuId.Trim() + "', @Date = '" + Date + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    TableRecords.Load(reader);
                    objListOutuput = (from DataRow dr in TableRecords.Rows
                                      select new BDLeadUpcomingAppointmentInfo()
                                      {
                                          City = "" + dr["City"],
                                          DealerCode = "" + dr["DealerCode"],
                                          Depot = "" + dr["Depot"],
                                          Description = "" + dr["Description"],
                                          Email = "" + dr["Email"],
                                          FirstName = "" + dr["FirstName"],
                                          Lastname = "" + dr["Lastname"],
                                          HomePhone = "" + dr["HomePhone"],
                                          LeadId = "" + dr["LeadId"],
                                          LeadGUID = "" + dr["LeadGUID"],
                                          LeadOpportunity = "" + dr["LeadOpportunity"],
                                          LeadSourceCode = "" + dr["LeadSourceCode"],
                                          LeadStatus = "" + dr["LeadStatus"],
                                          PaintingType = "" + dr["PaintingType"],
                                          PinCode = "" + dr["PinCode"],
                                          PrimaryNo = "" + dr["PrimaryNo"],
                                          Salutation = "" + dr["Salutation"],
                                          StartDate = "" + dr["StartDate"],
                                          State = "" + dr["State"]
                                      }).ToList();

                    int RecordCount = objListOutuput.Count;
                    if (RecordCount < 1)
                    {
                        oLogger.Log("WCF_BD_Apps", "BDLeadUpcomingAppointmentInfo", "No Record Found for DgGuId : " + DgGuId, "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "BDLeadUpcomingAppointmentInfo", "Exception: " + ex.ToString(), "Problem while fetching info for DgGuId : " + DgGuId);
                }
            }
            return objListOutuput;
        }
        #endregion


        #region Set Method : BDLeadDefferedFlagUpdate
        public string BDLeadDefferedFlagUpdate(string LeadGUID, string DgGUID, string StatusReasonCode, string FollowUpDate, string Description)
        {
            string retVal = "Success";

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    //SqlConnection conn = new SqlConnection(_dbConnectionString);
                    conn.Open();

                    string SqlQuery = "Select MAX(StateCode) from BergerUAT_MSCRM.dbo.Lead";
                    SqlQuery += " WHERE LeadId = '" + LeadGUID + "' and ber_DGcontact = '" + DgGUID + "'";
                    SqlCommand command = new SqlCommand(SqlQuery, conn);
                    string CurrentLeadStateCode = "" + command.ExecuteScalar();
                    if (CurrentLeadStateCode.Trim() == "")
                    {
                        retVal = "Lead not exists / This Lead is not belongs to the specific DG.";
                        return retVal;
                    }

                    SqlQuery = "SELECT '1' FROM BergerUAT_MSCRM.dbo.Lead";
                    SqlQuery += " WHERE StateCode = '" + CurrentLeadStateCode + "'";
                    SqlQuery += " AND StatusCode = '" + StatusReasonCode + "'";
                    command = new SqlCommand(SqlQuery, conn);
                    string CurrentLeadStatusCodeinDB = "" + command.ExecuteScalar();
                    if (CurrentLeadStatusCodeinDB.Trim() != "1")
                    {
                        retVal = "StatusReasonCode not exists / This StatusReasonCode is not belongs to the specific Lead's OptionSet or StateCode";
                        return retVal;
                    }

                    Entity lead_ = new Entity();
                    lead_.LogicalName = "lead";
                    lead_.Id = new Guid("" + LeadGUID);
                    //lead_.Attributes["statecode"] = 1;
                    lead_.Attributes["statuscode"] = new OptionSetValue(Convert.ToInt32(StatusReasonCode));
                    lead_.Attributes["ber_followupdate"] = DateTime.Parse(FollowUpDate);
                    lead_.Attributes["description"] = Description.Trim();
                    service = GetService();
                    service.Update(lead_);
                }
                catch (Exception ex)
                {
                    retVal = "Failed";
                    oLogger.Log("WCF_BD_Apps", "BDLeadDefferedFlagUpdate", "Exception: " + ex.ToString(), "Problem while updating for LeadGUID : " + LeadGUID);
                }
            }

            return retVal;
        }
        #endregion

        #region JsonTest 
        public Stream BDM(string MethodName, string ParametersWithValues)
        {
            MemoryStream StreamOupt = null;
            GetConfigurationData();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))    // Partha has been changed the code for disconnected architecture on  19-Dec-2016  
            {
                string query_text_exception = string.Empty; 
                try
                {
                    #region Get All Parameters With Values
                    NameValueCollection ArrayParameters = new NameValueCollection();
                    ArrayParameters = System.ServiceModel.Web.WebOperationContext.Current.IncomingRequest.UriTemplateMatch.QueryParameters;
                    string query_text = @"exec sp_BD" + ("" + MethodName).Trim();
                    for (int i = 1; i < ArrayParameters.Count; i++)
                    {
                        string ParamKey = "" + ArrayParameters.GetKey(i);
                        string ParamValue = "" + ArrayParameters.GetValues(i)[0];
                        query_text += (i > 1 ? "," : "");
                        query_text += " @" + ParamKey + " = '" + ParamValue + "'";
                    }
                    query_text_exception = query_text;
                    #endregion
                    #region Database Connectivity And SP Execution
                    // SqlConnection conn = new SqlConnection(_dbConnectionString);
                    conn.Open();
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    DataTable TableRecords = new DataTable(("" + MethodName).Trim());
                    TableRecords.Load(reader);
                    #endregion
                    #region Converting To JSON
                    if (TableRecords.Rows.Count > 0)
                    {
                        string jsonString = string.Empty;
                        jsonString = JsonConvert.SerializeObject(TableRecords);
                        byte[] resultBytes = Encoding.UTF8.GetBytes(jsonString);
                        WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
                        StreamOupt = new MemoryStream(resultBytes);
                    }
                    else
                    {
                        oLogger.Log("WCF_BD_Apps", "MethodName: BDM." + MethodName  + "Parameter: " + query_text, "No Record Found", "No Record Found");
                    }
                    #endregion
                }
                catch (IOException exIO)
                {
                    Console.Write("System Error" + exIO.Message.ToString());
                }
                catch (Exception ex)
                {
                    oLogger.Log("WCF_BD_Apps", "MethodName : BDM.  " + MethodName + "Parameter: " + query_text_exception, "Exception: " + ex.ToString(), "Error while fetching records");
                }
                finally
                {
                }
            }

            return StreamOupt;
        }
        #endregion

        #region Authentication

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["NetworkUser"].ToString();
            string _password = ConfigurationManager.AppSettings["NetworkPassword"].ToString();
            string _domain = ConfigurationManager.AppSettings["NetworkDomain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion

    }
}
