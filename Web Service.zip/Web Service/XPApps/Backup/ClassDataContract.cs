﻿using System.Runtime.Serialization;

namespace WCF_BD_Apps
{
    [DataContract]
    public class LeadDetailData
    {
        [DataMember]
        public string LeadGUID { get; set; }
        [DataMember]
        public string LeadId { get; set; }
        [DataMember]
        public string Salutation { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string Lastname { get; set; }
        [DataMember]
        public string PrimaryNo { get; set; }
        [DataMember]
        public string AlternateContactNo { get; set; }
        [DataMember]
        public string HomePhone { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string Street1 { get; set; }
        [DataMember]
        public string Street2 { get; set; }
        [DataMember]
        public string Street3 { get; set; }
        [DataMember]
        public string PinCode { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string LeadType { get; set; }
        [DataMember]
        public string LeadStatus { get; set; }
        [DataMember]
        public string LeadSource { get; set; }
        [DataMember]
        public string LeadOpportunity { get; set; }
        [DataMember]
        public string PaintingType { get; set; }
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string DealerCode { get; set; }
        [DataMember]
        public string CarpetArea { get; set; }
        [DataMember]
        public string Interior { get; set; }
        [DataMember]
        public string Exterior { get; set; }
        [DataMember]
        public string Wood { get; set; }
        [DataMember]
        public string CC { get; set; }
        [DataMember]
        public string StartDate { get; set; }
        [DataMember]
        public string EndDate { get; set; }
        [DataMember]
        public string FinalJobValue { get; set; }
        [DataMember]
        public string StateCode { get; set; }
        [DataMember]
        public string AppointmentDate { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string CaptureJobCompletedDate { get; set; }
        [DataMember]
        public string TotalValue { get; set; }
        [DataMember]
        public string MaterialValue { get; set; }
        [DataMember]
        public string LabourValue { get; set; }
        [DataMember]
        public string DgName { get; set; }
        [DataMember]
        public string DgMobileNo { get; set; }
    }


    [DataContract]
    public class BDDGValidtion
    {
        [DataMember(Order = 1)]
        public string GUID;

        [DataMember(Order = 2)]
        public string DG_Name;

        [DataMember(Order = 3)]
        public string Deopot_Code;
    }

    [DataContract]
    public class BDDealerListByDG
    {
        [DataMember(Order = 1)]
        public string DepotCode;

        [DataMember(Order = 2)]
        public string DealerCode;
    }

    [DataContract]
    public class BDGetNewLead
    {
        [DataMember(Order = 1)]
        public string City;
        [DataMember(Order = 2)]
        public string DealerCode;
        [DataMember(Order = 3)]
        public string Depot;
        [DataMember(Order = 4)]
        public string Description;
        [DataMember(Order = 5)]
        public string DgGUID;
        [DataMember(Order = 6)]
        public string Email;
        [DataMember(Order = 7)]
        public string FirstName;
        [DataMember(Order = 8)]
        public string Lastname;
        [DataMember(Order = 9)]
        public string HomePhone;
        [DataMember(Order = 10)]
        public string LeadId;
        [DataMember(Order = 11)]
        public string LeadOpportunity;
        [DataMember(Order = 12)]
        public string LeadSourceCode;
        [DataMember(Order = 13)]
        public string LeadStatus;
        [DataMember(Order = 14)]
        public string PaintingType;
        [DataMember(Order = 15)]
        public string PinCode;
        [DataMember(Order = 16)]
        public string PrimaryNo;
        [DataMember(Order = 17)]
        public string Salutation;
        [DataMember(Order = 18)]
        public string StartDate;
        [DataMember(Order = 19)]
        public string State;
        [DataMember(Order = 20)]
        public string LeadGUID;
    }

    [DataContract]
    public class BDGetLeadListByDG
    {
        [DataMember(Order = 1)]
        public string City;
        [DataMember(Order = 2)]
        public string DealerCode;
        [DataMember(Order = 3)]
        public string Depot;
        [DataMember(Order = 4)]
        public string Description;
        [DataMember(Order = 5)]
        public string DgGUID;
        [DataMember(Order = 6)]
        public string Email;
        [DataMember(Order = 7)]
        public string FirstName;
        [DataMember(Order = 8)]
        public string Lastname;
        [DataMember(Order = 9)]
        public string HomePhone;
        [DataMember(Order = 10)]
        public string LeadId;
        [DataMember(Order = 11)]
        public string LeadOpportunity;
        [DataMember(Order = 12)]
        public string LeadSourceCode;
        [DataMember(Order = 13)]
        public string LeadStatus;
        [DataMember(Order = 14)]
        public string PaintingType;
        [DataMember(Order = 15)]
        public string PinCode;
        [DataMember(Order = 16)]
        public string PrimaryNo;
        [DataMember(Order = 17)]
        public string Salutation;
        [DataMember(Order = 18)]
        public string StartDate;
        [DataMember(Order = 19)]
        public string State;
        [DataMember(Order = 20)]
        public string LeadGUID;
        [DataMember(Order = 21)]
        public string DealerName;
        [DataMember(Order = 22)]
        public string PainterName;
        [DataMember(Order = 23)]
        public string PainterMobile;
    }

    [DataContract]
    public class BDLeadUpcomingAppointmentInfo
    {
        [DataMember(Name = "City", IsRequired = true, Order = 1)]
        public string City;
        [DataMember(Order = 2)]
        public string DealerCode;
        [DataMember(Order = 3)]
        public string Depot;
        [DataMember(Order = 4)]
        public string Description;
        [DataMember(Order = 5)]
        public string Email;
        [DataMember(Order = 6)]
        public string FirstName;
        [DataMember(Order = 7)]
        public string Lastname;
        [DataMember(Order = 8)]
        public string HomePhone;
        [DataMember(Order = 9)]
        public string LeadId;
        [DataMember(Order = 10)]
        public string LeadOpportunity;
        [DataMember(Order = 11)]
        public string LeadSourceCode;
        [DataMember(Order = 12)]
        public string LeadStatus;
        [DataMember(Order = 13)]
        public string PaintingType;
        [DataMember(Order = 14)]
        public string PinCode;
        [DataMember(Order = 15)]
        public string PrimaryNo;
        [DataMember(Order = 16)]
        public string Salutation;
        [DataMember(Order = 17)]
        public string StartDate;
        [DataMember(Order = 18)]
        public string State;
        [DataMember(Order = 19)]
        public string LeadGUID;
    }

}
