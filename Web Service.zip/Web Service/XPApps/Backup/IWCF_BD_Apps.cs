﻿using System.Collections.Generic;
using System.IO;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace WCF_BD_Apps
{

    [ServiceContract]
    public interface IWCF_BD_Apps
    {
        [System.ServiceModel.Web.WebGet(UriTemplate = "/CEMonitoringReport/{OutputType}", BodyStyle = WebMessageBodyStyle.Bare)]
        [OperationContract]
        Stream CEMonitoringReport(string OutputType = "html");

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/GetLeadDetailData?LeadId={Lid}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadDetailData> GetLeadDetailData(string Lid);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDDGValidation?MobileNo={MobileNo}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<BDDGValidtion> BDDGValidation(string MobileNo);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDDealerListByDG?DgGuId={DgGuId}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<BDDealerListByDG> BDDealerListByDG(string DgGuId);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDGetNewLead?DgGuId={DgGuId}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<BDGetNewLead> BDGetNewLead(string DgGuId);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDGetLeadListByDG?DgGuId={DgGuId}&LeadStatus={LeadStatus}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<BDGetLeadListByDG> BDGetLeadListByDG(string DgGuId, string LeadStatus);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDLeadUpcomingAppointmentInfo?DgGuId={DgGuId}&Date={Date}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<BDLeadUpcomingAppointmentInfo> BDLeadUpcomingAppointmentInfo(string DgGuId, string Date);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDLeadDefferedFlagUpdate?LeadGUID={LeadGUID}&DgGUID={DgGUID}&StatusReasonCode={StatusReasonCode}&FollowUpDate={FollowUpDate}&Description={Description}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        string BDLeadDefferedFlagUpdate(string LeadGUID, string DgGUID, string StatusReasonCode, string FollowUpDate, string Description);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/BDM?MethodName={MethodName}&ParametersWithValues={ParametersWithValues}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        Stream BDM(string MethodName, string ParametersWithValues);
    }
   
}
