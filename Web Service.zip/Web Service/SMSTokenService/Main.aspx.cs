﻿using System;
using System.Data.SqlClient;
using System.Configuration;


namespace TokenSMSService
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string phone=string.Empty;
            string message=string.Empty;

            if (!IsPostBack)
            {
                if (Request.QueryString.Count > 0)
                {
                    phone = Request.QueryString["phone"].ToString();
                    message = Request.QueryString["message"].ToString();

                    BergerTokenService.BergerTokenServices ob = new BergerTokenService.BergerTokenServices();
                    string result = ob.CreateTokenRedemtion(phone, message, "mobile");
                    string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionInitialCatalog"] + ";User ID="+ConfigurationManager.AppSettings["UserID"]+";Password="+ConfigurationManager.AppSettings["Pwd"];
                                                                     
                    SqlConnection con = new SqlConnection(dbConnectionString);
                    con.Open();
                    string command = "insert into Token_SMS_Status (ID,URL,Status,CreatedOn) Values('" + Guid.NewGuid() + "','" + Request.RawUrl + "','" + result + "','" + DateTime.Now + "')";
                    SqlCommand cm = new SqlCommand(command, con);
                    int i = cm.ExecuteNonQuery();
                    con.Close();
                    con.Dispose();
                    cm.Dispose();
                }
                else
                {
                    string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionInitialCatalog"] + ";User ID=" + ConfigurationManager.AppSettings["UserID"] + ";Password=" + ConfigurationManager.AppSettings["Pwd"];
                    SqlConnection con = new SqlConnection(dbConnectionString);
                    con.Open();
                    string command = "insert into Token_SMS_Status (ID,URL,Status,CreatedOn) Values('" + Guid.NewGuid() + "','" + Request.RawUrl + "','Parameter Not passed','" + DateTime.Now + "')";
                    SqlCommand cm = new SqlCommand(command, con);
                    int i = cm.ExecuteNonQuery();
                    con.Close();
                    con.Dispose();
                    cm.Dispose();
                }
            }
        }
    }
}