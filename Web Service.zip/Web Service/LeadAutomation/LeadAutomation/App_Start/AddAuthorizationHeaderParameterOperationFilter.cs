﻿using Swashbuckle.Swagger;
using System.Web.Http.Description;

namespace LeadAutomation.App_Start
{
    /// <summary>
    /// Add filter in Swagger UI
    /// </summary>
    public class AddAuthorizationHeaderParameterOperationFilter : IOperationFilter

    {
        /// <summary>
        /// Token authorization document
        /// </summary>
        /// <param name="operation"></param>
        /// <param name="schemaRegistry"></param>
        /// <param name="apiDescription"></param>
        public void Apply(Operation operation, SchemaRegistry schemaRegistry, ApiDescription apiDescription)
        {
            if (operation.parameters != null)
            {
                operation.parameters.Add(new Parameter
                {
                    name = "Token",
                    @in = "header",
                    description = "Access token",
                    required = true,
                    type = "string"
                });
            }
        }
    }
}