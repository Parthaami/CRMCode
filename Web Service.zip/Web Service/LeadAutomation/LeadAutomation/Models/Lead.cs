﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LeadAutomation.Models
{
    /// <summary>
    /// Lead informations
    /// </summary>
    public class LeadDetail
    {
        /// <summary>
        /// First Name
        /// </summary>
        [Required(ErrorMessage = "First name is required")]
        public string FirstName { get; set; }
        /// <summary>
        /// Last Name
        /// </summary>
        [Required(ErrorMessage = "Last name is required")]
        public string LastName { get; set; }
        /// <summary>
        /// Primary Phone number
        /// </summary>
        [Required(ErrorMessage = "Phone number is required"), RegularExpression("^[0-9]*$")]
        public long Telephone { get; set; }
        /// <summary>
        /// Alternate Phone number
        /// </summary>
        [RegularExpression("^[0-9]*$")]
        public long? AlternateContactNo { get; set; }
        /// <summary>
        /// Primary Email
        /// </summary>
        //[RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$")]
        public string Email { get; set; }
        /// <summary>
        /// Address
        /// </summary>
        [MaxLength(500)]
        public string StreetAddress { get; set; }
        /// <summary>
        /// Pincode
        /// </summary>
        public int? Pincode { get; set; }
        /// <summary>
        /// KYC image
        /// </summary>
        public byte[] Image { get; set; }
        /// <summary>
        /// Source of Lead
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Customer query
        /// </summary>
        [MaxLength(1500)]
        public string Query { get; set; }


        /// <summary>
        /// campaignid
        /// </summary>
        public string campaignid { get; set; }

        /// <summary>
        /// campaignname
        /// </summary>
        public string campaignname { get; set; }

        /// <summary>
        /// campaignlocation
        /// </summary>
        public string campaignlocation { get; set; }

        /// <summary>
        /// homeshield
        /// </summary>
        public string homeshield { get; set; }


        //entity["ber_salutation"] = new OptionSetValue();
        //entity["ber_leadconversionrequired"] = new OptionSetValue();
        //entity["ber_interior"] = ""; //two option set
        //        entity["ber_exterior"] = ""; //two option set
        //        entity["address2_addresstypecode"] = new OptionSetValue(); //Painting Type	
        //entity["leadqualitycode"] = new OptionSetValue(); //Rating
        //entity["industrycode"] = new OptionSetValue(); //Lead (Oppurtunity)
        //entity["ber_numberoftowers"] = ""; ///No. Of Towers	
        //        entity["ber_noofstories"] = "";

        /// <summary>
        /// salutation
        /// </summary>
        public string salutation { get; set; }
        /// <summary>
        /// LeadConversionRequired
        /// </summary>
        public string LeadConversionRequired { get; set; }
        /// <summary>
        /// Interior
        /// </summary>
        public bool Interior { get; set; }
        /// <summary>
        /// Exterior
        /// </summary>
        public bool Exterior { get; set; }
        /// <summary>
        /// PaintingType
        /// </summary>
        public string PaintingType { get; set; }
        /// <summary>
        /// rating
        /// </summary>
        public string Rating { get; set; }
        /// <summary>
        /// LeadOppurtunity
        /// </summary>
        public string LeadOppurtunity { get; set; }
        /// <summary>
        /// NumberofTowers
        /// </summary>
        public string NumberofTowers { get; set; }
        /// <summary>
        /// NumberofStories
        /// </summary>
        public string NumberofStories { get; set; }
        /// <summary>
        /// CarpetArea
        /// </summary>
        public string CarpetArea { get; set; }
        /// <summary>
        /// NumberOfrRooms
        /// </summary>
        public string NumberOfrRooms { get; set; }


    }
    /// <summary>
    /// Request to create Lead
    /// </summary>
    public class Lead
    {
        /// <summary>
        /// Originating source
        /// </summary>
        [Required(ErrorMessage = "Origin is required")]
        public string Origin { get; set; }
        /// <summary>
        /// Lead Details
        /// </summary>
        [Required(ErrorMessage = "Lead details is required")]
        public List<LeadDetail> LeadDetails { get; set; }
    }
    /// <summary>
    /// Source to map Lead in CRM
    /// </summary>
    public class Source
    {
        /// <summary>
        /// call info
        /// </summary>
        public int CallInfo { get; set; }
        /// <summary>
        /// lead source
        /// </summary>
        public int LeadSource { get; set; }
    }
}