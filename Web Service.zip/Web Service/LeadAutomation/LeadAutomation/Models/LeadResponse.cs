﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LeadAutomation.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class LeadResponse
    {
        /// <summary>
        /// 
        /// </summary>
        public string Status { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<ResultSet> ResultSet { get; set; }
    }
    /// <summary>
    /// 
    /// </summary>
    public class ResultSet
    {
        /// <summary>
        /// 
        /// </summary>
        public Guid Id { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public long? Telephone { get; set; }
    }
}