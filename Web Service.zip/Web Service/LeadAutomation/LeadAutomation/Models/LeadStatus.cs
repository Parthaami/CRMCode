﻿using System;

namespace LeadAutomation.Models
{
    /// <summary>
    /// Lead status
    /// </summary>
    public class LeadStatus
    {
        /// <summary>
        /// Lead CRM Id
        /// </summary>
        public String Id { get; set; }
        /// <summary>
        /// Full Name
        /// </summary>
        public String Name { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public String Email { get; set; }
        /// <summary>
        /// Telephone
        /// </summary>
        public long? Telephone { get; set; }
        /// <summary>
        /// Status
        /// </summary>
        public String Status { get; set; }

        /// <summary>
        /// PinCode
        /// </summary>
        public String PinCode { get; set; }

    }
}