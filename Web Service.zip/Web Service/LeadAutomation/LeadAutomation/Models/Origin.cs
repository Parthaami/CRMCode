﻿namespace LeadAutomation.Models
{
    /// <summary>
    /// Lead source types
    /// </summary>
    public enum Origin
    {
        /// <summary>
        /// For HGS
        /// </summary>
        sms = 278290000,
        /// <summary>
        /// For ACL
        /// </summary>
        website = 278290001,
        /// <summary>
        /// For MCC
        /// </summary>
        mcc = 278290002
    }
    /// <summary>
    /// Status for log
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Success
        /// </summary>
        Success = 0,
        /// <summary>
        /// Failure
        /// </summary>
        Failure = 1
    }


}