﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LeadAutomation.Models
{/// <summary>
/// PinCode
/// </summary>
    public class PinCodeRetval
    {
        /// <summary>
        /// Id of pincode
        /// </summary>
        public Guid PinCodeGuiId { get; set; }
        /// <summary>
        /// Pin_Code
        /// </summary>
        public String Pin_Code { get; set; }
    }
}