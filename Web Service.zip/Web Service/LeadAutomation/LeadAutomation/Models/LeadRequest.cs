﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace LeadAutomation.Models
{
    /// <summary>
    /// Request to retrieve Leads
    /// </summary>
    public class LeadRequest
    {
        /// <summary>
        /// Originating source
        /// </summary>
        [Required(ErrorMessage = "Origin is required")]
        public string Origin { get; set; }
        /// <summary>
        /// Lead Id collection
        /// </summary>
        [Required(ErrorMessage = "Lead Id is required")]
        public List<LeadId> LeadDetails { get; set; }
    }
    /// <summary>
    /// Lead Id
    /// </summary>
    public class LeadId
    {
        /// <summary>
        /// Lead Id
        /// </summary>
        [Required(ErrorMessage = "Id is required")]
        public Guid Id { get; set; }
    }
}