﻿using System;

namespace LeadAutomation.Models
{
    /// <summary>
    /// Address
    /// </summary>
    public class Address
    {
        /// <summary>
        /// Id of pincode
        /// </summary>
        public Guid PinCodeId { get; set; }
        /// <summary>
        /// Id of city
        /// </summary>
        public Guid CityId { get; set; }
        /// <summary>
        /// LeadforTsi
        /// </summary>
        public Guid LeadforTsi { get; set; }
    }
}