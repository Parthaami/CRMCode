﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LeadAutomation.Models
{
    /// <summary>
    /// AddressAndLeadInfo
    /// </summary>
    public class AddressAndLeadInfo
    {
        /// <summary>
        /// Id of pincode
        /// </summary>
        public Guid PinCodeId { get; set; }
        /// <summary>
        /// Id of city
        /// </summary>
        public Guid CityId { get; set; }
        /// <summary>
        /// StateId
        /// </summary>
        public Guid StateId { get; set; }
        /// <summary>
        /// LeadType
        /// </summary>
        public int LeadType { get; set; }
        /// <summary>
        /// SubLeadType
        /// </summary>
        public int SubLeadType { get; set; }

        /// <summary>
        /// isChargable
        /// </summary>
        public int isChargable { get; set; }

        /// <summary>
        /// ServiceCost
        /// </summary>
        public decimal ServiceCost { get; set; }
        /// <summary>
        /// Tower
        /// </summary>
        public int Tower { get; set; }

        /// <summary>
        /// Building
        /// </summary>
        public int Building { get; set; }
        /// <summary>
        /// DefaultDepotId
        /// </summary>
        public Guid DefaultDepotId { get; set; }

    }
}