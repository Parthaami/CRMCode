﻿using System;
using System.Web;
using Microsoft.Xrm.Sdk;
using System.ServiceModel.Description;
using System.Configuration;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using LeadAutomation.Models;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Collections;

namespace LeadAutomation.Helper
{
    /// <summary>
    /// Generic class to maintain utilities
    /// </summary>
    public class Utility
    {
        /// <summary>
        /// Connect CRM and Initialize Organization Service
        /// </summary>
        /// <returns></returns>
        internal static IOrganizationService ConnectToCRM()
        {
            try
            {
                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["SoapUri"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
                return (IOrganizationService)orgService;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }
        /// <summary>
        /// Create log
        /// </summary>
        /// <param name="requestObject"></param>
        /// <param name="methodName"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static Guid CreateLog(string requestObject, String methodName, IOrganizationService _service)
        {
            try
            {
                var entity = new Entity("ber_leadautomationlog");
                entity.Attributes["ber_name"] = "Log_" + methodName + " " + DateTime.Now;
                entity.Attributes["ber_event"] = methodName;
                entity.Attributes["ber_requestbody"] = requestObject;
                return _service.Create(entity);
            }
            catch (FaultException<IOrganizationService> ex)
            {
                return Guid.Empty;
            }
            catch (Exception ex)
            {
                return Guid.Empty;
            }
        }

        /// <summary>
        /// Authenticate header token
        /// </summary>
        /// <param name="authenticationHeader"></param>
        /// <returns></returns>
        internal static bool isValidRequest(String authenticationHeader)
        {
            var request = HttpContext.Current.Request;
            var authHeader = request.Headers["Token"];
            if (authHeader != null)
            {
                return authHeader.Equals(authenticationHeader) ? true : false;
            }
            return false;
        }
        /// <summary>
        /// Retrieve default currency of Org
        /// </summary>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static Guid RetrieveDefaultCurrency(IOrganizationService _service)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "transactioncurrency",
                    ColumnSet = new ColumnSet("currencyname"),
                    NoLock = true
                };
                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    return ec.Entities[0].Id;
                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to retrieve default currency from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to retrieve default currency from CRM " + ex.Message);
            }
            return Guid.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="origin"></param>
        /// <param name="source"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static Source RetrieveSourceFromMapping(string origin, string source, IOrganizationService _service)
        {
            var originVal = GetValueOf(origin);
            try
            {
                QueryExpression qe = new QueryExpression();
                qe.EntityName = "ber_callinfoandsourcemapping";
                qe.ColumnSet = new ColumnSet("ber_origin");
                qe.NoLock = true;
                qe.Criteria = new FilterExpression
                {
                    Conditions =
                        {
                        new ConditionExpression ("ber_origin", ConditionOperator.Equal, Convert.ToInt32(originVal))
                        }
                };
                qe.LinkEntities.Add(new LinkEntity("ber_callinfoandsourcemapping", "ber_leadsource", "ber_callinfoandsourcemappingid", "ber_origin", JoinOperator.Inner));
                qe.LinkEntities[0].Columns.AddColumns("ber_name", "ber_callinfo", "ber_targetsource");
                qe.LinkEntities[0].EntityAlias = "ls";
                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    foreach (var item in ec.Entities)
                    {
                        if (source.ToLowerInvariant().Equals(item.GetAttributeValue<AliasedValue>("ls.ber_name").Value.ToString().ToLowerInvariant()))
                        {
                            return new Source
                            {
                                CallInfo   = item.Contains("ls.ber_callinfo") ? int.Parse(((OptionSetValue)(item.GetAttributeValue<AliasedValue>("ls.ber_callinfo")).Value).Value.ToString()) : default(int),
                                LeadSource = item.Contains("ls.ber_targetsource") ? int.Parse(((OptionSetValue)(item.GetAttributeValue<AliasedValue>("ls.ber_targetsource")).Value).Value.ToString()) : default(int)
                            };
                        }
                    }
                }
                return null;
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to map lead source from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to map lead source from CRM " + ex.Message);
            }
        }

        internal static void CallSmsWorkflow(Guid leadId, Guid logId, IOrganizationService _service)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// UpdateLeadServiceCost
        /// </summary>
        /// <param name="leadId"></param>
        /// <param name="logId"></param>
        /// <param name="BoolCCother"></param>
        /// <param name="LockedforAD"></param>
        /// <param name="_CityStateLeadDetailsByPincode"></param>
        /// <param name="_service"></param>
        internal static void UpdateLeadServiceCost(Guid leadId, Guid logId,bool BoolCCother,string LockedforAD, AddressAndLeadInfo _CityStateLeadDetailsByPincode, IOrganizationService _service)
        {
            try
            {
                // ber_cityid                => lookup city
                // ber_stateid               => lookup state
                // ber_leadtype
                // ber_subleadtype
                // ber_ischargeable
                // ber_servicecost
                //------------------------------------------
                /*Lead Type (ber_leadtype)*/

                // BDM 278290000
                // Home Decor  278290001
                // XP  278290002
                // null
                //------------------------------------------
                /*Lead Type (ber_leadtype)*/

                //BDM 278290000
                //Home Decor  278290001
                //XP  278290002

                var _isChargable = _CityStateLeadDetailsByPincode.isChargable;
                var _ServiceCost = _CityStateLeadDetailsByPincode.ServiceCost;
                var _Tower = _CityStateLeadDetailsByPincode.Tower;
                var _Building = _CityStateLeadDetailsByPincode.Building;
                var _CityId =_CityStateLeadDetailsByPincode.CityId;
                var _StateId = _CityStateLeadDetailsByPincode.StateId;
                var _DefaultDepotId = _CityStateLeadDetailsByPincode.DefaultDepotId;

                // "ber_cityid", "ber_citytype", "ber_stateid", "ber_ischargeable", "ber_applicablecost"
                // new EntityReference("transactioncurrency", Utility.RetrieveDefaultCurrency(_service));
                // new OptionSetValue(0);

                // _isChargable
                //278290001	   No
                //278290000    Yes

                var entity = new Entity("lead", leadId);
                entity["ber_cityid"] = new EntityReference("ber_city", _CityId);
                entity["ber_stateid"] = new EntityReference("ber_state", _StateId);
                entity["ber_depotid"] = new EntityReference("ber_depot", _DefaultDepotId);

                if (BoolCCother == true && LockedforAD == "Yes" && _isChargable == 278290000)
                {
                    entity["ber_servicecost"] = "Rs. 500.00";
                    entity["ber_leadtype"] = new OptionSetValue(278290002);      // Lead Type         => XP         278290002
                    entity["ber_subleadtype"] = new OptionSetValue(278290002);   // Sublead Type      => CC-Lead    278290002
                    entity["ber_ischargeable"] = "Yes";                          // 278290000         => Yes AND 278290001  => No
                    entity["ber_numberoftowers"] = Convert.ToInt32(_Tower);
                    entity["ber_noofstories"] = Convert.ToInt32(_Tower); ;
                }
                else if(LockedforAD == "Yes" && _isChargable == 278290000)
                {
                    entity["ber_leadtype"] = new OptionSetValue(278290002);      // Lead Type         => XP
                    entity["ber_ischargeable"] = "Yes";                          // 278290000         => Yes AND 278290001  => No
                    entity["ber_servicecost"] = "Rs. "+_ServiceCost.ToString();
                    entity["ber_numberoftowers"] = Convert.ToInt32(_Tower);
                    entity["ber_noofstories"] = Convert.ToInt32(_Tower); ;
                }



                _service.Update(entity);

            }
            catch (FaultException<IOrganizationService> ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
        }

        /// <summary>
        /// RetrieveLeadsourceAD
        /// </summary>
        /// <param name="leadsourcecode"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static string RetrieveLeadsourceAD(string leadsourcecode, IOrganizationService _service)
        {
            //var originVal = GetValueOf(origin);
            string RetVal = String.Empty;
            try
            {
                QueryExpression qe = new QueryExpression();
                qe.EntityName = "ber_ad_leadsourcemapping";
                qe.ColumnSet = new ColumnSet("ber_leadsourcecode", "ber_lockedforad");
                qe.NoLock = true;
                qe.Criteria = new FilterExpression
                {
                    Conditions =
                        {
                        new ConditionExpression ("ber_leadsourcecode", ConditionOperator.Equal, Convert.ToInt32(leadsourcecode))
                        }
                };
               // EntityCollection ec = _service.RetrieveMultiple(qe);

                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {

                    foreach (Entity LeadsourceAD in ec.Entities)
                    {
                        // RetVal = LeadsourceAD["ber_lockedforad"].ToString();
                        RetVal = ((OptionSetValue)(LeadsourceAD["ber_lockedforad"])).Value.ToString();
                        if(RetVal =="0")
                        {
                            RetVal = "Yes";
                        }
                        else if(RetVal == "1")
                        {
                            RetVal = "No";
                        }

                    }
                }

            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to retrieve RetrieveLeadsourceAD from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to retrieve RetrieveLeadsourceAD from CRM " + ex.Message);
            }
            return RetVal;

        }

        /// <summary>
        /// Assign lead to respective owner based on status
        /// </summary>
        /// <param name="leadId"></param>
        /// <param name="logId"></param>
        /// <param name="_service"></param>
        /// <param name="cityId"></param>
        internal static void AssignLead(Guid leadId, Guid logId, IOrganizationService _service, Guid? cityId)
        {
            try
            {
                if (cityId != null)
                {
                    var depotId = GetDefaultDepotByCity(cityId, logId, _service);
                    if (depotId != Guid.Empty)
                    {
                        AssignRecord(depotId, logId, leadId, _service);
                    }
                }
                else
                {
                    var depotId = new Guid(ConfigurationManager.AppSettings["DefaultOwner"]);
                    AssignRecord(depotId, logId, leadId, _service);
                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
        }
        /// <summary>
        /// Assign lead owner
        /// </summary>
        /// <param name="depotId"></param>
        /// <param name="logId"></param>
        /// <param name="leadId"></param>
        /// <param name="_service"></param>
        private static void AssignRecord(Guid depotId, Guid logId, Guid leadId, IOrganizationService _service)
        {
            try
            {
                AssignRequest assign = new AssignRequest
                {
                    Assignee = new EntityReference("systemuser", depotId),
                    Target = new EntityReference("lead", leadId)
                };
                _service.Execute(assign);
            }
            catch (FaultException<IOrganizationService> ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
        }
        /// <summary>
        /// Get default depot by city
        /// </summary>
        /// <param name="cityId"></param>
        /// <param name="logId"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        private static Guid GetDefaultDepotByCity(Guid? cityId, Guid logId, IOrganizationService _service)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "ber_city",
                    ColumnSet = new ColumnSet("ber_name", "ber_defaultdepotid"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                        new ConditionExpression ("ber_cityid", ConditionOperator.Equal, cityId)
                        }
                    }
                };
                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    return !ec.Entities[0].Contains("ber_defaultdepotid") ? Guid.Empty : GetDepotOwnerByDepotId(ec.Entities[0].GetAttributeValue<EntityReference>("ber_defaultdepotid").Id, _service);
                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service); ;
            }
            return Guid.Empty;
        }
        /// <summary>
        /// Get Depot owner by depot
        /// </summary>
        /// <param name="depotId"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        private static Guid GetDepotOwnerByDepotId(Guid depotId, IOrganizationService _service)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "ber_depot",
                    ColumnSet = new ColumnSet("ber_name", "ber_depotuser"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                        new ConditionExpression ("ber_depotid", ConditionOperator.Equal, depotId)
                        }
                    }
                };
                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    return !ec.Entities[0].Contains("ber_depotuser") ? Guid.Empty : ec.Entities[0].GetAttributeValue<EntityReference>("ber_depotuser").Id;
                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to get depot owner from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to get depot owner from CRM" + ex.Message);
            }
            return Guid.Empty;
        }

        /// <summary>
        /// Change status of lead
        /// </summary>
        /// <param name="leadId"></param>
        /// <param name="logId"></param>
        /// <param name="_service"></param>
        internal static void UpdateLeadStatus(Guid leadId, Guid logId, IOrganizationService _service)
        {
            try
            {
                var entity = new Entity("lead", leadId);
                entity["statecode"] = new OptionSetValue(0); //Status
                entity["statuscode"] = new OptionSetValue(1); //Status reason
                _service.Update(entity);

            }
            catch (FaultException<IOrganizationService> ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
            }
        }




        /// <summary>
        /// Update log in CRM
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="response"></param>
        /// <param name="errorMessage"></param>
        /// <param name="status"></param>
        /// <param name="_service"></param>
        internal static void UpdateLog(Guid logId, String response, String errorMessage, int status, IOrganizationService _service)
        {
            try
            {
                var entity = new Entity("ber_leadautomationlog");
                entity.Id = logId;
                if (!String.IsNullOrEmpty(response))
                {
                    entity.Attributes["ber_responsemessage"] = response;
                }
                if (!String.IsNullOrEmpty(errorMessage))
                {
                    entity.Attributes["ber_errormessage"] = errorMessage;
                }
                entity.Attributes["ber_status"] = new OptionSetValue(status);
                _service.Update(entity);
            }
            catch (FaultException<IOrganizationService> ex)
            {

            }
            catch (Exception ex)
            {

            }
        }

        /// <summary>
        /// Get Pincode Id and city Id by pincode
        /// </summary>
        /// <param name="pincode"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static Address GetIdByPincode(int? pincode, IOrganizationService _service)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "ber_pincode",
                    ColumnSet = new ColumnSet("ber_name", "ber_cityid"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                        new ConditionExpression ("ber_name", ConditionOperator.Equal, pincode.ToString())
                        }
                    }
                };



                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    return new Address
                    {
                        PinCodeId = ec.Entities[0].Id,
                        CityId = ec.Entities[0].GetAttributeValue<EntityReference>("ber_cityid").Id
                    };

                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to get pincode from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to get pincode from CRM" + ex.Message);
            }
            return null;
        }

        internal static AddressAndLeadInfo GetCityStateLeadDetailsByPincode(Guid CityId, IOrganizationService _service)
        {
            try
            {
                // ber_cityid                => lookup city
                // ber_stateid               => lookup state
                // ber_leadtype
                // ber_subleadtype
                // ber_ischargeable
                // ber_servicecost
                //------------------------------------------
                /*Lead Type (ber_leadtype)*/

                // BDM 278290000
                // Home Decor  278290001
                // XP  278290002
                // null
                //------------------------------------------
                /*Lead Type (ber_leadtype)*/

                //BDM 278290000
                //Home Decor  278290001
                //XP  278290002

                QueryExpression qe = new QueryExpression
                {
                    EntityName = "ber_city",
                    ColumnSet = new ColumnSet("ber_cityid", "ber_citytype", "ber_stateid", "ber_ischargeable", "ber_applicablecost", "ber_defaultdepotid"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression ("ber_cityid", ConditionOperator.Equal, CityId.ToString())
                        }
                    }
                };

                EntityCollection ec = _service.RetrieveMultiple(qe);
                if (ec.Entities.Count > 0)
                {
                    return new AddressAndLeadInfo
                    {
                        CityId = ec.Entities[0].Id,
                        StateId = ec.Entities[0].GetAttributeValue<EntityReference>("ber_stateid").Id,
                        isChargable = ((OptionSetValue)(ec.Entities[0].Attributes["ber_ischargeable"])).Value,
                        ServiceCost = ((Money)(ec.Entities[0].Attributes["ber_applicablecost"])).Value,
                        Tower = 1,
                        Building = 1,
                        DefaultDepotId = ec.Entities[0].GetAttributeValue<EntityReference>("ber_defaultdepotid").Id
                    };

                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to get pincode from CRM " + ex.Message);
            }
        catch (Exception ex)
            {
                throw new Exception("Error trying to get pincode from CRM" + ex.Message);
            }
            return null;
        }


        /// <summary>
        /// Retrieve CRM encryption key
        /// </summary>
        /// <param name="logId"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static String GetEncryptionKey(Guid logId, IOrganizationService _service)
        {
            try
            {
                RetrieveDataEncryptionKeyRequest retrieveDataEncryptionKeyRequest = new RetrieveDataEncryptionKeyRequest();
                RetrieveDataEncryptionKeyResponse retrieveDataEncryptionKeyResponse =
                (RetrieveDataEncryptionKeyResponse)_service.Execute(retrieveDataEncryptionKeyRequest);
                return retrieveDataEncryptionKeyResponse.EncryptionKey;
            }
            catch (Exception ex)
            {
                UpdateLog(logId, null, ex.Message, (int)Status.Success, _service);
                throw ex;
            }
        }
        /// <summary>
        /// Retrieve Lead by Id
        /// </summary>
        /// <param name="_service"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        internal static LeadStatus RetrieveLeadsById(IOrganizationService _service, Guid id)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "lead",
                    ColumnSet = new ColumnSet("subject", "fullname", "emailaddress1", "telephone1", "statuscode", "ber_pincodeid"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                        new ConditionExpression ("leadid", ConditionOperator.Equal, id)
                        }
                    }
                };
                EntityCollection ec = _service.RetrieveMultiple(qe);
                 



                if (ec.Entities.Count > 0)
                {
                    PinCodeRetval Pincode = null;
                    string _Pincode = string.Empty;
                    Guid pincodeGuid = !ec.Entities[0].Contains("ber_pincodeid") ? Guid.Empty : ec.Entities[0].GetAttributeValue<EntityReference>("ber_pincodeid").Id; 
                   

                    //((EntityReference)new System.Collections.Generic.Mscorlib_DictionaryValueCollectionDebugView<string, object>((ec.Entities[0]).Attributes.Values).Items[6]).Name
                    if (pincodeGuid != null)
                    {
                        Pincode = GetIdByPincodeByID(pincodeGuid, _service);
                    }                 
                    if (Pincode != null)
                    {
                        _Pincode = Pincode.Pin_Code.ToString();
                    }


                    return new LeadStatus
                    {
                        Id = ec.Entities[0].Attributes["subject"].ToString(),
                        Name = ec.Entities[0].Attributes["fullname"].ToString(),
                        Email = ec.Entities[0].Contains("emailaddress1") ? ec.Entities[0].Attributes["emailaddress1"].ToString() : null,
                        Telephone = ec.Entities[0].Contains("telephone1") ? Int64.Parse(ec.Entities[0].Attributes["telephone1"].ToString()) : default(Int64),
                        Status = ec.Entities[0].FormattedValues["statuscode"].ToString(),
                        PinCode = _Pincode
                    };
                }
                return null;
            }
            catch (FaultException<IOrganizationService> ex)
            {
                throw new Exception("Error trying to get lead data from CRM " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Error trying to get lead data from CRM " + ex.Message);
            }
        }
        /// <summary>
        /// GetIdByPincodeByID
        /// </summary>
        /// <param name="pincodeGuid"></param>
        /// <param name="_service"></param>
        /// <returns></returns>
        internal static PinCodeRetval GetIdByPincodeByID(Guid pincodeGuid, IOrganizationService _service)
        {
            try
            {
                QueryExpression qe1 = new QueryExpression
                {
                    EntityName = "ber_pincode",
                    ColumnSet = new ColumnSet("ber_pincodeid", "ber_name"),
                    NoLock = true,
                    Criteria = new FilterExpression
                    {
                        Conditions =
                        {
                        new ConditionExpression ("ber_pincodeid", ConditionOperator.Equal, pincodeGuid),
                        new ConditionExpression ("statecode", ConditionOperator.Equal, 0)
                        }
                    }
                };

                //entity.GetAttributeValue<bool>("new_boolean");

                EntityCollection ec1 = _service.RetrieveMultiple(qe1);
                if (ec1.Entities.Count > 0)
                {
                    return new PinCodeRetval
                    {
                        PinCodeGuiId = ec1.Entities[0].Id,
                        Pin_Code =    ec1.Entities[0].Attributes["ber_name"].ToString()
                    };

                }
            }
            catch (FaultException<IOrganizationService> ex)
            {
                //throw new Exception("Error trying to get pincode from CRM " + ex.Message);
                return null;
            }
            catch (Exception ex)
            {
                //throw new Exception("Error trying to get pincode from CRM" + ex.Message);
                return null;
            }
            return null;
        }
        /// <summary>
        /// Retrieve enum value dynamically
        /// </summary>
        /// <param name="enumConst"></param>
        /// <returns></returns>
        private static int GetValueOf(string enumConst)
        {
            Type enumType = Type.GetType("LeadAutomation.Models.Origin");
            if (enumType == null)
            {
                throw new ArgumentException("Specified enum type could not be found", "Origin");
            }

            object value = Enum.Parse(enumType, enumConst.ToLowerInvariant());
            return Convert.ToInt32(value);
        }

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["Domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
    }
}