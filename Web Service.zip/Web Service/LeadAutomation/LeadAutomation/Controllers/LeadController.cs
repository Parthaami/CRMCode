﻿using LeadAutomation.Helper;
using LeadAutomation.Models;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Reflection;

namespace LeadAutomation.Controllers
{/// <summary>
/// Lead controller defines all endpoints related with Lead
/// </summary>
    [RoutePrefix("lead")]
    public class LeadController : ApiController
    {
        private static IOrganizationService _service = Utility.ConnectToCRM();
        /// <summary>
        /// Create Lead
        /// </summary>
        /// <param name="leadinfo"></param>
        /// <returns></returns>
        [Route("import")]
        [HttpPost]
        public HttpResponseMessage Create([FromBody] Lead leadinfo)
        {
            var logId = Guid.Empty;
            try
            {
                if (ModelState.IsValid)
                {
                    string _ad_leadsourcemappings = null;
                    var json = JsonConvert.SerializeObject(leadinfo);
                    logId = Utility.CreateLog(json, MethodBase.GetCurrentMethod().Name, _service);
                    var createdList = new List<ResultSet>();
                    var authenticationHeader = Utility.GetEncryptionKey(logId,_service);
                    if (Utility.isValidRequest(authenticationHeader))
                    {
                        foreach (var item in leadinfo.LeadDetails)
                        {
                            var pinCode = Guid.Empty;
                            var cityId = Guid.Empty;

                            if (item.Pincode != null || item.Pincode != default(int))
                            {
                                var addressDetails =  Utility.GetIdByPincode(item.Pincode, _service);
                                pinCode = addressDetails!= null ? addressDetails.PinCodeId : Guid.Empty;
                                cityId = addressDetails != null ? addressDetails.CityId : Guid.Empty;
                            }

                            var lead = new Entity("lead");
                            lead.Attributes["firstname"] = item.FirstName;
                            lead.Attributes["lastname"] = item.LastName;
                            lead.Attributes["emailaddress1"] = !string.IsNullOrEmpty(item.Email) ? item.Email : null;
                            lead.Attributes["telephone1"] = item.Telephone.ToString();
                            lead.Attributes["mobilephone"] = item.AlternateContactNo != null ? item.AlternateContactNo.ToString() : null;
                            lead.Attributes["address1_line1"] = !string.IsNullOrEmpty(item.StreetAddress) ? item.StreetAddress : null;
                            lead.Attributes["ber_pincodeid"] = pinCode != default(Guid) ? new EntityReference("ber_pincode", pinCode) : null;
                            lead.Attributes["entityimage"] = item.Image != null ? item.Image : null;
                            lead.Attributes["description"] = !string.IsNullOrEmpty(item.Query) ? item.Query : null;
                            lead.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", Utility.RetrieveDefaultCurrency(_service));


                            // Code added by Dhiman on 10-Jan-2020
                            bool BoolCCother = false;
                            bool.TryParse(item.homeshield, out BoolCCother);
                            if (BoolCCother != true && BoolCCother != false)
                            {
                                BoolCCother = false;
                            }
                            lead.Attributes["ber_ccother"] = BoolCCother;

                            lead.Attributes["ber_leadconversionrequired"] = new OptionSetValue(3); // 

                            // Code Added on 16-July-2019 
                            if (!string.IsNullOrEmpty(item.campaignid))
                                lead.Attributes["ber_campaignid"] = item.campaignid;
                            if (!string.IsNullOrEmpty(item.campaignname))
                                lead.Attributes["ber_campaignname"] = item.campaignname;
                            if (!string.IsNullOrEmpty(item.campaignlocation))
                                lead.Attributes["ber_campaignlocation"] = item.campaignlocation;


                            if (!string.IsNullOrEmpty(item.Source))
                            {
                                var source = Utility.RetrieveSourceFromMapping(leadinfo.Origin,item.Source, _service);
                                if (source != null)
                                {
                                    lead.Attributes["leadsourcecode"] = source.LeadSource != default(int) ? new OptionSetValue(source.LeadSource) : null;
                                    lead.Attributes["ber_callinfo"] = source.CallInfo != default(int) ? new OptionSetValue(source.CallInfo) : null;

                                    // if lead.Attributes["leadsourcecode"] not null then set value coming from table ber_ad_leadsourcemappings w
                                    string _LeadSource = Convert.ToString(source.LeadSource);
                                    if (!String.IsNullOrEmpty(_LeadSource))
                                    {
                                        _ad_leadsourcemappings = Utility.RetrieveLeadsourceAD(_LeadSource, _service);
                                        if(!String.IsNullOrEmpty(_LeadSource))
                                        {
                                            lead.Attributes["ber_lockedforad"] = _ad_leadsourcemappings;
                                        }
                                    }
                                }
                            }


                            //Salutation		                option set	
                            //Lead Conversion Required		option set
                            //Interior		                chk
                            //Exterior		                chk
                            //Painting Type		            option set
                            //Lead (Oppurtunity)	            option set
                            //No. Of Towers		            string
                            //No Of Stories		            string
                            //Rating		                    option set

                            /*
                                  /// <summary>
                                  /// salutation
                                  /// </summary>
                                  public string salutation { get; set; }
                                  /// <summary>
                                  /// leadconversionrequired
                                  /// </summary>
                                  public string leadconversionrequired { get; set; }
                                  /// <summary>
                                  /// interior
                                  /// </summary>
                                  public string interior { get; set; }
                                  /// <summary>
                                  /// exterior
                                  /// </summary>
                                  public string exterior { get; set; }
                                  /// <summary>
                                  /// addresstypecode
                                  /// </summary>
                                  public string addresstypecode { get; set; }
                                  /// <summary>
                                  /// qualitycode
                                  /// </summary>
                                  public string qualitycode { get; set; }
                                  /// <summary>
                                  /// industrycode
                                  /// </summary>
                                  public string industrycode { get; set; }
                                  /// <summary>
                                  /// numberoftowers
                                  /// </summary>
                                  public string numberoftowers { get; set; }
                                  /// <summary>
                                  /// noofstories
                                  /// </summary>
                                  public string noofstories { get; set; }

                          */

                            // Code Added on 11-May-2020 
                            if (!string.IsNullOrEmpty(item.salutation))
                                lead.Attributes["ber_salutation"] = new OptionSetValue(Convert.ToInt32(item.salutation));
                            if (!string.IsNullOrEmpty(item.LeadConversionRequired))
                                lead.Attributes["ber_leadconversionrequired"] = new OptionSetValue(Convert.ToInt32(item.LeadConversionRequired));
                           // if (item.interior !=null)
                                lead.Attributes["ber_interior"] = item.Interior;
                            //if (!string.IsNullOrEmpty(item.exterior))
                                lead.Attributes["ber_exterior"] = item.Exterior;
                            if (!string.IsNullOrEmpty(item.PaintingType))
                                lead.Attributes["address2_addresstypecode"] = new OptionSetValue(Convert.ToInt32(item.PaintingType));
                            if (!string.IsNullOrEmpty(item.Rating))
                                lead.Attributes["leadqualitycode"] = new OptionSetValue(Convert.ToInt32(item.Rating));
                            if (!string.IsNullOrEmpty(item.LeadOppurtunity))
                                lead.Attributes["industrycode"] = new OptionSetValue(Convert.ToInt32(item.LeadOppurtunity));
                            if (!string.IsNullOrEmpty(item.NumberofTowers))
                                lead.Attributes["ber_numberoftowers"] = Convert.ToInt32(item.NumberofTowers);
                            if (!string.IsNullOrEmpty(item.NumberofStories))
                                lead.Attributes["ber_noofstories"] = Convert.ToInt32(item.NumberofStories);
                            if (!string.IsNullOrEmpty(item.CarpetArea))
                                lead.Attributes["ber_carpetarea"] = Convert.ToDecimal(item.CarpetArea);

                            if (!string.IsNullOrEmpty(item.NumberOfrRooms))
                                lead.Attributes["ber_noofrooms"] = Convert.ToInt32(item.NumberOfrRooms);


                            //NumberOfrRooms

                            //add 2 field 


                            //ber_carpetarea // ber_noofrooms


                            var leadId = _service.Create(lead);

                            if (leadId != Guid.Empty)
                            {
                                if (cityId != default(Guid))
                                {
                                    Utility.UpdateLeadStatus(leadId, logId, _service);
                                    Utility.AssignLead(leadId, logId, _service, cityId);

                                    // Add method for Getlogic 
                                    AddressAndLeadInfo _CityStateLeadDetailsByPincode = Utility.GetCityStateLeadDetailsByPincode(cityId , _service);
                                    // Add method for updated logic 
                                    Utility.UpdateLeadServiceCost(leadId, logId, BoolCCother, _ad_leadsourcemappings, _CityStateLeadDetailsByPincode, _service);
                                    // Updated workflow
                                    //Utility.CallSmsWorkflow(leadId, logId, _service);

                                }
                                else
                                {
                                    Utility.AssignLead(leadId, logId, _service, null);
                                }
                                var resultSet = new ResultSet()
                                {
                                    Id = leadId,
                                    Telephone = item.Telephone
                                };
                                createdList.Add(resultSet);
                            }
                        }
                        var leadDetails = new LeadResponse()
                        {
                            Status = "OK",
                            ResultSet = createdList
                        };
                        if (logId !=Guid.Empty)
                        {
                            var response = JsonConvert.SerializeObject(leadDetails);
                            Utility.UpdateLog(logId, response, null, (int)Status.Success, _service);
                        }
                        return Request.CreateResponse(HttpStatusCode.OK, leadDetails);
                    }
                    else
                    {
                        if (logId != Guid.Empty)
                        {
                            Utility.UpdateLog(logId, null, HttpStatusCode.Unauthorized.ToString(), (int)Status.Failure, _service);
                        }
                        return Request.CreateErrorResponse(HttpStatusCode.Unauthorized, "You are unauthorized to access the service.");
                    }
                }
                else
                {
                    if (logId != Guid.Empty)
                    {
                        Utility.UpdateLog(logId, null, HttpStatusCode.BadRequest.ToString(), (int)Status.Failure, _service);
                    }
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Request is invalid");
                }
            }
            catch (Exception ex)
            {
                Utility.UpdateLog(logId, null, ex.Message, (int)Status.Failure, _service);
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Unable to create Lead, try again later!");
            }
        }
        /// <summary>
        /// Get all leads by Id
        /// </summary>
        /// <param name="leadDetails"></param>
        /// <returns></returns>
        [Route("info")]
        [HttpPost]
        public HttpResponseMessage RetrieveLeadsById([FromBody] LeadRequest leadDetails)
        {
            var logId = Guid.Empty;
            try
            {
                if (ModelState.IsValid)
                {
                    var json = JsonConvert.SerializeObject(leadDetails);
                    logId = Utility.CreateLog(json, MethodBase.GetCurrentMethod().Name, _service);
                    var authenticationHeader = Utility.GetEncryptionKey(logId,_service);
                    if (Utility.isValidRequest(authenticationHeader))
                    {
                        var leadinfo = new List<LeadStatus>();
                        foreach (var item in leadDetails.LeadDetails)
                        {
                            var leadResponse = Utility.RetrieveLeadsById(_service, item.Id);
                            if(leadResponse!= null)
                            {
                                leadinfo.Add(leadResponse);
                            }
                        }
                        if (logId != Guid.Empty)
                        {
                            var response = JsonConvert.SerializeObject(leadinfo);
                            Utility.UpdateLog(logId, response, null, (int)Status.Success, _service);
                        }
                        return Request.CreateResponse(HttpStatusCode.OK, JsonConvert.SerializeObject(leadinfo, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore }));
                    }
                    else
                    {
                        if (logId != Guid.Empty)
                        {
                            Utility.UpdateLog(logId, null, HttpStatusCode.Unauthorized.ToString(), (int)Status.Failure, _service);
                        }
                        return Request.CreateErrorResponse(HttpStatusCode.Unauthorized, "You are unauthorized to access the service.");
                    }

                }
                else
                {
                    if (logId != Guid.Empty)
                    {
                        Utility.UpdateLog(logId, null, HttpStatusCode.BadRequest.ToString(), (int)Status.Failure, _service);
                    }
                    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Request is invalid");
                }
            }
            catch (Exception ex)
            {
                if (logId != Guid.Empty)
                {
                    Utility.UpdateLog(logId, null, ex.Message, (int)Status.Failure, _service);
                }
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Unable to fetch Lead, try again later!");
            }
        }
    }
}
