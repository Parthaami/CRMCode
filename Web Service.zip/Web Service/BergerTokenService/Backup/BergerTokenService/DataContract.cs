﻿using System;
using System.Runtime.Serialization;

namespace BergerTokenService
{
    public class DataContract
    {       

        [DataContract]
        public class Authenticate
        {
            [DataMember(IsRequired = true)]
            public Guid UserID
            {
                get;
                set;
            }

            [DataMember(IsRequired = true)]
            public Boolean IsAuthenticated
            {
                get;
                set;
            }
        }

    }
}
