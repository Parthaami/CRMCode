﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace BergerTokenService
{
    [ServiceContract]    
    public interface IBergerTokenService
    {
        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
            UriTemplate ="/AuthenticateUser")]       
        DataContract.Authenticate AuthenticateUser();

        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "/CreateTokenRedemtion/?Mobile={Mobile}&TokenNumber={TokenNumber}&Source={Source}")]
        String CreateTokenRedemtion(string Mobile, string TokenNumber, string Source);        
 

        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "/CreateTokenMaster/?SrlNo={SrlNo}&TokenType={TokenType}&Product={Product}&PackSize={PackSize}&Denomination={Denomination}&TokenMonth={TokenMonth}&TokenYear={TokenYear}&TokenKeyNo={TokenKeyNo}&ExpireDate={ExpireDate}")]
        String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate);
             
      
        
    }
}
