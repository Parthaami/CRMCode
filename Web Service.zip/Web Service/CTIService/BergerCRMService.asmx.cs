﻿using System;
using System.Web.Services;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace CTIWebService
{
    public struct ServiceResponse
    {
        public string NumberExist;
        public string LanguagePreference1;
        public string LanguagePreference2;
        public string Region;
        public string URL;
    }
    /// <summary>
    /// Summary description for Service1
    /// </summary>    
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]

    [WebService(Namespace = "http://bergerindia.org/")]
    public class BergerCRMService : System.Web.Services.WebService
    {
        Logger oLogger;
        public static string _loggerPath = string.Empty;
        public static Configuration config;
        public static string _orgName = ConfigurationManager.AppSettings["Organization"];
        public static string _dbConnectionString = ConfigurationManager.ConnectionStrings["SQLDBConnectionString"].ConnectionString;
        public static int LogLevel = Convert.ToInt32(ConfigurationManager.AppSettings["LogLevel"]);        
        ServiceResponse SP;
       
        public BergerCRMService()
        {            
            try
            {
                #region Read Registry Key & get Pragmasys.config Path
                /*
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }
                */
                #endregion

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                ///
                 
                //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _orgName + "\\Pragmasys.config";
                

                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_orgName, _loggerPath);
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("CTIWebService", "BergerCRMService", ex.Message, ex.StackTrace.ToString());
            }
        }  

        [WebMethod]
        public ServiceResponse GetUrl(string ContactNo)
        {
            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "GetURL", "GetUrl Method START", "Original Phone No.  : " + ContactNo);


            ContactNo = ContactNo.Substring(Math.Max(0,ContactNo.Length - 10));
            
            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "GetURL", "GetUrl Method START", "Last 10 No's of Original Phone No. : " + ContactNo);

            

            SP = new ServiceResponse();
            SP.NumberExist = "";
            SP.LanguagePreference1 = "";
            SP.LanguagePreference2 = "";
            SP.Region = "";
            SP.URL = "";
            try
            {
                decimal PhNumber = Convert.ToDecimal(ContactNo);

                string query1 = "select 'Y' as Ex,A.accountnumber as dcode,R.ber_name as region,L1.ber_languagecode as L1,L2.ber_languagecode as L2 " +
                                "from account as A " +
                                "left outer join ber_language as L1 on A.ber_preferredlanguage1 = L1.ber_languageid " +
                                "left outer join ber_language as L2 on A.ber_preferredlanguage2 = L2.ber_languageid " +
                                "left outer join ber_region as R on A.ber_region = r.ber_regionid " +
                                "where (telephone1 = '" + ContactNo + "' OR telephone2= '" + ContactNo + "' OR telephone3='" + ContactNo + "' OR address1_telephone1 ='" + ContactNo + "') " +
                                "and parentaccountid is null " +
                                "and A.statecode = 0 ";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetURL", "Dealer Query :", query1);

                DataTable CustomerDetails = FetchData(query1);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetURL", "No. of Dealers Found:", CustomerDetails.Rows.Count.ToString());


                #region Check the Accounts are present for this Phone Number or not
                if (CustomerDetails.Rows.Count > 0)
                {
                    SP.NumberExist = "Y";

                    #region Logic change as per Ticket - A0601 on 24-May-2013
                    //if (CustomerDetails.Rows.Count == 1)
                    //{
                    //    SP.LanguagePreference1 = CustomerDetails.Rows[0].ItemArray[3].ToString();
                    //    SP.LanguagePreference2 = CustomerDetails.Rows[0].ItemArray[4].ToString();
                    //    SP.Region = CustomerDetails.Rows[0].ItemArray[2].ToString();
                    //    SP.URL = "Ex=Y&Type=D&dCode=" + CustomerDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;

                    //    if (LogLevel >= 2)
                    //        oLogger.Log("CTIWebService", "GetURL", "URL:", SP.URL.ToString());

                    //}
                    //else
                    //{
                    //    SP.LanguagePreference1 = "";
                    //    SP.LanguagePreference2 = "";
                    //    SP.Region = "";
                    //    SP.URL = "Ex=Y&Type=D&PhNum=" + ContactNo;

                    //    if (LogLevel >= 2)
                    //        oLogger.Log("CTIWebService", "GetURL", "URL:", SP.URL.ToString());
                    //}
                    #endregion

                    int rowCount = 0;
                    string lang1 = "";
                    string lang2 = "";

                    for (rowCount = 0; rowCount < CustomerDetails.Rows.Count; rowCount++)
                    {
                        lang1 = CustomerDetails.Rows[rowCount].ItemArray[3].ToString();
                        lang2 = CustomerDetails.Rows[rowCount].ItemArray[4].ToString();


                        if (lang1.Length>0 || lang2.Length>0)
                        {                            
                            SP.LanguagePreference1 = lang1;
                            SP.LanguagePreference2 = lang2;
                            SP.Region = CustomerDetails.Rows[rowCount].ItemArray[2].ToString();
                            SP.URL = "Ex=Y&Type=D&dCode=" + CustomerDetails.Rows[rowCount].ItemArray[1].ToString() + "&PhNum=" + ContactNo;

                            if (LogLevel >= 2)
                                oLogger.Log("CTIWebService", "GetURL", "URL:", SP.URL.ToString());

                            break;
                        }
                    }

                    if (lang1.Length == 0 && lang2.Length == 0)
                    {
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=Y&Type=D&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetURL", "URL:", SP.URL.ToString());
                    }
                }
                #endregion
                
                else
                {
                    if (LogLevel >= 2)
                        oLogger.Log("CTIWebService", "GetURL", "Dealers Not Found with specified Phone no.", ContactNo.ToString());
                    //Get Details of TSI
                    GetTSIDetails(ContactNo);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Dealer Details", "RetriveDealerData. Contact No:- " + ContactNo, ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "GetURL", "GetUrl Method END", "Phone No. : " + ContactNo);

            return SP;
        }

        #region Function to search TSI details using Contact no
        public void GetTSIDetails(string ContactNo)
        {
            try
            {
                string query2 = "select 'Y' as Ex,T.ber_tsiid as Tsi,R.ber_name as Region,L1.ber_languagecode as L1,L2.ber_languagecode as L2 " +
                "from ber_tsi as T " +
                "left outer join ber_language as L1 on T.ber_preferredlanguage1 = L1.ber_languageid " +
                "left outer join ber_language as L2 on T.ber_preferredlanguage2 = L2.ber_languageid " +
                "inner join ber_depot as D on T.ber_depotid = D.ber_depotid " +
                "inner join ber_region as R on D.ber_region = R.ber_regionid " +
                "where (T.ber_mobilenumber = '" + ContactNo + "'  or T.ber_Telephone2 = '" + ContactNo + "') and T.statecode = 0";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetTSIDetails", "TSI Query :", query2);                        

                DataTable TSIDetails = FetchData(query2);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetTSIDetails", "No. Of TSI Found for Specified Phone No. :", TSIDetails.Rows.Count.ToString());


                if (TSIDetails.Rows.Count > 0)
                {
                    if (TSIDetails.Rows.Count == 1)
                    {
                        SP.NumberExist = "Y";
                        SP.LanguagePreference1 = TSIDetails.Rows[0].ItemArray[3].ToString();
                        SP.LanguagePreference2 = TSIDetails.Rows[0].ItemArray[4].ToString();
                        SP.Region = TSIDetails.Rows[0].ItemArray[2].ToString();
                        SP.URL = "Ex=Y&Type=T&Tsi=" + TSIDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetTSIDetails", "TSI URL :", SP.URL.ToString());
                    }
                    else
                    {
                        SP.NumberExist = "N";
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=N&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetTSIDetails", "More than 1 TSI fount.", "TSI URL :" + SP.URL.ToString());

                    }
                }
                else
                {
                    GetContactDetails(ContactNo);
                }                
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving TSI Details", "GetTSIDetails", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
        #endregion  

        #region Function to search Painter/DG/BDO details using Contact no
        public void GetContactDetails(string ContactNo)
        {
            try
            {
                string query2 = "select 'Y' as Ex, Cust.contactid  as Conid,R.ber_name as Region,L1.ber_languagecode as L1,L2.ber_languagecode as L2," +
                                "Cust.ber_CustomerType , Cust.ber_parentpainter " +  //changes as per subPainter requirement on 4/12/2016
                                "from Contact as Cust " +
                                "left outer join ber_region as R on Cust.ber_regionid = R.ber_regionid " +
                                "left outer join ber_language as L1 on Cust.ber_preferredlanguage1 = L1.ber_languageid " +
                                "left outer join ber_language as L2 on Cust.ber_preferredlanguage2 = L2.ber_languageid " +
                                //"where (Cust.telephone1='" + ContactNo + "' OR Cust.mobilephone='" + ContactNo + "') and Cust.statecode = 0 " + // Remove telephone 1 condition based on discussion 
                                 "where (Cust.mobilephone='" + ContactNo + "') and Cust.statecode = 0 " +
                                "and Cust.ber_CustomerType in ('278290001','278290005','278290008')";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetContactDetails", "Contact Query :", query2);

                DataTable PainterDetails = FetchData(query2);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetContactDetails", "No. Of Contacts Found for Specified Phone No. :", PainterDetails.Rows.Count.ToString());

                if (PainterDetails.Rows.Count > 0)
                {
                    if (PainterDetails.Rows.Count == 1)
                    {
                        SP.NumberExist = "Y";
                        SP.LanguagePreference1 = PainterDetails.Rows[0].ItemArray[3].ToString();
                        SP.LanguagePreference2 = PainterDetails.Rows[0].ItemArray[4].ToString();
                        SP.Region = PainterDetails.Rows[0].ItemArray[2].ToString();

                        string CustType = string.Empty;
                        if (Convert.ToInt32(PainterDetails.Rows[0].ItemArray[5].ToString()) == 278290001)//Painter
                            CustType = "P";
                        else if (Convert.ToInt32(PainterDetails.Rows[0].ItemArray[5].ToString()) == 278290005)//DG
                            CustType = "DG";
                        else if (Convert.ToInt32(PainterDetails.Rows[0].ItemArray[5].ToString()) == 278290008)//BDO
                            CustType = "BDO";

                        if (!string.IsNullOrEmpty(PainterDetails.Rows[0]["ber_parentpainter"].ToString()))    //changes as per subPainter requirement on 4/12/2016
                        {
                            SP.URL = "Ex=Y&Type=" + CustType + "&Conid=" + PainterDetails.Rows[0]["ber_parentpainter"].ToString() + "&PhNum=" + ContactNo;
                        }
                        else
                        {
                            SP.URL = "Ex=Y&Type=" + CustType + "&Conid=" + PainterDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo; 
                        }

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetContactDetails", "Contact URL :", SP.URL.ToString());
                    }
                    else
                    {
                        SP.NumberExist = "N";
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=N&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetContactDetails", "More than 1 Contact fount.", "Contact URL :" + SP.URL.ToString());

                    }
                }
                else
                {
                    GetRSCUser(ContactNo);
                }                
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Contact Details.", "GetContactDetails", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
        #endregion  

        #region Function to search RSC User details using Contact no.
        public void GetRSCUser(string ContactNo)
        {
            try
            {
                string query3 = "select 'Y' as Ex,U.SystemUserId,L1.ber_LanguageCode,U.PreferredAddressCode " +
                                "from SystemUser as U " +
                                "left outer join ber_language as L1 on U.ber_PrimaryLanguage = L1.ber_languageid " +
                                "where (U.MobilePhone ='" + ContactNo +"' OR U.HomePhone='"+ ContactNo +"') " +
                                //"OR U.Address1_Telephone1='"+ ContactNo +"' OR U.Address1_Telephone2='"+ ContactNo +"')" + 
                                "and U.PreferredAddressCode in ('278290003','100000000') and U.IsDisabled = '0'";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetRSCUser", "RSC Query :", query3);

                DataTable RSCDetails = FetchData(query3);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetRSCUser", "No. Of RSC Users Found for Specified Phone No. :", RSCDetails.Rows.Count.ToString());

                if (RSCDetails.Rows.Count > 0)
                {
                    if (RSCDetails.Rows.Count == 1)
                    {
                        SP.NumberExist = "Y";
                        SP.LanguagePreference1 = RSCDetails.Rows[0].ItemArray[2].ToString();
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        if (Convert.ToInt32(RSCDetails.Rows[0].ItemArray[3].ToString()) == 278290003)//RSC
                            SP.URL = "Ex=Y&Type=RSC&RSCid=" + RSCDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;
                        else if (Convert.ToInt32(RSCDetails.Rows[0].ItemArray[3].ToString()) == 100000000)//BDM
                            SP.URL = "Ex=Y&Type=BDM&Conid=" + RSCDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;


                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "ToString", "RSC URL :", SP.URL.ToString());
                    }
                    else
                    {
                        SP.NumberExist = "N";
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=N&PhNum = " + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetRSCUser", "More than 1 RSC User fount.", "RSC URL :" + SP.URL.ToString());

                    }
                }
                else
                {
                    GetDepotDetails(ContactNo);
                }                
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving RSC User Details", "GetRSCUser", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }

        }
        #endregion

        #region Function to get Depot Details using contact number
        public void GetDepotDetails(string ContactNo)
        {
            try
            {
                string query3 = "select 'Y' as Ex,D.ber_depotid as DepotId,r.ber_name as Region,l1.ber_languagecode as l1, l2.ber_languagecode as l2 " +
                "from ber_depot D " +
                "left outer join ber_language as L1 on D.ber_PreferredLanguage1 = L1.ber_languageid " +
                "left outer join ber_language as L2 on D.ber_preferredlanguage2 = L2.ber_languageid " +
                "left outer join ber_region as R on D.ber_region = r.ber_regionid " +
                "where (d.ber_DMMobilePhone = '" + ContactNo + "' or d.ber_ContactNumbers = '" + ContactNo + "' or d.ber_Telephone1 = '" + ContactNo + "' or d.ber_Telephone2 = '" + ContactNo + "' or d.ber_Telephone3 = '" + ContactNo + "'or d.ber_AdminPhoneNumber = '" + ContactNo + "') " +
                "and d.statecode = 0";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetDepotDetails", "Depot Query :", query3);

                DataTable DepotDetails = FetchData(query3);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetDepotDetails", "No. Of Depot Found for Specified Phone No. :", DepotDetails.Rows.Count.ToString());

                if (DepotDetails.Rows.Count > 0)
                {
                    if (DepotDetails.Rows.Count == 1)
                    {
                        SP.NumberExist = "Y";
                        SP.LanguagePreference1 = DepotDetails.Rows[0].ItemArray[3].ToString();
                        SP.LanguagePreference2 = DepotDetails.Rows[0].ItemArray[4].ToString();
                        SP.Region = DepotDetails.Rows[0].ItemArray[2].ToString();
                        SP.URL = "Ex=Y&Type=B&Depot=" + DepotDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetDepotDetails", "Depot URL :", SP.URL.ToString());
                    }
                    else
                    {
                        SP.NumberExist = "N";
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=N&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetDepotDetails", "More than 1 Depot fount.", "Depot URL :" + SP.URL.ToString());

                    }
                }
                else
                {
                    GetRegionDetails(ContactNo);
                }                
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Depot Details", "GetDepotDetails", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
        #endregion

        #region Function to get Region Details on specified contactno.
        public void GetRegionDetails(string ContactNo)
        {
            try
            {
                string query4 = "select 'Y' as Ex,r.ber_regionid,r.ber_name as Region,l1.ber_languagecode as l1, l2.ber_languagecode as l2 " +
                "from ber_region r " +
                "left outer join ber_language as L1 on r.ber_PreferredLanguage1 = L1.ber_languageid " +
                "left outer join ber_language as L2 on r.ber_preferredlanguage2 = L2.ber_languageid " +
                "where (r.ber_RSMMobile = '" + ContactNo + "' or r.ber_RSMPhone = '" + ContactNo + "') " +
                "and r.statecode = 0";

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetRegionDetails", "Region Query :", query4);

                DataTable RegionDetails = FetchData(query4);

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "GetRegionDetails", "No. Of Region Found for Specified Phone No. :", RegionDetails.Rows.Count.ToString());

                if (RegionDetails.Rows.Count > 0)
                {
                    if (RegionDetails.Rows.Count == 1)
                    {
                        SP.NumberExist = "Y";
                        SP.LanguagePreference1 = RegionDetails.Rows[0].ItemArray[3].ToString();
                        SP.LanguagePreference2 = RegionDetails.Rows[0].ItemArray[4].ToString();
                        SP.Region = RegionDetails.Rows[0].ItemArray[2].ToString();
                        SP.URL = "Ex=Y&Type=R&Region=" + RegionDetails.Rows[0].ItemArray[1].ToString() + "&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "GetRegionDetails", "Region URL :", SP.URL.ToString());
                    }
                    else
                    {
                        SP.NumberExist = "N";
                        SP.LanguagePreference1 = "";
                        SP.LanguagePreference2 = "";
                        SP.Region = "";
                        SP.URL = "Ex=N&PhNum=" + ContactNo;

                        if (LogLevel >= 2)
                            oLogger.Log("CTIWebService", "RegionDetails", "More than 1 Region fount.", "Region URL :" + SP.URL.ToString());

                    }
                }
                else
                {
                    SP.NumberExist = "N";
                    SP.LanguagePreference1 = "";
                    SP.LanguagePreference2 = "";
                    SP.Region = "";
                    SP.URL = "Ex=N&PhNum=" + ContactNo;

                    if (LogLevel >= 2)
                        oLogger.Log("CTIWebService", "RegionDetails", "No Region fount.", "Region URL :" + SP.URL.ToString());
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Region Details", "GetRegionDetails", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
        #endregion

        #region Function to Fetch Data from SQL DB
        public DataTable FetchData(string Query)
        {
            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "FetchData", "FetchData START", Query);

            DataTable DT = new DataTable();
            SqlConnection connection = new SqlConnection(_dbConnectionString);

            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "FetchData", "SQL connection String:", _dbConnectionString);

            try
            {
                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "FetchData", "Open Connection", "Opening...");

                connection.Open();

                if (LogLevel >= 2)
                    oLogger.Log("CTIWebService", "FetchData", "Open Connection", "Opened successfuly.");

                SqlCommand command = new SqlCommand(Query, connection);
                command.CommandType = CommandType.Text;
                SqlDataReader reader = command.ExecuteReader();
                DT.Load(reader);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving data from SQL", "FetchData", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            if (LogLevel >= 2)
                oLogger.Log("CTIWebService", "FetchData", "FetchData END", "");

            return DT;
        }
        #endregion
    }
}