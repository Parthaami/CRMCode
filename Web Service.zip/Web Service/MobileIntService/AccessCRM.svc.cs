﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Crm.Sdk.Messages;

namespace Mobile_IntService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "AccessCRM" in code, svc and config file together.
    public class AccessCRM : IAccessCRM
    {
        public static Logger oLogger;
        public static string _organizationName = string.Empty;
        public static string _loggerPath = string.Empty;
        public static string _dbConnectionString = ConfigurationManager.ConnectionStrings["SQLDBConnectionString"].ConnectionString;
      
        
        private static IOrganizationService  Orgservice = null;

        public AccessCRM()
        {
            Orgservice = GetOrganizationService();
        }


        private static IOrganizationService GetOrganizationService()
        {
            IServiceManagement<IOrganizationService> orgServiceManagement =
                     ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                     new Uri(ConfigurationManager.AppSettings["OrgService"].ToString()));

            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["Username"].ToString();
            authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["Password"].ToString();

            OrganizationServiceProxy OrgserviceProxy = GetProxy<IOrganizationService, 
                                                       OrganizationServiceProxy>(orgServiceManagement, authCredentials);
            OrgserviceProxy.EnableProxyTypes();

            return (IOrganizationService)OrgserviceProxy;
        }


        private void GetConfigurationData()
        {
            try
            {
                _organizationName = ConfigurationManager.AppSettings["OrgName"].ToString();
                _loggerPath = ConfigurationManager.AppSettings["loggerpath"].ToString();

                oLogger = new Logger(_organizationName, _loggerPath);

            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetConfigurationData", "Exception: " + ex.ToString(), "Problem while fetching ConfigData");

            }
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        private decimal ReduceCurrencyFromValue(string strTotalJobValue)
        {
            decimal numericTotalJobValue = 0;
            if (strTotalJobValue.Trim() != "")
            {
                decimal.TryParse(strTotalJobValue, out numericTotalJobValue);
                if (numericTotalJobValue == 0)
                {
                    try
                    {
                        string CurrencyString = "" + Regex.Replace(strTotalJobValue, @"\d+.", "");
                        string ComaSeperatedValue = "";
                        string FilteredValue = "";
                        if (CurrencyString.Trim() != "")
                        {
                            ComaSeperatedValue = "" + strTotalJobValue.Replace(CurrencyString, "");
                        }
                        if (ComaSeperatedValue.Trim() != "")
                        {
                            FilteredValue = "" + Regex.Replace(ComaSeperatedValue, @"[^\d+.]", "");
                        }
                        decimal.TryParse(FilteredValue, out numericTotalJobValue);
                    }
                    catch (Exception) { }
                }
            }
            return numericTotalJobValue;
        }

        #region GetPainterDetails
        public List<PainterDetails> GetPainterDetails(string Mno)
        {
            GetConfigurationData();

            List<PainterDetails> p = new List<PainterDetails>();
            try
            {
                string FXml =
                 @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                <entity name='contact'>
                <attribute name='fullname' />
                <attribute name='contactid' />
                <attribute name='pager' />
                <attribute name='ber_epstatus'/>
                <order attribute='fullname' descending='false' />
                <filter type='and'>
                <condition attribute='ber_customertype' operator='eq' value='278290001' />
                <condition attribute='mobilephone' operator='eq' value='" + Mno + @"' />
                <condition attribute='statecode' value='0' operator='eq'/>
                <condition attribute='ber_epstatus' operator='in'> 
                    <value>278290003</value> 
                    <value>278290000</value> 
                    <value>278290001</value>
                    <value>278290002</value>
                </condition>
                </filter>
                </entity>
                </fetch>";

                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(FXml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                PainterDetails[] pDetails = new PainterDetails[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        pDetails[i] = new PainterDetails();
                        if (c.Contains("fullname"))
                            pDetails[i].FullName = c.Attributes["fullname"].ToString();
                        if (c.Contains("contactid"))
                            pDetails[i].PainterGuid = c.Attributes["contactid"].ToString();
                        if (c.Contains("pager"))
                            pDetails[i].CustomerId = c.Attributes["pager"].ToString();
                        if (c.Contains("ber_epstatus"))
                            pDetails[i].EpStatus = c.FormattedValues["ber_epstatus"].ToString(); // added by soumen 15-07-2016
                        i++;
                    }

                    p = pDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "GetPainterDetails", "No Record Found for " + Mno + " from CRM", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetPainterDetails", "Exception: " + ex.ToString(), "Problem while fetching Painter Details for " + Mno + " from CRM");
            }
            return p;

        }
        #endregion

        #region GetTotalAccumulatedPoints
        public string GetTotalAccumulatedPoints(string MobileNo, string LWCode)
        {

            GetConfigurationData();
            string TAPoints = string.Empty;
            string fxml = string.Empty;
            try
            {
                fxml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='ber_paintermeetcontact'>
                            <attribute name='ber_paintermeetcontactid' />
                            <attribute name='ber_totalpoint' />
                            <order attribute='ber_paintermeet' descending='false' />
                            <link-entity name='contact' from='contactid' to='ber_contact' alias='ad'>
                              <filter type='and'>
                                <condition attribute='mobilephone' operator='eq' value='" + MobileNo + @"' />
                              </filter>
                            </link-entity>
                            <link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_paintermeet' alias='ae'>
                              <link-entity name='ber_meet' from='ber_meetid' to='ber_meet' alias='af'>
                                <filter type='and'>
                                  <condition attribute='ber_meetnumber' operator='eq' value='" + LWCode + @"' />
                                </filter>
                              </link-entity>
                            </link-entity>
                          </entity>
                        </fetch>";


                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(fxml));
                if (result.Entities.Count > 0 && result[0].Contains("ber_totalpoint"))
                {

                    TAPoints = Convert.ToString(result[0].Attributes["ber_totalpoint"]);

                }
                else
                {
                    TAPoints = "0";
                    oLogger.Log("MobileIntService", "GetTotalAccumulatedPoints", "No Record Found for " + MobileNo + " and " + LWCode + " from CRM", "No Record Found");

                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetTotalAccumulatedPoints", "Exception: " + ex.ToString(), "Problem while fetching TotalAccumulatedPoints for " + MobileNo + " and " + LWCode + " from CRM");

            }
            return TAPoints;
        }
        #endregion

        #region GetLeadSummaryData
        public List<LeadSummaryData> GetLeadSummaryData(string Mno)
        {

            GetConfigurationData();
            List<LeadSummaryData> LeadSumData = new List<LeadSummaryData>();

            try
            {
                string fxml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lead'>
                                <attribute name='telephone1' />
                                <attribute name='subject' />
                                <attribute name='ber_leadtype' />
                                <attribute name='lastname' />
                                <attribute name='firstname' />
                                <attribute name='ber_salutation' />
                                <attribute name='statuscode' />
                                <attribute name='createdon' /> 
                                <attribute name='ber_depotid'/> 
                                 <attribute name='ber_dealerid'/> 
                                <attribute name='ber_paintermobilenumber'/> 
                                  <attribute name='ber_painterallocationdate'/>
                                 <attribute name='ber_masterpainterid'/>
                                <order attribute='leadid' descending='false' />
                                <filter type='and'>
                                  <condition attribute='ber_leadtype' operator='eq' value='278290002' /> 
                                </filter>
                                <link-entity name ='contact' alias='aa' to='ber_masterpainterid' from='contactid'>
                                <attribute name='pager'/>
                                <attribute name='fullname'/>
                                 <filter type='and'>
                                  <condition attribute='mobilephone' operator='eq' value='" + Mno + @"' />
                                  <condition attribute='statecode' operator='eq' value='0' />
                                </filter>
                                </link-entity>
                                  <link-entity name='account' alias='ad' to='ber_dealerid' from='accountid' link-type='outer' visible='false'> 
                                      <attribute name='accountnumber'/> 
                                </link-entity> 
                              </entity>
                            </fetch>";

                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(fxml));

                int ResultCount = result.Entities.Count;
                LeadSummaryData[] LData = new LeadSummaryData[ResultCount];
                int i = 0;

                if (ResultCount > 0)
                {
                    foreach (var item in result.Entities)
                    {
                        LData[i] = new LeadSummaryData();
                        if (item.Contains("subject"))
                            LData[i].LeadId = Convert.ToString(item.Attributes["subject"]);
                        if (item.Contains("ber_salutation"))
                            LData[i].Salutation = Convert.ToString(item.FormattedValues["ber_salutation"]);
                        if (item.Contains("firstname"))
                            LData[i].Firstname = Convert.ToString(item.Attributes["firstname"]);
                        if (item.Contains("lastname"))
                            LData[i].Lastname = Convert.ToString(item.Attributes["lastname"]);
                        if (item.Contains("telephone1"))
                            LData[i].Telephone = Convert.ToString(item.Attributes["telephone1"]);
                        if (item.Contains("ber_leadtype"))
                            LData[i].Leadtype = Convert.ToString(item.FormattedValues["ber_leadtype"]);
                        if (item.Contains("statuscode"))
                            LData[i].Statuscode = Convert.ToString(item.FormattedValues["statuscode"]);
                        if (item.Contains("aa.pager"))
                            LData[i].PainterID = ((Microsoft.Xrm.Sdk.AliasedValue)item.Attributes["aa.pager"]).Value.ToString();
                        if (item.Contains("ber_depotid"))
                            LData[i].Depot = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_depotid"])).Name;
                        if (item.Contains("ad.accountnumber"))
                            LData[i].Dealer = ((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["ad.accountnumber"])).Value.ToString() + " - " + ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_dealerid"])).Name;
                        if (item.Contains("createdon"))
                            LData[i].LeadEntryDate = Convert.ToString(item.FormattedValues["createdon"]);
                        if (item.Contains("ber_paintermobilenumber"))
                            LData[i].PainterMobileNo = Convert.ToString(item.Attributes["ber_paintermobilenumber"]);
                        if (item.Contains("ber_painterallocationdate"))
                            LData[i].LeadAssignmentDate = Convert.ToString(item.FormattedValues["ber_painterallocationdate"]);
                        if (item.Contains("aa.fullname"))
                            LData[i].PainterName = ((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["aa.fullname"])).Value.ToString();

                        LeadSumData.Add(LData[i]);
                        i++;
                    }



                }
                else
                {
                    oLogger.Log("MobileIntService", "GetLeadSummaryData", "No Record Found for " + Mno + " from CRM", "No Record Found");

                }

            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetLeadSummaryData", "Exception: " + ex.ToString(), "Problem while fetching LeadSummaryData for " + Mno + " from CRM");
            }
            return LeadSumData;


        }
        #endregion

        #region GetLeadDetailData
        public List<LeadDetailData> GetLeadDetailData(string Lid)
        {
            GetConfigurationData();
            List<LeadDetailData> LeadDetailData = new List<LeadDetailData>();

            try
            {
                string fxml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lead'>
                                <attribute name='telephone1'/>
                                <attribute name='leadid' />
                                <attribute name='subject' />
                                <attribute name='ber_woods' />
                                <attribute name='statecode' />
                                <attribute name= 'statuscode' />
                                <attribute name='ber_stateid' />
                                <attribute name='ber_startdate' />
                                <attribute name='ber_salutation' />
                                <attribute name='ber_pincodeid' />
                                <attribute name='address2_addresstypecode' />
                                <attribute name='mobilephone' />
                                <attribute name='industrycode' />
                                <attribute name='ber_leadtype' />
                                <attribute name='leadsourcecode' />
                                <attribute name='lastname' />
                                <attribute name='ber_interior' />
                                <attribute name='telephone2' />
                                <attribute name='firstname' />
                                <attribute name='ber_exterior' />
                                <attribute name='ber_enddate' />
                                <attribute name='emailaddress1' />
                                <attribute name='ber_depotid' />
                                <attribute name='ber_cityid' />
                                <attribute name='ber_cc' />
                                <attribute name='ber_carpetarea' />
                                <attribute name='address2_line3' />
                                <attribute name='address2_line2' />
                                <attribute name='address2_line1' />
                                <attribute name='ber_dealerid' /> 
                        <attribute name='ber_totaljobvalue' />
                        <attribute name='ber_appointmentdate' />
                        <attribute name='description' />
                        <attribute name='ber_capturejobcompleteddate' />
                        <attribute name='ber_estimatedpaintingcost' />
                        <attribute name='ber_tmaterialcost' />
                        <attribute name='ber_tlabourcost' />
                                <order attribute='leadid' descending='false' />
                                <filter type='and'>
                                  <condition attribute='ber_leadtype' operator='eq' value='278290002' />
                                  <condition attribute='subject' operator='eq' value='" + Lid + @"' />
                                </filter>
                                <link-entity name='account' alias='a_b' link-type='outer' visible='false' to='ber_dealerid' from='accountid'>
                                    <attribute name='accountnumber'/>    
                                    <attribute name='ber_dg'/>
                                     <link-entity name='contact' alias='c' link-type='outer' visible='false' to='ber_dg' from='contactid'>
                                        <attribute name='fullname'/>                                   
                                        <attribute name='mobilephone'/>
                                     </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";

                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(fxml));

                int ResultCount = result.Entities.Count;
                LeadDetailData[] LData = new LeadDetailData[ResultCount];
                int i = 0;

                if (ResultCount > 0)
                {
                    foreach (var item in result.Entities)
                    {
                        LData[i] = new LeadDetailData();
                        if (item.Contains("subject"))
                            LData[i].LeadId = Convert.ToString(item.Attributes["subject"]);
                        if (item.Contains("ber_salutation"))
                            LData[i].Salutation = Convert.ToString(item.FormattedValues["ber_salutation"]);
                        if (item.Contains("firstname"))
                            LData[i].FirstName = Convert.ToString(item.Attributes["firstname"]);
                        if (item.Contains("lastname"))
                            LData[i].Lastname = Convert.ToString(item.Attributes["lastname"]);
                        if (item.Contains("telephone1"))
                            LData[i].PrimaryNo = Convert.ToString(item.Attributes["telephone1"]);
                        if (item.Contains("ber_leadtype"))
                            LData[i].LeadType = Convert.ToString(item.FormattedValues["ber_leadtype"]);
                        if (item.Contains("statuscode"))
                            LData[i].LeadStatus = Convert.ToString(item.FormattedValues["statuscode"]);
                        if (item.Contains("mobilephone"))
                            LData[i].AlternateContactNo = Convert.ToString(item.Attributes["mobilephone"]);
                        if (item.Contains("address2_addresstypecode"))
                            LData[i].PaintingType = Convert.ToString(item.FormattedValues["address2_addresstypecode"]);
                        if (item.Contains("telephone2"))
                            LData[i].HomePhone = Convert.ToString(item.Attributes["telephone2"]);
                        if (item.Contains("emailaddress1"))
                            LData[i].Email = Convert.ToString(item.Attributes["emailaddress1"]);
                        if (item.Contains("address2_line1"))
                            LData[i].Street1 = Convert.ToString(item.Attributes["address2_line1"]);
                        if (item.Contains("address2_line2"))
                            LData[i].Street2 = Convert.ToString(item.Attributes["address2_line2"]);
                        if (item.Contains("address2_line3"))
                            LData[i].Street3 = Convert.ToString(item.Attributes["address2_line3"]);
                        if (item.Contains("ber_depotid"))
                            LData[i].Depot = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_depotid"])).Name;
                        if (item.Contains("ber_dealerid") && item.Contains("a_b.accountnumber"))
                            LData[i].DealerCode = Convert.ToString(((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["a_b.accountnumber"])).Value) + " - " + ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_dealerid"])).Name;
                        if (item.Contains("ber_pincodeid"))
                            LData[i].PinCode = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_pincodeid"])).Name;
                        if (item.Contains("ber_cityid"))
                            LData[i].City = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_cityid"])).Name;
                        if (item.Contains("ber_stateid"))
                            LData[i].State = ((Microsoft.Xrm.Sdk.EntityReference)(item.Attributes["ber_stateid"])).Name;
                        if (item.Contains("leadsourcecode"))
                            LData[i].LeadSource = Convert.ToString(item.FormattedValues["leadsourcecode"]);
                        if (item.Contains("industrycode"))
                            LData[i].LeadOpportunity = Convert.ToString(item.FormattedValues["industrycode"]);
                        if (item.Contains("ber_cc"))
                            LData[i].CC = Convert.ToString(item.FormattedValues["ber_cc"]);
                        if (item.Contains("ber_startdate"))
                            LData[i].StartDate = Convert.ToString(item.Attributes["ber_startdate"]);
                        if (item.Contains("ber_enddate"))
                            LData[i].EndDate = Convert.ToString(item.Attributes["ber_enddate"]);
                        if (item.Contains("ber_woods"))
                            LData[i].Wood = Convert.ToString(item.FormattedValues["ber_woods"]);
                        if (item.Contains("ber_exterior"))
                            LData[i].Exterior = Convert.ToString(item.FormattedValues["ber_exterior"]);
                        if (item.Contains("ber_interior"))
                            LData[i].Interior = Convert.ToString(item.FormattedValues["ber_interior"]);
                        if (item.Contains("ber_carpetarea"))
                            LData[i].CarpetArea = Convert.ToString(item.Attributes["ber_carpetarea"]);

                        /*Added by Dhiman */
                        if (item.Contains("ber_totaljobvalue"))
                        {
                            string strTotalJobValue = "" + item.FormattedValues["ber_totaljobvalue"];
                            LData[i].FinalJobValue = "" + ReduceCurrencyFromValue(strTotalJobValue);
                        }
                        else
                        {
                            LData[i].FinalJobValue = "0";
                        }

                        if (item.Contains("statecode"))
                        {
                            LData[i].StateCode = "" + item.FormattedValues["statecode"];
                        }
                        if (item.Contains("ber_appointmentdate"))
                        {
                            LData[i].AppointmentDate = "" + item.FormattedValues["ber_appointmentdate"];
                        }
                        if (item.Contains("description"))
                        {
                            LData[i].Description = "" + item.Attributes["description"];
                        }
                        if (item.Contains("ber_capturejobcompleteddate"))
                        {
                            LData[i].CaptureJobCompletedDate = "" + item.FormattedValues["ber_capturejobcompleteddate"];
                        }
                        if (item.Contains("ber_estimatedpaintingcost"))
                        {
                            string TotalValue = "" + item.FormattedValues["ber_estimatedpaintingcost"];
                            LData[i].TotalValue = "" + ReduceCurrencyFromValue(TotalValue);
                        }


                        if (item.Contains("ber_tmaterialcost"))
                        {
                            LData[i].MaterialValue = "" + item.FormattedValues["ber_tmaterialcost"];
                        }
                        else
                        {
                            LData[i].MaterialValue = "0";
                        }

                        if (item.Contains("ber_tlabourcost"))
                        {
                            LData[i].LabourValue = "" + item.FormattedValues["ber_tlabourcost"];
                        }
                        else
                        {
                            LData[i].LabourValue = "0";
                        }

                        if (item.Contains("c.fullname"))
                        {
                            LData[i].DgName = "" + ((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["c.fullname"])).Value;
                        }

                        if (item.Contains("c.mobilephone"))
                        {
                            LData[i].DgMobileNo = "" + ((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["c.mobilephone"])).Value;
                        }

                        LeadDetailData.Add(LData[i]);
                        i++;
                    }



                }
                else
                {
                    oLogger.Log("MobileIntService", "GetLeadDetailData", "No Record Found for LeadId " + Lid + " from CRM", "No Record Found");

                }

            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetLeadDetailData", "Exception: " + ex.ToString(), "Problem while fetching LeadSummaryData for LeadId" + Lid + " from CRM");
            }
            return LeadDetailData;
        }

        #endregion

        #region GetAccountStatement
        public List<AccountStatement> GetAccountStatement(string MobileNo, string LWCode)
        {
            GetConfigurationData();
            List<AccountStatement> LAcc = new List<AccountStatement>();

            DataTable dtA = new DataTable();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {

                    conn.Open();
                    string query_text = @"exec SP_ACCOUNTSTATEMENT @Meet = '" + LWCode + "',@MobileNo='" + MobileNo + "'";

                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    //foreach (DataRow dr in dtA.Rows)
                    //{

                    //    AccountStatement a = new AccountStatement();
                    //    a.RegisteredDealerCode = Convert.ToString(dr["MD_Dealer"]);
                    //    a.Category = dr["MD_PainterStatus"].ToString();
                    //    a.Date = dr["LiftingRegisterDate"].ToString();
                    //    a.LiftingDealerCode = dr["Dealer"].ToString();// + " " + dr["DealerName"].ToString(),
                    //    a.Product = dr["Product"].ToString();
                    //    a.Status = dr["LDStatus"].ToString();
                    //    a.Volume = dr["Volume"].ToString();
                    //    a.Loading = dr["LOADING"].ToString();
                    //    a.GroupBonus = dr["MD_Groupbonus"].ToString();
                    //    a.VolumeBonus = dr["MD_Volumebonus"].ToString();
                    //    a.PointsCarriedForward = dr["PointCarryFWD"].ToString();
                    //    a.RegisteredDepot = dr["MD_Depot"].ToString();
                    //    LAcc.Add(a);

                    //}

                    LAcc = (from DataRow dr in dtA.Rows
                            select new AccountStatement()
                            {
                                RegisteredDealerCode = Convert.ToString(dr["MD_Dealer"]),
                                Category = dr["MD_PainterStatus"].ToString(),

                                Date = dr["LiftingRegisterDate"].ToString(),
                                LiftingDealerCode = dr["Dealer"].ToString(),// + " " + dr["DealerName"].ToString(),
                                Product = dr["Product"].ToString(),
                                Status = dr["LDStatus"].ToString(),
                                Volume = dr["Volume"].ToString(),
                                Loading = dr["LOADING"].ToString(),
                                GroupBonus = dr["MD_Groupbonus"].ToString(),
                                RegisteredDepot = dr["MD_Depot"].ToString(),
                                VolumeBonus = dr["MD_Volumebonus"].ToString(),
                                PointsCarriedForward = dr["PointCarryFWD"].ToString()


                            }).ToList();


                }
                catch (Exception ex)
                {

                    oLogger.Log("MobileIntService", "GetAccountStatement", "Exception: " + ex.ToString(), "Problem while fetching data from CRM for " + MobileNo + " and " + LWCode + "from CRM");


                }
            }

            return LAcc;
        }
        #endregion

        #region GetLeadForAllPainters
        public List<LeadForAllPainters> GetLeadForAllPainters(string F_Date)
        {

            GetConfigurationData();
            List<LeadForAllPainters> LeadData = new List<LeadForAllPainters>();

            try
            {

                if (F_Date != string.Empty)
                {
                    string fxml = @"<?xml version='1.0'?>
                <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'> 
                <entity name='lead'> 
                <attribute name='leadid'/> 
                <attribute name='subject'/>
                <attribute name='lastname'/> 
                <attribute name='firstname'/> 
                <attribute name='statuscode'/> 
                <attribute name='telephone1'/> 
                <attribute name='ber_leadtype'/>
                <attribute name='ber_salutation'/>
                <order descending='false' attribute='firstname'/> 
                    <filter type='and'> 
                    <condition attribute='ber_painterallocationdate' value='" + F_Date + @"' operator='on-or-after'/> 
                    </filter> 
                <link-entity name='contact' alias='aa' to='ber_masterpainterid' from='contactid'> 
                    <attribute name='mobilephone'/>
                </link-entity>
                </entity> 
                </fetch>";

                    EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(fxml));

                    int ResultCount = result.Entities.Count;
                    LeadForAllPainters[] LData = new LeadForAllPainters[ResultCount];
                    int i = 0;

                    if (ResultCount > 0)
                    {
                        foreach (var item in result.Entities)
                        {
                            LData[i] = new LeadForAllPainters();
                            if (item.Contains("subject"))
                                LData[i].LeadId = Convert.ToString(item.Attributes["subject"]);
                            if (item.Contains("ber_salutation"))
                                LData[i].Salutation = Convert.ToString(item.FormattedValues["ber_salutation"]);
                            if (item.Contains("firstname"))
                                LData[i].FirstName = Convert.ToString(item.Attributes["firstname"]);
                            if (item.Contains("lastname"))
                                LData[i].Lastname = Convert.ToString(item.Attributes["lastname"]);
                            if (item.Contains("aa.mobilephone"))
                                LData[i].PrimaryNo = ((Microsoft.Xrm.Sdk.AliasedValue)(item.Attributes["aa.mobilephone"])).Value.ToString();
                            if (item.Contains("ber_leadtype"))
                                LData[i].LeadType = Convert.ToString(item.FormattedValues["ber_leadtype"]);
                            if (item.Contains("statuscode"))
                                LData[i].LeadStatus = Convert.ToString(item.FormattedValues["statuscode"]);
                            LeadData.Add(LData[i]);
                            i++;
                        }



                    }
                    else
                    {
                        oLogger.Log("MobileIntService", "GetLeadForAllPainters", "No Record Found from " + F_Date + " in CRM", "No Record Found");

                    }
                }
                else
                {
                    oLogger.Log("MobileIntService", "GetLeadForAllPainters", "No Date Provided" + F_Date + " by Url", "No Date Provided");

                }


            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "GetLeadForAllPainters", "Exception: " + ex.ToString(), "Problem while fetching LeadForAllPainters from " + F_Date + " in CRM");
            }
            return LeadData;



        }
        #endregion

        #region DisplayPainterDetails
        public List<DPainterDetails> DisplayPainterDetails(string Mno)
        {
            GetConfigurationData();

            List<DPainterDetails> p = new List<DPainterDetails>();
            try
            {
                string FXml =
                 @"
                <fetch distinct='true' mapping='logical' output-format='xml-platform' version='1.0'> 
                <entity name='contact'> 
                <attribute name='fullname'/> 
                <attribute name='contactid'/>  
                <attribute name='ber_depotid'/> 
                <attribute name='ber_dealerid'/> 
                <attribute name='pager'/> 
                <attribute name='ber_epstatus'/> 
                <order descending='false' attribute='fullname'/> 
                <filter type='and'> 
                    <condition attribute='statecode' value='0' operator='eq'/> 
                    <condition attribute='mobilephone' value='" + Mno + @"' operator='eq'/> 
                </filter> 
                    <link-entity name='ber_paintermeetcontact' alias='aa' to='contactid' from='ber_contact'> 
                        <attribute name='ber_volumestatus'/>   
                        <attribute name='createdon'/>                  
                    <link-entity name='ber_paintermeet' alias='ab' to='ber_paintermeet' from='ber_paintermeetid'> 
                    <link-entity name='ber_meet' alias='ac' to='ber_meet' from='ber_meetid'> 
                        <filter type='and'> 
                            <condition attribute='ber_type' value='278290002' operator='eq'/> 
                        </filter> 
                    </link-entity> 
                    </link-entity> 
                    </link-entity>
                <link-entity name='account' alias='ad' to='ber_dealerid' from='accountid' link-type='outer' visible='false'> 
                    <attribute name='accountnumber'/> 
                </link-entity> 
                </entity> 
                </fetch>";

                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(FXml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                DPainterDetails[] pDetails = new DPainterDetails[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        pDetails[i] = new DPainterDetails();
                        if (c.Contains("fullname"))
                            pDetails[i].PainterName = c.Attributes["fullname"].ToString();
                        if (c.Contains("pager"))
                            pDetails[i].PainterID = c.Attributes["pager"].ToString();

                        if (c.Contains("aa.createdon"))
                            pDetails[i].PainterEnrollmentDate = Convert.ToString(c.FormattedValues["aa.createdon"]);

                        if (c.Contains("ber_depotid"))
                            pDetails[i].LinkedToDepot = ((Microsoft.Xrm.Sdk.EntityReference)(c.Attributes["ber_depotid"])).Name;
                        if (c.Contains("ber_dealerid"))
                            pDetails[i].LinkedToDealer = ((Microsoft.Xrm.Sdk.AliasedValue)(c.Attributes["ad.accountnumber"])).Value.ToString() + " - " + ((Microsoft.Xrm.Sdk.EntityReference)(c.Attributes["ber_dealerid"])).Name;
                        if (c.Contains("aa.ber_volumestatus"))
                            pDetails[i].PainterStatus = Convert.ToString(c.FormattedValues["aa.ber_volumestatus"]);
                        if (c.Contains("ber_epstatus"))
                        {
                            if (c.FormattedValues["ber_epstatus"] == "Yes")
                            {
                                pDetails[i].PainterType = "XP";
                            }
                            else if (c.FormattedValues["ber_epstatus"] == "No")
                            {
                                pDetails[i].PainterType = "Non-XP";
                            }
                        }
                        i++;
                    }

                    p = pDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "DisplayPainterDetails", "No Record Found for " + Mno + "  from CRM", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "DisplayPainterDetails", "Exception: " + ex.ToString(), "Problem while fetching Painter Details  for " + Mno + " from CRM");
            }
            return p;
        }
        #endregion

        #region Master Painter Info
        public List<MPainterInfo> MasterPainterInfo(string Dp, string Dealer)
        {
            GetConfigurationData();

            List<MPainterInfo> mp = new List<MPainterInfo>();
            try
            {
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                      <entity name='contact'>
                        <attribute name='fullname' />
                        <attribute name='contactid' />
                        <attribute name='pager' />
                        <attribute name='mobilephone' />
                        <order attribute='fullname' descending='false' />
                        <filter type='and'>
                          <condition attribute='ber_customertype' operator='eq' value='278290001' />
                        </filter>
                        <link-entity name='ber_depot' from='ber_depotid' to='ber_depotid' alias='aa'>
                          <filter type='and'>
                            <condition attribute='ber_depotnumber' operator='eq' value='" + Dp + @"' />
                          </filter>
                        </link-entity>
                        <link-entity name='ber_paintermeetcontact' from='ber_contact' to='contactid' alias='ac'>
                          <link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_paintermeet' alias='ad'>
                            <filter type='and'>
                              <condition attribute='ber_meettype' operator='eq' value='278290002' />
                            </filter>
                          </link-entity>
                        </link-entity>
                        <link-entity name='account' from='accountid' to='ber_dealerid' alias='ab'>
                          <attribute name='accountnumber' />
                          <filter type='and'>
                            <condition attribute='accountnumber' operator='eq' value='" + Dealer + @"' />
                          </filter>
                        </link-entity>
                      </entity>
                    </fetch>";


                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(Fxml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                MPainterInfo[] mpDetails = new MPainterInfo[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        mpDetails[i] = new MPainterInfo();
                        if (c.Contains("pager"))
                            mpDetails[i].MPainterCode = c.Attributes["pager"].ToString();

                        if (c.Contains("fullname"))
                            mpDetails[i].MPainterName = c.Attributes["fullname"].ToString();

                        if (c.Contains("mobilephone"))
                            mpDetails[i].MPainterMobileNo = c.Attributes["mobilephone"].ToString();
                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {
                    oLogger.Log("MobileIntService", "MasterPainterInfo", "No Record Found for Depot" + Dp + " & Dealer" + Dealer + " ", "No Record Found");
                }
            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "MasterPainterInfo", "Exception: " + ex.ToString(), "Problem while fetching Master Painter Info  for Depot" + Dp + " & Dealer" + Dealer + " ");
            }
            return mp;
        }
        #endregion

        //Dealer Apps

        #region Dealer Validation
        public List<DValidation> Dealer_Validation(string Dcode)
        {
            GetConfigurationData();

            List<DValidation> mp = new List<DValidation>();
            try
            {

                // This is old Commented by Partha on 31-MAY-2016
                /*
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='account'>
                        <attribute name='name' />
                        <attribute name='accountid' />
                        <attribute name='telephone1' />
                        <order attribute='name' descending='false' />
                        <filter type='and'>
                          <condition attribute='accountcategorycode' operator='in'>
                            <value>278290009</value>
                            <value>278290008</value>
                            <value>278290005</value>
                            <value>278290007</value>
                            <value>278290010</value>
                            <value>278290006</value>
                          </condition>
                          <condition attribute='parentaccountid' operator='null' />
                          <condition attribute='accountnumber' operator='eq' value='" + Dcode + @"' />
                        </filter>
                      </entity>
                    </fetch>";
                */
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='account'>
                        <attribute name='name' />
                        <attribute name='accountid' />
                        <attribute name='telephone1' />
                        <attribute name='accountcategorycode' />
                        <attribute name='telephone3' />
                        <attribute name='address1_telephone1' />
                        <attribute name='telephone2' />
                        <attribute name='ber_retailercontactnumber'/>
                        <order attribute='name' descending='false' />
                        <filter type='and'>
                          <condition attribute='parentaccountid' operator='null' />
                          <condition attribute='accountnumber' operator='eq' value='" + Dcode + @"' />
                        </filter>
                      </entity>
                    </fetch>";


                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(Fxml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                DValidation[] mpDetails = new DValidation[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        mpDetails[i] = new DValidation();
                        if (c.Contains("name"))
                            mpDetails[i].DName = c.Attributes["name"].ToString();

                        if (c.Contains("telephone1"))
                            mpDetails[i].DPrimary_MobileNo = c.Attributes["telephone1"].ToString();

                        if (c.Contains("accountcategorycode"))
                        {
                            if (Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value) == "278290009" ||
                                Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value) == "278290008" ||
                                Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value) == "278290005" ||
                                Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value) == "278290007" ||
                                Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value) == "278290006")
                            {


                                mpDetails[i].DealerType = "XP-Dealer";
                            }
                            else
                            {
                                mpDetails[i].DealerType = "NON XP-Dealer";
                            }


                            mpDetails[i].CustomerType = Convert.ToString(((OptionSetValue)c.Attributes["accountcategorycode"]).Value);
                        }

                        if (c.Contains("telephone3"))
                            mpDetails[i].alt_Ph1 = Convert.ToString(c.Attributes["telephone3"]);

                        if (c.Contains("address1_telephone1"))
                            mpDetails[i].alt_Ph2 = Convert.ToString(c.Attributes["address1_telephone1"]);

                        if (c.Contains("telephone2"))
                            mpDetails[i].alt_Ph3 = Convert.ToString(c.Attributes["telephone2"]);

                        if (c.Contains("ber_retailercontactnumber"))
                            mpDetails[i].Rtl_Ph1 = Convert.ToString(c.Attributes["ber_retailercontactnumber"]);


                        //int result = Check() ? 1 : 0;

                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "DValidation", "No Record Found for Dealer" + Dcode + "", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "DValidation", "Exception: " + ex.ToString(), "Problem while Dealer Info for Dealer" + Dcode + "");
            }
            return mp;
        }
        #endregion

        #region  Lead Summary By DealerCode
        public List<DLeadSummary> LeadSummary_ByDealer(string Dcode)
        {
            GetConfigurationData();

            List<DLeadSummary> mp = new List<DLeadSummary>();
            try
            {
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='lead'>
                        <attribute name='subject' />
                        <attribute name='lastname' />
                        <attribute name='firstname' />
                        <attribute name='ber_depotid' />
                        <attribute name='createdon' />
                        <attribute name='ber_leadtype' />
                        <attribute name='statuscode' />
                        <attribute name='statecode' />
                        <attribute name='ber_startdate' />
                        <attribute name='ber_enddate' />                       
                        <attribute name='ber_appointmentdate' />
                        <attribute name='description' />
                        <attribute name='ber_tmaterialcost' />
                        <attribute name='ber_tlabourcost' />
                        <attribute name='ber_capturejobcompleteddate' />
                        <order attribute='fullname' descending='false' />
                        <attribute name='ber_salutation'/> 
                        <attribute name='ber_totaljobvalue' /> 
                        <link-entity name='contact' from='contactid' to='ber_masterpainterid' visible='false' link-type='outer' alias='ab'>
                          <attribute name='mobilephone' />
                          <attribute name='pager' />
                          <attribute name='fullname' />                         
                        <filter type='and'>
                                <condition attribute='ber_customertype' operator='eq' value='278290001' />
                              </filter>
                        </link-entity>
                        <link-entity name='account' from='accountid' to='ber_dealerid' alias='ac'>
                          <attribute name='accountnumber' />
                          <attribute name='name' />
                          <filter type='and'>
                            <condition attribute='parentaccountid' operator='null' />
                            <condition attribute='accountnumber' operator='eq' value='" + Dcode + @"' />
                          </filter>
                        </link-entity>   
                      </entity>
                    </fetch>";


                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(Fxml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                DLeadSummary[] mpDetails = new DLeadSummary[RecordCount];
                if (RecordCount > 0)
                {
                    string strStatusCode = "";
                    foreach (var c in result.Entities)
                    {
                        strStatusCode = "";
                        mpDetails[i] = new DLeadSummary();
                        if (c.Contains("ac.name"))
                            mpDetails[i].Dealer = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ac.name"]).Value.ToString();

                        if (c.Contains("ber_depotid"))
                            mpDetails[i].Depot = ((Microsoft.Xrm.Sdk.EntityReference)c.Attributes["ber_depotid"]).Name;
                        if (c.Contains("firstname"))
                            mpDetails[i].Firstname = "" + c.Attributes["firstname"];
                        if (c.Contains("lastname"))
                            mpDetails[i].Lastname = "" + c.Attributes["lastname"];
                        if (c.Contains("createdon"))
                            mpDetails[i].LeadEntryDate = "" + c.FormattedValues["createdon"];
                        if (c.Contains("statuscode"))
                        {
                            strStatusCode = "" + c.FormattedValues["statuscode"].ToString();
                            mpDetails[i].Statuscode = strStatusCode;
                            mpDetails[i].LdStatuscode = ((Microsoft.Xrm.Sdk.OptionSetValue)(c.Attributes["statuscode"])).Value.ToString();
                        }
                        if (c.Contains("ab.pager"))
                            mpDetails[i].PainterID = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.pager"]).Value.ToString();
                        if (c.Contains("ab.mobilephone"))
                            mpDetails[i].PainterMobileNo = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.mobilephone"]).Value.ToString();
                        if (c.Contains("subject"))
                            mpDetails[i].LeadId = "" + c.Attributes["subject"];
                        if (c.Contains("ber_leadtype"))
                            mpDetails[i].Leadtype = "" + c.FormattedValues["ber_leadtype"];
                        if (c.Contains("ab.fullname"))
                            mpDetails[i].PainterName = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.fullname"]).Value.ToString();
                        if (c.Contains("ber_salutation"))
                            mpDetails[i].PainterSalutation = "" + c.FormattedValues["ber_salutation"];
                        /*Added by Dhiman */
                        if (c.Contains("ber_startdate"))
                        {
                            mpDetails[i].Startdate = "" + c.FormattedValues["ber_startdate"];
                        }
                        if (c.Contains("ber_enddate"))
                        {
                            mpDetails[i].EndDate = "" + c.FormattedValues["ber_enddate"];
                        }

                        if (c.Contains("ber_totaljobvalue"))
                        {
                            string strTotalJobValue = "" + c.FormattedValues["ber_totaljobvalue"];
                            mpDetails[i].TotalJobValue = "" + ReduceCurrencyFromValue(strTotalJobValue);
                        }
                        else
                        {
                            mpDetails[i].TotalJobValue = "0";
                        }

                        if (c.Contains("statecode"))
                        {
                            mpDetails[i].StateCode = "" + c.FormattedValues["statecode"];
                        }
                        if (c.Contains("ber_appointmentdate"))
                        {
                            mpDetails[i].AppointmentDate = "" + c.FormattedValues["ber_appointmentdate"];
                        }
                        if (c.Contains("description"))
                        {
                            mpDetails[i].Description = "" + c.Attributes["description"];
                        }
                        if (c.Contains("ber_capturejobcompleteddate"))
                        {
                            mpDetails[i].CaptureJobCompletedDate = "" + c.FormattedValues["ber_capturejobcompleteddate"];
                        }

                        if (c.Contains("ber_tmaterialcost"))
                        {
                            mpDetails[i].MaterialValue = "" + c.FormattedValues["ber_tmaterialcost"];
                        }
                        else
                        {
                            mpDetails[i].MaterialValue = "0";
                        }

                        if (c.Contains("ber_tlabourcost"))
                        {
                            mpDetails[i].LabourValue = "" + c.FormattedValues["ber_tlabourcost"];
                        }
                        else
                        {
                            mpDetails[i].LabourValue = "0";
                        }

                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "LeadSummary_ByDealer", "No Record Found for Dealer" + Dcode + "", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "LeadSummary_ByDealer", "Exception: " + ex.ToString(), "Problem while Dealer Info for Dealer" + Dcode + "");
            }
            return mp;
        }

        #endregion

        #region Painter Summary by DealerCode for XP
        public List<DPainterSummary> PainterSummary_ByDealer(string Dcode)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<DPainterSummary> LPS = new List<DPainterSummary>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec SP_PainterSummaryByDealer @DCode = '" + Dcode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    conn.Close();
                    LPS = (from DataRow dr in dtA.Rows
                           select new DPainterSummary()
                           {
                               PainterName = dr["fullname"].ToString(),
                               PainterID = dr["pager"].ToString(),
                               PainterMobileNo = dr["mobilephone"].ToString(),
                               PainterCategory = dr["PainterCategory"].ToString(),
                               LostLeads = dr["LostLeads"].ToString(),
                               Converted_Lead = dr["JobWon"].ToString(),
                               InProgressLeads = dr["Total_Lead_InProgress"].ToString(),
                               NewLeads = dr["NewLeads"].ToString(),
                               TotalLeads = dr["TotalXPLeads"].ToString(),
                               TotalJobValue = dr["ber_totaljobvalue"].ToString(),
                               TotalMaterialValue = dr["TotalMaterialValue"].ToString(),
                               TotalLabourValue = dr["TotalLabourValue"].ToString(),
                               SanderVolume = dr["SanderVolume"].ToString(),
                               PainterRating = dr["PainterRating"].ToString()

                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {

                        oLogger.Log("MobileIntService", "PainterSummary_ByDealer", "No Record Found for Dealer " + Dcode + "", "No Record Found");

                    }


                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "PainterSummary_ByDealer", "Exception: " + ex.ToString(), "Problem while Dealer Info for Dealer " + Dcode + "");
                }
            }
            return LPS;
        }
        #endregion

        #region  Lead Summary By DealerCode For A Painter
        public List<DLeadSummary> LeadSummaryForPainter(string Dcode, string Mno)
        {
            GetConfigurationData();

            List<DLeadSummary> mp = new List<DLeadSummary>();
            try
            {
                /*New fields added by Dhiman:
                <attribute name='ber_startdate' />
                <attribute name='ber_enddate' />
                <attribute name='ber_totaljobvalue' />
                <attribute name='ber_appointmentdate' />
                <attribute name='description' />
                <attribute name='ber_capturejobcompleteddate' />
                */
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='lead'>
                        <attribute name='subject' />
                        <attribute name='lastname' />
                        <attribute name='firstname' />
                        <attribute name='telephone1' />
                        <attribute name='ber_depotid' />
                        <attribute name='createdon' />
                        <attribute name='ber_leadtype' />
                        <attribute name='statuscode' />
                        <attribute name='statecode' />
                        <attribute name='ber_startdate' />
                        <attribute name='ber_enddate' />
                        <attribute name='ber_totaljobvalue' />
                        <attribute name='ber_appointmentdate' />
                        <attribute name='description' />
                        <attribute name='ber_capturejobcompleteddate' />
                        <attribute name='ber_painterallocationdate'/>
                        <order attribute='fullname' descending='false' />
                        <attribute name='ber_salutation'/>
                        <link-entity name='contact' from='contactid' to='ber_masterpainterid' alias='ab'>
                          <attribute name='mobilephone' />
                          <attribute name='pager' />
                          <attribute name='fullname' />                       
                        <filter type='and'>
                                <condition attribute='ber_customertype' operator='eq' value='278290001' />
                                <condition attribute='mobilephone' operator='eq' value='" + Mno + @"' />
                              </filter>
                        </link-entity>
                        <link-entity name='account' from='accountid' to='ber_dealerid' alias='ac'>
                          <attribute name='accountnumber' />
                          <attribute name='name' />
                          <filter type='and'>
                            <condition attribute='parentaccountid' operator='null' />
                            <condition attribute='accountnumber' operator='eq' value='" + Dcode + @"' />
                          </filter>
                        </link-entity>
                      </entity>
                    </fetch>";


                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(Fxml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                DLeadSummary[] mpDetails = new DLeadSummary[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        mpDetails[i] = new DLeadSummary();
                        if (c.Contains("ac.name"))
                            mpDetails[i].Dealer = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ac.name"]).Value.ToString();
                        if (c.Contains("ber_depotid"))
                            mpDetails[i].Depot = ((Microsoft.Xrm.Sdk.EntityReference)c.Attributes["ber_depotid"]).Name;
                        if (c.Contains("firstname"))
                            mpDetails[i].Firstname = "" + c.Attributes["firstname"];
                        if (c.Contains("lastname"))
                            mpDetails[i].Lastname = "" + c.Attributes["lastname"];
                        if (c.Contains("telephone1"))
                            mpDetails[i].Telephone = "" + c.Attributes["telephone1"];
                        if (c.Contains("createdon"))
                            mpDetails[i].LeadEntryDate = "" + c.Attributes["createdon"];
                        if (c.Contains("statuscode"))
                            mpDetails[i].Statuscode = "" + c.FormattedValues["statuscode"];
                        if (c.Contains("ab.pager"))
                            mpDetails[i].PainterID = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.pager"]).Value.ToString();
                        if (c.Contains("ab.mobilephone"))
                            mpDetails[i].PainterMobileNo = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.mobilephone"]).Value.ToString();
                        if (c.Contains("subject"))
                            mpDetails[i].LeadId = "" + c.Attributes["subject"];
                        if (c.Contains("ber_leadtype"))
                            mpDetails[i].Leadtype = "" + c.FormattedValues["ber_leadtype"];
                        if (c.Contains("ab.fullname"))
                            mpDetails[i].PainterName = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.fullname"]).Value.ToString();
                        if (c.Contains("ber_salutation"))
                            mpDetails[i].PainterSalutation = "" + c.FormattedValues["ber_salutation"];
                        /*Added by Dhiman */
                        if (c.Contains("ber_startdate"))
                        {
                            mpDetails[i].Startdate = "" + c.FormattedValues["ber_startdate"];
                        }
                        if (c.Contains("ber_enddate"))
                        {
                            mpDetails[i].EndDate = "" + c.FormattedValues["ber_enddate"];
                        }
                        if (c.Contains("ber_totaljobvalue"))
                        {
                            string strTotalJobValue = "" + c.FormattedValues["ber_totaljobvalue"];
                            mpDetails[i].TotalJobValue = "" + ReduceCurrencyFromValue(strTotalJobValue);
                        }
                        else
                        {
                            mpDetails[i].TotalJobValue = "0";
                        }
                        if (c.Contains("statecode"))
                        {
                            mpDetails[i].StateCode = "" + c.FormattedValues["statecode"];
                        }
                        if (c.Contains("ber_appointmentdate"))
                        {
                            mpDetails[i].AppointmentDate = "" + c.FormattedValues["ber_appointmentdate"];
                        }
                        if (c.Contains("description"))
                        {
                            mpDetails[i].Description = "" + c.Attributes["description"];
                        }
                        if (c.Contains("ber_capturejobcompleteddate"))
                        {
                            mpDetails[i].CaptureJobCompletedDate = "" + c.FormattedValues["ber_capturejobcompleteddate"];
                        }
                        if (c.Contains("ber_painterallocationdate"))
                        {
                            mpDetails[i].LeadAssignmentDate = Convert.ToString(c.FormattedValues["ber_painterallocationdate"]);
                        }

                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "LeadSummary_ByDealer", "No Record Found for Dealer" + Dcode + "", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "LeadSummary_ByDealer", "Exception: " + ex.ToString(), "Problem while Dealer Info for Dealer" + Dcode + "");
            }
            return mp;
        }

        #endregion

        #region Lead Data For a Day
        public List<LeadDataFor_a_Day> LeadDataByDate(string Date_)
        {
            GetConfigurationData();

            List<LeadDataFor_a_Day> mp = new List<LeadDataFor_a_Day>();
            try
            {
                QueryExpression query = new QueryExpression("lead");
                query.NoLock = true;
                query.ColumnSet = new ColumnSet("lastname", "firstname", "ber_leadtype", "subject", "statuscode", "ber_tmaterialcost", "ber_tlabourcost");
                LinkEntity LinkContact = new LinkEntity("lead", "contact", "ber_masterpainterid", "contactid", JoinOperator.Inner);
                LinkContact.EntityAlias = "lc";
                LinkContact.Columns.AddColumns("mobilephone");

                query.LinkEntities.Add(LinkContact);
                LinkEntity LinkAccount = new LinkEntity("lead", "account", "ber_dealerid", "accountid", JoinOperator.Inner);
                LinkAccount.EntityAlias = "la";
                LinkAccount.Columns.AddColumns("accountnumber");

                query.LinkEntities.Add(LinkAccount);
                query.Criteria.AddCondition("createdon", ConditionOperator.On, Date_);
                query.Criteria.AddCondition("ber_depotid", ConditionOperator.NotNull);
                query.Criteria.AddFilter(LogicalOperator.And);
                EntityCollection result = Orgservice.RetrieveMultiple(query);
                int RecordCount = result.Entities.Count;
                int i = 0;
                LeadDataFor_a_Day[] mpDetails = new LeadDataFor_a_Day[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        mpDetails[i] = new LeadDataFor_a_Day();
                        if (c.Contains("subject"))
                            mpDetails[i].LeadId = c.Attributes["subject"].ToString();
                        if (c.Contains("firstname"))
                            mpDetails[i].FirstName = c.Attributes["firstname"].ToString();
                        if (c.Contains("lastname"))
                            mpDetails[i].Lastname = c.Attributes["lastname"].ToString();
                        if (c.Contains("ber_leadtype"))
                            mpDetails[i].LeadType = c.FormattedValues["ber_leadtype"].ToString();
                        if (c.Contains("statuscode"))
                            mpDetails[i].LeadStatus = c.FormattedValues["statuscode"].ToString();
                        if (c.Contains("lc.mobilephone"))
                            mpDetails[i].PainterPrimaryNo = ((AliasedValue)c.Attributes["lc.mobilephone"]).Value.ToString();
                        if (c.Contains("la.accountnumber"))
                            mpDetails[i].DealerCode = ((AliasedValue)c.Attributes["la.accountnumber"]).Value.ToString();


                        if (c.Contains("ber_tmaterialcost"))
                        {
                            mpDetails[i].MaterialValue = "" + c.FormattedValues["ber_tmaterialcost"];
                        }
                        else
                        {
                            mpDetails[i].MaterialValue = "0";
                        }

                        if (c.Contains("ber_tlabourcost"))
                        {
                            mpDetails[i].LabourValue = "" + c.FormattedValues["ber_tlabourcost"];
                        }
                        else
                        {
                            mpDetails[i].LabourValue = "0";
                        }

                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {

                    oLogger.Log("MobileIntService", "LeadDataByDate", "No Record Found on Date" + Date_ + "", "No Record Found");

                }


            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "LeadDataByDate", "Exception: " + ex.ToString(), "Problem while fetching information on date " + Date_ + "");
            }
            return mp;
        }
        #endregion

        //Depot Summary

        public List<DepotSummary> Depot_Summary(string DCode)
        {
            /*
             * Field - ber_totaljobvalue added by Dhiman on 15-Jan-2015
             * Last modified : 2-Feb-2016
             */
            List<DepotSummary> dptDetails = new List<DepotSummary>();
            GetConfigurationData();
            DataTable dtA = new DataTable();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_DepotSummary @DCode = '" + DCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    int RecordCount = dtA.Rows.Count;
                    DepotSummary[] ArrlistDepotSum = new DepotSummary[RecordCount];
                    if (RecordCount > 0)
                    {
                        int i = 0;
                        foreach (DataRow dr in dtA.Rows)
                        {
                            ArrlistDepotSum[i] = new DepotSummary();
                            ArrlistDepotSum[i].TerritoryCode = dr["ber_Territory"].ToString();
                            ArrlistDepotSum[i].TerritoryName = dr["Name"].ToString();
                            ArrlistDepotSum[i].TSIName = dr["ber_TSIIdName"].ToString();
                            ArrlistDepotSum[i].LostLeads = dr["LostLeads"].ToString();
                            ArrlistDepotSum[i].Converted_Lead = dr["JobWon"].ToString();
                            ArrlistDepotSum[i].NewLeadsCount = dr["NewLeads"].ToString();
                            ArrlistDepotSum[i].InProgressLeads = dr["Total_Lead_InProgress"].ToString();
                            ArrlistDepotSum[i].TotalLead = dr["TotalXPLeads"].ToString();
                            ArrlistDepotSum[i].TotalJobValue = "" + dr["ber_totaljobvalue"];
                            ArrlistDepotSum[i].MaterialValue = "" + dr["TotalMaterialValue"];
                            ArrlistDepotSum[i].LabourValue = "" + dr["TotalLabourValue"];
                            i++;
                        }

                        dptDetails = ArrlistDepotSum.ToList();
                    }
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "DepotSummary", "No Record Found for Depot " + DCode + "", "No Record Found");
                    }

                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "DepotSummary", "Exception: " + ex.ToString(), "Problem while fetching info for Depot " + DCode + "");
                }
            }
            return dptDetails;
        }


        public List<TerritorySummary> Territory_Summary(string DCode, string TrCode)
        {
            /*
             * Field - ber_totaljobvalue added by Dhiman on 15-Jan-2015
             * Last modified date : 2-Feb-2016
             */
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<TerritorySummary> LPS = new List<TerritorySummary>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_TerritorySummary @DCode = '" + DCode + "',@TrCode='" + TrCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new TerritorySummary()
                           {
                               DealerCode = dr["AccountNumber"].ToString(),
                               DealerName = dr["Name"].ToString(),
                               TotalLead = dr["TotalXPLeads"].ToString(),
                               LostLeads = dr["LostLeads"].ToString(),
                               Converted_Lead = dr["JobWon"].ToString(),
                               InProgressLeads = dr["Total_Lead_InProgress"].ToString(),
                               NewLeads = dr["NewLeads"].ToString(),
                               TotalMaterialValue = dr["TotalMaterialValue"].ToString(),
                               TotalLabourValue = dr["TotalLabourValue"].ToString(),
                               DealerRating = dr["DealerRating"].ToString(),
                               TotalJobValue = dr["ber_totaljobvalue"].ToString()

                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {

                        oLogger.Log("MobileIntService", "TerritorySummary", "No Record Found for Depot " + DCode + " and TrCode " + TrCode + " ", "No Record Found");

                    }


                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "TerritorySummary", "Exception: " + ex.ToString(), "Problem while fetching info for  Depot " + DCode + " and TrCode " + TrCode + "");
                }
            }
            return LPS;
        }


        public List<OverTradeVolumeSummary> OverTradeVolume_Summary(string DlrCode)
        {

            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<OverTradeVolumeSummary> LPS = new List<OverTradeVolumeSummary>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec OverTrade_Volume_Summary_Suvidha_Dealer @AccountNumber = '" + DlrCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new OverTradeVolumeSummary()
                           {
                               Product = dr["Product"].ToString(),
                               SellOutValue = dr["Sell-Out Value"].ToString(),
                               OvertradeQty = dr["Overtrade Qty"].ToString(),
                               OTClearQty = dr["OTClearQty"].ToString()
                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "OverTradeVolume_Summary", "No Record Found for Dealer : " + DlrCode + "", "No Record Found");
                    }

                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "OverTradeVolume_Summary", "Exception: " + ex.ToString(), "Problem while fetching info for Dealer " + DlrCode + "");
                }
            }
            return LPS;
        }


        public List<LiftAndWinPointsSummary> LiftAndWinPoints_Summary(string DlrCode)
        {

            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<LiftAndWinPointsSummary> LPS = new List<LiftAndWinPointsSummary>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec Lift_and_Win_Points_Summary_For_Suvidha_Dealer @AccountNumber = '" + DlrCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new LiftAndWinPointsSummary()
                           {
                               PainterID = dr["PainterID"].ToString(),
                               PainterMobileNo = dr["PainterMobileNo"].ToString(),
                               PainterName = dr["PainterName"].ToString(),
                               TotalSellOutVol = dr["Total_Sell_out_Vol"].ToString(),
                               MDTPoint = dr["MDTPoint"].ToString(),
                               YTDPoint = dr["YTDPoint"].ToString()
                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "LiftAndWinPoints_Summary", "No Record Found for Dealer : " + DlrCode + "", "No Record Found");
                    }

                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "LiftAndWinPoints_Summary", "Exception: " + ex.ToString(), "Problem while fetching info for Dealer " + DlrCode + "");
                }
            }
            return LPS;
        }


        #region List of Dealers by Depot-Code and Territory-Code
        public List<DealerList> DealerList(string DepotCode, string TerritoryCode)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<DealerList> DLists = new List<DealerList>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_GetDealerList @DepotCode = '" + DepotCode + "', @TerritoryCode = '" + TerritoryCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    DLists = (from DataRow dr in dtA.Rows
                              select new DealerList()
                              {
                                  DealerCode = dr["AccountNumber"].ToString(),
                                  Name = dr["Name"].ToString()
                              }).ToList();

                    int RecordCount = 0;
                    RecordCount = DLists.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "DealerList", "No Record Found for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + " ", "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "DealerList", "Exception: " + ex.ToString(), "Problem while fetching info for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + "");
                }
            }
            return DLists;
        }

        #endregion



        #region Product Wise Points Summary
        public List<ProductWisePointsSummary> ProductWisePointsSummary(string DealerCode, string PainterMobile)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<ProductWisePointsSummary> DLists = new List<ProductWisePointsSummary>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_ProductWisePointsSummary @DealerCode = '" + DealerCode + "', @PainterMobile = '" + PainterMobile + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    DLists = (from DataRow dr in dtA.Rows
                              select new ProductWisePointsSummary()
                              {
                                  Product = "" + dr["ber_productIdName"],
                                  VolConsideredForPoints = "" + dr["Vol_considered_for_Points"],
                                  VolumeUnderOTHold = "" + dr["Volume_under_OT_Hold"],
                                  TotalPoints = "" + dr["TotalPoints"]
                              }).ToList();

                    int RecordCount = 0;
                    RecordCount = DLists.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "ProductWisePointsSummary", "No Record Found for Dealer-Code: " + DealerCode + " and Painter-Mobile: " + PainterMobile + " ", "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "ProductWisePointsSummary", "Exception: " + ex.ToString(), "Problem while fetching info for Dealer-Code: " + DealerCode + " and Painter-Mobile: " + PainterMobile + "");
                }
            }
            return DLists;
        }

        #endregion


        #region Painter Summary For Territory   
        public List<PainterSummaryForTerritory> PainterSummaryForTerritory(string DepotCode, string TerritoryCode)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<PainterSummaryForTerritory> DLists = new List<PainterSummaryForTerritory>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_PainterSummaryForTerritory @DepotCode = '" + DepotCode + "', @TerritoryCode = '" + TerritoryCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    DLists = (from DataRow dr in dtA.Rows
                              select new PainterSummaryForTerritory()
                              {
                                  PainterID = "" + dr["PainterID"],
                                  PainterMobileNo = "" + dr["PainterMobileNo"],
                                  PainterName = "" + dr["PainterName"],
                                  PainterCategory = dr["PainterCategory"].ToString(),
                                  NewLeads = dr["NewLeads"].ToString(),
                                  ConvertedLeads = "" + dr["ConvertedLead"],
                                  InProgress = "" + dr["InProgress"],
                                  LostLeads = "" + dr["Lost"],
                                  TotalLeads = "" + dr["TotalLeads"],
                                  TotalJobValue = "" + dr["TotalJobValue"],
                                  TotalMaterialValue = dr["TotalMaterialValue"].ToString(),
                                  TotalLabourValue = dr["TotalLabourValue"].ToString(),
                                  SanderVolume = dr["SanderVolume"].ToString(),
                                  PainterRating = dr["PainterRating"].ToString()
                              }
                              ).ToList();

                    int RecordCount = 0;
                    RecordCount = DLists.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "PainterSummaryForTerritory", "No Record Found for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + " ", "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "PainterSummaryForTerritory", "Exception: " + ex.ToString(), "Problem while fetching info for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + "");
                }
            }
            return DLists;
        }

        #endregion


        #region Lead Summary For Painter By Painter-Mobile 
        public List<LeadSummaryForPainterByMobile> LeadSummaryForPainterByMobile(string MobileNo)
        {
            GetConfigurationData();

            List<LeadSummaryForPainterByMobile> mp = new List<LeadSummaryForPainterByMobile>();
            try
            {
                string Fxml = @"
                    <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='lead'>
                        <attribute name='subject' />
                        <attribute name='lastname' />
                        <attribute name='firstname' />
                        <attribute name='telephone1' />
                        <attribute name='ber_depotid' />
                        <attribute name='createdon' />
                        <attribute name='ber_leadtype' />
                        <attribute name='statuscode' />
                        <attribute name='statecode' />
                        <attribute name='ber_startdate' />
                        <attribute name='ber_enddate' />
                        <attribute name='ber_totaljobvalue' />
                        <attribute name='ber_appointmentdate' />
                        <attribute name='description' />
                        <attribute name='ber_capturejobcompleteddate' />
                        <attribute name='ber_painterallocationdate'/>
                        <attribute name='ber_tmaterialcost' />
                        <attribute name='ber_tlabourcost' />
                        <order attribute='fullname' descending='false' />
                        <attribute name='ber_salutation'/>
                        <link-entity name='contact' from='contactid' to='ber_masterpainterid' alias='ab'>
                          <attribute name='mobilephone' />
                          <attribute name='pager' />
                          <attribute name='fullname' />                       
                        <filter type='and'>
                                <condition attribute='ber_customertype' operator='eq' value='278290001' />
                                <condition attribute='mobilephone' operator='eq' value='" + MobileNo + @"' />
                              </filter>
                        </link-entity>
                        <link-entity name='account' from='accountid' to='ber_dealerid' alias='ac'>
                          <attribute name='accountnumber' />
                          <attribute name='name' />
                          <filter type='and'>
                            <condition attribute='parentaccountid' operator='null' />                            
                          </filter>
                        </link-entity>
                      </entity>
                    </fetch>";

                EntityCollection result = Orgservice.RetrieveMultiple(new FetchExpression(Fxml));
                int RecordCount = result.Entities.Count;
                int i = 0;
                LeadSummaryForPainterByMobile[] mpDetails = new LeadSummaryForPainterByMobile[RecordCount];
                if (RecordCount > 0)
                {

                    foreach (var c in result.Entities)
                    {
                        mpDetails[i] = new LeadSummaryForPainterByMobile();
                        if (c.Contains("ac.name"))
                            mpDetails[i].Dealer = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ac.name"]).Value.ToString();

                        if (c.Contains("ber_depotid"))
                            mpDetails[i].Depot = ((Microsoft.Xrm.Sdk.EntityReference)c.Attributes["ber_depotid"]).Name;
                        if (c.Contains("firstname"))
                            mpDetails[i].Firstname = "" + c.Attributes["firstname"];
                        if (c.Contains("lastname"))
                            mpDetails[i].Lastname = "" + c.Attributes["lastname"];
                        if (c.Contains("telephone1"))
                            mpDetails[i].Telephone = "" + c.Attributes["telephone1"];
                        if (c.Contains("createdon"))
                            mpDetails[i].LeadEntryDate = "" + c.Attributes["createdon"];
                        if (c.Contains("statuscode"))
                            mpDetails[i].Statuscode = "" + c.FormattedValues["statuscode"];
                        if (c.Contains("ab.pager"))
                            mpDetails[i].PainterID = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.pager"]).Value.ToString();
                        if (c.Contains("ab.mobilephone"))
                            mpDetails[i].PainterMobileNo = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.mobilephone"]).Value.ToString();
                        if (c.Contains("subject"))
                            mpDetails[i].LeadId = "" + c.Attributes["subject"];
                        if (c.Contains("ber_leadtype"))
                            mpDetails[i].Leadtype = "" + c.FormattedValues["ber_leadtype"];
                        if (c.Contains("ab.fullname"))
                            mpDetails[i].PainterName = ((Microsoft.Xrm.Sdk.AliasedValue)c.Attributes["ab.fullname"]).Value.ToString();
                        if (c.Contains("ber_salutation"))
                            mpDetails[i].PainterSalutation = "" + c.FormattedValues["ber_salutation"];
                        /*Added by Dhiman */
                        if (c.Contains("ber_startdate"))
                        {
                            mpDetails[i].Startdate = "" + c.FormattedValues["ber_startdate"];
                        }
                        if (c.Contains("ber_enddate"))
                        {
                            mpDetails[i].EndDate = "" + c.FormattedValues["ber_enddate"];
                        }
                        if (c.Contains("ber_totaljobvalue"))
                        {
                            string strTotalJobValue = "" + c.FormattedValues["ber_totaljobvalue"];
                            mpDetails[i].TotalJobValue = "" + ReduceCurrencyFromValue(strTotalJobValue);
                        }
                        else
                        {
                            mpDetails[i].TotalJobValue = "0";
                        }
                        if (c.Contains("statecode"))
                        {
                            mpDetails[i].StateCode = "" + c.FormattedValues["statecode"];
                        }
                        if (c.Contains("ber_appointmentdate"))
                        {
                            mpDetails[i].AppointmentDate = "" + c.FormattedValues["ber_appointmentdate"];
                        }
                        if (c.Contains("description"))
                        {
                            mpDetails[i].Description = "" + c.Attributes["description"];
                        }
                        if (c.Contains("ber_capturejobcompleteddate"))
                        {
                            mpDetails[i].CaptureJobCompletedDate = "" + c.FormattedValues["ber_capturejobcompleteddate"];
                        }
                        if (c.Contains("ber_painterallocationdate"))
                            mpDetails[i].LeadAssignmentDate = Convert.ToString(c.FormattedValues["ber_painterallocationdate"]);

                        if (c.Contains("ber_tmaterialcost"))
                        {
                            mpDetails[i].MaterialValue = "" + c.FormattedValues["ber_tmaterialcost"];
                        }
                        else
                        {
                            mpDetails[i].MaterialValue = "0";
                        }

                        if (c.Contains("ber_tlabourcost"))
                        {
                            mpDetails[i].LabourValue = "" + c.FormattedValues["ber_tlabourcost"];
                        }
                        else
                        {
                            mpDetails[i].LabourValue = "0";
                        }

                        i++;
                    }

                    mp = mpDetails.ToList();

                }
                else
                {
                    oLogger.Log("MobileIntService", "LeadSummaryForPainterByMobile", "No Record Found for the Mobile-No: " + MobileNo + "", "No Record Found");
                }

            }

            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "LeadSummaryForPainterByMobile", "Exception: " + ex.ToString(), "Problem while fetching Painter Info for Mobile-No: " + MobileNo + "");
            }
            return mp;
        }
        #endregion


        #region Lead Summary By Appointment Date
        public List<LeadSummaryByAppointmentDate> LeadSummaryByAppointmentDate(string AppointmentDate)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<LeadSummaryByAppointmentDate> LPS = new List<LeadSummaryByAppointmentDate>();

            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec SP_LeadSummaryByAppointmentDate @AppointmentDate = '" + AppointmentDate + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new LeadSummaryByAppointmentDate()
                           {
                               AppointmentDate = dr["AppointmentDate"].ToString(),
                               CaptureJobCompletedDate = dr["CaptureJobCompletedDate"].ToString(),
                               Dealer = dr["Dealer"].ToString(),
                               Depot = dr["Depot"].ToString(),
                               Description = dr["Description"].ToString(),
                               EndDAte = dr["EndDAte"].ToString(),
                               FirstName = dr["FirstName"].ToString(),
                               LastName = dr["LastName"].ToString(),
                               LeadAssignmentDate = dr["LeadAssignmentDate"].ToString(),
                               LeadEntryDate = dr["LeadEntryDate"].ToString(),
                               LeadId = dr["LeadId"].ToString(),
                               LeadType = dr["LeadType"].ToString(),
                               PainterID = dr["PainterID"].ToString(),
                               PainterMobileNumber = dr["PainterMobileNumber"].ToString(),
                               PainterName = dr["PainterName"].ToString(),
                               PainterSalutation = dr["PainterSalutation"].ToString(),
                               StartDate = dr["StartDate"].ToString(),
                               StateCode = dr["StateCode"].ToString(),
                               StatusCode = dr["StatusCode"].ToString(),
                               Telephone = dr["Telephone"].ToString(),
                               TotalJobValue = dr["TotalJobValue"].ToString(),
                               DepotNumber = dr["DepotNumber"].ToString(),
                               Territory = dr["Territory"].ToString(),
                               CustomerAddress = dr["CustomerAddress"].ToString(),
                               CustomerMobile = dr["CustomerMobile"].ToString(),
                               CustomerPinCode = dr["CustomerPinCode"].ToString()

                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {

                        oLogger.Log("MobileIntService", "LeadSummaryByAppointmentDate", "No Record Found for the Appointment-Date: " + AppointmentDate, "No Record Found");

                    }


                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "LeadSummaryByAppointmentDate", "Exception: " + ex.ToString(), "Problem while fetching Info for Appointment-Date: " + AppointmentDate);
                }
            }
            return LPS;
        }
        #endregion


        #region Painter Summery For DG
        public List<PainterSummeryForDG> PainterSummeryForDG(string DepotCode, string TerritoryCode, string DgMobileNo)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<PainterSummeryForDG> LPS = new List<PainterSummeryForDG>();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec SP_PainterSummeryForDG @DepotCode = '" + DepotCode + "', @TerritoryCode = '" + TerritoryCode + "', @DgMobileNo = '" + DgMobileNo + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new PainterSummeryForDG()
                           {
                               DgFullName = dr["DgFullName"].ToString(),
                               DgId = dr["DgId"].ToString(),
                               DgMobileNo = dr["DgMobileNo"].ToString(),
                               Painter_Name = dr["Painter_Name"].ToString(),
                               PainterMobile = dr["PainterMobile"].ToString(),
                               SanderVolume = dr["SanderVolume"].ToString(),
                               LostLeads = dr["LostLeads"].ToString(),
                               Converted_Lead = dr["JobWon"].ToString(),
                               InProgressLeads = dr["Total_Lead_InProgress"].ToString(),
                               NewLeads = dr["NewLeads"].ToString(),
                               TotalLeads = dr["TotalXPLeads"].ToString(),
                               TotalJobValue = dr["ber_totaljobvalue"].ToString(),
                               TotalMaterialValue = dr["TotalMaterialValue"].ToString(),
                               TotalLabourValue = dr["TotalLabourValue"].ToString()

                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {

                        oLogger.Log("MobileIntService", "PainterSummeryForDG", "No Record Found for DgMobileNo " + DgMobileNo + "", "No Record Found");

                    }

                }

                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "PainterSummeryForDG", "Exception: " + ex.ToString(), "Problem while Dealer Info for DgMobileNo : " + DgMobileNo + "");
                }
            }
            return LPS;
        }
        #endregion


        #region  Dg Summary By Depot And Territory
        public List<DgSummaryByDepotAndTerritory> DgSummaryByDepotAndTerritory(string DepotCode, string TerritoryCode)
        {
            GetConfigurationData();
            DataTable dtA = new DataTable();
            List<DgSummaryByDepotAndTerritory> LPS = new List<DgSummaryByDepotAndTerritory>();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string query_text = @"exec sp_DgSummaryByDepotAndTerritory @DepotCode = '" + DepotCode + "', @TerritoryCode = '" + TerritoryCode + "'";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                    LPS = (from DataRow dr in dtA.Rows
                           select new DgSummaryByDepotAndTerritory()
                           {
                               DgFullName = dr["DgFullName"].ToString(),
                               DgId = dr["DgId"].ToString(),
                               DgMobileNo = dr["DgMobileNo"].ToString(),
                               LostLeads = dr["LostLeads"].ToString(),
                               Converted_Lead = dr["JobWon"].ToString(),
                               InProgressLeads = dr["Total_Lead_InProgress"].ToString(),
                               NewLeads = dr["NewLeads"].ToString(),
                               TotalLeads = dr["TotalXPLeads"].ToString(),
                               TotalJobValue = dr["ber_totaljobvalue"].ToString(),
                               TotalMaterialValue = dr["TotalMaterialValue"].ToString(),
                               TotalLabourValue = dr["TotalLabourValue"].ToString()

                           }).ToList();

                    int RecordCount = 0;
                    RecordCount = LPS.Count;
                    if (RecordCount <= 0)
                    {
                        oLogger.Log("MobileIntService", "DgSummaryByDepotAndTerritory", "No Record Found for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + " ", "No Record Found");
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "DgSummaryByDepotAndTerritory", "Exception: " + ex.ToString(), "Problem while fetching info for Depot-Code: " + DepotCode + " and Territory-Code: " + TerritoryCode + "");
                }
            }
            return LPS;
        }
        #endregion


        #region Set Lead Status
        public string SetLeadStatus(string LeadID, string StatusCode)
        {
            string ReturnValue = "0";
            GetConfigurationData();
            using (SqlConnection conn = new SqlConnection(_dbConnectionString))
            {
                try
                {
                    conn.Open();
                    string SelectQuery = "select count(1) from BergerUAT_MSCRM.dbo.LeadBase where [Subject] = '" + LeadID + "'";
                    SqlCommand cmdSelect = new SqlCommand(SelectQuery, conn);
                    int RecordExists = int.Parse("" + cmdSelect.ExecuteScalar());
                    if (RecordExists > 0)
                    {
                        string UpdateQuery = @"update BergerUAT_MSCRM.dbo.LeadBase set StatusCode = '" + StatusCode + "' where [Subject] = '" + LeadID + "'";
                        SqlCommand cmd = new SqlCommand(UpdateQuery, conn);
                        cmd.ExecuteNonQuery();
                    }
                    else
                    {
                        oLogger.Log("MobileIntService", "SetLeadStatus", "No Record Found for the LeadID : " + LeadID, "No Record Found");
                        ReturnValue = "No Record Found for the LeadID : " + LeadID;
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "SetLeadStatus", "Exception: " + ex.ToString(), "Problem while updating Lead Status for the LeadId : " + LeadID + " and StatusCode = " + StatusCode);
                    ReturnValue = "Error while executing the method SetLeadStatus(). The error details as follows : \n " + ex.ToString();
                }
            }
            return ReturnValue;
        }
        #endregion


        #region CE Monitoring Report In HTML Output
        public Stream CEMonitoringReport(string OutputType = "html")
        {
            byte[] resultBytes = Encoding.UTF8.GetBytes("");
            GetConfigurationData();
            DataTable dtA = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection(_dbConnectionString))
                {

                    conn.Open();
                    string query_text = @"exec SP_HTML_CEMonitoringReport;";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    SqlDataReader reader = command.ExecuteReader();
                    dtA.Load(reader);
                }
                int RecordCount = dtA.Rows.Count;
                /*---------------------------------------------------*/
                string html = "";
                foreach (DataRow dr in dtA.Rows)
                {
                    foreach (DataColumn dc in dr.Table.Columns)
                    {
                        html += "" + dr[dc];
                    }
                }
                if (RecordCount > 0)
                {
                    resultBytes = Encoding.UTF8.GetBytes(html);
                    if (OutputType.Trim().Equals("xl", StringComparison.CurrentCultureIgnoreCase))
                    {
                        String headerInfo = "attachment; filename=" + "CEMonitoringReport" + "." + "xls";
                        WebOperationContext.Current.OutgoingResponse.Headers["Content-Disposition"] = headerInfo;
                        WebOperationContext.Current.OutgoingResponse.ContentType = "application/octet-stream";
                        WebOperationContext.Current.OutgoingResponse.Headers["Content-Length"] = resultBytes.Length.ToString();
                    }
                    else
                    {
                        WebOperationContext.Current.OutgoingResponse.ContentType = "text/html";
                    }
                }
                else
                {
                    oLogger.Log("MobileIntService", "CEMonitoringReport", "No Record Found", "No Record Found");
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "CEMonitoringReport", "Exception: " + ex.ToString(), "Problem while fetching data forCEMonitoringReport");
            }

            return new MemoryStream(resultBytes);
        }

        #endregion


        //-------------------------------------Update for Token Services-----------------------------------------

        #region Create Token Redemption
        public string CreateTokenRedemtion(string Mobile, string TokenNumber, string Source)
        {
            string result = string.Empty;
            DataTable PainterTable = null;
            DataTable PainterMeetTable = new DataTable();

            if (string.IsNullOrEmpty(TokenNumber) && string.IsNullOrEmpty(Mobile))
            {
                result = ConfigurationManager.AppSettings["MobileOrTokenNotProvide"].ToString();
                CreateTokenLog(result, Mobile, TokenNumber);
                return result;
            }

            #region [Check Token]
            QueryExpression tokenQuery = new QueryExpression("ber_tokenmaster");
            tokenQuery.NoLock = true;
            tokenQuery.ColumnSet = new ColumnSet(true);
            tokenQuery.Criteria.AddCondition(new ConditionExpression("ber_tokenkeyno", ConditionOperator.Equal, TokenNumber));
            EntityCollection tokenCollection = Orgservice.RetrieveMultiple(tokenQuery);
            if (tokenCollection.Entities.Count <= 0)
            {
                result = ConfigurationManager.AppSettings["InvalidToken"].ToString();  //Return if token not found
                CreateTokenLog(result, Mobile, TokenNumber);
                return result;
            }
            else
            {
                if (((OptionSetValue)tokenCollection.Entities[0].Attributes["statuscode"]).Value != 1)
                {
                    result = ConfigurationManager.AppSettings["TokenConsumed"].ToString();  //Return if token already redemed                    
                    CreateTokenLog(result, Mobile, TokenNumber);
                    return result;
                }
                else
                {
                    if (!tokenCollection.Entities[0].Attributes.Contains("ber_expiredate"))
                    {
                        result = ConfigurationManager.AppSettings["InvalidTokenExpireDateNotfound"].ToString();  //Return if ExpireDate not found                    
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }

                    #region Check Token Expiry date
                    DateTime expireDate = Convert.ToDateTime(tokenCollection.Entities[0].Attributes["ber_expiredate"]);
                    DateTime today = DateTime.Today;
                    //string _today = today.ToString("MM/dd/yyyy");
                    //string _expireDate = expireDate.ToString("MM/dd/yyyy");
                    if (today > expireDate)
                    {
                        SetStateRequest setStateRequest = new SetStateRequest()
                        {
                            EntityMoniker = new EntityReference
                            {
                                Id = tokenCollection.Entities[0].Id,
                                LogicalName = tokenCollection.Entities[0].LogicalName,
                            },
                            State = new OptionSetValue(1),
                            Status = new OptionSetValue(278290000)
                        };
                        Orgservice.Execute(setStateRequest);
                        result = ConfigurationManager.AppSettings["TokenExpired"].ToString();  //Return if token already redemed
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }
                    #endregion

                    #region Check Token Type
                    EntityReference tokenTypeMaster = null;
                    tokenTypeMaster = (EntityReference)tokenCollection.Entities[0].Attributes["ber_tokentype"];
                    if (tokenTypeMaster == null)
                    {
                        result = ConfigurationManager.AppSettings["InvalidToken"].ToString();  //Return if token type not found
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }

                    int _tokenType = 0;
                    Entity tokenTypeMasterEntity = Orgservice.Retrieve(tokenTypeMaster.LogicalName, tokenTypeMaster.Id, new ColumnSet(new string[] { "ber_customertype" }));
                    if (tokenTypeMasterEntity != null)
                    {
                        _tokenType = ((OptionSetValue)tokenTypeMasterEntity.Attributes["ber_customertype"]).Value;
                    }
                    #endregion

                    if (_tokenType == 1) //Check for Dealer
                    {
                        #region [Check Delear]

                        string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["InitialCatalog"] + ";Integrated Security=True";
                        using (SqlConnection con = new SqlConnection(dbConnectionString))
                        {
                            try
                            {
                                string command = "select accountid from Account where ParentAccountId is null and StateCode=0 and (Telephone1='" + Mobile + "' or  Telephone2='" + Mobile + "' or Address1_Telephone1='" + Mobile + "' or Telephone3='" + Mobile + "')";
                                SqlCommand cm = new SqlCommand(command, con);
                                SqlDataAdapter da = new SqlDataAdapter(cm);
                                DataTable DealerTable = new DataTable();
                                da.Fill(DealerTable);
                                if (DealerTable.Rows.Count <= 0 || DealerTable.Rows.Count > 1)
                                {
                                    result = ConfigurationManager.AppSettings["DealerNotFound"].ToString();
                                    CreateTokenLog(result, Mobile, TokenNumber);
                                    return result;
                                }
                                CreateTokenRedemptioninCRM(DealerTable, result, TokenNumber, Source, tokenCollection, Mobile);
                            }
                            catch (Exception ex)
                            {
                                result = ex.Message;
                                CreateTokenLog(result, Mobile, TokenNumber);
                                oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with fetch account.");
                            }
                        }
                        #endregion
                    }
                    else// check for Painter
                    {
                        Guid painterGuid = Guid.Empty;
                        Guid subPainterGuid = Guid.Empty;

                        try
                        {
                            #region [Check for Sub Painter]
                            DataTable subPainterTable = null;
                            string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["InitialCatalog"] + ";User Id = crmdbuser;Password=Berger@1234";
                            using (SqlConnection con = new SqlConnection(dbConnectionString))
                            {
                                try
                                {
                                    con.Open();
                                    string command = "select ber_parentpainter,contactid from Contact where StateCode=0 and mobilephone='" + Mobile + "' and (ber_subdealer=0 or ber_subdealer is null) and ber_customertype=278290001 and ber_parentpainter is not null";
                                    SqlCommand cm = new SqlCommand(command, con);
                                    SqlDataAdapter da = new SqlDataAdapter(cm);
                                    subPainterTable = new DataTable();
                                    da.Fill(subPainterTable);
                                    if (subPainterTable.Rows.Count > 0)
                                    {
                                        painterGuid = new Guid(subPainterTable.Rows[0][0].ToString());
                                        subPainterGuid = new Guid(subPainterTable.Rows[0]["contactid"].ToString());
                                    }
                                }
                                catch (Exception ex)
                                {
                                    result = ex.Message;
                                    CreateTokenLog(result, Mobile, TokenNumber);
                                    oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with fetch contact info");
                                }
                            }
                            #endregion
                            if (painterGuid == Guid.Empty)
                            {
                                #region [Check Painter]
                                using (SqlConnection con = new SqlConnection(dbConnectionString))
                                {
                                    try
                                    {
                                        con.Open();
                                        //string command1 = "select contactid from Contact where StateCode=0 and mobilephone='" + Mobile + "' and ber_subdealer=0 and ber_customertype=278290001";
                                        string command1 = "select contactid from Contact where StateCode=0 and mobilephone='" + Mobile + "' and (ber_subdealer=0 or isnull(ber_subdealer,'') = '') and ber_customertype=278290001";

                                        SqlCommand cm = new SqlCommand(command1, con);
                                        SqlDataAdapter da = new SqlDataAdapter(cm);
                                        PainterTable = new DataTable();
                                        da.Fill(PainterTable);

                                        if (PainterTable.Rows.Count <= 0)
                                        {
                                            result = ConfigurationManager.AppSettings["PainterNotFound"].ToString();
                                            CreateTokenLog(result, Mobile, TokenNumber);
                                            return result;
                                        }
                                        else
                                        {
                                            painterGuid = new Guid(PainterTable.Rows[0][0].ToString());
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        result = ex.Message;
                                        CreateTokenLog(result, Mobile, TokenNumber);
                                        oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with fetch contact info");
                                    }
                                }
                            }

                           
                            #endregion

                            if (painterGuid != Guid.Empty)
                            {
                                #region [Get PainterMeet]

                                string PainterMeetCommand = "select ber_paintermeetId from ber_paintermeet  as pm inner join ber_paintermeetcontact as pmc on pm.ber_paintermeetId=pmc.ber_PainterMeet " +
                                                            "inner join ber_meet as m on pm.ber_Meet=m.ber_meetId and m.statecode=0  where pmc.statecode=0 and pmc.ber_Contact='" + painterGuid.ToString() + "' and m.ber_PainterCall=1 and m.ber_SchemeRequired=1" +
                                                            "or(m.ber_FinalPointCalculationDate > GETDATE() and m.ber_FinalPointCalculationDate is null) and pm.ber_MeetType=278290002";
                                using (SqlConnection con = new SqlConnection(dbConnectionString))
                                {
                                    try
                                    {
                                        con.Open();
                                        SqlCommand cm = new SqlCommand(PainterMeetCommand, con);
                                        SqlDataAdapter da = new SqlDataAdapter(cm);
                                        da.Fill(PainterMeetTable);
                                        if (PainterMeetTable.Rows.Count <= 0)
                                        {
                                            result = ConfigurationManager.AppSettings["PainterNotFound"].ToString();
                                            CreateTokenLog(result, Mobile, TokenNumber);
                                            return result;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        result = ex.Message;
                                        CreateTokenLog(result, Mobile, TokenNumber);
                                        oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with fetch painter meet");

                                    }
                                }
                                #endregion

                                #region [Get linked Dealer]
                                DataTable DealerTable = new DataTable();
                                string dealerCommand = "select accountid from Account a inner join ber_depot as d on a.ber_DepotId=d.ber_depotId " +
                                                        "where a.ParentAccountId is null and a.StateCode=0 and a.accountclassificationcode=1 and a.ber_mpdealer=1 " +
                                                        "and d.ber_CityId=(select c.ber_cityId from ber_city as c inner join ber_depot as dp on c.ber_cityId=dp.ber_CityId " +
                                                        "where dp.ber_depotId=(select ber_depot from ber_paintermeet where ber_paintermeetId='" + new Guid(PainterMeetTable.Rows[0][0].ToString()) + "'))";
                                using (SqlConnection con = new SqlConnection(dbConnectionString))
                                {
                                    try
                                    {
                                        con.Open();
                                        SqlCommand cm = new SqlCommand(dealerCommand, con);
                                        SqlDataAdapter da = new SqlDataAdapter(cm);
                                        da.Fill(DealerTable);
                                    }
                                    catch (Exception ex)
                                    {
                                        result = ex.Message;
                                        CreateTokenLog(result, Mobile, TokenNumber);
                                        oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with fetch link dealer");
                                    }
                                }

                                #endregion

                                #region [Create Redemption]
                                Entity _tokenRedemtion = new Entity("ber_tokenredemption");
                                _tokenRedemtion.Attributes["ber_token"] = new EntityReference(tokenCollection.Entities[0].LogicalName, tokenCollection.Entities[0].Id);
                                _tokenRedemtion.Attributes["ber_painter"] = new EntityReference("contact", painterGuid);
                                _tokenRedemtion.Attributes["ber_tokennumber"] = TokenNumber;
                                switch (Source.ToLower())
                                {
                                    case "web": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(1); break;
                                    case "mobile": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(2); break;
                                    case "sms": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(3); break;
                                }
                                _tokenRedemtion.Attributes["ber_paintermeet"] = new EntityReference("ber_paintermeet", new Guid(PainterMeetTable.Rows[0][0].ToString()));
                                if (DealerTable.Rows.Count > 0)
                                {
                                    _tokenRedemtion.Attributes["ber_linkeddealer"] = new EntityReference("account", new Guid(DealerTable.Rows[0][0].ToString()));
                                }

                                if (subPainterGuid != Guid.Empty)
                                {
                                    _tokenRedemtion.Attributes["ber_subpainter"] = new EntityReference("contact", subPainterGuid);
                                }

                                Orgservice.Create(_tokenRedemtion);
                                result = ConfigurationManager.AppSettings["TokenConsumedSucess"].ToString();
                                CreateTokenLog(result, Mobile, TokenNumber);
                                #endregion
                            }
                        }
                        catch (Exception ex)
                        {
                            result = ex.Message;
                            CreateTokenLog(result, Mobile, TokenNumber);
                            oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem with creating Token redemption");
                        }
                    }
                }
            }

            return result;
        }
        #endregion

        #region Create Token Redemption in CRM
        private void CreateTokenRedemptioninCRM(DataTable dealerTable, string result, string TokenNumber, string source, EntityCollection tokenCollection, string Mobile)
        {
            try
            {
                Entity _tokenRedemtion = new Entity("ber_tokenredemption");
                _tokenRedemtion.Attributes["ber_token"] = new EntityReference(tokenCollection.Entities[0].LogicalName, tokenCollection.Entities[0].Id);
                _tokenRedemtion.Attributes["ber_dealer"] = new EntityReference("account", new Guid(dealerTable.Rows[0][0].ToString()));
                _tokenRedemtion.Attributes["ber_tokennumber"] = TokenNumber;
                switch (source.ToLower())
                {
                    case "web": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(1); break;
                    case "mobile": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(2); break;
                    case "sms": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(3); break;
                }

                Orgservice.Create(_tokenRedemtion);
                result = ConfigurationManager.AppSettings["TokenConsumedSucess"].ToString();
                CreateTokenLog(result, Mobile, TokenNumber);
            }
            catch (FaultException<IOrganizationService> ex)
            {
                result = ex.Message;
                CreateTokenLog(result, Mobile, TokenNumber);
                oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem while creating Token redemption in CRM");
            }
            catch (Exception ex)
            {
                result = ex.Message;
                CreateTokenLog(result, Mobile, TokenNumber);
                oLogger.Log("MobileIntService", "CreateTokenRedemtion", "Exception: " + ex.ToString(), "Problem while creating Token redemption in CRM.");
            }
        }
        #endregion
        #endregion

        //#region CreateTokenMaster
        //public String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate)
        //{
        //    string mess = string.Empty;
        //    string DBConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionDatabase"] + ";User ID=" + ConfigurationManager.AppSettings["UserID"] + ";Password=" + ConfigurationManager.AppSettings["Pwd"];
        //   // SqlConnection _sqlConnection = null;
        //    try
        //    {
        //        string insertCommand = "INSERT INTO Token_Master_Integration ([SrlNo],[TokenType],[Product],[PackSize],[Denomination],[TokenMonth],[TokenYear],[TokenKeyNo],tokenExpireDate,[Status])";
        //        using (SqlConnection conn = new SqlConnection(DBConnectionString))
        //        {
        //            try
        //            {
        //                conn.Open();
        //                #region Insert into Transaction Table
        //                insertCommand += "VALUES ('";
        //                insertCommand += SrlNo;
        //                insertCommand += "','" + TokenType;
        //                insertCommand += "','" + Product;
        //                insertCommand += "','" + PackSize;
        //                insertCommand += "','" + Denomination;
        //                insertCommand += "','" + TokenMonth;
        //                insertCommand += "','" + TokenYear;
        //                insertCommand += "','" + TokenKeyNo;
        //                insertCommand += "','" + ExpireDate;
        //                insertCommand += "','R')";
        //                SqlCommand sqlCmd = new SqlCommand(insertCommand, conn);
        //                int i = sqlCmd.ExecuteNonQuery();
        //                mess = "Success";
        //                #endregion
        //            }
        //            catch (Exception ex)
        //            {
        //                oLogger.Log("MobileIntService", "CreateTokenMaster", "Exception: " + ex.ToString(), "Problem with creating Token master in CRM");
        //                return ex.Message;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        oLogger.Log("MobileIntService", "CreateTokenMaster", "Exception: " + ex.ToString(), "Problem while creating Token Master");
        //        return ex.Message;
        //    }
        //    return mess;
        //}
        //#endregion

        #region CreateTokenMaster
        public String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate)
        {
            GetConfigurationData();
            string mess = "Failed";
            string DBConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"];
            DBConnectionString += "; Initial Catalog=" + ConfigurationManager.AppSettings["TransactionDatabase"];
            DBConnectionString += "; User ID=" + ConfigurationManager.AppSettings["UserID"];
            DBConnectionString += "; Password=" + ConfigurationManager.AppSettings["Pwd"];
            try
            {
                using (SqlConnection conn = new SqlConnection(DBConnectionString))
                {
                    try
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand("dbo.SP_BD_CreateTokenMaster", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@SrlNo", SrlNo);
                        cmd.Parameters.AddWithValue("@TokenType", TokenType);
                        cmd.Parameters.AddWithValue("@Product", Product);
                        cmd.Parameters.AddWithValue("@PackSize", PackSize);
                        cmd.Parameters.AddWithValue("@Denomination", Denomination);
                        cmd.Parameters.AddWithValue("@TokenMonth", TokenMonth);
                        cmd.Parameters.AddWithValue("@TokenYear", TokenYear);
                        cmd.Parameters.AddWithValue("@TokenKeyNo", TokenKeyNo);
                        cmd.Parameters.AddWithValue("@ExpireDate", ExpireDate);
                        cmd.Parameters.AddWithValue("@Status", "R");
                        cmd.ExecuteNonQuery();
                        mess = "Success";
                    }
                    catch (Exception ex)
                    {
                        oLogger.Log("MobileIntService", "CreateTokenMaster", "Exception: " + ex.ToString(), "Problem with creating Token master in CRM");
                        return ex.Message;
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "CreateTokenMaster", "Exception: " + ex.ToString(), "Problem while creating Token Master");
                return ex.Message;
            }
            return mess;
        }
        #endregion



        #region Create Token log
        public void CreateTokenLog(string result, string mobile, string tokenNumber)
        {
            string[] item = new string[] { "Data Source=", ConfigurationManager.AppSettings["TransactionDataSource"], ";Initial Catalog=", ConfigurationManager.AppSettings["TransactionDatabase"], ";User ID=", ConfigurationManager.AppSettings["UserID"], ";Password=", ConfigurationManager.AppSettings["Pwd"] };
            using (SqlConnection conn = new SqlConnection(string.Concat(item)))
            {
                try
                {
                    conn.Open();
                    string query_text = "insert into Token_Service_log (ID,CustomerMobile,CustomerToken,Status,CreatedOn) Values('" + Guid.NewGuid() + "','" + mobile + "','" + tokenNumber + "','" + result + "','" + DateTime.Now + "')";
                    SqlCommand command = new SqlCommand(query_text, conn);
                    command.CommandType = CommandType.Text;
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    oLogger.Log("MobileIntService", "CreateTokenLog", "Exception: " + ex.ToString(), "Problem with creating log for token redemption.");
                }
            }
        }
        #endregion
        //-------------------------------------------------------------------------------------------------------

        //-------------------------------------Influencer -------------------------------------------------------
        #region [aidorganisationInsUpt]
        public string aidorganisationInsUpt(string AidName, string AidOrganizationOwerType, string AidOrganisationType, string AidMobile, string AidStreet1, string AidStree2, string AidPincCode)
        {
            GetConfigurationData();
            string Insertquery = string.Empty;
            string result = string.Empty;
            string iSUpdate = string.Empty;
            Entity _aidorganisation = new Entity("ber_aidorganisation");
            DataTable aidOrganizationTable = null;
            DataTable _CityState = null;
            DataTable _PinCode = null;
            string dbConnectionString = ConfigurationManager.ConnectionStrings["SQLDBConnectionString"].ConnectionString;
            try
            {
                #region [Retrive pincode Code GUiD]
                string commandQueryPinCode = "select top 1 p.ber_pincodeId,p.ber_name from [BPIL_MSCRM].dbo.ber_pincode p where p.ber_name = '" + AidPincCode + "'";
                _PinCode = GetDataTable(dbConnectionString, commandQueryPinCode);
                Guid PinCodeGuid = new Guid(_PinCode.Rows[0]["ber_pincodeId"].ToString());
                #endregion

                if (string.IsNullOrEmpty(AidMobile))
                {
                    result = returnValue("", "Mobile Number should not be blank");
                    return result;
                }

                if (_PinCode.Rows.Count < 1)
                {
                    result = returnValue("", "PinCode should not be blank");
                    return result;
                }



                #region [Checking Existing AidOrganization]

                string command = "select  a.ber_aidorganisationId,a.ber_MobileNumber from  [BPIL_MSCRM].dbo.ber_aidorganisationBase  a where a.ber_MobileNumber ='" + AidMobile + "' and a.statuscode = 1";

                aidOrganizationTable = GetDataTable(dbConnectionString, command);
                if (aidOrganizationTable.Rows.Count > 0)
                {
                    iSUpdate = aidOrganizationTable.Rows[0]["ber_MobileNumber"].ToString();
                }
                #endregion

                #region [Checking PinCode ]
                //string commandQuery = "SELECT c.ber_cityId as [CITY],c.ber_StateId as [STATE] FROM [BPIL_MSCRM].dbo.ber_city AS c WHERE (ber_cityId = (SELECT  ber_CityId FROM [BPIL_MSCRM].dbo.ber_pincode AS p WHERE (ber_name = '" + AidPincCode + "')))";
                string commandQuery = "SELECT c.ber_cityId as [CITY],c.ber_StateId as [STATE] FROM [BPIL_MSCRM].dbo.ber_city AS c WHERE (ber_cityId = (SELECT top 1 ber_CityId FROM [BPIL_MSCRM].dbo.ber_pincode AS p WHERE (ber_name = '" + AidPincCode + "') and statecode = 0 ))";
                _CityState = GetDataTable(dbConnectionString, commandQuery);
                Guid CityGuid = new Guid(_CityState.Rows[0]["CITY"].ToString());
                Guid StateGuid = new Guid(_CityState.Rows[0]["STATE"].ToString());
                #endregion


                if (iSUpdate == String.Empty)
                {
                    // Insert ber_aidorganisation
                    _aidorganisation.Attributes["ber_name"] = AidName;
                    _aidorganisation.Attributes["ber_organisationownertype"] = new OptionSetValue(Convert.ToInt32(AidOrganizationOwerType));
                    _aidorganisation.Attributes["ber_organisationtype"] = new OptionSetValue(Convert.ToInt32(AidOrganisationType));
                    _aidorganisation.Attributes["ber_mobilenumber"] = AidMobile;
                    _aidorganisation.Attributes["ber_street1"] = AidStreet1;
                    _aidorganisation.Attributes["ber_stree2"] = AidStree2;
                    _aidorganisation.Attributes["ber_pincode"] = new EntityReference("ber_pincode", PinCodeGuid);
                    _aidorganisation.Attributes["ber_city"] = new EntityReference("ber_city", CityGuid);
                    _aidorganisation.Attributes["ber_state"] = new EntityReference("ber_state", StateGuid);
                    result = Orgservice.Create(_aidorganisation).ToString();

                    result = returnValue(result, "INSERTED");
                    Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[AidorganisationInsUpt_log]([ber_name],[ber_organisationownertype],[ber_organisationtype],[ber_street1],[ber_stree2],[ber_pincode] ,[ber_city],[ber_state],[ErrorMsg],[Status],[CreatedOn]) VALUES ( '" + AidName + "','" + AidOrganizationOwerType + "','" + AidOrganizationOwerType + "','" + AidStreet1 + "','" + AidStree2 + "','" + AidPincCode + "','" + Convert.ToString(_CityState.Rows[0]["CITY"].ToString()) + "','" + _CityState.Rows[0]["STATE"].ToString() + "','','I','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
                    TransLogTable(dbConnectionString, Insertquery);


                }
                else if (iSUpdate != String.Empty)
                {
                    Guid aidorganisationId = new Guid(aidOrganizationTable.Rows[0]["ber_aidorganisationId"].ToString());
                    _aidorganisation.Id = aidorganisationId;
                    if (!string.IsNullOrEmpty(AidName))
                        _aidorganisation.Attributes["ber_name"] = AidName;

                    _aidorganisation.Attributes["ber_organisationownertype"] = new OptionSetValue(Convert.ToInt32(AidOrganizationOwerType));
                    _aidorganisation.Attributes["ber_organisationtype"] = new OptionSetValue(Convert.ToInt32(AidOrganisationType));

                    if (!string.IsNullOrEmpty(AidMobile))
                        _aidorganisation.Attributes["ber_mobilenumber"] = AidMobile;  //if blank then same as before 

                    if (!string.IsNullOrEmpty(AidStreet1))
                        _aidorganisation.Attributes["ber_street1"] = AidStreet1;

                    if (!string.IsNullOrEmpty(AidStree2))
                        _aidorganisation.Attributes["ber_stree2"] = AidStree2;

                    _aidorganisation.Attributes["ber_pincode"] = new EntityReference("ber_pincode", PinCodeGuid);
                    _aidorganisation.Attributes["ber_city"] = new EntityReference("ber_city", CityGuid);
                    _aidorganisation.Attributes["ber_state"] = new EntityReference("ber_state", StateGuid);
                    Orgservice.Update(_aidorganisation);

                    result = returnValue(Convert.ToString(aidorganisationId), "Updated");
                    Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[AidorganisationInsUpt_log]([ber_name],[ber_organisationownertype],[ber_organisationtype],[ber_street1],[ber_stree2],[ber_pincode] ,[ber_city],[ber_state],[ErrorMsg],[Status],[CreatedOn]) VALUES ( '" + AidName + "','" + AidOrganizationOwerType + "','" + AidOrganizationOwerType + "','" + AidStreet1 + "','" + AidStree2 + "','" + AidPincCode + "','" + Convert.ToString(_CityState.Rows[0]["CITY"].ToString()) + "','" + _CityState.Rows[0]["STATE"].ToString() + "','','U','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
                    TransLogTable(dbConnectionString, Insertquery);

                }
            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                result = "Error";
                oLogger.Log("MobileIntService", "aidorganisationInsUpt", "Exception: " + ex.ToString(), "Problem with creating log for aidorganisation.");
            }
            catch (System.TimeoutException ex)
            {
                result = "Error";
                oLogger.Log("MobileIntService", "aidorganisationInsUpt", "Exception: " + ex.ToString(), "Problem with creating log for aidorganisation.");
            }
            catch (Exception ex)
            {
                result = "Error";
                oLogger.Log("MobileIntService", "aidorganisationInsUpt", "Exception: " + ex.ToString(), "Problem with creating log for token redemption.");

                Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[AidorganisationInsUpt_log]([ber_name],[ber_organisationownertype],[ber_organisationtype],[ber_street1],[ber_stree2],[ber_pincode] ,[ber_city],[ber_state],[ErrorMsg],[Status],[CreatedOn]) VALUES ( '" + AidName + "','" + AidOrganizationOwerType + "','" + AidOrganizationOwerType + "','" + AidStreet1 + "','" + AidStree2 + "','" + AidPincCode + "','" + Convert.ToString(_CityState.Rows[0]["CITY"].ToString()) + "','" + _CityState.Rows[0]["STATE"].ToString() + "','" + ex.ToString() + "','F','" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
                TransLogTable(dbConnectionString, Insertquery);
            }
            finally
            {
            }
            return result;
        }
        #endregion

        #region InfluencerInsUpt
        public string InfluencerInsUpt(string InfluencerOrganizationID, string InfluencerFirstName, string InfluencerMiddleName, string InfluencerLastName, string InfluencerType, string InfluencerMobileNumber, string InfluencerAddress, string Influencermailaddress)
        {
            GetConfigurationData();

            string Insertquery = string.Empty;
            string result = string.Empty;
            string iSUpdate = string.Empty;
            Entity _influencer = new Entity("ber_influencer");
            DataTable dtInfluncer = null;
            string dbConnectionString = ConfigurationManager.ConnectionStrings["SQLDBConnectionString"].ConnectionString;
            string InfluencerNameFullName = InfluencerFirstName + ' ' + InfluencerMiddleName + ' ' + InfluencerLastName;

            try
            {

                if (string.IsNullOrEmpty(InfluencerMobileNumber))
                {
                    result = returnValue("", "Mobile Number should not be blank");
                    return result;
                }

                string commandQuery = "select distinct inf.ber_influencerId, inf.ber_MobileNumber  from [BPIL_MSCRM].dbo.ber_influencerBase inf where inf.ber_MobileNumber = '" + InfluencerMobileNumber + "' and inf.ber_aidorganisation ='" + InfluencerOrganizationID + "' and statecode = 0";

                #region [Checking Influencer Mobile Exist]
                dtInfluncer = GetDataTable(dbConnectionString, commandQuery);
                if (dtInfluncer.Rows.Count > 0)
                {
                    iSUpdate = dtInfluncer.Rows[0]["ber_MobileNumber"].ToString();
                }
                #endregion
                if (iSUpdate == string.Empty)
                {
                    _influencer.Attributes["ber_aidorganisation"] = new EntityReference("ber_aidorganisation", new Guid(InfluencerOrganizationID)); // InfluencerOrganizationID;
                    _influencer.Attributes["ber_influencername"] = InfluencerNameFullName;
                    _influencer.Attributes["ber_firstname"] = InfluencerFirstName;
                    _influencer.Attributes["ber_middlename"] = InfluencerMiddleName;
                    _influencer.Attributes["ber_lastname"] = InfluencerLastName;
                    _influencer.Attributes["ber_influencertype"] = new OptionSetValue(Convert.ToInt32(InfluencerType));
                    _influencer.Attributes["ber_mobilenumber"] = InfluencerMobileNumber;
                    _influencer.Attributes["ber_address"] = InfluencerAddress;
                    _influencer.Attributes["ber_emailaddress"] = Influencermailaddress;
                    Orgservice.Create(_influencer);

                    Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[InfluencerInsUpt_log]([ber_Organisation],[ber_InfluencerName],[ber_FirstName],[ber_MiddleName],[ber_LastName],[ber_InfluencerType],[ber_MobileNumber],[ber_Address],[ber_emailaddress],[ErrorMsg],[Status],[CreatedOn]) " +
                    "VALUES('" + InfluencerOrganizationID + "','" + InfluencerNameFullName + "','" + InfluencerFirstName + "','" + InfluencerMiddleName + "','" + InfluencerLastName + "','" + InfluencerType + "','" + InfluencerMobileNumber + "','" + InfluencerAddress + "', '"+ Influencermailaddress + "',  '','I','" + DateTime.Today.ToString("yyyy-MM-dd") + "')";
                    TransLogTable(dbConnectionString, Insertquery);

                    result = "Inserted";
                }
                else if (iSUpdate != String.Empty)
                {
                    Guid aidorganisationId = new Guid(dtInfluncer.Rows[0]["ber_influencerId"].ToString());
                    _influencer.Id = aidorganisationId;
                    _influencer.Attributes["ber_aidorganisation"] = new EntityReference("ber_aidorganisation", new Guid(InfluencerOrganizationID)); //InfluencerOrganizationID;

                    if (!string.IsNullOrEmpty(InfluencerNameFullName))
                        _influencer.Attributes["ber_influencername"] = InfluencerNameFullName;

                    if (!string.IsNullOrEmpty(InfluencerFirstName))
                        _influencer.Attributes["ber_firstname"] = InfluencerFirstName;

                    if (!string.IsNullOrEmpty(InfluencerMiddleName))
                        _influencer.Attributes["ber_middlename"] = InfluencerMiddleName;

                    if (!string.IsNullOrEmpty(InfluencerLastName))
                        _influencer.Attributes["ber_lastname"] = InfluencerLastName;

                    _influencer.Attributes["ber_influencertype"] = new OptionSetValue(Convert.ToInt32(InfluencerType));
                    _influencer.Attributes["ber_mobilenumber"] = InfluencerMobileNumber;

                    if (!string.IsNullOrEmpty(InfluencerAddress))
                        _influencer.Attributes["ber_address"] = InfluencerAddress;

                    if(!string.IsNullOrEmpty(Influencermailaddress))
                        _influencer.Attributes["ber_emailaddress"] = Influencermailaddress;

                    Orgservice.Update(_influencer);

                    Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[InfluencerInsUpt_log]([ber_Organisation],[ber_InfluencerName],[ber_FirstName],[ber_MiddleName],[ber_LastName],[ber_InfluencerType],[ber_MobileNumber],[ber_Address],[ber_emailaddress],[ErrorMsg],[Status],[CreatedOn]) " +
                    "VALUES('" + InfluencerOrganizationID + "','" + InfluencerNameFullName + "','" + InfluencerFirstName + "','" + InfluencerMiddleName + "','" + InfluencerLastName + "','" + InfluencerType + "','" + InfluencerMobileNumber + "','" + InfluencerAddress + "', '" + Influencermailaddress + "', ' ','U','" + DateTime.Today.ToString("yyyy-MM-dd") + "')";
                    TransLogTable(dbConnectionString, Insertquery);
                    result = "Updated";
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "InfluencerInsUpt", "No Record Found for the aidorganisationInsUpt : " + ex.Message.ToString(), "ERROR");

                Insertquery = "INSERT INTO [DATAMIGRATION_BPIL].[dbo].[InfluencerInsUpt_log]([ber_Organisation],[ber_InfluencerName],[ber_FirstName],[ber_MiddleName],[ber_LastName],[ber_InfluencerType],[ber_MobileNumber],[ber_Address],[ber_emailaddress],[ErrorMsg],[Status],[CreatedOn]) " +
                "VALUES('" + InfluencerOrganizationID + "','" + InfluencerNameFullName + "','" + InfluencerFirstName + "','" + InfluencerMiddleName + "','" + InfluencerLastName + "','" + InfluencerType + "','" + InfluencerMobileNumber + "','" + InfluencerAddress + "', '" + Influencermailaddress + "','" + ex.Message.ToString() + "','F','" + DateTime.Today.ToString("yyyy-MM-dd") + "')";
                TransLogTable(dbConnectionString, Insertquery);

                result = "Error while Insert/Update";
            }
            finally
            {
            }
            return result;
        }
        #endregion

        #region AidInfluenContactsUpdate [ For Future assignment]
        public string AidInfluenContactsUpdate(string Contact_GUID_Pager, string AidOrganizationID, string TieupCompany)
        {
            string result = String.Empty;
            Entity _ContactBase = new Entity("ContactBase");
            try
            {

            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "InfluencerInsUpt", "No Record Found for the aidorganisationInsUpt : " + ex.Message.ToString(), "ERROR");
            }
            finally
            {
            }
            return result;
        }
        #endregion

        #region [GetDataTable]
        public DataTable GetDataTable(string cnString, string sql)
        {
            using (SqlConnection cn = new SqlConnection(cnString))
            {
                cn.Open();
                using (SqlDataAdapter da = new SqlDataAdapter(sql, cn))
                {
                    da.SelectCommand.CommandTimeout = 120;
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    return ds.Tables[0];
                }
            }
        }
        #endregion

        #region [Insert Error Log]
        public string TransLogTable(string cnString, string insertCommand)
        {
            string sReturn = String.Empty;
            try
            {
                using (SqlConnection cn = new SqlConnection(cnString))
                {
                    cn.Open();
                    using (SqlCommand sqlCmd = new SqlCommand(insertCommand, cn))
                    {
                        int i = sqlCmd.ExecuteNonQuery();
                        sReturn = "Success";
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("MobileIntService", "ErrorLogTable", "No Record Found for the aidorganisationInsUpt : " + ex.Message.ToString(), "ERROR");
            }
            finally
            {
            }
            return sReturn;
        }
        #endregion

        #region [Return Formated JSON Result]
        public string returnValue(string aidorganisationId, string Operation)
        {
            //MemoryStream StreamOupt = null;
            Dictionary<string, string> myValues = new Dictionary<string, string>();
            myValues.Add("GUID", aidorganisationId);
            myValues.Add("OPERATION", Operation);

            StringBuilder sb = new StringBuilder();
            sb.Append("[{");
            bool first = true;
            foreach (string k in myValues.Keys)
            {
                if (!first)
                {
                    sb.Append(",");
                }
                sb.AppendFormat("\"{0}\":\"{1}\"", k, myValues[k]);
                first = false;
            }
            sb.Append("}]");
            string outputjson = sb.ToString().Replace("\\", "");
            return outputjson;

            //string jsonString = (new System.Web.Script.Serialization.JavaScriptSerializer()).Serialize((object)myValues);
            //return jsonString;
            //string jsonsample = "{\"GUID\":\"a5b31506-9465-e811-a2ba-0050568c440d\",\"OPERATION\":\"Updated\"}";
            //string xx = [{ "GUID":"a5b31506-9465-e811-a2ba-0050568c440d","OPERATION":"Updated"}]
            //byte[] resultBytes = Encoding.UTF8.GetBytes(jsonString);
            //WebOperationContext.Current.OutgoingResponse.ContentType = "application/json; charset=utf-8";
            //StreamOupt = new MemoryStream(resultBytes);
            //return StreamOupt;
        }




        #endregion

        #region [Connect to Service ]
        //public static void ConnectToMSCRM(string UserName, string Password, string SoapOrgServiceUri)
        //{
        //    try
        //    {
        //        ClientCredentials credentials = new ClientCredentials();
        //        credentials.UserName.UserName = UserName;
        //        credentials.UserName.Password = Password;
        //        Uri serviceUri = new Uri(SoapOrgServiceUri);
        //        OrganizationServiceProxy proxy = new OrganizationServiceProxy(serviceUri, null, credentials, null);
        //        proxy.EnableProxyTypes();
        //        _service = (IOrganizationService)proxy;
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine("Error while connecting to CRM " + ex.Message);
        //        Console.ReadKey();
        //    }
        //}
        #endregion
        //----------------------------------------------------------------------------------------------------------------------------------------


    }
}

