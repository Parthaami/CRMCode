﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.ServiceModel.Activation;
using System.IO;
using Microsoft.Xrm.Sdk;

namespace Mobile_IntService
{

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IAccessCRM" in both code and config file together.
    [ServiceContract]
    public interface IAccessCRM
    {
        [WebInvoke(Method="GET",BodyStyle=WebMessageBodyStyle.Wrapped, UriTemplate = "/GetPainterData/MobileNo={Mno}", ResponseFormat = WebMessageFormat.Json)]  
        [OperationContract]
        List<PainterDetails> GetPainterDetails(string Mno);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/GetTAPoints?MobileNo={MobileNo}&LW_Code={LWCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        string GetTotalAccumulatedPoints(string MobileNo, string LWCode);

        [WebGet(BodyStyle=WebMessageBodyStyle.Wrapped,UriTemplate= "/GetLeadSummaryData?MobileNo={Mno}",ResponseFormat=WebMessageFormat.Json)]
        [OperationContract]
        List<LeadSummaryData> GetLeadSummaryData(string Mno);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/GetLeadDetailData?LeadId={Lid}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadDetailData> GetLeadDetailData(string Lid);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/GetAccountStatement?MobileNo={MobileNo}&LW_Code={LWCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<AccountStatement> GetAccountStatement(string MobileNo, string LWCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/GetLeadForAllPainters?FromDate={FDate}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadForAllPainters> GetLeadForAllPainters(string FDate);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/DisplayPainterDetails?MobileNo={Mno}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DPainterDetails> DisplayPainterDetails(string Mno);


        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/MasterPainterInfo?DepotNo={Dp}&DealerAccNo={Dealer}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<MPainterInfo> MasterPainterInfo(string Dp,string Dealer);

        //For Dealer Apps
        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/DealerValidationFor_XP_PXP_?DealerCode={DCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DValidation> Dealer_Validation(string DCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LeadSummary_ByDealer?DealerCode={DCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DLeadSummary> LeadSummary_ByDealer(string DCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/PainterSummary_ByDealer?DealerCode={DCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DPainterSummary> PainterSummary_ByDealer(string DCode);


        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LeadSummaryForPainter?DealerCode={DCode}&PainterMobile={PainterMno}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DLeadSummary> LeadSummaryForPainter(string DCode, string PainterMno);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LeadDataByDate?OnDate={Date_}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadDataFor_a_Day> LeadDataByDate(string Date_);

        //For TSI
        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/DepotSummary?DepotCode={DCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DepotSummary> Depot_Summary(string DCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/TerritorySummary?DepotCode={DCode}&TerrCode={TrCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<TerritorySummary> Territory_Summary(string DCode, string TrCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/OverTradeVolumeSummary?DealerCode={DlrCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<OverTradeVolumeSummary> OverTradeVolume_Summary(string DlrCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LiftAndWinPointsSummary?DealerCode={DlrCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LiftAndWinPointsSummary> LiftAndWinPoints_Summary(string DlrCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/DealerList?DepotCode={DepotCode}&TerritoryCode={TerritoryCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DealerList> DealerList(string DepotCode, string TerritoryCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/ProductWisePointsSummary?DealerCode={DealerCode}&PainterMobile={PainterMobile}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<ProductWisePointsSummary> ProductWisePointsSummary(string DealerCode, string PainterMobile);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/PainterSummaryForTerritory?DepotCode={DepotCode}&TerritoryCode={TerritoryCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<PainterSummaryForTerritory> PainterSummaryForTerritory(string DepotCode, string TerritoryCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LeadSummaryForPainterByMobile?MobileNo={MobileNo}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadSummaryForPainterByMobile> LeadSummaryForPainterByMobile(string MobileNo);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/LeadSummaryByAppointmentDate?AppointmentDate={AppointmentDate}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<LeadSummaryByAppointmentDate> LeadSummaryByAppointmentDate(string AppointmentDate);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/PainterSummeryForDG?DepotCode={DepotCode}&TerritoryCode={TerritoryCode}&DgMobileNo={DgMobileNo}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<PainterSummeryForDG> PainterSummeryForDG(string DepotCode, string TerritoryCode, string DgMobileNo);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/DgSummaryByDepotAndTerritory?DepotCode={DepotCode}&TerritoryCode={TerritoryCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        List<DgSummaryByDepotAndTerritory> DgSummaryByDepotAndTerritory(string DepotCode, string TerritoryCode);

        [WebGet(BodyStyle = WebMessageBodyStyle.Wrapped, UriTemplate = "/SetLeadStatus?LeadID={LeadID}&StatusCode={StatusCode}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        string SetLeadStatus(string LeadID, string StatusCode);

        [System.ServiceModel.Web.WebGet(UriTemplate = "/CEMonitoringReport/{OutputType}", BodyStyle = WebMessageBodyStyle.Bare)]
        [OperationContract]
        Stream CEMonitoringReport(string OutputType = "html");

        //-------------------------------------------------------Token Services--------------------------------------------------------------------

        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
         UriTemplate = "/CreateTokenRedemtion/?Mobile={Mobile}&TokenNumber={TokenNumber}&Source={Source}")]
        String CreateTokenRedemtion(string Mobile, string TokenNumber, string Source);


        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
           UriTemplate = "/CreateTokenMaster/?SrlNo={SrlNo}&TokenType={TokenType}&Product={Product}&PackSize={PackSize}&Denomination={Denomination}&TokenMonth={TokenMonth}&TokenYear={TokenYear}&TokenKeyNo={TokenKeyNo}&ExpireDate={ExpireDate}")]
        String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate);
        //-----------------------------------------------------------------------------------------------------------------------------------------------

        //-------------------------------------------------------- Influncer ----------------------------------------------------------------------------------------------------

        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
         UriTemplate = "/aidorganisationInsUpt/?AidName={AidName}&AidOrganizationOwerType={AidOrganizationOwerType}&AidOrganisationType={AidOrganisationType}&AidMobile={AidMobile}&AidStreet1={AidStreet1}&AidStree2={AidStree2}&AidPincCode={AidPincCode}")]
        string aidorganisationInsUpt(string AidName, string AidOrganizationOwerType, string AidOrganisationType, string AidMobile, string AidStreet1, string AidStree2, string AidPincCode);

        [OperationContract, WebGet(BodyStyle = WebMessageBodyStyle.Bare, RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json,
         UriTemplate = "/InfluencerInsUpt/?InfluencerOrganizationID={InfluencerOrganizationID}&InfluencerFirstName={InfluencerFirstName}&InfluencerMiddleName={InfluencerMiddleName}&InfluencerLastName={InfluencerLastName}&InfluencerType={InfluencerType}&InfluencerMobileNumber={InfluencerMobileNumber}&InfluencerAddress={InfluencerAddress}&Influencermailaddress={Influencermailaddress}")]
        string InfluencerInsUpt(string InfluencerOrganizationID, string InfluencerFirstName, string InfluencerMiddleName, string InfluencerLastName, string InfluencerType, string InfluencerMobileNumber, string InfluencerAddress,string Influencermailaddress);


        //-----------------------------------------------------------------------------------------------------------------------------------------------

    }

    [DataContract]
    public class AccountStatement 
    {
        
        [DataMember]
        public string RegisteredDealerCode { get; set; }
        [DataMember]
        public string Category { get; set; }
        [DataMember]
        public string Date { get; set; }
        [DataMember]
        public string LiftingDealerCode { get; set; }
        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public string Volume { get; set; }
        [DataMember]
        public string Loading { get; set; }
        [DataMember]
        public string GroupBonus { get; set; }
        [DataMember]
        public string VolumeBonus { get; set; }
        [DataMember]
        public string PointsCarriedForward { get;set;}
        [DataMember]
        public string RegisteredDepot { get; set; }
        
    }

    [DataContract]
    public class PainterDetails
    {
        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public string CustomerId { get; set; }

        [DataMember]
        public string PainterGuid { get; set; }

        [DataMember]
        public string EpStatus { get; set; } //added by soumen
    }

    [DataContract]
    public class LeadSummaryData
    {
        [DataMember]
        public string LeadId { get; set; }

        [DataMember]
        public string Salutation { get; set; }

        [DataMember]
        public string Firstname { get; set; }


        [DataMember]
        public string Lastname { get; set; }

        [DataMember]
        public string Telephone { get; set; }

        [DataMember]
        public string Leadtype { get; set; }

        [DataMember]
        public string Statuscode { get; set; }
        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string Dealer { get; set; }
        [DataMember]
        public string LeadEntryDate { get; set; }
        [DataMember]
        public string LeadAssignmentDate { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterMobileNo { get; set; }
        


    }

    [DataContract]
    public class LeadDetailData
    {
        [DataMember]
        public string LeadId { get; set; }
        [DataMember]
        public string Salutation { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string Lastname { get; set; }
        [DataMember]
        public string PrimaryNo { get; set; }
        [DataMember]
        public string AlternateContactNo { get; set; }
        [DataMember]
        public string HomePhone { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string Street1 { get; set; }
        [DataMember]
        public string Street2 { get; set; }
        [DataMember]
        public string Street3 { get; set; }
        [DataMember]
        public string PinCode { get; set; }
        [DataMember]
        public string City { get; set; }
        [DataMember]
        public string State { get; set; }
        [DataMember]
        public string LeadType { get; set; }
        [DataMember]
        public string LeadStatus { get; set; }
        [DataMember]
        public string LeadSource { get; set; }
        [DataMember]
        public string LeadOpportunity { get; set; }
        [DataMember]
        public string PaintingType { get; set; }
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string DealerCode { get; set; }
        [DataMember]
        public string CarpetArea { get; set; }
        [DataMember]
        public string Interior { get; set; }
        [DataMember]
        public string Exterior { get; set; }
        [DataMember]
        public string Wood { get; set; }
        [DataMember]
        public string CC { get; set; }
        [DataMember]
        public string StartDate { get; set; }
        [DataMember]
        public string EndDate { get; set; }
        [DataMember]
        public string FinalJobValue { get; set; }
        [DataMember]
        public string StateCode { get; set; }
        [DataMember]
        public string AppointmentDate { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string CaptureJobCompletedDate { get; set; }
        [DataMember]
        public string TotalValue { get; set; }
        [DataMember]
        public string MaterialValue { get; set; }
        [DataMember]
        public string LabourValue { get; set; }
        [DataMember]
        public string DgName { get; set; }
        [DataMember]
        public string DgMobileNo { get; set; }
    }

    [DataContract]
    public class LeadForAllPainters
    {
        [DataMember]
        public string LeadId {get;set;}
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string Salutation { get; set; }
        [DataMember]
        public string Lastname { get; set; }
        [DataMember]
        public string PrimaryNo { get; set; }
        [DataMember]
        public string LeadType { get; set; }
        [DataMember]
        public string LeadStatus { get; set; }
    }


    [DataContract]
    public class DPainterDetails
    {
        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterEnrollmentDate { get; set; }
        [DataMember]
        public string LinkedToDepot { get; set; }
        [DataMember]
        public string LinkedToDealer { get; set; }
        [DataMember]
        public string PainterStatus { get; set; }
        [DataMember]
        public string PainterType { get; set; }

   }

    [DataContract]
    public class MPainterInfo
    {
        [DataMember]
        public string MPainterCode { get; set; }
        [DataMember]
        public string MPainterMobileNo { get; set; }
        [DataMember]
        public string MPainterName { get; set; }

    }

    [DataContract]
    public class DValidation
    {
        [DataMember]
        public string DPrimary_MobileNo { get; set; }
        [DataMember]
        public string DName { get; set; }
        [DataMember]
        public string CustomerType { get; set; }
        [DataMember]
        public string DealerType { get; set; }
        [DataMember]
        public string alt_Ph1 { get; set; }
        [DataMember]
        public string alt_Ph2 { get; set; }
        [DataMember]
        public string alt_Ph3 { get; set; }
       //added by soumen dated 21-jun-2019 for retails dealer validation
        [DataMember]        
        public string Rtl_Ph1 { get; set; }   


    }


    [DataContract]
    public class DLeadSummary
    {
       [DataMember]
        public string Dealer { get; set; }
        
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string Firstname { get; set; }
        [DataMember]
        public string Lastname { get; set; }

        [DataMember]
        public string LeadAssignmentDate { get; set; }
        [DataMember]
        public string LeadEntryDate { get; set; }
        [DataMember]
        public string LeadId { get; set; }

        [DataMember]
        public string Leadtype { get; set; }

        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string PainterMobileNo { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterSalutation { get; set; }
        [DataMember]
        public string Statuscode { get; set; }
        [DataMember]
        public string LdStatuscode { get; set; }
        [DataMember]
        public string Telephone { get; set; }
        [DataMember]
        public string Startdate { get; set; }
        [DataMember]
        public string EndDate { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string StateCode { get; set; }
        [DataMember]
        public string AppointmentDate { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string CaptureJobCompletedDate { get; set; }
         [DataMember]
        public string MaterialValue { get; set; }
         [DataMember]
        public string LabourValue { get; set; }
    }

    [DataContract]
    public class DPainterSummary
    {
        [DataMember]
        public string PainterID { get; set; }

        [DataMember]
        public string PainterMobileNo { get; set; }

        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string Converted_Lead { get; set; }

        [DataMember]
        public string TotalLeads { get; set; }

        [DataMember]
        public string InProgressLeads { get; set; }

        [DataMember]
        public string LostLeads { get; set; }

        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string PainterCategory { get; set; }
        [DataMember]
        public string NewLeads { get; set; }
        [DataMember]
        public string TotalMaterialValue { get; set; }
        [DataMember]
        public string TotalLabourValue { get; set; }
        [DataMember]
        public string SanderVolume { get; set; }
        [DataMember]
        public string PainterRating { get; set; }
    }

    [DataContract]
    public class LeadDataFor_a_Day
    {
        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string Lastname { get; set; }

        [DataMember]
        public string LeadId { get; set; }
        [DataMember]
        public string LeadStatus { get; set; }
        [DataMember]
        public string LeadType { get; set; }
        [DataMember]
        public string PainterPrimaryNo { get; set; }
        [DataMember]
        public string DealerCode { get; set; }
        [DataMember]
        public string MaterialValue { get; set; }
        [DataMember]
        public string LabourValue { get; set; }
    }

    [DataContract]
    public class DepotSummary
    {
        [DataMember]
        public string TerritoryCode { get; set; }

        [DataMember]
        public string TerritoryName { get; set; }

        [DataMember]
        public string TotalLead { get; set; }

        [DataMember]
        public string Converted_Lead { get; set; }

        [DataMember]
        public string InProgressLeads { get; set; }

        [DataMember]
        public string LostLeads { get; set; }
        [DataMember]
        public string TSIName { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string NewLeadsCount { get; set; }
        [DataMember]
        public string TotalXPLeads { get; set; }
        [DataMember]
        public string MaterialValue { get; set; }
        [DataMember]
        public string LabourValue { get; set; }
    }

    [DataContract]
    public class TerritorySummary
    {
        [DataMember]
        public string DealerCode { get; set; }

        [DataMember]
        public string DealerName { get; set; }

        [DataMember]
        public string TotalLead { get; set; }

        [DataMember]
        public string Converted_Lead { get; set; }

        [DataMember]
        public string InProgressLeads { get; set; }

        [DataMember]
        public string LostLeads { get; set; }

        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string NewLeads { get; set; }
        [DataMember]
        public string TotalMaterialValue { get; set; }
        [DataMember]
        public string TotalLabourValue { get; set; }
        [DataMember]
        public string DealerRating { get; set; }
    }

    [DataContract]
    public class OverTradeVolumeSummary
    {
        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public string SellOutValue { get; set; }
        [DataMember]
        public string OvertradeQty { get; set; }
        [DataMember]
        public string OTClearQty { get; set; }
    }


    [DataContract]
    public class LiftAndWinPointsSummary
    {
        [DataMember]
        public string PainterID { get; set; }

        [DataMember]
        public string PainterMobileNo { get; set; }

        [DataMember]
        public string PainterName { get; set; }

        [DataMember]
        public string TotalSellOutVol { get; set; }

        [DataMember]
        public string MDTPoint { get; set; }

        [DataMember]
        public string YTDPoint { get; set; }

    }

    [DataContract]
    public class DealerList
    {
        [DataMember]
        public string DealerCode { get; set; }
        [DataMember]
        public string Name { get; set; }
    }

    [DataContract]
    public class ProductWisePointsSummary
    {
        [DataMember]
        public string Product { get; set; }
        [DataMember]
        public string VolConsideredForPoints { get; set; }
        [DataMember]
        public string VolumeUnderOTHold { get; set; }
        [DataMember]
        public string TotalPoints { get; set; }
    }

    [DataContract]
    public class PainterSummaryForTerritory
    {
        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterMobileNo { get; set; }
        [DataMember]
        public string TotalLeads { get; set; }
        [DataMember]
        public string ConvertedLeads { get; set; }
        [DataMember]
        public string InProgress { get; set; }
        [DataMember]
        public string LostLeads { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string PainterCategory { get; set; }
        [DataMember]
        public string NewLeads { get; set; }
        [DataMember]
        public string TotalMaterialValue { get; set; }
        [DataMember]
        public string TotalLabourValue { get; set; }
        [DataMember]
        public string SanderVolume { get; set; }
        [DataMember]
        public string PainterRating { get; set; }
    }

    [DataContract]
    public class LeadSummaryForPainterByMobile
    {
        [DataMember]
        public string Dealer { get; set; }
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string Firstname { get; set; }
        [DataMember]
        public string Telephone { get; set; }
        [DataMember]
        public string Lastname { get; set; }
        [DataMember]
        public string LeadEntryDate { get; set; }
        [DataMember]
        public string LeadAssignmentDate { get; set; }
        [DataMember]
        public string Statuscode { get; set; }
        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string PainterMobileNo { get; set; }
        [DataMember]
        public string LeadId { get; set; }
        [DataMember]
        public string Leadtype { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterSalutation { get; set; }
        [DataMember]
        public string Startdate { get; set; }
        [DataMember]
        public string EndDate { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string StateCode { get; set; }
        [DataMember]
        public string AppointmentDate { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string CaptureJobCompletedDate { get; set; }
        [DataMember]
        public string MaterialValue { get; set; }
        [DataMember]
        public string LabourValue { get; set; }
    }   


    [DataContract]
    public class LeadSummaryByAppointmentDate
    {
        [DataMember]
        public string AppointmentDate { get; set; }
        [DataMember]
        public string CaptureJobCompletedDate { get; set; }
        [DataMember]
        public string Dealer { get; set; }
        [DataMember]
        public string Depot { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string EndDAte { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string LeadAssignmentDate { get; set; }
        [DataMember]
        public string LeadEntryDate { get; set; }
        [DataMember]
        public string LeadId { get; set; }
        [DataMember]
        public string LeadType { get; set; }
        [DataMember]
        public string PainterID { get; set; }
        [DataMember]
        public string PainterMobileNumber { get; set; }
        [DataMember]
        public string PainterName { get; set; }
        [DataMember]
        public string PainterSalutation { get; set; }
        [DataMember]
        public string StartDate { get; set; }
        [DataMember]
        public string StateCode { get; set; }
        [DataMember]
        public string StatusCode { get; set; }
        [DataMember]
        public string Telephone { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string DepotNumber { get; set; }
        [DataMember]
        public string Territory { get; set; }

        [DataMember]
        public string CustomerAddress { get; set; }
        [DataMember]
        public string CustomerPinCode { get; set; }
        [DataMember]
        public string CustomerMobile { get; set; }
    }

    [DataContract]
    public class PainterSummeryForDG
    {
        [DataMember]
        public string DgFullName { get; set; }
        [DataMember]
        public string DgId { get; set; }
        [DataMember]
        public string LostLeads { get; set; }
        [DataMember]
        public string DgMobileNo { get; set; }
        [DataMember]
        public string Converted_Lead { get; set; }
        [DataMember]
        public string InProgressLeads { get; set; }
        [DataMember]
        public string NewLeads { get; set; }
        [DataMember]
        public string TotalLeads { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string TotalMaterialValue { get; set; }
        [DataMember]
        public string TotalLabourValue { get; set; }
        [DataMember]
        public string SanderVolume { get; set; }
        [DataMember]
        public string Painter_Name { get; set; }
        [DataMember]
        public string PainterMobile { get; set; }
    }

    [DataContract]
    public class DgSummaryByDepotAndTerritory
    {
        [DataMember]
        public string DgFullName { get; set; }
        [DataMember]
        public string DgId { get; set; }
        [DataMember]
        public string LostLeads { get; set; }
        [DataMember]
        public string DgMobileNo { get; set; }
        [DataMember]
        public string Converted_Lead { get; set; }
        [DataMember]
        public string InProgressLeads { get; set; }
        [DataMember]
        public string NewLeads { get; set; }
        [DataMember]
        public string TotalLeads { get; set; }
        [DataMember]
        public string TotalJobValue { get; set; }
        [DataMember]
        public string TotalMaterialValue { get; set; }
        [DataMember]
        public string TotalLabourValue { get; set; }
    }

}
