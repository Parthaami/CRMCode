USE [DATAMIGRATION_BPIL]
GO
/****** Object:  StoredProcedure [dbo].[SP_BD_CreateTokenMaster]    Script Date: 30-12-2019 06:49:45 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

create PROCEDURE [dbo].[SP_BD_CreateTokenMaster] 
	@SrlNo varchar(100),
	@TokenType nvarchar(100),
	@Product varchar(100),
	@PackSize varchar(100),
	@Denomination money,
	@TokenMonth varchar(50),
	@TokenYear varchar(50),
	@TokenKeyNo varchar(100),
	@ExpireDate date,
	@Status varchar(1)
AS
BEGIN
	SET NOCOUNT ON;
	IF @@TRANCOUNT < 1 
	BEGIN 
		BEGIN TRY		
			BEGIN TRAN;
			INSERT INTO Token_Master_Integration with (rowlock) (
			[SrlNo],[TokenType],[Product],[PackSize],[Denomination]
			,[TokenMonth],[TokenYear],[TokenKeyNo],[tokenExpireDate]
			,[Status]
			)
			VALUES (
				@SrlNo,
				@TokenType,
				@Product,
				@PackSize,
				@Denomination,
				@TokenMonth,
				@TokenYear,
				@TokenKeyNo,
				@ExpireDate,
				@Status
			);
			COMMIT TRAN;
		END TRY
		BEGIN CATCH
			ROLLBACK TRAN;
			THROW;
		END CATCH
	END
	ELSE
	BEGIN
		DECLARE @CustomError NVARCHAR(200);
		SET @CustomError = 'Can''t Insert Data At This Moment!' + CHAR(13)+CHAR(10) 
							+ 'Cause: Previous Transaction Already Active.';
		THROW 50010, @CustomError, 1;
	END
END
