﻿using System;
using System.Configuration;
using System.Web.Services;
using System.Web.Services.Protocols;
using Oracle.DataAccess;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using Oracle.DataAccess.Client;
using System.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
namespace OracleConnectWebservice
{
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]

    [WebService(Namespace = "http://bergerindia.org/")]
    public class BergerOracleService : System.Web.Services.WebService
    {
        static string crmdb = ConfigurationManager.ConnectionStrings["BergerCRMConnectionString"].ConnectionString;
        static int oracleFetchSize = Convert.ToInt32(ConfigurationManager.AppSettings["oracleFetchSize"].ToString());
        static string oradb = ConfigurationManager.ConnectionStrings["erpconstring"].ConnectionString;
        static string oledb_oradb = ConfigurationManager.ConnectionStrings["Oledb_erpconstring"].ConnectionString;

        static string gcscschemeid = ConfigurationManager.AppSettings["gcscschemeid"].ToString();
        static string staschemeid = ConfigurationManager.AppSettings["staschemeid"].ToString();
        static string gcscschemedescription = ConfigurationManager.AppSettings["gcscschemedescription"].ToString();
        static string stachemedescription = ConfigurationManager.AppSettings["stachemedescription"].ToString();
        static string PRStatus = ConfigurationManager.AppSettings["PRStatus"].ToString();
        
        static string filewrite = ConfigurationManager.AppSettings["filewrite"].ToString().ToLower();
        static string LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
        Logger oLogger = new Logger("Berger", LogPath);
        
        public DataSet getDataFromCRM(string query)
        {
            DataSet ds = new DataSet();
            SqlConnection sqlConn = new SqlConnection(crmdb);
            SqlDataAdapter da = new SqlDataAdapter(query, sqlConn);
            try
            {
                da.Fill(ds);
                if (filewrite == "yes")
                    oLogger.Log("OracleService", "getDataFromCRM", "Query: " + query, "Packet Size: " + sqlConn.PacketSize.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("OracleService", "getDataFromCRM", ex.Message.ToString() + "Query: " + query, ex.StackTrace.ToString());
            }
            finally
            {
                da.Dispose();
                sqlConn.Dispose();
            }
            return ds;
        }
        [WebMethod]
        public string ExecuteQueryOnOracleDB(string query)
        {
            OleDbConnection connection = new OleDbConnection(oledb_oradb);
            OleDbCommand command = new OleDbCommand();
            string retStatus = "ERROR";

            command.Connection = connection;
            command.CommandText = query;
            command.CommandType = CommandType.Text;

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                retStatus = "SUCCESS";
                if (filewrite == "yes")
                    oLogger.Log("OracleService", "ExecuteQueryOnOracleDB", "Query : " + query ,"");

            }
            catch (Exception ex)
            {
                oLogger.Log("OracleService", "ExecuteQueryOnOracleDB", ex.Message.ToString() + "Query: " + query, ex.StackTrace.ToString());
            }
            finally
            {
                command.Dispose();
                connection.Close();
                connection.Dispose();
                query = string.Empty;
            }
            return retStatus;
        }

        [WebMethod]
        public Boolean CMDMStatusQuery(string depotCode, string VoucherNumber)
        {

            return true;
        }

        [WebMethod]
        public string FetchOAStatus(string depotCode, string OANumber)
        {

            return "Message from ERP";
        }

        [WebMethod]
        public DataSet fetchdata(string query, string tablename)
        {
            DataSet sds = new DataSet();
            OracleConnection connection = new OracleConnection(oradb);
            OracleCommand command = new OracleCommand();
            OracleDataAdapter dataAdapter = new OracleDataAdapter(command);
            try
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = query;
                command.CommandType = CommandType.Text;
                command.FetchSize = oracleFetchSize;
                dataAdapter.Fill(sds);

                if (filewrite == "yes")
                {
                    oLogger.Log("OracleService", "fetchdata", "Query : " + query, "Row Size: " + command.RowSize + "Fetch Size: " + command.FetchSize);
                    if (sds.Tables.Count > 0)
                    {
                        oLogger.Log("OracleService", "fetchdata","Query : " + query,"No. of tables retrieved : " + sds.Tables.Count.ToString() + "No. of Rows retrieved : " + sds.Tables[0].Rows.Count.ToString());

                    }
                }
            }
            catch (Exception exp)
            {
                oLogger.Log("OracleService", "fetchdata", "Query : " + query + "Row Size: " + command.RowSize + "Fetch Size: " + command.FetchSize, " Exception: " + exp.ToString() + exp.StackTrace.ToString());
            }
            finally
            {
                dataAdapter.Dispose();
                command.Dispose();
                connection.Close();
                connection.Dispose();
            }
            return sds;
        }

        [WebMethod]
        public DataSet Payments(string siteid, bool isSiteId)
         {
            string PaymentQuery = string.Empty;
            string sqlQuery = string.Empty;
            DataSet childAccounts = new DataSet();
            if (isSiteId)
                PaymentQuery = "select DOC_SEQUENCE_VALUE  as \"Trx #\",TO_CHAR(TXN_DATE, 'DD-MM-YYYY') as \"Trx Date\",abs(ORIGINAL_AMOUNT) as \"Original Amt\",abs(PAYMENT_AMOUNT) as \"Balance Amt\" ," + 
                                " PAYMENT_MODE as \"Payment Mode\", RECEIPT_NUMBER as \"Inst #\" from table(xxcrm_payments_table_f(" + Convert.ToInt32(siteid) + ")) " + 
                                " where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 order by TXN_DATE desc";
            else
            {
                sqlQuery = @"select t1.AccountNumber from Account t1 inner join Account t2 on t1.ParentAccountId = t2.AccountId where t1.statecode = 0  and t2.AccountNumber = '" + siteid.ToString() + "'";
                childAccounts = getDataFromCRM(sqlQuery);
                if (childAccounts.Tables.Count != 0 && childAccounts.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < childAccounts.Tables[0].Rows.Count; i++)
                    {
                        PaymentQuery = PaymentQuery + " select DOC_SEQUENCE_VALUE  as \"Trx #\",TO_CHAR(TXN_DATE, 'DD-MM-YYYY') as \"Trx Date\",abs(ORIGINAL_AMOUNT) as \"Original Amt\",abs(PAYMENT_AMOUNT) as \"Balance Amt\" ," +
                                        " PAYMENT_MODE as \"Payment Mode\", RECEIPT_NUMBER as \"Inst #\" from table(xxcrm_payments_table_f(" + Convert.ToInt32(childAccounts.Tables[0].Rows[i]["AccountNumber"].ToString()) + ")) " +
                                        " where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 UNION ";
                    }
                    PaymentQuery = PaymentQuery.Substring(0, PaymentQuery.Length - 6); 
                    PaymentQuery = "Select * from (" + PaymentQuery + ") order by \"Trx Date\" desc";
                }
            }
            childAccounts.Dispose();
            return fetchdata(PaymentQuery, "Payments");
         } 

        [WebMethod]
        public DataSet stock(string productid, string depotid)
        {
            string stockQuery = "SELECT  DUAL_PACK as \"Dual Pack\",PRODUCT_CODE as \"SKU\",PARENT_ITEM as \"ParentSKU\",PRODUCT_DESCRIPTION as \"Product\",nvl(FREE_STOCK,0) as \"Fresh Stock\"," +
                                " (nvl(MRP1,0)  + nvl(MRP2,0) + nvl(MRP3,0)) as \"Old MRP Stock\", PRICE as \"Price\" FROM table(xxcrm_product_table_f('" + productid + "'," + Convert.ToInt32(depotid) + "))";
            return fetchdata(stockQuery, "stock");
        }

        [WebMethod]
        public string GetStockForSingleSKU(string sku, string depotid)
        {
            
            DataSet dsStock = null;
            string stockQuery = "SELECT BPIL.BPIL_PKS_CRM_STK(" + Convert.ToInt32(depotid) + ",'" + sku + "') FROM DUAL";
            dsStock = fetchdata(stockQuery, "stock");
            string stock = dsStock.Tables[0].Rows[0][0].ToString();
            if(string.IsNullOrEmpty(stock))
                 stock = "0";
            return stock;
        }

        [WebMethod]
        public string updatePaymentAdvise(string paymentAdviceId, string status)
        {
            string retStatus = "ERROR";
            string oraUpdQuery = string.Empty;
            try
            {
                oraUpdQuery = "UPDATE XXCRM_PAYMENT_ADVICE SET status = '" + status + "' where PR_ID = '" + paymentAdviceId.ToString() + "'";

                if (filewrite == "yes")
                    oLogger.Log("OracleService", "updatePaymentAdvise", "Query: " + oraUpdQuery, "PaymentAdviceId: " + paymentAdviceId);
                retStatus = ExecuteQueryOnOracleDB(oraUpdQuery);
            }
            catch(Exception ex)
            {
                oLogger.Log("OracleService", "updatePaymentAdvise", "Query: " + oraUpdQuery + " Exception: " + ex.Message.ToString() + ex.StackTrace.ToString() + ex.InnerException.ToString(), "PaymentAdviceId: " + paymentAdviceId);
            }
            finally
            {
                oraUpdQuery = string.Empty;
            }
            return retStatus;
        }    
        [WebMethod]
        public string createPaymentAdvise(string paymentAdviceId)
        {
            string queryPaymentTrans = string.Empty;
            DataSet PaymentTransaction = new DataSet();
            string oraQuery = string.Empty;
            string returnStatus = string.Empty;

            try
            {
                //" substring(t2.ber_ChequeAmount,5, LEN(t2.ber_ChequeAmount)) as CHEQUE_AMOUNT, " +
                queryPaymentTrans = " select t2.ber_name as PR_NUMBER,t3.AccountNumber as ACCOUNT_NUMBER,t4.AccountNumber as BILL_TO, "+
                                    " case t2.ber_paymentmode when '278290000' THEN 'CHEQUE' when '278290001' THEN 'RTGS' When '278290002' THEN 'CASH' when " +
                                    " '278290003' THEN 'DRAFT' when '278290004' THEN 'CN' END as PAYMENT_MODE, " +
                                    " t5.ber_DepotNumber as DEPOT_CODE,t2.ber_Chequenumber as CHEQUE_NUMBER, " +
                                    " t2.ber_ChequeAmount as CHEQUE_AMOUNT, " +
                                    " case t1.ber_Type WHEN '278290000' THEN 'CM' WHEN '278290001' THEN 'DM'  "+
                                    " WHEN '278290002' THEN 'PMT' WHEN '278290003' THEN 'INV' END as TRANSACTION_TYPE, "+
                                    " t1.ber_name as TRANSACTION_NUMBER, t1.ber_CorrectionAmount as TRANSACTION_AMOUNT , getdate() as CREATION_DATE, getDate() as LAST_UPDATE_DATE from  " +
                                    " ber_creditdebitnote t1  inner join ber_paymentadvice t2 on t1.ber_paymentadvicecndnid = t2.ber_paymentadviceId inner join " +
                                    " Account t3 on t2.ber_account = t3.AccountId inner join Account t4 on t2.ber_payment_advice_account = t4.AccountId inner join " +
                                    " ber_depot t5 on t4.ber_DepotId = t5.ber_depotId where t2 .ber_paymentadviceId = '"+paymentAdviceId+"' "; 
                
                PaymentTransaction = getDataFromCRM(queryPaymentTrans);

                if (filewrite == "yes")
                    oLogger.Log("OracleService", "createPaymentAdvise", "Query: " + queryPaymentTrans, "PaymentAdviceId: " + paymentAdviceId);
                
                if (PaymentTransaction.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < PaymentTransaction.Tables[0].Rows.Count; i++)
                    {
                        if (PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_TYPE"].ToString() == "CM" || PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_TYPE"].ToString() == "PMT")
                        {
                        oraQuery = "INSERT INTO XXCRM_PAYMENT_ADVICE (    PR_ID,    PR_NUMBER,    ACCOUNT_NUMBER,    BILL_TO,    PAYMENT_MODE,    DEPOT_CODE, " +
                                    " CHEQUE_NUMBER,    CHEQUE_AMOUNT,    TRANSACTION_TYPE,    TRANSACTION_NUMBER,    TRANSACTION_AMOUNT,    P_CASH_RECEIPT_ID, " +
                                    " STATUS,    ERR_MSG,    UNAPPLIED_AMOUNT,    CREATION_DATE,    LAST_UPDATE_DATE,    REQUEST_ID, NUM_OF_TRANSACTIONS  )  VALUES  ( " +
                                    " '" + paymentAdviceId + "',    '" + PaymentTransaction.Tables[0].Rows[i]["PR_NUMBER"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["ACCOUNT_NUMBER"].ToString() + "' ,  '" + PaymentTransaction.Tables[0].Rows[i]["BILL_TO"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["PAYMENT_MODE"].ToString().ToUpper() + "'" +
                                    " ,'" + PaymentTransaction.Tables[0].Rows[i]["DEPOT_CODE"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["CHEQUE_NUMBER"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["CHEQUE_AMOUNT"].ToString().Replace(",","") + "',    '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_TYPE"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_NUMBER"].ToString() + "',"+'-' +
                                    " '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_AMOUNT"].ToString() + "',    '',    '" + PRStatus + "',    '',    ''," +
                                    "    '" + PaymentTransaction.Tables[0].Rows[i]["CREATION_DATE"] + "',    '" + PaymentTransaction.Tables[0].Rows[i]["LAST_UPDATE_DATE"].ToString() + "' ,'','" + PaymentTransaction.Tables[0].Rows.Count.ToString() + "' )";
                        }
                        else{
                            oraQuery = "INSERT INTO XXCRM_PAYMENT_ADVICE (    PR_ID,    PR_NUMBER,    ACCOUNT_NUMBER,    BILL_TO,    PAYMENT_MODE,    DEPOT_CODE, " +
                                    " CHEQUE_NUMBER,    CHEQUE_AMOUNT,    TRANSACTION_TYPE,    TRANSACTION_NUMBER,    TRANSACTION_AMOUNT,    P_CASH_RECEIPT_ID, " +
                                    " STATUS,    ERR_MSG,    UNAPPLIED_AMOUNT,    CREATION_DATE,    LAST_UPDATE_DATE,    REQUEST_ID, NUM_OF_TRANSACTIONS  )  VALUES  ( " +
                                    " '" + paymentAdviceId + "',    '" + PaymentTransaction.Tables[0].Rows[i]["PR_NUMBER"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["ACCOUNT_NUMBER"].ToString() + "' ,  '" + PaymentTransaction.Tables[0].Rows[i]["BILL_TO"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["PAYMENT_MODE"].ToString().ToUpper() + "'" +
                                    " ,'" + PaymentTransaction.Tables[0].Rows[i]["DEPOT_CODE"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["CHEQUE_NUMBER"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["CHEQUE_AMOUNT"].ToString().Replace(",", "") + "',    '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_TYPE"].ToString() + "',    '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_NUMBER"].ToString() + "'," +
                                    " '" + PaymentTransaction.Tables[0].Rows[i]["TRANSACTION_AMOUNT"].ToString() + "',    '',     '" + PRStatus + "',    '',    ''," +
                                    "    '" + PaymentTransaction.Tables[0].Rows[i]["CREATION_DATE"] + "',    '" + PaymentTransaction.Tables[0].Rows[i]["LAST_UPDATE_DATE"].ToString() + "' ,'','" + PaymentTransaction.Tables[0].Rows.Count.ToString() + "' )";
                        

                        }
                        if (filewrite == "yes")
                            oLogger.Log("OracleService", "createPaymentAdvise", "Query: " + oraQuery, "PaymentAdviceId: " + paymentAdviceId);
                        returnStatus = ExecuteQueryOnOracleDB(oraQuery);
                        oraQuery = string.Empty;
                        if (returnStatus == "ERROR")
                            break;
                        returnStatus = "SUCCESS";
                    }
                }
                
            }
            catch (Exception exp)
            {
                returnStatus = "ERROR";
                oLogger.Log("OracleService", "createPaymentAdvise", "Query: " + queryPaymentTrans, "PaymentAdviceId: " + paymentAdviceId + "Exception: " + exp.ToString());
            }
            finally
            {
                PaymentTransaction.Dispose();
            }
            return returnStatus;
        }
  
        [WebMethod]
        public DataSet CreditLimit(string siteid)
         {
             string crLimitQuery = "SELECT  total_cr_limit,available_cr_limit,hold_y_n,total_outstanding,hold_reason FROM table(xxcrm_cr_limit_table_f(" + Convert.ToInt32(siteid) + "))";
             return fetchdata(crLimitQuery, "CreditLimit");
         }

        [WebMethod]
        public DataSet SiteCreditLimit(string acid, string siteid)
        {
            string siteCrQuery = "SELECT  total_cr_limit,available_cr_limit,hold_y_n,hold_reason,total_outstanding FROM table(xxcrm_cr_limit_table_f(" + Convert.ToInt32(acid) + "," + Convert.ToInt32(siteid) + "))";
            return fetchdata(siteCrQuery, "SiteCreditLimit");
        }
        [WebMethod]
        public DataSet getGCSCQualificationData(string acid)
        {
            string queryScheme = "select ly \"LY\",tgt \"TGT\",act \"ACT\" from bpil.bpil_mcc_crm_scheme where description = '" + gcscschemedescription + "' and  scheme_id = '" + gcscschemeid + "' and account_number  =  '" + acid + "'";
            return fetchdata(queryScheme, "getGCSCQualificationData");
        }
        [WebMethod]
        public DataSet getSTAQualificationData(string acid)
        {
            string queryScheme = "select ly \"LY\",tgt \"TGT\",act \"ACT\" from bpil.bpil_mcc_crm_scheme where description = '" + stachemedescription + "' and scheme_id = '" + staschemeid + "' and account_number  =  '" + acid + "'";
            return fetchdata(queryScheme, "getSTAQualificationData");
        }
        [WebMethod]
        public DataSet ChequeInv(string siteid, bool isSiteId)
        {
             string chequeInv = string.Empty;
             string sqlQuery = string.Empty;
             DataSet childAccounts = new DataSet();
             if (isSiteId)
                chequeInv = "SELECT  CHEQUE_NUMBER as \"Cheque #\", STATUS as \"Status\", BOUNCED_FLAG as \"Bounced\", TO_CHAR(CHEQUE_ENTRY_DATE,'DD-MM-YYYY') as \"Cheque Entry Date\", " + 
                            " cheque_type as \"Type\",Amount as \"Amount\",BILL_TO as \"SiteId\" FROM table(xxcrm_cheque_table_f(" + Convert.ToInt32(siteid) + ")) order by CHEQUE_NUMBER asc";
            else
            {
                sqlQuery = @"select t1.AccountNumber from Account t1 inner join Account t2 on t1.ParentAccountId = t2.AccountId where t1.statecode = 0 and t2.AccountNumber = '" + siteid.ToString() + "'";
                childAccounts = getDataFromCRM(sqlQuery);
                if (childAccounts.Tables.Count != 0 && childAccounts.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < childAccounts.Tables[0].Rows.Count; i++)
                    {
                        chequeInv = chequeInv + " SELECT CHEQUE_NUMBER as \"Cheque #\", STATUS as \"Status\", BOUNCED_FLAG as \"Bounced\", TO_CHAR(CHEQUE_ENTRY_DATE,'DD-MM-YYYY') as \"Cheque Entry Date\"," +
                                    " cheque_type as \"Type\",Amount as \"Amount\",BILL_TO as \"SiteId\" FROM table(xxcrm_cheque_table_f(" + Convert.ToInt32(childAccounts.Tables[0].Rows[i]["AccountNumber"].ToString()) + ")) UNION ";
                    }
                    chequeInv = chequeInv.Substring(0, chequeInv.Length - 6);
                    chequeInv = "Select * from (" + chequeInv + ")  order by \"Cheque #\" asc";
                }
            }
            childAccounts.Dispose();
            return fetchdata(chequeInv, "ChequeInv");
         }

        [WebMethod]
        public DataSet CNDN(string billto, bool isSiteId)
        {
            string cnDnInvQuery = string.Empty;
            string sqlQuery = string.Empty;
            DataSet childAccounts = new DataSet();
            if (isSiteId)
            {
                cnDnInvQuery = "SELECT  TXN_NUMBER as \"Trx #\",TO_CHAR(TXN_DATE, 'DD-MM-YYYY') as \"Trx Date\",trunc(sysdate)-trunc(txn_date) as \"Age\", CLASS as \"Class\",NAME as \"Type\", TO_CHAR(DUE_DATE, 'DD-MM-YYYY') as \"Due Date\", " + 
                            " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\",concat(concat(remarks1, ' - '),remarks2) as \"Description\" FROM " +
                            " table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(billto) + ")) where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 order by TXN_DATE desc";
            }
            else
            {
                sqlQuery = @"select t1.AccountNumber from Account t1 inner join Account t2 on t1.ParentAccountId = t2.AccountId where t1.statecode = 0 and t2.AccountNumber = '" + billto.ToString() + "'";
                childAccounts = getDataFromCRM(sqlQuery);
                if (childAccounts.Tables.Count != 0 && childAccounts.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < childAccounts.Tables[0].Rows.Count; i++)
                    {
                        cnDnInvQuery = cnDnInvQuery + " SELECT  TXN_NUMBER as \"Trx #\",TO_CHAR(TXN_DATE, 'DD-MM-YYYY') as \"Trx Date\",trunc(sysdate)-trunc(txn_date) as \"Age\", CLASS as \"Class\",NAME as \"Type\", " +
                            " TO_CHAR(DUE_DATE, 'DD-MM-YYYY') as \"Due Date\",abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\",concat(concat(remarks1, ' - '),remarks2) as \"Description\" FROM" +
                            " table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(childAccounts.Tables[0].Rows[i]["AccountNumber"].ToString()) + ")) where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 UNION ";
                    }
                    childAccounts.Dispose();
                    cnDnInvQuery = cnDnInvQuery.Substring(0, cnDnInvQuery.Length - 6);
                    cnDnInvQuery = "Select * from (" + cnDnInvQuery + ")  order by \"Trx #\" desc";
                }
            }
            return fetchdata(cnDnInvQuery, "CNDN");
        }

        [WebMethod]
        public DataSet finsummary(string acid)
          {
              string finsummaryQuery = "select bill_to_site as \"Site\",leg_name as \"Legacy Name\", CUST_TYPE as \"Cust Type\",ORDER_TYPE as \"Order Type\",DEPOT_NAME as \"Depot\",BILL_TO as \"Site Code\", " +
                  " decode(PRIM,'PRI','Y','N') as \"Primary\",HOLD_YES_NO as \"Hold\",HOLD_REASON as \"Hold Reason\", to_number(nvl(SITE_OUTSTANDING,0)) as \"Outstanding\" FROM " + 
                  " table(xxcrm_site_table_f(" + Convert.ToInt32(acid) + ")) where ORDER_TYPE not like '%SCRAP%' AND ORDER_TYPE not like '%DAMAGE%' AND ORDER_TYPE not like '%BANK%'";
              return fetchdata(finsummaryQuery, "finsummary");               
          }

        [WebMethod]
        public DataSet PaymentAdvInvoices(string siteid, string paymentmode, string invno)
        {
            string queryDueInv = string.Empty;
            if (paymentmode == "CHEQUE")
            {
                if (invno.Length > 0)
                    queryDueInv = "SELECT  class as \"Type\",trx_number as \"Trx #\",abs(original_amount) as \"Trx Amt\", abs(payable_amount) as \"Balance Amt\",TO_CHAR(trx_date, 'DD-MM-YYYY') as \"Trx Date\"," +
                        " TO_CHAR(dn1_date, 'DD-MM-YYYY') as \"DN1 Date\",abs(dn1_amount) as \"DN1 Amount\",TO_CHAR(dn2_date,'DD-MM-YYYY') as \"DN2 Date\",abs(dn2_amount) as \"DN2 Amount\"," +
                        " TO_CHAR(payment_due_date,'DD-MM-YYYY') as \"Payment Due Date\",payment_mode as \"Payment Mode\",cheque_number as \"Cheque Number\" FROM " +
                        " table(xxcrm_due_invoice_table_f(" + Convert.ToInt32(siteid) + ")) where payable_amount is not null and payable_amount <> 0 and trx_number not in (" + invno + ") " +
                        " order by trx_date asc,cheque_number asc";
                else
                    queryDueInv = "SELECT  class as \"Type\",trx_number as \"Trx #\",abs(original_amount) as \"Trx Amt\", abs(payable_amount) as \"Balance Amt\", " + 
                        " TO_CHAR(trx_date, 'DD-MM-YYYY') as \"Trx Date\",TO_CHAR(dn1_date, 'DD-MM-YYYY') as \"DN1 Date\",abs(dn1_amount) as \"DN1 Amount\"," +
                        " TO_CHAR(dn2_date,'DD-MM-YYYY')  as \"DN2 Date\",abs(dn2_amount) as \"DN2 Amount\",TO_CHAR(payment_due_date,'DD-MM-YYYY')  as \"Payment Due Date\"," +
                        " payment_mode as \"Payment Mode\",cheque_number as \"Cheque Number\" FROM table(xxcrm_due_invoice_table_f(" + Convert.ToInt32(siteid) + ")) where" +
                        " payable_amount is not null and payable_amount <> 0  order by trx_date asc,cheque_number asc";
            }
            else
            {
                if (invno.Length > 0)
                    queryDueInv = "SELECT  class as \"Type\",trx_number as \"Trx #\",abs(original_amount) as \"Trx Amt\", abs(payable_amount) as \"Balance Amt\", " +
                        " TO_CHAR(trx_date,'DD-MM-YYYY') as \"Trx Date\",TO_CHAR(dn1_date,'DD-MM-YYYY') as \"DN1 Date\",abs(dn1_amount) as \"DN1 Amount\"," +
                        " TO_CHAR(dn2_date,'DD-MM-YYYY') as \"DN2 Date\",abs(dn2_amount) as \"DN2 Amount\",TO_CHAR(payment_due_date,'DD-MM-YYYY') as \"Payment Due Date\"," +
                        " payment_mode as \"Payment Mode\",cheque_number as \"Cheque Number\" FROM  table(xxcrm_due_invoice_table_f(" + Convert.ToInt32(siteid) + ")) " +
                        " where (payable_amount is not null and payable_amount <> 0) and (((payment_mode not in ('CHEQUE','Cheque') AND CLASS = 'INV') or (CLASS = 'DM')) " +
                        " AND trx_number not in (" + invno + "))  order by trx_date asc,cheque_number asc";
                else
                    queryDueInv = "SELECT  class as \"Type\",trx_number as \"Trx #\",abs(original_amount) as \"Trx Amt\", abs(payable_amount) as \"Balance Amt\", " +
                        " TO_CHAR(trx_date,'DD-MM-YYYY') as \"Trx Date\",TO_CHAR(dn1_date,'DD-MM-YYYY') as \"DN1 Date\",abs(dn1_amount) as \"DN1 Amount\", " +
                        " TO_CHAR(dn2_date,'DD-MM-YYYY') as \"DN2 Date\",abs(dn2_amount) as \"DN2 Amount\",TO_CHAR(payment_due_date,'DD-MM-YYYY') as \"Payment Due Date\", " +
                        " payment_mode as \"Payment Mode\",cheque_number as \"Cheque Number\" FROM table(xxcrm_due_invoice_table_f(" + Convert.ToInt32(siteid) + ")) where (payable_amount is not null and " +
                        " payable_amount <> 0) and ((payment_mode not in ('CHEQUE','Cheque') AND CLASS = 'INV') or (CLASS = 'DM'))  order by trx_date asc,cheque_number asc";
            }
            return fetchdata(queryDueInv, "PaymentAdvInvoices");
        }

        [WebMethod]
        public DataSet PaymentAdvCNDN(string siteid, string invno)
        {
             string queryCnPmt = string.Empty;
             if (invno.Length > 0)
                 queryCnPmt = "SELECT  CLASS as \"Type\",TXN_NUMBER as \"Trx #\", TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\"," +
                     " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\", name as \"Name\" FROM table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(siteid) + ")) " +
                     " where CLASS = 'CM' and PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 and txn_number not in (" + invno + ")  ";

                 /* queryCnPmt = "SELECT  CLASS as \"Type\",TXN_NUMBER as \"Trx #\", TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\"," +
                     " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\", name as \"Name\" FROM table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(siteid) + ")) " +
                     " where CLASS = 'CM' and PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 and txn_number not in (" + invno + ")  union " + 
                     " select 'PMT' as \"Type\",DOC_SEQUENCE_VALUE as \"Trx #\", TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\"," +
                     " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\", (PAYMENT_MODE ||('-')|| RECEIPT_NUMBER ) as \"Name\"  from " +
                     " table(xxcrm_payments_table_f(" + Convert.ToInt32(siteid) + ")) where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 and txn_number not in (" + invno + ") "; */
            else
                 queryCnPmt = "SELECT  CLASS as \"Type\",TXN_NUMBER as \"Trx #\", TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\"," +
                     " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\", name as \"Name\" FROM table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(siteid) + ")) " +
                     " where CLASS = 'CM' and PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0 ";

             /* queryCnPmt = "SELECT  CLASS as \"Type\",TXN_NUMBER as \"Trx #\", TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\"," +
                      " abs(ORIGINAL_AMOUNT) as \"Original Amt\", abs(PAYMENT_AMOUNT) as \"Balance Amt\", name as \"Name\" FROM table(xxcrm_cn_dn_table_f(" + Convert.ToInt32(siteid) + ")) " +
                      " where CLASS = 'CM' and PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0   union select 'PMT' as \"Type\",DOC_SEQUENCE_VALUE as \"Trx #\"," +
                      " TO_CHAR(TXN_DATE,'DD-MM-YYYY') as \"Trx Date\",  TO_CHAR(DUE_DATE,'DD-MM-YYYY') as \"Due Date\",abs(ORIGINAL_AMOUNT) as \"Original Amt\", " +
                      " abs(PAYMENT_AMOUNT) as \"Balance Amt\", (PAYMENT_MODE ||('-')|| RECEIPT_NUMBER ) as \"Name\"  from table(xxcrm_payments_table_f(" + Convert.ToInt32(siteid) + ")) " +
                      " where PAYMENT_AMOUNT is not null and PAYMENT_AMOUNT <> 0  "; */

             return fetchdata(queryCnPmt, "PaymentAdvCNDN");
        }
        
        [WebMethod]
        public DataSet SchemeQualification(string accountId, string SchemeId)
        {
            string queryScheme = string.Empty;
            queryScheme = "select desc_srl as \"S.No.\",description \"Description\",ly \"LY\",tgt \"TGT\",act \"ACT\",status \"Status\",points \"Points\",cn \"CN\",gift \"Gift\",gift_qty \"Gift Qty\"," +
                " last_update_date \"Last Updated\" from bpil.bpil_mcc_crm_scheme where scheme_id = '" + SchemeId + "' and account_number  =  '" + accountId + "' order by to_number(desc_srl)";

            return fetchdata(queryScheme, "SchemeQualification");
        } 
        [WebMethod]
        public DataSet PaymentAdvChequeAll(string siteid, string invno)
        {
            string queryChequeAll = string.Empty;
            if (invno.Length > 0)
                queryChequeAll = "SELECT  Cheque_type as \"Cheque Type\",CHEQUE_NUMBER as \"Cheque #\", STATUS as \"Status\",  Amount as \"Amount\"," +
                    " PART_PAYMENT_FLAG as \"Part Payment\" FROM table(xxcrm_cheque_pa_table_f(" + Convert.ToInt32(siteid) + ")) WHERE ((CHEQUE_TYPE = 'BLANK') OR" +
                    " (CHEQUE_TYPE = 'FILLED' AND PART_PAYMENT_FLAG = 'N')) AND (cheque_number not in(" + invno + ")) order by CHEQUE_NUMBER asc";
            else
                queryChequeAll = "SELECT  Cheque_type as \"Cheque Type\",CHEQUE_NUMBER as \"Cheque #\", STATUS as \"Status\",  Amount as \"Amount\",PART_PAYMENT_FLAG as \"Part Payment\" FROM " +
                    " table(xxcrm_cheque_pa_table_f(" + Convert.ToInt32(siteid) + ")) WHERE ((CHEQUE_TYPE = 'BLANK') OR (CHEQUE_TYPE = 'FILLED' AND PART_PAYMENT_FLAG = 'N'))  order by CHEQUE_NUMBER asc";
            return fetchdata(queryChequeAll, "PaymentAdvChequeAll");
        }
        
        [WebMethod]
        public DataSet OrderDispatch(string ordernumber)
        {
            string dispatchHeader = "SELECT ORDER_NUMBER as \"Order #\",DESPATCH_ID as \"Dispatch Id\",dispatch_date as \"Dispatch Date\",L_TRANSPOTER_NAME as \"Transporter\"," +
                " L_VECHILE_NO as \"Vechile Number\",REMARKS as \"Remark\" FROM table(xxcrm_dispatch_hdr_table_f('" + ordernumber + "')) where DESPATCH_ID is not null AND CANCEL_FLAG = 'N'";
              return fetchdata(dispatchHeader, "DispatchHeader");
        }

        [WebMethod]
        public DataSet OrderInvoice(string ordernumber)
        {
            string orderInvoice = "SELECT ORDER_NUMBER as \"Order #\",ORDER_STATUS as \"Status\",INV_NO as \"Invoice #\",TO_CHAR(INV_DATE,'DD-MM-YYYY')  as \"Invoice Date\"," +
                " to_number(nvl(INV_AMOUNT,0)) as \"Invoice Amt\", DESPATCH_ID as \"Dispatch Id\" FROM table(xxcrm_dispatch_hdr_table_f('" + ordernumber + "')) where INV_NO is not null";
             return fetchdata(orderInvoice, "OrderInvoice");
        }

        [WebMethod]
        public DataSet OrderInvoiceItems(string ordernumber)
        {

            string query = string.Empty;
            string str2 = string.Empty;
            DataSet set = new DataSet();
            DataSet set2 = new DataSet();
            DataSet set3 = new DataSet();
            try
            {
                query = "select t3.ProductNumber as \"SKU Code\" , floor(SUM(t1.Quantity)) as \"Ordered NOP\",t3.description as \"Product\" from SalesOrderDetail t1 inner join SalesOrder t2 on t1.SalesOrderId = t2.SalesOrderId and t2.ber_ERPHeaderId = '" + ordernumber + "' inner join Product t3 on t1.ProductId = t3.ProductId group by t3.ProductNumber,t3.description ";
                set = this.getDataFromCRM(query);
                str2 = "select ITEM_ID as \"SKU Code\",Description as \"Product\",sum(Quantity_invoiced) as \"Invoiced NOP\", sum(to_number(nvl(Extended_amount,0))) as \"Extended Amount\" from table(xxcrm_invoice_line_table_f(" + Convert.ToInt32(ordernumber) + ")) where line_type in ('LINE','CHARGES') and description not like '%B99%' group by ITEM_ID,Description";
                set2 = this.fetchdata(str2, "OrderInvoiceItem");
                if ((set.Tables.Count > 0) && (set2.Tables.Count > 0))
                {
                    DataTable table = set2.Tables[0];
                    DataTable table2 = set.Tables[0];
                    DataTable table3 = new DataTable();
                    table3.Columns.Add("S.No.");
                    table3.Columns.Add("SKU Code");
                    table3.Columns.Add("Product");
                    table3.Columns.Add("Ordered NOP");
                    table3.Columns.Add("Invoiced NOP");
                    table3.Columns.Add("Extended Amount");
                    if (table.Rows.Count == 0)
                    {
                        set3.Tables.Add(table3);
                        return set3;
                    }
                    int num = 1;
                    foreach (DataRow row in table2.Rows)
                    {
                        DataRow row2 = table3.NewRow();
                        row2["S.No."] = num;
                        row2["SKU Code"] = row["SKU Code"];
                        row2["Product"] = row["Product"];
                        row2["Ordered NOP"] = row["Ordered NOP"];
                        row2["Invoiced NOP"] = 0;
                        row2["Extended Amount"] = 0;
                        table3.Rows.Add(row2);
                        num++;
                    }
                    foreach (DataRow row2 in table3.Rows)
                    {
                        DataRow[] rowArray = table.Select("[SKU Code] = '" + row2["SKU Code"] + "'");
                        if ((rowArray != null) && (rowArray.Length > 0))
                        {
                            row2["Invoiced NOP"] = rowArray[0]["Invoiced NOP"];
                            row2["Extended Amount"] = rowArray[0]["Extended Amount"];
                        }
                    }
                    set3.Tables.Add(table3);
                }
            }
            catch (Exception exception)
            {
                this.oLogger.Log("OracleService", "orderInvoiceItem_Webmethod", "ordernumber: " + ordernumber, exception.ToString());
            }
            finally
            {
                set.Dispose();
                set2.Dispose();
            }
            return set3;
        }

        [WebMethod]
        public DataSet OrderItemDispatch(string ordernumber)
        {
            string query = string.Empty;
            string str2 = string.Empty;
            DataSet set = new DataSet();
            DataSet set2 = new DataSet();
            DataSet set3 = new DataSet();
            try
            {
                query = "select t3.ProductNumber as \"SKU Code\" , floor(SUM(t1.Quantity)) as \"Ordered NOP\",t3.description as \"Product\" from SalesOrderDetail t1 inner join SalesOrder t2 on t1.SalesOrderId = t2.SalesOrderId and t2.ber_ERPHeaderId = '" + ordernumber + "' inner join Product t3 on t1.ProductId = t3.ProductId group by t3.ProductNumber,t3.description ";
                set = this.getDataFromCRM(query);
                str2 = "SELECT  SKU as \"SKU Code\",DESCRIPTION as \"Product\",sum(INV_NOP) as \"Invoiced NOP\",sum(DESP_NOP) as \"Dispatched NOP\" ,sum(LTR) as \"LTR\", sum(KG) as \"KG\", sum(WT) as \"WT\" FROM table(xxcrm_dispatch_line_table_f('" + ordernumber + "')) where DESPATCH_ID is not null AND CANCEL_FLAG = 'N' group by SKU, Description";
                set2 = this.fetchdata(str2, "DispatchItem");
                if ((set.Tables.Count > 0) && (set2.Tables.Count > 0))
                {
                    DataTable table = set2.Tables[0];
                    DataTable table2 = set.Tables[0];
                    DataTable table3 = new DataTable();
                    table3.Columns.Add("S.No.");
                    table3.Columns.Add("SKU Code");
                    table3.Columns.Add("Product");
                    table3.Columns.Add("Ordered NOP");
                    table3.Columns.Add("Invoiced NOP");
                    table3.Columns.Add("Dispatched NOP");
                    table3.Columns.Add("LTR");
                    table3.Columns.Add("KG");
                    table3.Columns.Add("WT");
                    if (table.Rows.Count == 0)
                    {
                        set3.Tables.Add(table3);
                        return set3;
                    }
                    int num = 1;
                    foreach (DataRow row in table2.Rows)
                    {
                        DataRow row2 = table3.NewRow();
                        row2["S.No."] = num;
                        row2["SKU Code"] = row["SKU Code"];
                        row2["Product"] = row["Product"];
                        row2["Ordered NOP"] = row["Ordered NOP"];
                        row2["Invoiced NOP"] = 0;
                        row2["Dispatched NOP"] = 0;
                        row2["LTR"] = 0;
                        row2["KG"] = 0;
                        row2["WT"] = 0;
                        table3.Rows.Add(row2);
                        num++;
                    }
                    foreach (DataRow row2 in table3.Rows)
                    {
                        DataRow[] rowArray = table.Select("[SKU Code] = '" + row2["SKU Code"] + "'");
                        if ((rowArray != null) && (rowArray.Length > 0))
                        {
                            row2["Invoiced NOP"] = rowArray[0]["Dispatched NOP"];
                            row2["Dispatched NOP"] = rowArray[0]["Dispatched NOP"];
                            row2["LTR"] = rowArray[0]["LTR"];
                            row2["KG"] = rowArray[0]["KG"];
                            row2["WT"] = rowArray[0]["WT"];
                        }
                    }
                    set3.Tables.Add(table3);
                }
            }
            catch (Exception exception)
            {
                this.oLogger.Log("OracleService", "orderDispatchItem_Webmethod", "ordernumber: " + ordernumber, exception.ToString());
            }
            finally
            {
                set.Dispose();
                set2.Dispose();
            }
            return set3;
        }


        [WebMethod]
        public DataSet explodeDualPack(string parentProdId , int orderedQuantity)
        {
            string queryGetDualPackProd = "select PRODUCT_CODE \"Product Code\", PRODUCT_DESCRIPTION \"Product\", BENEFIT_QTY \"QTY\"  from table(xxcrm_dual_product_table_f('" + parentProdId + "','" + orderedQuantity + "'))";
            return fetchdata(queryGetDualPackProd, "explodeDualPack");
        }

        [WebMethod]
        public string CreateOrderItem(string serial, _OrderProduct[] OrderProducts)
        {
            string returnMessage = string.Empty;
            OleDbConnection erpConn = new OleDbConnection(oledb_oradb);
            OleDbCommand dbCommand = new OleDbCommand();
            
            _OrderProduct op = new _OrderProduct();
            try
            {
                for (int i = 0; i < OrderProducts.Length; i++)
                {
                    op = OrderProducts[i];
                    dbCommand = new OleDbCommand();
                    dbCommand.Connection = erpConn;
                    erpConn.Open();
                    dbCommand.CommandText = "apps.xxcrm_berger_ont_integration1.create_line_crm";

                    dbCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    dbCommand.Parameters.Add(new OleDbParameter("l_crm_order_id", op.CRMOrderId));
                    dbCommand.Parameters.Add(new OleDbParameter("l_item_number", op.ProductCode));
                    dbCommand.Parameters.Add(new OleDbParameter("l_item_quantity", op.Quantity));
                    dbCommand.Parameters.Add(new OleDbParameter("l_crm_line_id", op.OrderItemGuid));
                    dbCommand.Parameters.Add(new OleDbParameter("l_serial", Convert.ToInt32(serial)));
                    if (filewrite == "yes")
                        oLogger.Log("OracleService", "CreateOrderItem", "Args : " + op.CRMOrderId.ToString() + "-SKU-" + op.ProductCode + "-Quantity-" + op.Quantity + "-ItemId-" + op.OrderItemGuid + "-Serial-" + serial, "Table Name : " + dbCommand.CommandText);
                    
                    dbCommand.ExecuteNonQuery();
                    returnMessage = "SUCCESS";
                    dbCommand.Dispose();
                    erpConn.Close();
                }
            }
            catch (Exception exp)
            {
                returnMessage = exp.Message.ToString();
                oLogger.Log("OracleService", "CreateOrderItem", "Exception : " + op.CRMOrderId.ToString() + exp.Message.ToString() + exp.StackTrace.ToString(), "Table Name : " + dbCommand.CommandText + "-SKU-" + op.ProductCode + "-Quantity-" + op.Quantity + "-ItemId-" + op.OrderItemGuid + "-Serial-" + serial);
            }
            finally
            {
                dbCommand.Dispose();
                erpConn.Close();
                erpConn.Dispose();
                op = null;
            }
            return returnMessage;
        }

        [WebMethod]
        public DataSet getOrderItemStock(string OrderId)
        {
            string sqlQuery  = string.Empty;
            string oraQuery  = string.Empty;
            string sqlQueryDestSorceDepot = string.Empty;
            string SqlSplitableDepot = string.Empty;

            DataSet OrderSplitableProduct   = new DataSet();
            DataSet OrderProducts           = new DataSet();
            DataSet OracleOrderItems        = new DataSet();
            Guid requestid = Guid.NewGuid();
            bool isSplitabelProd = false;

            try
            {

                //  If five depot Exits Guwahati / Guwahati-2 / Guwahati-3 / Jammu / Srinagar-1 
                SqlSplitableDepot = " Select COUNT(*) cnt from SalesOrder s inner join ber_depot d on s.ber_DepotId = d.ber_depotId where   s.SalesOrderId = '" + OrderId.ToString() + "' " +
	                                " And d.ber_DepoterpId in ('200','479','1503','240','1142') ";

                OrderSplitableProduct = getDataFromCRM(SqlSplitableDepot);
                
                if (OrderSplitableProduct.Tables.Count != 0)
                {
                    if (Convert.ToInt32(OrderSplitableProduct.Tables[0].Rows[0]["cnt"].ToString()) > 0)
                    {
                        isSplitabelProd = true;
                    }
                    else
                    {
                        isSplitabelProd = false;
                    }
                }
                else
                {
                    isSplitabelProd = false;
                }

                if (isSplitabelProd == false)
                {
                    //  For Normal Depot .....................
                    sqlQuery = @"Select productnumber,sum(quantity) as quantity,ber_DepoterpId as depot
                                from 
                                SalesOrderDetail  with (nolock)
                                inner join SalesOrder with (nolock)     on SalesOrderDetail.SalesOrderId = SalesOrder.SalesOrderId
                                inner join ber_depot with (nolock)      on salesorder.ber_DepotId = ber_depot.ber_depotId
                                inner join Product with (nolock)        on SalesOrderDetail.productid = Product.productid 
                                where SalesOrder.salesorderid = '" + OrderId.ToString() + "' group by productnumber,ber_DepoterpId";
                }
                else
                {
                    // For Splitable Depot ......................
                    sqlQuery = "SELECT	prod.ProductNumber, SUM(oli.Quantity) AS quantity, prod.ProductId , " +
                                "                                                                   case when SalesOrder.ber_DepotIdName = '002:Guwahati'	  then '200' " +
                                "                                                                   when SalesOrder.ber_DepotIdName = '118:Guwahati-2'  then '479' " +
                                "                                                                   when SalesOrder.ber_DepotIdName = '158:Guwahati-3'  then '1503' " +
                                "                                                                   when SalesOrder.ber_DepotIdName = '027:Jammu'       then '240' " +
                                "                                                                   when SalesOrder.ber_DepotIdName = '146:Srinagar-1'  then '1142' end depot " +
                                " FROM         SalesOrderDetailBase AS oli WITH (nolock) INNER JOIN SalesOrder with (nolock)  on oli.SalesOrderId = SalesOrder.SalesOrderId " +
                                " INNER JOIN	Product AS prod ON oli.ProductId = prod.ProductId " +
                                " WHERE     (oli.SalesOrderId = '" + OrderId.ToString() + "' ) AND (prod.ProductId NOT IN " +
                                "                            (SELECT     ber_splittableproduct " +
                                "                            FROM          ber_product_depot " +
                                "                            WHERE      (ber_SourceDepot =    " +
                                "                                                        (SELECT     ber_depotId " +
                                "                                                          FROM          ber_depot AS d " +
                                "                                                          WHERE      (ber_depotId = " +
                                "                                                                                     (SELECT     ber_DepotId " +
                                "                                                                                       FROM          SalesOrder AS s " +
                                "                                                                                       WHERE      (SalesOrderId = '" + OrderId.ToString() + "'))))))) " +
                                " GROUP BY prod.ProductNumber, prod.ProductId,SalesOrder.ber_DepotIdName " +
                                " UNION " +
                                " SELECT		 prod.ProductNumber, SUM(oli.Quantity) AS quantity, prod.ProductId, case when SalesOrder.ber_DepotIdName = '002:Guwahati'	then '1423'     " +
                                "																					 when SalesOrder.ber_DepotIdName = '118:Guwahati-2'		then '1463'	    " +
                                "																					 when SalesOrder.ber_DepotIdName = '158:Guwahati-3'		then '1504'	    " +
                                "																					 when SalesOrder.ber_DepotIdName = '027:Jammu'			then '232'	    " +
                                "																					 when SalesOrder.ber_DepotIdName = '146:Srinagar-1'		then '1162'     " +
                                "																					 end as depot " +
                                " FROM         SalesOrderDetailBase AS oli WITH (nolock) INNER JOIN SalesOrder with (nolock)  on oli.SalesOrderId = SalesOrder.SalesOrderId " +
                                " INNER JOIN   Product AS prod ON oli.ProductId = prod.ProductId " +
                                " WHERE     (oli.SalesOrderId = '" + OrderId.ToString() + "') AND (prod.ProductId IN " +
                                "                          (SELECT     ber_splittableproduct " +
                                "                            FROM          ber_product_depot " +
                                "                            WHERE      (ber_SourceDepot = " +
                                "                                                       (SELECT     ber_depotId " +
                                "                                                         FROM          ber_depot AS d " +
                                "                                                         WHERE      (ber_depotId = " +
                                "                                                                                    (SELECT     ber_DepotId " +
                                "                                                                                      FROM          SalesOrder AS s " +
                                "                                                                                      WHERE      (SalesOrderId = '" + OrderId.ToString() + "'))))))) " +
                                " GROUP BY prod.ProductNumber, prod.ProductId,SalesOrder.ber_DepotIdName ";
                }
                
                OrderProducts = getDataFromCRM(sqlQuery); //OrderProducts
                if (OrderProducts.Tables.Count != 0)
                {
                        if (OrderProducts.Tables.Count != 0)
                        {
                            for (int i = 0; i < OrderProducts.Tables[0].Rows.Count; i++)
                            {
                                oraQuery = "Insert into XXCRM_STOCK_CHECK (REQUEST_ID,ITEM_CODE,DEPOT_ID,QUANTITY,ORDER_TYPE) VALUES " +
                                    "   ('" + requestid.ToString() + "', '" + OrderProducts.Tables[0].Rows[i]["productnumber"].ToString() + "', " + OrderProducts.Tables[0].Rows[i]["depot"].ToString() + ", " + OrderProducts.Tables[0].Rows[i]["quantity"].ToString() + ", '')";
                                ExecuteQueryOnOracleDB(oraQuery);
                                oraQuery = string.Empty;
                            }
                        }
                }

                oraQuery = "SELECT  DUAL_PACK as \"Dual Pack\",PRODUCT_CODE as \"SKU\",PARENT_ITEM as \"ParentSKU\",PRODUCT_DESCRIPTION as \"Product\",ORDERED_QUANTITY as \"Order NOP\", " + 
                    " nvl(FREE_STOCK,0) as \"Fresh Stock\",(nvl(MRP1,0)  + nvl(MRP2,0) + nvl(MRP3,0)) as \"Old MRP Stock\"  FROM table(xxcrm_stock_table_f('" + requestid.ToString() + "'))";
                
                OracleOrderItems = fetchdata(oraQuery, "XXCRM_STOCK_CHECK");
            }
            catch (Exception ex)
            {
                oLogger.Log("OracleService", "getOrderItemStock", OrderId.ToString() + "_" + ex.Message.ToString(), ex.StackTrace.ToString());
            }
            finally
            {
                OrderProducts.Dispose();
                sqlQuery = string.Empty;
                oraQuery = string.Empty;
            }
            return OracleOrderItems;
        }

        [WebMethod]
        public string CreateOrderMaster(string ordercode, string customernumber, string sitecustomernumber, string OrderGuid, string count,string shipmentPriority, string customerPO, string P_ATTRIBUTE_CONTEXT, string P_ATTRIBUTE1, string P_ATTRIBUTE2, string P_ATTRIBUTE3, string P_ATTRIBUTE4, string P_ATTRIBUTE5, string P_ATTRIBUTE6, string P_ATTRIBUTE7, string P_ATTRIBUTE8, string P_ATTRIBUTE9, string P_ATTRIBUTE10, string P_ATTRIBUTE11, string P_ATTRIBUTE12,bool isDraft,string orderValue,bool ccUser)
        {
            if (filewrite == "yes")
                oLogger.Log("OracleConnectWebservice", "CreateOrderMaster", "Order Amount=" + orderValue, "Is Call Center User :" + ccUser.ToString());
            string orderCreateStatus = string.Empty;    
            string orderquery = string.Empty;
            
            int response = -1;
            int custnumber = Convert.ToInt32(customernumber);
            int sitecustnumber = Convert.ToInt32(sitecustomernumber);

            DataSet Order = new DataSet();

            OleDbConnection erpConn = new OleDbConnection(oledb_oradb);
            OleDbCommand dbCommand = new OleDbCommand();
            OleDbParameter x_return_status = new OleDbParameter();
            OleDbParameter x_return_msg = new OleDbParameter();
            OleDbParameter x_serial = new OleDbParameter();

            try
            {
               
                dbCommand.Connection = erpConn;
                dbCommand.CommandText = "apps.xxcrm_berger_ont_integration1.create_order_crm";

                dbCommand.CommandType = System.Data.CommandType.StoredProcedure;
                dbCommand.Parameters.Add(new OleDbParameter("l_customer_number", custnumber));
                dbCommand.Parameters.Add(new OleDbParameter("l_site_use_id ", sitecustnumber));
                dbCommand.Parameters.Add(new OleDbParameter("l_line_count", Convert.ToInt32(count)));
                dbCommand.Parameters.Add(new OleDbParameter("l_crm_order_id", ordercode));
                dbCommand.Parameters.Add(new OleDbParameter("l_order_guid", OrderGuid));
                dbCommand.Parameters.Add(new OleDbParameter("l_header_info ", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("l_paymentmode", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("p_shipment_priority", shipmentPriority));
                dbCommand.Parameters.Add(new OleDbParameter("l_cheque_type", "LOCAL"));
                dbCommand.Parameters.Add(new OleDbParameter("l_customer_po", customerPO));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE_CONTEXT", P_ATTRIBUTE_CONTEXT));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE1", P_ATTRIBUTE1));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE2", P_ATTRIBUTE2));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE3", P_ATTRIBUTE3));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE4", P_ATTRIBUTE4));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE5", P_ATTRIBUTE5));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE6", P_ATTRIBUTE6));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE7", P_ATTRIBUTE7));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE8", P_ATTRIBUTE8));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE9", P_ATTRIBUTE9));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE10", P_ATTRIBUTE10));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE11", P_ATTRIBUTE11));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE12", P_ATTRIBUTE12));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE13", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE14", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE15", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE16", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE17", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE18", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE19", string.Empty));
                dbCommand.Parameters.Add(new OleDbParameter("P_ATTRIBUTE20", string.Empty));
                if (isDraft)
                    dbCommand.Parameters.Add(new OleDbParameter("P_BOOK", 'N'));
                else
                    dbCommand.Parameters.Add(new OleDbParameter("P_BOOK", 'Y'));

               dbCommand.Parameters.Add(new OleDbParameter("P_ORDER_TYPE", string.Empty));
               dbCommand.Parameters.Add(new OleDbParameter("P_ORDER_VALUE", orderValue));
               if (ccUser)
                   dbCommand.Parameters.Add(new OleDbParameter("P_CCUSER", 'Y'));
               else
                   dbCommand.Parameters.Add(new OleDbParameter("P_CCUSER", 'N'));

                x_return_status = new OleDbParameter("x_return_status", OleDbType.VarChar, 1000);
                x_return_status.Direction = ParameterDirection.Output;
                x_return_msg = new OleDbParameter("x_return_msg", OleDbType.VarChar, 1000);
                x_return_msg.Direction = ParameterDirection.Output;
                x_serial = new OleDbParameter("x_serial", OleDbType.Integer, 1000);
                x_serial.Direction = ParameterDirection.Output;

                dbCommand.Parameters.Add(x_return_status);
                dbCommand.Parameters.Add(x_return_msg);
                dbCommand.Parameters.Add(x_serial);

                if (filewrite == "yes")
                    oLogger.Log("OracleService", "CreateOrderMaster", "Args : " + ordercode + "_" + dbCommand.ToString(), "Table Name : " + dbCommand.CommandText );

                erpConn.Open();
                response = dbCommand.ExecuteNonQuery();

                if (response > 0)
                    orderCreateStatus = "-1" + "||" + x_serial.Value.ToString() + "||" + x_return_status.Value.ToString() + "||" + x_return_msg.Value.ToString() + "||" + response.ToString();
            }
            catch (Exception exp)
            {
                orderCreateStatus = exp.Message.ToString();
                oLogger.Log("OracleService", "CreateOrderMaster", "Exception : " + ordercode + "_" + exp.Message.ToString() + exp.StackTrace.ToString(), "Table Name : " + dbCommand.CommandText);
            }
            finally
            {
                x_return_status = null;
                x_return_msg = null;
                x_serial = null;
                dbCommand.Dispose();
                erpConn.Close();
                erpConn.Dispose();
                Order.Dispose();
                orderquery = string.Empty;
                response = 0;
                custnumber = 0;
                sitecustnumber = 0;
            }
            return orderCreateStatus;
        }
        [WebMethod]
        public string splitOrder(string orderid, string productType, string orderItemstoprocess, int numOfItems)
        {
            string retStatus = string.Empty;
            string[] itemToProcess = orderItemstoprocess.Split(',');

            try
            {
                oLogger.Log("split order", "1", "numOfItems", numOfItems.ToString());
                
                ClientCredentials credentials = new ClientCredentials();
                string serverurl = ConfigurationManager.AppSettings["OrgSvc"].ToString();
                string user = ConfigurationManager.AppSettings["user"].ToString();
                string domain = ConfigurationManager.AppSettings["domain"].ToString();
                string password = ConfigurationManager.AppSettings["password"].ToString();

                credentials.Windows.ClientCredential = new NetworkCredential(user, password, domain);
                Uri organizationUri = new Uri(serverurl);
                Uri homeRealmUri = null;
                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                
                oLogger.Log("split order", "2", "numOfItems", numOfItems.ToString());
                
                Entity order = new Entity("salesorder");
                ColumnSet orderColumns = new ColumnSet(true);
                order = orgService.Retrieve(order.LogicalName, new Guid(orderid), orderColumns);
                
                oLogger.Log("split order", "3", "length of array", itemToProcess.Length.ToString());
                
                Entity newOrder = EntityExtensions.Clone(order);
                newOrder.Attributes.Remove("salesorderid");
                newOrder.Attributes.Remove("ordernumber");
                newOrder.Attributes.Remove("statecode");
                newOrder.Attributes.Remove("statuscode");
                newOrder.Id = Guid.NewGuid();
                // make is submitted as false
                newOrder.Attributes.Remove("ber_ordersubmitted");
                newOrder.Attributes.Remove("willcall");

                oLogger.Log("split order", "4", "", "");
                // Query Order Items to be cloned
                //string sqlQuery = @"select SalesOrderDetail.SalesOrderDetailId from SalesOrderDetail with (nolock)  inner join Product with (nolock)  on SalesOrderDetail.ProductId = product.ProductId and product.ber_ProductType = '" + productType + "' where SalesOrderDetail.SalesOrderId = '" + order.Id.ToString() + "'";
                //DataSet products = orderItems;

                //clone order items

                Entity orderItem = null;
                oLogger.Log("split order", "no fo lineS", numOfItems.ToString(), "");
                if (numOfItems > 0)
                {
                    Guid newOrderId = orgService.Create(newOrder);
                    Microsoft.Xrm.Sdk.EntityReference refParent = new Microsoft.Xrm.Sdk.EntityReference(newOrder.LogicalName, newOrderId);
                    foreach (string orderItemId in itemToProcess)
                    //     foreach (DataRow dr in products.Rows)
                    {
                        orderItem = new Entity();
                        orderItem.LogicalName = "salesorderdetail";
                        orderItem.Id = new Guid(orderItemId);
                        orderItem.Attributes["salesorderid"] = refParent;
                        orgService.Update(orderItem);
                        orderItem = null;
                    }
                    //submit order flag on order
                    newOrder = new Entity();
                    newOrder.LogicalName = "salesorder";
                    newOrder.Id = newOrderId;
                    newOrder.Attributes["willcall"] = true;
                    orgService.Update(newOrder);
                }

                retStatus = "SUCCESS";
            }
            catch (Exception e)
            {
                
                oLogger.Log("splitOrder", "splitOrder" + orderid.ToString(), "prodType: " + productType, e.InnerException.Message);
                retStatus = "ERROR" +  e.StackTrace;

            }
            return retStatus;
        }

    }
}