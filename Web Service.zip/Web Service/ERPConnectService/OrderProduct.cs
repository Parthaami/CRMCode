﻿using System;
using System.Net;


namespace OracleConnectWebservice
{
    public class _OrderProduct
    {
        public String ProductCode { get; set; }
        public decimal Quantity { get; set; }
        public String OrderItemGuid { get; set; }
        public String CRMOrderId { get; set; }
        
    }
    public class _OrderItemStockQuery
    {
        public String ProductCode { get; set; }
        public decimal Quantity { get; set; }
        //public String OrderItemGuid { get; set; }
        //public String CRMOrderId { get; set; }

    }
    public class EntityReference
    {
        Guid Id { get; set; }
        String Name { get; set; }
        String LogicalName { get; set; }
    }
}
