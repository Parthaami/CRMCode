﻿using System;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel.Description;
using CRMConnectService.OracleConnect;

namespace CRMConnectService
{
    public partial class UpdateOrder : System.Web.UI.Page
    {
        string LogPath = string.Empty;
        Logger oLogger = null;
        string OracleWebServiceURL = string.Empty;
        string filewrite = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
 
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
            
            string erpOrderNo = string.Empty;
            string erpHeaderId = string.Empty;
            string crmOrderId = string.Empty;
            string status = string.Empty;
            string description = string.Empty;
            string oraRowId = string.Empty;
            try
            {
                erpOrderNo = Request.QueryString["erpOrderNo"].ToString();
                erpHeaderId = Request.QueryString["erpHeaderId"].ToString();
                crmOrderId = Request.QueryString["crmOrderId"].ToString();
                status = Request.QueryString["status"].ToString();
                description = Request.QueryString["description"].ToString();
                oraRowId = Request.QueryString["oraRowId"].ToString();
                description = description.Replace("+", " ");
                if (filewrite.ToLower() == "yes")
                {
                    oLogger.Log("CRMService", "OracleUpdateOrder _Page_Load", " oraRowId: " + oraRowId + " erpOrderNo: " + erpOrderNo + " erpHeaderId: " + erpHeaderId + " crmOrderId: " + crmOrderId + " status: " + status + " description: " + description, "");
                }
                Response.Write(UpdateOrderInCRM(erpOrderNo, erpHeaderId, crmOrderId, status, description, oraRowId));
            }
            catch (Exception ex)
            {
                oLogger.Log("CRMService", "OracleUpdateOrder_Page_Load_EXP", " oraRowId: " + oraRowId + " erpOrderNo: " + erpOrderNo + " erpHeaderId: " + erpHeaderId + " crmOrderId: " + crmOrderId + " status: " + status + " description: " + description, " Message: " + ex.ToString() + " " + ex.StackTrace.ToString());
            }
        }
        public string ExecuteQueryOnOracleDB(string query)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();

            string retStatus = "ERROR";
            OracleConnectService.Url = OracleWebServiceURL;
            try
            {
                OracleConnectService.ExecuteQueryOnOracleDB(query);
            }
            catch(Exception ex)
            {
                oLogger.Log("CRMService", "ExecuteQueryOnOracleDB", " query: " + query , " Message: " + ex.ToString() + " " + ex.StackTrace.ToString() + " " + ex.Message);
            }
            return retStatus;
        }

        public string UpdateOrderInCRM(string erpOrderNo, string erpHeaderId, string crmOrderId, string status, string description, string oraRowId)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();

            string updStatus = "ERROR";
            string oraQuery = string.Empty;
            IOrganizationService service = null;
            OrganizationServiceProxy orgService = null;
           
            AuthenticationCredentials credentials = new AuthenticationCredentials();
          
            Entity orderUpdate = new Entity();
            string orgUrl;
            try
            {
                if (filewrite.ToLower() == "yes")
                {
                    oLogger.Log("CRMService", "UpdateOrder_CRM_Update", " oraRowId: " + oraRowId + " erpOrderNo: " + erpOrderNo + " erpHeaderId: " + erpHeaderId + " crmOrderId: " + crmOrderId + " status: " + status + " description: " + description, "");
                }
               

                orgUrl = ConfigurationManager.AppSettings["CRMService"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

                service = (IOrganizationService)orgService;
                orderUpdate.LogicalName = "salesorder";
                orderUpdate.Attributes["ber_erporderno"] = erpOrderNo;
                orderUpdate.Attributes["ber_erpheaderid"] = erpHeaderId;
                orderUpdate.Attributes["ber_erporderstatus"] = status;
                orderUpdate.Attributes["ber_ebizerror"] = description;
                if (status == "TODEPOT")
                {
                    orderUpdate.Attributes["ber_integrationfaultcode"] = "06";
                    orderUpdate.Attributes["ber_erporderstatus"] = status;
                   
                }
                orderUpdate.Id = new Guid(crmOrderId);
                service.Update(orderUpdate);

                if (status == "TODEPOT")
                {
                    SetStateRequest request = new SetStateRequest();
                    request.EntityMoniker = new EntityReference("salesorder", new Guid(crmOrderId));
                    request.State = new OptionSetValue(0);
                    request.Status = new OptionSetValue(278290000);

                    SetStateResponse responce = (SetStateResponse)service.Execute(request);
                }

                updStatus = "COMPLETED";
                oraQuery = "UPDATE XXCRM_ORDER_HEADER SET CRM_STATUS = 'COMPLETED' WHERE ROWID = " + "'" + oraRowId + "'" + "";
                ExecuteQueryOnOracleDB(oraQuery);

            }
            catch (Exception ex)
            {
                updStatus = updStatus + "||" + ex.ToString();
                oLogger.Log("CRMService", "UpdateOrder_CRM_Update_EXP", " oraRowId: " + oraRowId + " erpOrderNo: " + erpOrderNo + " erpHeaderId: " + erpHeaderId + " crmOrderId: " + crmOrderId + " status: " + status + " description: " + description, " Message: " + ex.ToString() + " " + ex.StackTrace.ToString());
                oraQuery = "UPDATE XXCRM_ORDER_HEADER SET CRM_STATUS = 'ERROR', CRM_REMARKS = " + "'" + ex.Message.ToString().Replace("'"," ") + "'" + " WHERE ROWID = " + "'" + oraRowId + "'" + "";
                ExecuteQueryOnOracleDB(oraQuery);
            }
            finally
            {
                orderUpdate = null;
                orgService = null;
                credentials = null;
                service = null;
            }
            return updStatus;
        }

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["NwUserName"].ToString();
            string _password = ConfigurationManager.AppSettings["NwPassword"].ToString();
            string _domain = ConfigurationManager.AppSettings["NwDomain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
    }
}