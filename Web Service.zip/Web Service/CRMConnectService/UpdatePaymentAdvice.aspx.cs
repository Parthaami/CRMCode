﻿using System;
using System.ServiceModel;
using System.Web.UI;
using System.Configuration;
using System.Net;
using System.Text;
using System.IO;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel.Description;
using System.Web.Services.Description;
using CRMConnectService.OracleConnect;

namespace CRMConnectService
{
    public partial class UpdatePaymentAdvice : System.Web.UI.Page
    {
        string LogPath = string.Empty;
        Logger oLogger = null;
        string filewrite = string.Empty;
        OracleConnect.BergerOracleService OracleConnectService = null;
        string OracleWebServiceURL = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();

            string crmPAId = string.Empty;
            string status = string.Empty;
            string description = string.Empty;
            string requestId = string.Empty;
            try
            {
                crmPAId = Request.QueryString["crmPAId"].ToString();
                status = Request.QueryString["status"].ToString();
                description = Request.QueryString["description"].ToString();
                requestId = Request.QueryString["requestId"].ToString();
                description = description.Replace("+", " ");
                if (filewrite.ToLower() == "yes")
                {
                    oLogger.Log("CRMService", "OracleUpdatePA _Page_Load", " crmPAId: " + crmPAId + " status: " + status + " description: " + description,"");
                }
                Response.Write(UpdatePAInCRM(crmPAId, status, description, requestId));
            }
            catch (Exception ex)
            {
                oLogger.Log("CRMService", "OracleUpdatePA _Page_Load_EXP", " crmPAId: " + crmPAId + " status: " + status + " description: " + description, " Message: " + ex.ToString() + " " + ex.StackTrace.ToString() + ex.Message.ToString());
            }
        }
        public string ExecuteQueryOnOracleDB(string query)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();
           
            string retStatus = "ERROR";
            OracleConnectService.Url = OracleWebServiceURL;
            try
            {
                OracleConnectService.ExecuteQueryOnOracleDB(query);
            }
            catch (Exception ex)
            {
                oLogger.Log("CRMService", "ExecuteQueryOnOracleDB", " query: " + query, " Message: " + ex.ToString() + " " + ex.StackTrace.ToString() + " " + ex.Message);
            }
            return retStatus;
        }
        public string UpdatePAInCRM(string crmPAId, string status, string description, string requestId)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
            OracleConnect.BergerOracleService OracleConnectService = new BergerOracleService();
            OracleWebServiceURL = ConfigurationManager.AppSettings["OracleWebServiceURL"].ToString();

            string updStatus = "ERROR";
            IOrganizationService service = null;
            OrganizationServiceProxy orgService = null;
            //ClientCredentials credentials = new ClientCredentials();
            AuthenticationCredentials credentials = new AuthenticationCredentials();
            //Uri blankURI = null;
            Entity paUpdate = new Entity();
            string oraQuery = string.Empty;
            string orgUrl;
            try
            {
                if (filewrite.ToLower() == "yes")
                {
                    oLogger.Log("CRMService", "UpdatePA_CRM_Update", " crmPAId: " + crmPAId + " status: " + status + " description: " + description, "");
                }

                //credentials.Windows.ClientCredential = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["NwUserName"].ToString(), ConfigurationManager.AppSettings["NwPassword"].ToString(), ConfigurationManager.AppSettings["NwDomain"].ToString());
                //orgService = new OrganizationServiceProxy(new Uri(ConfigurationManager.AppSettings["CRMService"].ToString()), blankURI, credentials, null);
                orgUrl = ConfigurationManager.AppSettings["CRMService"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
                service = (IOrganizationService)orgService;

                paUpdate.LogicalName = "ber_paymentadvice";
                paUpdate.Attributes["ber_erpstatus"] = status;
                paUpdate.Attributes["ber_erpremarks"] = description;
                paUpdate.Id = new Guid(crmPAId);
                service.Update(paUpdate);
                updStatus = "COMPLETED";
                oraQuery = "UPDATE xxcrm_payment_Advice SET CRM_STATUS = 'COMPLETED' WHERE PR_ID = " + "'" + crmPAId + "'" + "  AND REQUEST_ID = " + "'" + requestId + "'" + "";
                ExecuteQueryOnOracleDB(oraQuery);

            }
            catch (Exception ex)
            {
                updStatus = updStatus + "||" + ex.ToString();
                oLogger.Log("CRMService", "UpdatePA_CRM_Update_EXP", " crmPAId: " + crmPAId + " status: " + status + " description: " + description, " Message: " + ex.ToString() + " " + ex.StackTrace.ToString() + " " + ex.Message.ToString());
                oraQuery = "UPDATE XXCRM_ORDER_HEADER SET xxcrm_payment_Advice CRM_STATUS = 'ERROR', CRM_REMARKS = " + "'" + ex.Message.ToString().Replace("'", " ") + "'" + " WHERE PR_ID = " + "'" + crmPAId + "'" + "  AND REQUEST_ID = " + "'" + requestId + "'" + "";
                ExecuteQueryOnOracleDB(oraQuery);
            }
            finally
            {
                paUpdate = null;
                orgService = null;
                credentials = null;
                service = null;
            }
            return updStatus;
        }

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["NwUserName"].ToString();
            string _password = ConfigurationManager.AppSettings["NwPassword"].ToString();
            string _domain = ConfigurationManager.AppSettings["NwDomain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

    }
}