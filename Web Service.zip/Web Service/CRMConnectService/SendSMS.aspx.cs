﻿using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Net;
using System.Text;

namespace CRMConnectService
{
    public partial class SendSMS : System.Web.UI.Page
    {

        string LogPath = string.Empty;
        Logger oLogger = null;
        string filewrite = string.Empty;
        string URLType = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
                oLogger = new Logger("Berger", LogPath);
                filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
                URLType = ConfigurationManager.AppSettings["URL"].ToString();

                if (Request.QueryString["phno"] != null && Request.QueryString["message"] != null)
                {
                    string PhoneNum = Request.QueryString["phno"].ToString();
                    string Msg = Request.QueryString["message"].ToString();
                    if (filewrite.ToLower() == "yes")
                    {
                        oLogger.Log("CRMService", "SendSMS_Page_Load", "PhoneNum: " + PhoneNum, "Message: " + Msg);
                    }
                    string SMSResponse = SendsSMS(URLType, PhoneNum, Msg);
                    if (filewrite.ToLower() == "yes")
                    {
                        oLogger.Log("CRMService", "SendSMS_Page_Load", "SMSResponse: " + SMSResponse, "");
                    }
                    Response.Write(SMSResponse);
                }
                else
                {
                    oLogger.Log("CRMService", "SendSMS_Page_Load", "Expected Query String parameters missing.","");
                    Response.Write("Expected Query String parameters missing. Please provide appropriate paramters to send SMS.");
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("CRMService", "SendSMS_Page_Load", ex.Message, ex.StackTrace.ToString() + ex.Message.ToString());
            }
        }
        public string SendsSMS(string URL, string PhoneNum, string oMsg)
        {
            LogPath = ConfigurationManager.AppSettings["loggerPath"].ToString().ToLower();
            oLogger = new Logger("Berger", LogPath);
            filewrite = ConfigurationManager.AppSettings["filewrite"].ToString();
            URLType = ConfigurationManager.AppSettings["URL"].ToString();

            string responseStatus = string.Empty;
            string sendData = oMsg;
            string Url = URL + PhoneNum + "&text=" + oMsg;
            HttpWebResponse response = null;
            HttpWebRequest request = null;
            byte[] byteArray = null;
            Stream IOStream = null;
            Encoding enc = null;
            StreamReader ResponseStream = null;
            string retValue = string.Empty;

            try
            {
                request = (HttpWebRequest)WebRequest.Create(Url);
                if (filewrite.ToLower() == "yes")
                {
                    oLogger.Log("CRMService", "SendSMS_SendsSMS", "Url: " + Url, "Phone: " + PhoneNum);
                }
                request.Method = "POST";
                byteArray = Encoding.UTF8.GetBytes(sendData);
                request.ContentLength = byteArray.Length;
                request.ContentType = "application/x-www-form-urlencoded";
                IOStream = request.GetRequestStream();
                IOStream.Write(byteArray, 0, byteArray.Length);
                IOStream.Close();
                request.AllowAutoRedirect = true;
                response = (HttpWebResponse)request.GetResponse();
                       
                enc = Encoding.GetEncoding(response.CharacterSet);
                ResponseStream = new StreamReader(response.GetResponseStream(), enc);
                responseStatus = ResponseStream.ReadToEnd();
                ResponseStream.Close();
                response.Close();
                retValue = "SMSENT";
            }
            catch (Exception ex)
            {
                oLogger.Log("SMS Sending Failed", "SendSMS_SendsSMS: " + Url, ex.ToString(), ex.StackTrace.ToString() + ex.Message.ToString());
                retValue = "SMSFAILED";
            }
            finally
            {
                response = null;
                request = null;
                byteArray = null;
                enc = null;
                ResponseStream.Dispose();
                IOStream.Dispose();
            }
            return responseStatus.ToString() + " " + retValue;
        }
    }
}