﻿// -----------------------------------------------------------------------
// <copyright file="AssignShareLD.cs" company="Pragmasys Consulting LLP">
// TODO: Pragmasys Consulting LLP (c).  All rights reserved.
// </copyright>
// -----------------------------------------------------------------------

[assembly: System.CLSCompliant(true)]

namespace Berger.Plugin.AssignLiftingDts_ShareWithBDM
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Data;
    using System.IO;
    using System.Text;      
    using System.Xml;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Win32;
    using Microsoft.Xrm.Sdk;    
    using Microsoft.Xrm.Sdk.Messages;    

    /// <summary>
    /// Class AssignShareLD is used to assign lifting details to dealer owner and share lifting details
    /// with dealer-depot, BDM user.
    /// </summary>
    public class AssignShareLD : IPlugin
    {
        /// <summary>
        /// Configuration object
        /// </summary>
        private static System.Configuration.Configuration config;

        /// <summary>
        /// Logger class object
        /// </summary>
        private static PragmasysLogger objLogger;

        /// <summary>
        /// Plugin main method
        /// </summary>
        /// <param name="serviceProvider">IService provider object</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ////ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string organizationName = context.OrganizationName;
                ////Guid callingUserId = context.UserId;
                ////string primaryEntityName = context.PrimaryEntityName;
                ////Guid primaryEntityId = context.PrimaryEntityId;
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string db_Path = obj_dbpath.ToString();

                string configpath = db_Path + "\\CRMWeb\\ISV\\" + organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    ////  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        objLogger = new PragmasysLogger(organizationName, loggerPath);                      
                    }
                }

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity liftingDetailsEntity = (Entity)context.InputParameters["Target"];
                    if (liftingDetailsEntity.Attributes.Contains("ber_dealerid"))
                    {
                        EntityReference liftingDetailsDealer = (EntityReference)liftingDetailsEntity["ber_dealerid"];

                        StringBuilder query = new StringBuilder();
                        query.Append("<fetch mapping='logical' >");
                        query.Append("<entity name='account'>");
                        query.Append("<attribute name='accountid' />");
                        query.Append("<attribute name='ownerid' />");
                        query.Append("<filter type='and'>");
                        query.Append("<condition attribute='accountid' operator='eq' uitype='account' value='" + liftingDetailsDealer.Id + "' />");
                        query.Append("</filter>");
                        query.Append("<link-entity name='ber_depot' from='ber_depotid' to='ber_depotid' visible='false' link-type='outer' alias='dpt'>");
                        query.Append("<attribute name='ber_bdmid' />");
                        query.Append("</link-entity>");
                        query.Append("</entity>");
                        query.Append("</fetch>");

                        EntityCollection result = Retrieve(service, query.ToString());

                        if (result.Entities.Count > 0)
                        {
                            Entity entDealer = result.Entities[0];

                            ////Assign Lifting details to Dealer owner
                            if (entDealer.Attributes.Contains("ownerid"))
                            {
                                EntityReference dealerRecordOwner = (EntityReference)entDealer["ownerid"];
                                AssignRequest assign = new AssignRequest
                                {
                                    Assignee = new EntityReference(dealerRecordOwner.LogicalName, dealerRecordOwner.Id),
                                    Target = new EntityReference(liftingDetailsEntity.LogicalName, liftingDetailsEntity.Id)
                                };
                                service.Execute(assign);                              
                            }

                            ////Share Lifting Details with Dealer-Depot,BDM user.
                            if (entDealer.Attributes.Contains("dpt.ber_bdmid"))
                            {
                                EntityReference depotBDMUser = (EntityReference)((AliasedValue)entDealer["dpt.ber_bdmid"]).Value;
                                ShareRecord(service, depotBDMUser, liftingDetailsEntity.LogicalName, liftingDetailsEntity.Id);
                            }
                        }                      
                    }
                }
            }
            catch (InvalidCastException fex)
            {
                objLogger.Log("Berger.Plugin.AssignLiftingDts_ShareWithBDM", "Execute", fex.Message, fex.StackTrace.ToString());
            }
            catch (Exception ex)
            {
                objLogger.Log("Berger.Plugin.AssignLiftingDts_ShareWithBDM", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Function to Share Record
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="assigneeUser">Assigned to user reference</param>
        /// <param name="entityName">Entity name which is assigned to user</param>
        /// <param name="entityId">Entity record unique id</param>        
        public static void ShareRecord(IOrganizationService crmService, EntityReference assigneeUser, string entityName, Guid entityId)
        {
            try
            {
                GrantAccessRequest shareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ReadAccess | AccessRights.AppendAccess | AccessRights.AppendToAccess,
                        Principal = assigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };

                crmService.Execute(shareRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Function to Retrieve Data from Fetch XMl
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="strFetchXML">Fetch xml</param>
        /// <returns>Result collection</returns>
        private static EntityCollection Retrieve(IOrganizationService crmService, string strFetchXML)
        {
            RetrieveMultipleResponse objResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)crmService.Execute(fetch);

                RetrieveMultipleRequest objRequest = new RetrieveMultipleRequest();
                objRequest.Query = qe.Query;

                objResponse = (RetrieveMultipleResponse)crmService.Execute(objRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objResponse.EntityCollection;
        }   
    }
}
