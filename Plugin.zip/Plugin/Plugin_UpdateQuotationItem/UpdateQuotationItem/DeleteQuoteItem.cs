﻿//========================================================================
//  This plugin executed on Delete event of Quotation Item(Estimate Item) record.
//  It manages the Estimate Amount.
//
//  Copyright @ Pragmasys Consulting LLP.
//========================================================================


namespace UpdateQuotationItem
{
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;
    using System;
    using System.Configuration;
    using Microsoft.Win32;
    using System.IO;

    public class DeleteQuoteItem : IPlugin
    {
        public static System.Configuration.Configuration config;        
        public static Logger oLogger = null;
        

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationService service = ((IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(new Guid?(context.UserId));
                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is EntityReference))
                {
                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();
                    
                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                    */
                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                           string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);                            
                        }
                    }
                    #endregion

                    EntityReference reference = (EntityReference)context.InputParameters["Target"];
                    ColumnSet set = new ColumnSet();
                    Entity entity = new Entity();
                    QueryExpression query = null;
                    EntityCollection entitys = new EntityCollection();
                    query = new QueryExpression("ber_quotationitem");
                    set.AddColumns(new string[] { "ber_totalamount" });
                    query.ColumnSet = set;
                    query.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, new object[] { ((EntityReference)context.PreEntityImages["QuotItem"].Attributes["ber_estimateid"]).Id.ToString() });
                    entitys = service.RetrieveMultiple(query);
                    decimal num = 0M;
                    for (int i = 0; i < entitys.Entities.Count; i++)
                    {
                        if (entitys.Entities[i] != null)
                        {
                            decimal num3 = ((Money)entitys.Entities[i]["ber_totalamount"]).Value;
                            num += num3;
                        }
                    }
                    //Get Estimate Discount Percentages.
                    int DiscountPer = 0;
                    ColumnSet eEstimateSet = new ColumnSet();
                    eEstimateSet.AddColumns(new string[] { "ber_discount" });
                    Entity eEstimate = service.Retrieve("ber_estimatedetails", ((EntityReference)context.PreEntityImages["QuotItem"].Attributes["ber_estimateid"]).Id, eEstimateSet);
                    if (eEstimate.Attributes.Contains("ber_discount"))
                    {
                        DiscountPer = Convert.ToInt32(eEstimate["ber_discount"]);
                    }

                    Entity entity2 = new Entity();
                    entity2.LogicalName = "ber_estimatedetails";
                    entity2.Id = ((EntityReference)context.PreEntityImages["QuotItem"].Attributes["ber_estimateid"]).Id;
                    entity2.Attributes["ber_grandtotal"] = new Money(num);
                    if (num > 0)
                        entity2.Attributes["ber_netamount"] = new Money(num - ((DiscountPer * num) / 100));
                    else
                        entity2.Attributes["ber_netamount"] = new Money(0);

                    service.Update(entity2);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("UpdateQuotationItem", "Execute", "Error on Delete of Quotation Item", ex.Message.ToString());
            }
        }
    }
}
