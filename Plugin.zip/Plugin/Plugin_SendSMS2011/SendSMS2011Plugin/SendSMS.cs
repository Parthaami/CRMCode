﻿// =====================================================================
//  This Plugin is triggered on Create event of SMS Activity record.
//  It takes Mobile number and description from SMS entity as input parameter
//  and call HTTP request on SMS gateway url.
//  The responce of HTTP Request gets updated in SMS entity record.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using System.IO;
using System.Net;
using Microsoft.Crm.Sdk.Messages;
using System.Net.Http;
using Newtonsoft.Json;

namespace SendSMS2011Plugin
{
    public class Parameter
    {
        public string MobileNumber { get; set; }

        public string SMSMessage { get; set; }

        public string IsServiceEnabled { get; set; }

    }
    public class SendSMS : IPlugin
    {
        #region Class Level Variables

        public static string _loggerPath = string.Empty;
        public System.Configuration.Configuration config;
        public static Logger oLogger;
        IOrganizationService service;

        public string URL = string.Empty;
        public string Message = string.Empty;

        public string ProxyServerIP = string.Empty;
        public string ProxyServerPort = string.Empty;
        public string responseStatus = string.Empty;

        public string urName = string.Empty;
        public string Passwd = string.Empty;
        public string oDomain = string.Empty;

        //public string PrintLog = string.Empty;
        public string SendAllSMS = string.Empty;
        public string _organizationName = string.Empty;
        public Guid oEntityId = Guid.Empty;
        public string oEntityName = string.Empty;

        public string SMSServerUrl = string.Empty;

        public string IsServiceEnabled = string.Empty; 

        #endregion

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                _organizationName = context.OrganizationName;
                oEntityId = context.PrimaryEntityId;
                oEntityName = context.PrimaryEntityName;

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity entity = (Entity)context.InputParameters["Target"];

                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                    */

                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(_organizationName, _loggerPath);
                            URL = config.AppSettings.Settings["SMSURL"].Value.ToString();
                            Message = config.AppSettings.Settings["SMSMSG"].Value.ToString();
                            ProxyServerIP = config.AppSettings.Settings["ProxyIP"].Value.ToString();
                            ProxyServerPort = config.AppSettings.Settings["ProxyPort"].Value.ToString();
                            //Proxy Server Creadentials
                            urName = config.AppSettings.Settings["ProxyUserName"].Value.ToString();
                            Passwd = config.AppSettings.Settings["ProxyPassword"].Value.ToString();
                            oDomain = config.AppSettings.Settings["ProxyDomain"].Value.ToString();

                            //PrintLog = config.AppSettings.Settings["PrintSMSLog"].Value.ToString();
                            SendAllSMS = config.AppSettings.Settings["SendAllSMS"].Value.ToString();

                            SMSServerUrl = config.AppSettings.Settings["SMSServerUrl"].Value.ToString();

                            IsServiceEnabled = config.AppSettings.Settings["IsSMSServiceEnabled"].Value.ToString();
                            tracingService.Trace("SMSServerUrl: " + SMSServerUrl);
                        }
                    }
                    #endregion

                    //If SMS Source is not Batch Service.
                    if (!(entity.Attributes.Contains("ber_smssource")) || (entity.Attributes.Contains("ber_smssource") && SendAllSMS.ToLower() == "yes"))
                    {
                        // Obtain the target entity from the input parmameters.
                        string MessageBody = string.Empty;
                        string MobileNo = string.Empty;
                        string SMSDirection = string.Empty;

                        if (entity.LogicalName == "pcl_sms")
                        {
                            if (entity.Attributes.Contains("description"))
                            {
                                MessageBody = entity.Attributes["description"].ToString();
                            }
                            if (entity.Attributes.Contains("pcl_mobilenumber"))
                            {
                                MobileNo = entity.Attributes["pcl_mobilenumber"].ToString();
                            }
                            if (entity.Attributes.Contains("pcl_direction"))
                            {
                                SMSDirection = entity.Attributes["pcl_direction"].ToString();
                            }
                            if (SMSDirection.ToLower() == "false") //false is nothing but SMS direction is Outgoing
                            {
                                if (URL != string.Empty || URL != null || URL != "")
                                {
                                    //string responce = sendSMS(URL, MessageBody, ProxyServerIP, ProxyServerPort, MobileNo);
                                    var spilttedMobileNumber = MobileNo.Split(',');
                                    foreach (var item in spilttedMobileNumber)
                                    {
                                        string responce = sendSMS(item, MessageBody, IsServiceEnabled);
                                        tracingService.Trace("Response:" + responce);
                                        updateSMSResponce(entity.Id, entity.LogicalName, responce);
                                    }
                                }
                                else
                                {
                                    oLogger.Log("SendSMS2011Plugin", "Execute", "SMS Url is Empty.", "Please Check Configuration");
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SendSMS2011Plugin", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        public string sendSMS(string URL, string oMsgBody, string ProxyServer, string ProxyServerPort, string oMobileNo)
        {
            try
            {
                string sendData = string.Empty;
                oMsgBody = oMsgBody.Replace(" ", "+");
                sendData = sendData + Message;
                sendData = sendData.Replace("Desc", oMsgBody);
                sendData = sendData.Replace("MobileNumber", oMobileNo);

                // Send it to the vendor
                string Uri = URL;

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Uri);
                if (oDomain != null && oDomain != "" && oDomain != "null")
                    request.Credentials = new NetworkCredential(urName, Passwd, oDomain);
                else
                    request.Credentials = new NetworkCredential(urName, Passwd);

                //if (ProxyServer != null && ProxyServer != "null" && ProxyServerPort != null && ProxyServerPort != "null")
                //{
                //    request.Proxy = new WebProxy(ProxyServer, Convert.ToInt32(ProxyServerPort));
                //    if (oDomain != null && oDomain != "" && oDomain != "null")
                //        request.Proxy.Credentials = new NetworkCredential(urName, Passwd, oDomain);
                //    else
                //        request.Credentials = new NetworkCredential(urName, Passwd);
                //}
                request.Method = "POST";
                byte[] byteArray = Encoding.UTF8.GetBytes(sendData);
                request.ContentLength = byteArray.Length;
                request.ContentType = "application/x-www-form-urlencoded";
                Stream IOStream = request.GetRequestStream();
                IOStream.Write(byteArray, 0, byteArray.Length);
                IOStream.Close();
                request.AllowAutoRedirect = true;

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                Encoding enc = Encoding.GetEncoding(response.CharacterSet);
                StreamReader ResponseStream = new StreamReader(response.GetResponseStream(), enc);
                responseStatus = ResponseStream.ReadToEnd();
                oLogger.Log("SendSMS2011Plugin", "SendSMS", "SMS Url: " + URL + sendData, "Responce: " + responseStatus);
                ResponseStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                oLogger.Log("SendSMS2011Plugin", "SendSMS", ex.Message, ex.StackTrace.ToString());
            }
            return responseStatus;
        }


        public string sendSMS(string MobileNumber, string SMSMessageString, string IsServiceEnabled)
        {
            string responseBody = string.Empty;
            try
            {

                using (var client = new HttpClient())
                {

                    Parameter param = new Parameter { MobileNumber = MobileNumber, SMSMessage = SMSMessageString, IsServiceEnabled= IsServiceEnabled };
                    var json = JsonConvert.SerializeObject(param);
                    client.BaseAddress = new Uri(SMSServerUrl);
                    var response = client.PostAsync("sms/SendSMS", new StringContent(json, Encoding.UTF8, "application/json")).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        responseBody = response.Content.ReadAsStringAsync().Result;
                    }
                    else
                        responseBody = "SMS Sending failed " ;
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("SendSMS2011Plugin", "SendSMS", ex.Message, ex.StackTrace.ToString());
            }
            return responseBody;
        }

        #region Function to update SMS responce and change activity status to completed
        public void updateSMSResponce(Guid activityId, string entityName, string msgStatus)
        {
            try
            {
                Entity updateEntity = new Entity(entityName);
                updateEntity.Id = activityId;
                updateEntity["pcl_smsresponce"] = msgStatus;
                service.Update(updateEntity);

                //Set status to sms send
                SetStateRequest oRequest = new SetStateRequest();
                oRequest.EntityMoniker = new EntityReference(entityName, activityId);
                oRequest.Status = new OptionSetValue(2);
                oRequest.State = new OptionSetValue(1);
                SetStateResponse oResponse = (SetStateResponse)service.Execute(oRequest);
                oLogger.Log("SendSMS2011Plugin", "updateSMSResponce", "SMS Activity Id: " + activityId.ToString(), "Responce: " + msgStatus);
            }
            catch (Exception ex)
            {
                oLogger.Log("SendSMS2011Plugin", "updateSMSResponce", "SMS Activity Id: " + activityId.ToString() + "--" + ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion
    }
}
