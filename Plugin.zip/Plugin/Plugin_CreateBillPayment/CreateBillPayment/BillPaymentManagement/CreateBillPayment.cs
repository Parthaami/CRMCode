﻿// =====================================================================
//  This plugin is triggered on Home Decor Dealer Payment/Contractor Payment Entities Create/Update/Delete Event.
//  The basic bussiness login in this code is while Creating/Updating Dealer Payment/Contractor Payment it verifies that 
//  by making the current payment to dealer/contractor will affect on Berger Remittance or not.
//  If it will reduces BR by expected % then it doesn't allows for record creation.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Query;

namespace CreateBillPayment.BillPaymentManagement
{
    public class CreateBillPayment : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;
        

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
                
                // The InputParameters collection contains all the data passed in the message request.
                 if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
               
                    #region To Read Config File
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    Entity targetEntity = new Entity();

                    if (context.MessageName == "Create")
                        targetEntity = (Entity)context.InputParameters["Target"];

                    #region For Bill Payment Create.
                    if (targetEntity.LogicalName == "ber_dealerpaymentdetail" && targetEntity.Attributes.Contains("ber_estimatedetailsid") && targetEntity.Attributes.Contains("ber_amount"))
                    {

                        decimal currentPayment = 0;
                        if (targetEntity.Attributes.Contains("ber_amount"))
                        {
                            currentPayment = ((Money)targetEntity["ber_amount"]).Value;
                        }

                        //Retrive All Bill Details for the Estimate.
                        ColumnSet BillDetailsCols = new ColumnSet();
                        Entity BillDetailsEntity = new Entity();
                        QueryExpression billDetailsQry = null;
                        EntityCollection ec = new EntityCollection();
                        billDetailsQry = new QueryExpression("ber_billdetail");
                        BillDetailsCols.AddColumns(new string[] { "ber_amount", "ber_pendingamount" });
                        billDetailsQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id.ToString());
                        billDetailsQry.ColumnSet = BillDetailsCols;
                        ec = service.RetrieveMultiple(billDetailsQry);

                        decimal billDetailsAmount = 0;
                        foreach (Entity billDetail in ec.Entities)
                        {
                            if (billDetail.Attributes.Contains("ber_amount") && billDetail.Attributes.Contains("ber_pendingamount"))
                            {
                                billDetailsAmount = billDetailsAmount + (((Money)billDetail["ber_amount"]).Value - ((Money)billDetail["ber_pendingamount"]).Value);
                            }
                        }

                        //Retrive Contractor Payment Amount Total.
                        ColumnSet ContPaymentCols = new ColumnSet();
                        Entity ContractorPaymentEntity = new Entity();
                        QueryExpression contractorPayQry = null;
                        EntityCollection contractorPayColl = new EntityCollection();
                        contractorPayQry = new QueryExpression("ber_contractorpaynmentdetail");
                        ContPaymentCols.AddColumns(new string[] { "ber_amount" });
                        contractorPayQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id.ToString());
                        contractorPayQry.ColumnSet = ContPaymentCols;
                        contractorPayColl = service.RetrieveMultiple(contractorPayQry);

                        decimal contractorPaymentTotal = 0;
                        foreach (Entity contPayment in contractorPayColl.Entities)
                        {
                            if (contPayment.Attributes.Contains("ber_amount"))
                            {
                                contractorPaymentTotal = contractorPaymentTotal + ((Money)contPayment["ber_amount"]).Value;
                            }
                        }

                        //Retrive Estimate Job value.
                        ColumnSet EstimateCols = new ColumnSet();
                        EstimateCols.AllColumns = true;                    
                        Entity EstimateEntity = new Entity();
                        EstimateEntity = service.Retrieve("ber_estimatedetails", ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id, EstimateCols);

                        if (EstimateEntity.Attributes.Contains("ber_netamount"))
                        {
                            decimal jobValue = ((Money)EstimateEntity["ber_netamount"]).Value;

                            if (EstimateEntity.Attributes.Contains("ber_br"))
                            {
                                decimal BR = Convert.ToDecimal(EstimateEntity["ber_br"]);

                                decimal JV = (jobValue - (billDetailsAmount + contractorPaymentTotal + currentPayment)) / jobValue  * 100 ;
                                if (BR <=  JV)
                                {
                                    //Update Bill Detail.
                                    if (targetEntity.Attributes.Contains("ber_billdetailid"))
                                    {
                                        ColumnSet currentBillDetailCols = new ColumnSet();
                                        currentBillDetailCols.AddColumns(new string[] { "ber_pendingamount" });
                                        Entity currentBillDetail = service.Retrieve("ber_billdetail", ((EntityReference)targetEntity.Attributes["ber_billdetailid"]).Id, currentBillDetailCols);

                                        if (currentBillDetail.Attributes.Contains("ber_pendingamount"))
                                        {
                                            Entity updateBillDetail = new Entity("ber_billdetail");
                                            updateBillDetail.Id = ((EntityReference)targetEntity.Attributes["ber_billdetailid"]).Id;
                                            updateBillDetail["ber_pendingamount"] = new Money(decimal.Round(((Money)currentBillDetail["ber_pendingamount"]).Value - currentPayment,2));
                                            service.Update(updateBillDetail);
                                        }
                                    }
                                }
                                else
                                {
                                    decimal BRAmount = (jobValue / 100) * BR;
                                    decimal TotalMaxPayableAmt = jobValue - BRAmount;
                                    decimal CurrentMaxPayableAmt = TotalMaxPayableAmt - (billDetailsAmount + contractorPaymentTotal);
                                    throw new Exception("Payment can not be processed.Processing this payment will reduce Berger Remittance below set limit.BR is " + Convert.ToString(EstimateEntity["ber_br"]) + "%.Max Payable Amt is " + decimal.Round(CurrentMaxPayableAmt,2));
                                }
                            }
                        }
                    }
                    #endregion

                    #region For Contractor Bill Create.
                    if (targetEntity.LogicalName == "ber_contractorpaynmentdetail" && targetEntity.Attributes.Contains("ber_estimateid") && targetEntity.Attributes.Contains("ber_amount"))
                    {
                        decimal currentPayment = 0;
                        if (targetEntity.Attributes.Contains("ber_amount"))
                        {
                            currentPayment = ((Money)targetEntity["ber_amount"]).Value;
                        }


                        //Retrive Contractor Payment Amount Total.
                        ColumnSet ContPaymentCols = new ColumnSet();
                        Entity ContractorPaymentEntity = new Entity();
                        QueryExpression contractorPayQry = null;
                        EntityCollection contractorPayColl = new EntityCollection();
                        contractorPayQry = new QueryExpression("ber_contractorpaynmentdetail");
                        ContPaymentCols.AddColumns(new string[] { "ber_amount" });
                        contractorPayQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, ((EntityReference)targetEntity.Attributes["ber_estimateid"]).Id.ToString());
                        contractorPayQry.ColumnSet = ContPaymentCols;
                        contractorPayColl = service.RetrieveMultiple(contractorPayQry);

                        decimal contractorPaymentTotal = 0;
                        foreach (Entity contPayment in contractorPayColl.Entities)
                        {
                            if (contPayment.Attributes.Contains("ber_amount"))
                            {
                                contractorPaymentTotal = contractorPaymentTotal + ((Money)contPayment["ber_amount"]).Value;
                            }
                        }

                        //Retrive All Bill Details for the Estimate.
                        ColumnSet BillDetailsCols = new ColumnSet();
                        Entity BillDetailsEntity = new Entity();
                        QueryExpression billDetailsQry = null;
                        EntityCollection ec = new EntityCollection();
                        billDetailsQry = new QueryExpression("ber_billdetail");
                        BillDetailsCols.AddColumns(new string[] { "ber_amount", "ber_pendingamount" });
                        billDetailsQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, ((EntityReference)targetEntity.Attributes["ber_estimateid"]).Id.ToString());
                        billDetailsQry.ColumnSet = BillDetailsCols;
                        ec = service.RetrieveMultiple(billDetailsQry);

                        decimal billDetailsAmount = 0;
                        foreach (Entity billDetail in ec.Entities)
                        {
                            if (billDetail.Attributes.Contains("ber_amount") && billDetail.Attributes.Contains("ber_pendingamount"))
                            {
                                billDetailsAmount = billDetailsAmount + (((Money)billDetail["ber_amount"]).Value - ((Money)billDetail["ber_pendingamount"]).Value);
                            }
                        }

                        //Retrive Estimate Job value.
                        ColumnSet EstimateCols = new ColumnSet();
                        EstimateCols.AllColumns = true;
                        Entity EstimateEntity = new Entity();
                        EstimateEntity = service.Retrieve("ber_estimatedetails", ((EntityReference)targetEntity.Attributes["ber_estimateid"]).Id, EstimateCols);

                        if (EstimateEntity.Attributes.Contains("ber_netamount"))
                        {
                            decimal jobValue = ((Money)EstimateEntity["ber_netamount"]).Value;

                            if (EstimateEntity.Attributes.Contains("ber_br"))
                            {
                                decimal BR = Convert.ToDecimal(EstimateEntity["ber_br"]);

                                decimal JV = (jobValue - (billDetailsAmount + contractorPaymentTotal + currentPayment)) / jobValue * 100;

                                if (!(BR <= JV))
                                {
                                    decimal BRAmount = (jobValue / 100) * BR;
                                    decimal TotalMaxPayableAmt = jobValue - BRAmount;
                                    decimal CurrentMaxPayableAmt = TotalMaxPayableAmt - (billDetailsAmount + contractorPaymentTotal);
                                    throw new Exception("Contractor Payment can not be processed.Processing this payment will reduce Berger Remittance below set limit. BR is " + Convert.ToString(EstimateEntity["ber_br"]) + "%.Max Payable Amt is " + decimal.Round(CurrentMaxPayableAmt, 2));
                                }                                
                            }
                        }

                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("CreateBillPayment", "Execute", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
    }
}
