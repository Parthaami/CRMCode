﻿// =====================================================================
//  This plugin is triggered on Home Decor Dealer Payment Entitie Delete Event.
//  It manages the Dealer Payment Amount on deletion of any existing payment.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Win32;
using System.Configuration;
using System.IO;
using Microsoft.Xrm.Sdk.Query;

namespace CreateBillPayment.BillPaymentManagement
{
    public class DeleteBillPayment : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger = null;

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                // Obtain the execution context from the service provider.
                Microsoft.Xrm.Sdk.IPluginExecutionContext context = (Microsoft.Xrm.Sdk.IPluginExecutionContext)
                  serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));

                // Obtain the organization service reference.
                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                // The InputParameters collection contains all the data passed in the message request.
                if (context.InputParameters.Contains("Target") &&
                  context.InputParameters["Target"] is EntityReference)
                {
                    #region To Read Config File
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    EntityReference targetEntity = (EntityReference)context.InputParameters["Target"];

                    ColumnSet currentBillDetailCols = new ColumnSet();
                    currentBillDetailCols.AddColumns(new string[] { "ber_pendingamount" });
                    Entity currentBillDetail = service.Retrieve("ber_billdetail", ((EntityReference)context.PreEntityImages["BillPay"].Attributes["ber_billdetailid"]).Id, currentBillDetailCols);

                    if (currentBillDetail.Attributes.Contains("ber_pendingamount"))
                    {
                        Entity updateBillDetail = new Entity("ber_billdetail");
                        updateBillDetail.Id = ((EntityReference)context.PreEntityImages["BillPay"].Attributes["ber_billdetailid"]).Id;
                        updateBillDetail["ber_pendingamount"] = new Money(decimal.Round(((Money)currentBillDetail["ber_pendingamount"]).Value + ((Money)(context.PreEntityImages["BillPay"].Attributes["ber_amount"])).Value,2));
                        service.Update(updateBillDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("CreateBillPayment", "Error on Delete of Bill Payment. ", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
