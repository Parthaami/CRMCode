﻿// =====================================================================
//  This plugin manages the values on Customer Invoice Entity based on Home Decor Estimate values.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Xml;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Query;

namespace Plugin_CustomerInvoiceManagement
{
    public class InvoiceManagement : IPlugin
    {
        //Class Level Variables
        public static System.Configuration.Configuration config;
        public static string oConfig = string.Empty;
        public static Logger oLogger;
      
      
        
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));


                string _organizationName = context.OrganizationName;

                //Check the Estimate Status is Job Closed or not.
                if (context.PrimaryEntityName == "ber_estimatedetails" && context.InputParameters.Contains("EntityMoniker") && context.InputParameters["EntityMoniker"] is EntityReference
                    && ((OptionSetValue)context.InputParameters["State"]).Value == 1 && ((OptionSetValue)context.InputParameters["Status"]).Value == 278290002)
                {
                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";

                    */
                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    //EntityReference targetEntityReference = (EntityReference)context.InputParameters["EntityMoniker"];
                    //var State = (OptionSetValue)context.InputParameters["State"];
                   //var Status = (OptionSetValue)context.InputParameters["Status"];
                    
                    Entity TargetEntity = service.Retrieve("ber_estimatedetails", context.PrimaryEntityId, new ColumnSet(true));

                    //Retrieve Estimate DEPOT
                    Entity Depot = new Entity();
                    if (TargetEntity.Attributes.Contains("ber_depotid"))
                    {
                        Depot = service.Retrieve("ber_depot", ((EntityReference)
                            TargetEntity.Attributes["ber_depotid"]).Id, new ColumnSet(true));
                    }
                    
                    //Create new Customer Invoice Record.
                    Entity CustomerInvoice = new Entity("ber_customerinvoice");
                    
                    CustomerInvoice.Attributes["ber_estimate"] = new EntityReference("ber_estimatedetails", TargetEntity.Id);

                    //Set Job Value
                    if (TargetEntity.Attributes.Contains("ber_netamount"))
                    {
                        CustomerInvoice.Attributes["ber_jobvalue"] = TargetEntity["ber_netamount"];
                    }
                    //Set Customer Payment value
                    if (TargetEntity.Attributes.Contains("ber_clearedamount"))
                    {
                        CustomerInvoice.Attributes["ber_customerpayment"] = TargetEntity["ber_clearedamount"];
                    }
                    //Set Bill Entry and Dealer Payment
                    //Retrive All Bill Details for the Estimate.
                    ColumnSet BillDetailsCols = new ColumnSet();
                    Entity BillDetailsEntity = new Entity();
                    QueryExpression billDetailsQry = null;
                    EntityCollection ec = new EntityCollection();
                    billDetailsQry = new QueryExpression("ber_billdetail");
                    BillDetailsCols.AddColumns(new string[] { "ber_amount", "ber_pendingamount" });
                    billDetailsQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, TargetEntity.Id.ToString());
                    billDetailsQry.ColumnSet = BillDetailsCols;
                    ec = service.RetrieveMultiple(billDetailsQry);

                    decimal billDetailsAmount = 0;
                    decimal DealerPaymentAmount = 0;
                    foreach (Entity billDetail in ec.Entities)
                    {
                        if (billDetail.Attributes.Contains("ber_amount"))
                        {
                            billDetailsAmount = billDetailsAmount + ((Money)billDetail["ber_amount"]).Value;
                        }
                        if (billDetail.Attributes.Contains("ber_amount") && billDetail.Attributes.Contains("ber_pendingamount"))
                        {
                            DealerPaymentAmount = DealerPaymentAmount + (((Money)billDetail["ber_amount"]).Value - ((Money)billDetail["ber_pendingamount"]).Value);
                        }
                    }
                    //Bill Entry
                    CustomerInvoice.Attributes["ber_billentry"] = new Money(decimal.Round(billDetailsAmount,2));
                    //Dealer Payment
                    CustomerInvoice.Attributes["ber_dealerpayment"] = new Money(decimal.Round(DealerPaymentAmount,2));

                    //Set Contractor Payment
                    //Retrive Contractor Payment Amount Total.
                    ColumnSet ContPaymentCols = new ColumnSet();
                    Entity ContractorPaymentEntity = new Entity();
                    QueryExpression contractorPayQry = null;
                    EntityCollection contractorPayColl = new EntityCollection();
                    contractorPayQry = new QueryExpression("ber_contractorpaynmentdetail");
                    ContPaymentCols.AddColumns(new string[] { "ber_amount" });
                    contractorPayQry.Criteria.AddCondition("ber_estimateid", ConditionOperator.Equal, TargetEntity.Id.ToString());
                    contractorPayQry.ColumnSet = ContPaymentCols;
                    contractorPayColl = service.RetrieveMultiple(contractorPayQry);

                    decimal contractorPaymentTotal = 0;
                    foreach (Entity contPayment in contractorPayColl.Entities)
                    {
                        if (contPayment.Attributes.Contains("ber_amount"))
                        {
                            contractorPaymentTotal = contractorPaymentTotal + ((Money)contPayment["ber_amount"]).Value;
                        }
                    }
                   //Contractor Payment
                    CustomerInvoice.Attributes["ber_contractorpayment"] = new Money(decimal.Round(contractorPaymentTotal,2));
                    
                    //SET BR AMOUNT
                    decimal BRAmount = 0;
                    decimal jobValue =0;
                    if (TargetEntity.Attributes.Contains("ber_netamount"))
                    {
                        jobValue = ((Money)TargetEntity["ber_netamount"]).Value;

                        if (TargetEntity.Attributes.Contains("ber_br"))
                        {                            
                            BRAmount = (jobValue / 100) * Convert.ToDecimal(TargetEntity["ber_br"]);
                            CustomerInvoice.Attributes["ber_bramount"] = new Money(decimal.Round(BRAmount,2));
                        }
                    }

                    //SET ADJUSTED MAT. COST & ADJUSTED LABOR COST & MINIMUM MATERIAL COST & APPLICABLE MATERIAL COST
                    decimal AdjustedMaterialCost = 0;
                    decimal AdjustedLaborCost = 0;
                    decimal MinimunMaterialCost = 0;
                    decimal ApplicableMaterialCost = 0;
                    if (Depot.Attributes.Contains("ber_bradjustmentinmat"))
                    {
                        decimal DepotBRAdjustedMaterialPer = (decimal)Depot["ber_bradjustmentinmat"];
                        //ADJUSTED MATERIAL COST.
                        AdjustedMaterialCost = DealerPaymentAmount + (DepotBRAdjustedMaterialPer/ 100) * BRAmount;
                        CustomerInvoice.Attributes["ber_adjustedmaterialcost"] = new Money(decimal.Round(AdjustedMaterialCost,2));
                        //MIN MATERIAL COST.
                        MinimunMaterialCost = (DepotBRAdjustedMaterialPer / 100) * jobValue;
                        CustomerInvoice.Attributes["ber_minmatcost"] = new Money(decimal.Round(MinimunMaterialCost,2));
                        //APPLICABLE MATERIAL COST
                        if (AdjustedMaterialCost > MinimunMaterialCost)
                        {
                            ApplicableMaterialCost = AdjustedMaterialCost;
                            CustomerInvoice.Attributes["ber_applicablematcost"] = new Money(decimal.Round(ApplicableMaterialCost,2));
                        }
                        else
                        {
                            ApplicableMaterialCost = MinimunMaterialCost;
                            CustomerInvoice.Attributes["ber_applicablematcost"] = new Money(decimal.Round(ApplicableMaterialCost,2));
                        }
                        //ADJUSTED LABOR COST.
                        AdjustedLaborCost = jobValue - ApplicableMaterialCost;
                        CustomerInvoice.Attributes["ber_adjustedlaborcost"] = new Money(decimal.Round(AdjustedLaborCost, 2));
                     
                    }
                    //SET SERVICE TAX %
                    if (Depot.Attributes.Contains("ber_servicetax"))
                    {
                        CustomerInvoice.Attributes["ber_servicetax"] = (decimal)Depot["ber_servicetax"];
                    }
                    //SET TAX STRUCTURE
                    if (Depot.Attributes.Contains("ber_taxstructure"))
                    {
                        bool DepotTaxStructure = (bool)Depot["ber_taxstructure"];//VAT=False & COT=True
                        CustomerInvoice.Attributes["ber_taxstructure"] = DepotTaxStructure;
                      
                        if (DepotTaxStructure == false) //If Tax Structure is VAT
                        {
                            if (Depot.Attributes.Contains("ber_servicetax"))
                            {
                                decimal DepotSTPer = (decimal)Depot["ber_servicetax"];
                                //SET NET LABOR COST.
                                decimal NetLaborCost = (100 * AdjustedLaborCost) / (100 + DepotSTPer);
                                CustomerInvoice.Attributes["ber_netlaborcost"] = new Money(decimal.Round(NetLaborCost, 2));

                                //SET ST AMOUNT FOR TAX STRUCTURE TYPE AS VAT.
                                CustomerInvoice.Attributes["ber_stamount"] = new Money(decimal.Round((AdjustedLaborCost - NetLaborCost), 2));                          
                            }                          
                            if (Depot.Attributes.Contains("ber_vat"))
                            {
                                decimal DepotVatPer = (decimal)Depot["ber_vat"];
                                //SET NET MATERIAL COST.
                                CustomerInvoice.Attributes["ber_netmatcost"] = new Money(decimal.Round((100 * ApplicableMaterialCost) / (100 + DepotVatPer),2));
                                //SET VAT %
                                CustomerInvoice.Attributes["ber_vat"] = DepotVatPer;
                                //SET VAT AMOUNT
                                CustomerInvoice.Attributes["ber_vatamount"] = new Money(decimal.Round(ApplicableMaterialCost - (100 * ApplicableMaterialCost) / (100 + DepotVatPer),2));                          
                            }
                            
                        }
                        else if (DepotTaxStructure == true) //If Tax Structure is COT
                        {
                            decimal STAmount = 0;
                            if (Depot.Attributes.Contains("ber_servicetax") && Depot.Attributes.Contains("ber_jobvalueforservicetax"))
                            {
                                decimal DepotSTPer = (decimal)Depot["ber_servicetax"];
                                decimal JobValuePerForST = (decimal)Depot["ber_jobvalueforservicetax"];

                                //SET ST AMOUNT FOR TAX STRUCTURE TYPE AS COT.
                                STAmount = ((jobValue * (JobValuePerForST / 100)) / (100 + DepotSTPer)) * DepotSTPer;
                                CustomerInvoice.Attributes["ber_stamount"] = new Money(decimal.Round(STAmount, 2));
                            
                            }
                            if (Depot.Attributes.Contains("ber_cot"))
                            {
                                decimal DepotCOTPer = (decimal)Depot["ber_cot"];
                                //SET COT %
                                CustomerInvoice.Attributes["ber_cot"] = DepotCOTPer;

                                //SET COT AMOUNT
                                decimal COTAmount = jobValue * DepotCOTPer / 100;
                                CustomerInvoice.Attributes["ber_cotamount"] =new Money(decimal.Round(COTAmount,2));

                                //SET NET CHARGES.
                                CustomerInvoice.Attributes["ber_netcharges"] = new Money(decimal.Round(jobValue - (COTAmount + STAmount),2));
                           
                            }                            
                        }
                    }
                    
                    //CREATE NEW CUSTOMER INVOICE FOR COMPLETED JOB.
                    service.Create(CustomerInvoice);
                }
            }
            catch (Exception ex)
            {
                // Handle the exception.
                //Log the Error Entry in Log Table.
                oLogger.Log("Plugin_CustomerInvoiceManagement", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
