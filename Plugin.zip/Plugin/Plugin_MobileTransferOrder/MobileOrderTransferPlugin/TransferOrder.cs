﻿using System;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using System.IO;
using Microsoft.Xrm.Sdk.Query;
using System.Runtime.Serialization;



namespace TransferOrder
{

    public class TransferOrder : IPlugin
    {
        #region Class Level Variables

        public static string _loggerPath = string.Empty;
        public System.Configuration.Configuration config;
        public static Logger oLogger;
        IOrganizationService service;
        public string _organizationName = string.Empty;
        enum Operation { create, update, delete };




        #endregion

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

               
                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                _organizationName = context.OrganizationName;

               


                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is Entity || context.InputParameters["Target"] is EntityReference))
                {
                    Entity entity = null;
                    EntityReference entityref = null;
                    string LogicalName = string.Empty;

                    if (context.InputParameters["Target"] is Entity)
                    {
                        entity = (Entity)context.InputParameters["Target"];
                        LogicalName = entity.LogicalName;
                    }

                    else if (context.InputParameters["Target"] is EntityReference)
                    {
                        entityref = (EntityReference)context.InputParameters["Target"];
                        LogicalName = entityref.LogicalName;
                    }

                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(_organizationName, _loggerPath);

                        }
                    }


                    if (LogicalName == "ber_mobileorderdetail")
                    {
                        Entity updateSalesOrderDetailEntity = new Entity("salesorderdetail");

                        if (context.MessageName.ToLower() == Operation.create.ToString() || context.MessageName.ToLower() == Operation.update.ToString())
                        {
                            Guid gSalesorderid;
                            Guid gProductid;


                            if (entity.Attributes.ContainsKey("ber_orderidlookupid"))
                                gSalesorderid = ((EntityReference)entity.Attributes["ber_orderidlookupid"]).Id;
                            else
                            {
                                EntityCollection OrderIdCollection = GetEntityCollection(service, entity.LogicalName, "ber_mobileorderdetailid",
                                        entity.Id.ToString(), new ColumnSet("ber_orderidlookupid"));

                                gSalesorderid = ((EntityReference)OrderIdCollection[0]["ber_orderidlookupid"]).Id;
                            }

                            if (entity.Attributes.ContainsKey("ber_skucode"))
                                gProductid = ((EntityReference)entity.Attributes["ber_skucode"]).Id;
                            else
                            {
                                EntityCollection ProductIdCollection = GetEntityCollection(service, entity.LogicalName, "ber_mobileorderdetailid",
                                       entity.Id.ToString(), new ColumnSet("ber_skucode"));

                                gProductid = ((EntityReference)ProductIdCollection[0]["ber_skucode"]).Id;
                            }

                            

                            string SalesOrderDetailId = ReturnSalesOrderDetail(service, gProductid.ToString(), gSalesorderid.ToString(), updateSalesOrderDetailEntity);

                            if (SalesOrderDetailId == string.Empty)
                            {
                                updateSalesOrderDetailEntity["salesorderid"] = new EntityReference("salesorder", gSalesorderid);

                                updateSalesOrderDetailEntity["productid"] = new EntityReference("product", gProductid);

                                updateSalesOrderDetailEntity["uomid"] =
                                    new EntityReference("uom", new Guid(entity.Attributes["ber_defaultuomidguid"].ToString()));

                                updateSalesOrderDetailEntity["quantity"] = CalculateQuantity(service, gProductid.ToString(), gSalesorderid.ToString(), entity);
                                updateSalesOrderDetailEntity["ber_recommendedquantity"] = entity.Attributes["ber_recommendedquantity"].ToString();

                                updateSalesOrderDetailEntity["producttypecode"] = new OptionSetValue(1);
                                updateSalesOrderDetailEntity["propertyconfigurationstatus"] = new OptionSetValue(2);

                                updateSalesOrderDetailEntity["description"] = "Order item created from mobile";
                                                               

                                service.Create(updateSalesOrderDetailEntity);

                                oLogger.Log("TransferOrder:Create", "Execute", "mobile order details to sales order details completed order id : " + gSalesorderid,
                                           "Mobile order transfer");
                            }
                            else
                            {
                                EntityCollection collection = GetEntityCollection(service, updateSalesOrderDetailEntity.LogicalName,
                                "salesorderdetailid", SalesOrderDetailId, new ColumnSet("productid","uomid", "quantity", "ber_recommendedquantity"));


                                collection[0]["productid"] = new EntityReference("product", gProductid);

                                if (entity.Attributes.ContainsKey("ber_defaultuomidguid"))
                                    collection[0]["uomid"] =
                                        new EntityReference("uom", new Guid(entity.Attributes["ber_defaultuomidguid"].ToString()));

                                
                                collection[0]["quantity"] = CalculateQuantity(service, gProductid.ToString(), gSalesorderid.ToString(), entity);

                                if (entity.Attributes.ContainsKey("ber_recommendedquantity"))
                                    collection[0]["ber_recommendedquantity"] = entity.Attributes["ber_recommendedquantity"].ToString();

                                service.Update(collection[0]);

                                oLogger.Log("TransferOrder:Update", "Execute", "sales order details updation completed order id : " + gSalesorderid,
                                           "Mobile order transfer");
                            }
                        }
                        else if (context.MessageName.ToLower() == Operation.delete.ToString())
                        {
                            EntityCollection mobiledetailcollection = GetEntityCollection(service, "ber_mobileorderdetail",
                                "ber_mobileorderdetailid", entityref.Id.ToString(), new ColumnSet("ber_orderidlookupid", "ber_skucode", "ber_recommendedquantity"));

                            if (mobiledetailcollection.Entities.Count > 0)
                            {
                                Guid orderid = ((EntityReference)mobiledetailcollection[0]["ber_orderidlookupid"]).Id;
                                Guid productid = ((EntityReference)mobiledetailcollection[0]["ber_skucode"]).Id;

                                EntityCollection modetailcollection = GetEntityCollection(service, "ber_mobileorderdetail", new string[] { "ber_orderidlookupid", "ber_skucode" },
                                new string[] { orderid.ToString(), productid.ToString() }, new ColumnSet("ber_recommendedquantity"));

                                EntityCollection sdetailcollection = GetEntityCollection(service, "salesorderdetail", new string[] { "salesorderid", "productid" },
                                new string[] { orderid.ToString(), productid.ToString() }, new ColumnSet("quantity"));

                                Guid SalesOrderid = sdetailcollection[0].Id;

                                if (modetailcollection.Entities.Count > 1)
                                {
                                    sdetailcollection[0]["quantity"] = Convert.ToDecimal(sdetailcollection[0]["quantity"]) -
                                                                                Convert.ToDecimal(modetailcollection[0]["ber_recommendedquantity"]);
                                    service.Update(sdetailcollection[0]);
                                }
                                else
                                    service.Delete(updateSalesOrderDetailEntity.LogicalName, SalesOrderid);
                            }
                            oLogger.Log("TransferOrder:Delete", "Execute", "sales order details deletion completed order id : " +  entityref.Id.ToString()  ,  "Mobile order transfer"); 
                                       
                        }

                    }


                }


            }
            catch (Exception ex)
            {
                oLogger.Log("TransferOrder", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        private static EntityCollection GetEntityCollection(IOrganizationService service, string entityName, string attributeName, string attributeValue, ColumnSet cols)
        {
            QueryExpression query = new QueryExpression
            {
                EntityName = entityName,
                ColumnSet = cols,
                Criteria = new FilterExpression
                {
                    Conditions =
                    {
                        new ConditionExpression
                        {
                            AttributeName = attributeName,
                            Operator = ConditionOperator.Equal,
                            Values = { attributeValue }
                        }

                    }
                }
            };
            return service.RetrieveMultiple(query);
        }

        private static EntityCollection GetEntityCollection(IOrganizationService service, string entityName, string[] attributeName, string[] attributeValue, ColumnSet cols)
        {
            QueryExpression query = new QueryExpression
            {
                EntityName = entityName,
                ColumnSet = cols,
                Criteria = new FilterExpression
                {
                    FilterOperator = LogicalOperator.And,
                    Conditions =
                    {
                       
                        new ConditionExpression
                        {
                            AttributeName = attributeName[0],
                            Operator = ConditionOperator.Equal,
                            Values = { attributeValue[0] }
                        },
                         new ConditionExpression
                        {
                            AttributeName = attributeName[1],
                            Operator = ConditionOperator.Equal,
                            Values = { attributeValue[1] }
                        }

                    }
                }
            };
            return service.RetrieveMultiple(query);
        }


        private static string ReturnSalesOrderDetail(IOrganizationService service, string Productid, string Salesorderid, Entity entity)
        {
            string returnstring = string.Empty;

            EntityCollection collection = GetEntityCollection(service, entity.LogicalName,
                               "salesorderid", Salesorderid.ToString(), new ColumnSet("productid"));

            for (int i = 0; i <= collection.Entities.Count - 1; i++)
            {
                string SalesOrderProductId = ((EntityReference)collection[i]["productid"]).Id.ToString().Replace("{", string.Empty).Replace("}", string.Empty).ToUpper();

                if (SalesOrderProductId == Productid.ToUpper())
                    return collection[i].Id.ToString();
            }

            return returnstring;

        }

        private static decimal CalculateQuantity(IOrganizationService service, string Productid, string Salesorderid, Entity entity)
        {
            EntityCollection collection = GetEntityCollection(service, entity.LogicalName,
                               "ber_orderidlookupid", Salesorderid.ToString(), new ColumnSet("ber_skucode", "ber_quantity"));

            decimal quantity = 0;

            for (int i = 0; i <= collection.Entities.Count - 1; i++)
            {
                string mobileproductid = ((EntityReference)collection[i]["ber_skucode"]).Id.ToString().Replace("{", string.Empty).Replace("}", string.Empty).ToUpper();

                if (mobileproductid == Productid.ToUpper())
                    quantity = quantity + Convert.ToDecimal(collection[i]["ber_quantity"]);
            }

            return quantity;
        }

    }
}
