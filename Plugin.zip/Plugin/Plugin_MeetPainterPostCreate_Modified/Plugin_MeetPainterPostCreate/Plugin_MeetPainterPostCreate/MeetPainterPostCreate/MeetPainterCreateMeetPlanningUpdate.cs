﻿//--------------------------------------------------------------------------------
// <copyright file="MeetPainterCreateMeetPlanningUpdate.cs" company="Pragmasys Consulting LLP">
//  © Copyright Pragmasys Consulting LLP, 2013-2014. All rights reserved.
// </copyright>
//--------------------------------------------------------------------------------
// Microsoft Dynamics CRM namespace(s)

[assembly: System.CLSCompliant(true)]

namespace MeetPainterPostCreate
{
    using System;    
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using System.Xml;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Win32;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;

    /// <summary>
    /// Class Meet painter create meet planning update
    /// </summary>
    public class MeetPainterCreateMeetPlanningUpdate : IPlugin
    {
        /// <summary>
        /// Configuration object
        /// </summary>
        private static System.Configuration.Configuration config;                

        /// <summary>
        /// Logger class object
        /// </summary>
        private static PragmasysLogger objLogger;        

        /// <summary>
        /// Plugin main method
        /// </summary>
        /// <param name="serviceProvider">Service provider object</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Get a reference to the organization service.
            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            // Get a reference to the tracing service.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            string organizationName = context.OrganizationName;

            try
            {
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");
                string db_Path = obj_dbpath.ToString();
                string configpath = db_Path + "\\CRMWeb\\ISV\\" + organizationName + "\\Pragmasys.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    ////  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        objLogger = new PragmasysLogger(organizationName, loggerPath);
                    }
                }

                lock (this)
                {
                    if (context.MessageName.ToLower() == "create")
                    {
                        Entity meetplanningRecord = this.RetriveMeetPainterPlanningRecord(context.PrimaryEntityId, context.PrimaryEntityName, service);

                        if (!string.IsNullOrEmpty(meetplanningRecord.LogicalName))
                        {
                            if (meetplanningRecord.Contains("ber_depot") && meetplanningRecord.Contains("ber_costperhead"))
                            {
                                EntityReference depotRef = this.GetMasterDepot((EntityReference)meetplanningRecord.Attributes["ber_depot"], service);

                                Money currentBudget = this.RetriveDepotCurrentBudget(depotRef, service);

                                Money costperHead = (Money)meetplanningRecord.Attributes["ber_costperhead"];

                                Money updatedBudget = new Money(currentBudget.Value - costperHead.Value);

                                this.UpdateDepot(depotRef, updatedBudget, service);

                                int enrollednum = 0;
                                if (meetplanningRecord.Contains("ber_enrolledpainters"))
                                {
                                    enrollednum = Convert.ToInt32(meetplanningRecord.Attributes["ber_enrolledpainters"].ToString());
                                }

                                this.UpdateEnrollmentnumber(meetplanningRecord.Id, meetplanningRecord.LogicalName, enrollednum, service);

                                EntityReference bdmUser = this.RetriveBDMUser((EntityReference)meetplanningRecord.Attributes["ber_depot"], service);

                                if (!string.IsNullOrEmpty(bdmUser.LogicalName))
                                {
                                    this.ShareRecord(context.PrimaryEntityName, context.PrimaryEntityId, bdmUser, service);
                                }
                            }
                        }
                    }
                   
                }
            }
            catch (Exception ex)
            {
                //// Handle the exception.
                ////Log the Error Entry in Log file.
                objLogger.Log("MeetPainterPostCreate", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Retrieve meet planning record for the provided meet painter
        /// </summary>
        /// <param name="entityId">Meet painter unique id</param>
        /// <param name="entityName">Meet planning name</param>
        /// <param name="service">CRM organization service</param>
        /// <returns>Meet planning record</returns>
        protected Entity RetriveMeetPainterPlanningRecord(Guid entityId, string entityName, IOrganizationService service)
        {
            try
            {
                ColumnSet meetPaintersColumns = new ColumnSet();
                meetPaintersColumns.AddColumn("ber_paintermeet");

                Entity meetPainterRecord = service.Retrieve(entityName, entityId, meetPaintersColumns);

                if (meetPainterRecord.Contains("ber_paintermeet"))
                {
                    EntityReference meetPlanningRef = (EntityReference)meetPainterRecord.Attributes["ber_paintermeet"];
                    ColumnSet meetPlanningColumns = new ColumnSet();
                    meetPlanningColumns.AddColumn("ber_depot");
                    meetPlanningColumns.AddColumn("ber_costperhead");
                    meetPlanningColumns.AddColumn("ber_enrolledpainters");

                    Entity meetPlanningRecord = service.Retrieve(meetPlanningRef.LogicalName, meetPlanningRef.Id, meetPlanningColumns);

                    return meetPlanningRecord;
                }

                return new Entity();
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "RetriveMeetPainterRecord", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to get depot
        /// </summary>
        /// <param name="depotRef">Depot entity reference</param>
        /// <param name="service">CRM organization service</param>
        /// <returns>Depot record reference</returns>
        protected EntityReference GetMasterDepot(EntityReference depotRef, IOrganizationService service)
        {
            try
            {
                ColumnSet depotColumns = new ColumnSet();
                depotColumns.AddColumn("ber_ismasterdepot");
                depotColumns.AddColumn("ber_masterdepotid");

                Entity depotRecord = service.Retrieve(depotRef.LogicalName, depotRef.Id, depotColumns);

                if (depotRecord.Contains("ber_ismasterdepot") && depotRecord.Contains("ber_masterdepotid"))
                {
                    bool masterDepot = Convert.ToBoolean(depotRecord.Attributes["ber_ismasterdepot"].ToString());

                    if (masterDepot)
                    {
                        return (EntityReference)depotRecord.Attributes["ber_masterdepotid"];
                    }
                }

                return depotRef;
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "GetMasterDepot", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to update depot attributes
        /// </summary>
        /// <param name="depotRef">Depot entity reference</param>
        /// <param name="amount">Amount attribute value</param>
        /// <param name="service">CRM service object</param>
        protected void UpdateDepot(EntityReference depotRef, Money amount, IOrganizationService service)
        {
            try
            {
                Entity newDepot = new Entity();
                newDepot.Id = depotRef.Id;
                newDepot.LogicalName = depotRef.LogicalName;
                newDepot["ber_remainingdepotbudget"] = amount;
                newDepot["ber_bdbudget"] = amount;
                service.Update(newDepot);
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "UpdateDepot", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to update meet planning attribute enrollment number
        /// </summary>
        /// <param name="meetplanningId">Meet planning unique id</param>
        /// <param name="meetplanningName">Meet planning entity name</param>
        /// <param name="enrollmentNumber">Enrollment number value</param>
        /// <param name="service">CRM service object</param>
        protected void UpdateEnrollmentnumber(Guid meetplanningId, string meetplanningName, int enrollmentNumber, IOrganizationService service)
        {
            try
            {
                Entity newMeetPlanning = new Entity();
                newMeetPlanning.Id = meetplanningId;
                newMeetPlanning.LogicalName = meetplanningName;
                newMeetPlanning["ber_enrolledpainters"] = enrollmentNumber + 1;

                service.Update(newMeetPlanning);
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "UpdateEnrollmentnumber", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to get specified depot Meet planning budget
        /// </summary>
        /// <param name="depotRef">Depot entity reference</param>
        /// <param name="service">CRM service object</param>
        /// <returns>Value in money format</returns>
        protected Money RetriveDepotCurrentBudget(EntityReference depotRef, IOrganizationService service)
        {
            try
            {
                ColumnSet depotColumns = new ColumnSet();
                depotColumns.AddColumns("ber_bdbudget","ber_remainingdepotbudget");

                Entity depotRecord = service.Retrieve(depotRef.LogicalName, depotRef.Id, depotColumns);

                if (depotRecord.Contains("ber_remainingdepotbudget"))
                {
                    Money bdBudget = (Money)depotRecord.Attributes["ber_remainingdepotbudget"];

                    return bdBudget;
                }
                else if (depotRecord.Contains("ber_bdbudget"))
                {
                    Money bdBudget = (Money)depotRecord.Attributes["ber_bdbudget"];

                    return bdBudget;

                }

                return new Money(0);
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "RetriveDepotCurrentBudget", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to get meet painter current status
        /// </summary>
        /// <param name="meetPainterId">Meet painter unique id</param>
        /// <param name="meetPainterName">Meet painter entity name</param>
        /// <param name="service">CRM service object</param>
        /// <returns>current status of meet painter in boolean format</returns>
        protected bool RetriveCurrentStatusReason(Guid meetPainterId, string meetPainterName, IOrganizationService service)
        {
            try
            {
                ColumnSet meetPainterColumns = new ColumnSet();
                meetPainterColumns.AddColumn("statuscode");

                Entity meetPaniterRecord = service.Retrieve(meetPainterName, meetPainterId, meetPainterColumns);

                if (meetPaniterRecord.Contains("statuscode"))
                {
                    OptionSetValue statusReason = (OptionSetValue)meetPaniterRecord.Attributes["statuscode"];
                    if (statusReason.Value == 278290001)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "RetriveCurrentStatusReason", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to get meet configuration details
        /// </summary>
        /// <param name="meetPlanningRef">Meet planning entity reference</param>
        /// <param name="service">CRM service object</param>
        /// <returns>Meet points for specific points</returns>
        protected Money RetriveMeetRSperpoint(Entity meetPlanningRef, IOrganizationService service)
        {
            try
            {
                ColumnSet meetPlanningColumns = new ColumnSet();
                meetPlanningColumns.AddColumn("ber_meet");

                Entity meetPlanningRecord = service.Retrieve(meetPlanningRef.LogicalName, meetPlanningRef.Id, meetPlanningColumns);

                if (meetPlanningRecord.Contains("ber_meet"))
                {
                    EntityReference meetRef = (EntityReference)meetPlanningRecord.Attributes["ber_meet"];

                    ColumnSet meetColumns = new ColumnSet();
                    meetColumns.AddColumn("ber_rsperpoint");

                    Entity meetRecord = service.Retrieve(meetRef.LogicalName, meetRef.Id, meetColumns);

                    if (meetRecord.Contains("ber_rsperpoint"))
                    {
                        Money rsPerpoint = (Money)meetRecord.Attributes["ber_rsperpoint"];

                        return rsPerpoint;
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "RetriveMeetRSperpoint", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to get meet painter total own points
        /// </summary>
        /// <param name="meetPainterId">Meet painter unique id</param>
        /// <param name="meetPainterName">Meet painter entity name</param>
        /// <param name="service">CRM service object</param>
        /// <returns>Total points of meet painter</returns>
        protected decimal RetriveTotalPoints(Guid meetPainterId, string meetPainterName, IOrganizationService service)
        {
            try
            {
                ColumnSet meetPainterColumns = new ColumnSet();
                meetPainterColumns.AddColumn("ber_totalpoint");

                Entity meetPainterRecord = service.Retrieve(meetPainterName, meetPainterId, meetPainterColumns);

                if (meetPainterRecord.Contains("ber_totalpoint"))
                {
                    return Convert.ToDecimal(meetPainterRecord.Attributes["ber_totalpoint"].ToString());
                }

                return 0;
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "RetriveTotalPoints", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Method to retrieve BDM user of specified depot
        /// </summary>
        /// <param name="depotRef">Depot record reference</param>
        /// <param name="service">CRM service object</param>
        /// <returns>Entity reference of user record</returns>
        protected EntityReference RetriveBDMUser(EntityReference depotRef, IOrganizationService service)
        {
            try
            {
                ColumnSet depotColumns = new ColumnSet();
                depotColumns.AddColumn("ber_bdmid");

                Entity depotRecord = service.Retrieve(depotRef.LogicalName, depotRef.Id, depotColumns);

                if (depotRecord.Contains("ber_bdmid"))
                {
                    return (EntityReference)depotRecord.Attributes["ber_bdmid"];
                }
                
                return new EntityReference();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method to share record with specified user
        /// </summary>
        /// <param name="entityName">Entity name</param>
        /// <param name="entityId">Entity unique id</param>
        /// <param name="assigneeUser">shared to user</param>
        /// <param name="service">CRM service object</param>
        protected void ShareRecord(string entityName, Guid entityId, EntityReference assigneeUser, IOrganizationService service)
        {
            try
            {
                GrantAccessRequest shareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ReadAccess | AccessRights.AppendAccess | AccessRights.AppendToAccess,
                        Principal = assigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };
                service.Execute(shareRequest);
            }
            catch (Exception ex)
            {
                objLogger.Log("AssociateDisassociateSharing", "ShareRecord", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }
    }
}
