﻿// =====================================================================
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// 
// OnChange of Status
//        Draft to Shipment
//              - Shipment Items quantity will be deducated from Source Inventory Locations' Inventory Items
//        Shipment to Received 
//              - Shipment Items quantity will be added in destination Inventory Location, if item doesn't exist then It will
//                  create new item.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using System.IO;

namespace Pragma_Plug_inInventoryItemQuantity
{
    public class InventoryItemQuantity : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;
        
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string _organizationName = context.OrganizationName;


                #region To Read Config File
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);
                    }
                }
                #endregion


                // Plug-in business logic goes below this line.
                // Invoke organization service methods.
                if (context.Depth == 1)
                {
                    if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                    {
                        // Obtain the target entity from the input parmameters.
                        Entity entity = (Entity)context.InputParameters["Target"];                        
                        Entity StockTransfer = service.Retrieve("ber_stocktransfer", entity.Id, new ColumnSet(true));
                        int stocktransferstatus = 0;
                        EntityCollection StockTransferItems = new EntityCollection();
                        EntityCollection InventoryItems = new EntityCollection();
                        string TransferType = "";
                        EntityReference StockReference = new EntityReference(StockTransfer.LogicalName, StockTransfer.Id);
                        EntityReference InventotyLocation = new EntityReference();
                        Entity DestInventoryLocation = new Entity();
                        Guid DestInventoryLocationId = Guid.Empty;                        
                        EntityReference InventoryType = new EntityReference();

                        if (StockTransfer.Contains("ber_to"))
                        {
                            DestInventoryLocationId = ((EntityReference)StockTransfer.Attributes["ber_to"]).Id;
                        }

                        if (entity.Contains("ber_status"))
                        {
                            stocktransferstatus = ((OptionSetValue)entity.Attributes["ber_status"]).Value;
                        }
                        else if (StockTransfer.Contains("ber_status"))
                        {
                            stocktransferstatus = ((OptionSetValue)StockTransfer.Attributes["ber_status"]).Value;
                        }


                        if (stocktransferstatus == 278290001)//Shipped
                        {
                            if (StockTransfer.Contains("ber_from"))
                            {
                                InventotyLocation = ((EntityReference)StockTransfer.Attributes["ber_from"]);

                                TransferType = "278290000";
                                StockTransferItems = RetrieveStockTransferItems(StockTransfer, service, TransferType);
                                InventoryItems = RetrieveInventoryItems(InventotyLocation, service);
                                UpdateInventoryLocationItem(StockTransferItems, DestInventoryLocationId, InventoryItems, service, stocktransferstatus);
                            }
                            //Set Stock Transfer Shipment Date.
                            Entity updateST = new Entity(StockTransfer.LogicalName);
                            updateST.Id = StockTransfer.Id;
                            updateST["ber_shippeddate"] = DateTime.Now;
                            service.Update(updateST);

                            //Assign Stock Transfer to Destinatin Inventory Owner.
                            if (StockTransfer.Contains("ber_to"))
                            {
                               Entity DestinationInvLocation = service.Retrieve("ber_inventorylocation", DestInventoryLocationId, new ColumnSet(true));
                               if (DestinationInvLocation.Attributes.Contains("ownerid"))
                               {
                                   AssignRequest request = new AssignRequest();
                                   request.Assignee = (EntityReference)DestinationInvLocation["ownerid"];
                                   request.Target = new EntityReference(StockTransfer.LogicalName,StockTransfer.Id);
                                   service.Execute(request);
                               }
                            }
                        }


                        if (stocktransferstatus == 278290002)//Received
                        {
                            if (StockTransfer.Contains("ber_to"))
                            {
                                InventotyLocation = ((EntityReference)StockTransfer.Attributes["ber_to"]);

                                TransferType = "278290001";
                                StockTransferItems = RetrieveStockTransferItems(StockTransfer, service, TransferType);
                                InventoryItems = RetrieveInventoryItems(InventotyLocation, service);
                                UpdateInventoryLocationItem(StockTransferItems, DestInventoryLocationId, InventoryItems, service, stocktransferstatus);
                            }

                            //Set Stock Transfer Shipment Date.
                            Entity updateST = new Entity(StockTransfer.LogicalName);
                            updateST.Id = StockTransfer.Id;
                            updateST["ber_receiveddate"] = DateTime.Now;
                            service.Update(updateST);

                            //Share Stock Transfer to Source Inventory Owner.
                            if (StockTransfer.Contains("ber_from"))
                            {
                                Entity SourceInvLocation = service.Retrieve("ber_inventorylocation", DestInventoryLocationId, new ColumnSet(true));
                                if (SourceInvLocation.Attributes.Contains("ownerid"))
                                {
                                    var grantAccessRequest = new GrantAccessRequest
                                    {
                                        PrincipalAccess = new PrincipalAccess
                                        {
                                            AccessMask = AccessRights.ShareAccess,
                                            Principal = (EntityReference)SourceInvLocation["ownerid"]
                                        },
                                        Target = StockReference
                                    };

                                    service.Execute(grantAccessRequest);
                                }
                            }

                            //Change Stock Transfer Status to Inactive after Received completed.
                            SetStateRequest setState = new SetStateRequest();
                            setState.EntityMoniker = StockReference;
                            setState.State = new OptionSetValue(1);
                            setState.Status = new OptionSetValue(2);
                            service.Execute(setState);
                        }                        
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception.
                //Log the Error Entry in Log Table.
                oLogger.Log("Pragma_Plug_inInventoryItemQuantity", "Execute", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private void UpdateInventoryLocationItem(EntityCollection StockTransferItems,Guid DestInventoryId, EntityCollection InventoryItems, IOrganizationService service, int stocktransferstatus)
        {
            
            foreach (Entity StockTransferItem in StockTransferItems.Entities)
            {
                bool inventorypresent = false;
                Guid StockItemId = new Guid();
                int StockItemCondition = 0;
                int StockItemQuantity = 0;
                if (StockTransferItem.Contains("ber_itemid"))
                {
                    StockItemId = ((EntityReference)StockTransferItem.Attributes["ber_itemid"]).Id;
                }
                if (StockTransferItem.Contains("ber_condition"))
                {
                    StockItemCondition = ((OptionSetValue)StockTransferItem.Attributes["ber_condition"]).Value;
                }
                if (StockTransferItem.Contains("ber_shippedquantity"))
                {
                    StockItemQuantity = Convert.ToInt32(StockTransferItem.Attributes["ber_shippedquantity"]);
                }

                foreach (Entity InventoryItem in InventoryItems.Entities)
                {
                    Guid InventoryItemId = new Guid();
                    int InventoryItemCondition = 0;
                    int InventoryItemQuantity = 0;
                    if (InventoryItem.Contains("ber_item"))
                    {
                        InventoryItemId = ((EntityReference)InventoryItem.Attributes["ber_item"]).Id;
                    }
                    if (InventoryItem.Contains("ber_condition"))
                    {
                        InventoryItemCondition = ((OptionSetValue)InventoryItem.Attributes["ber_condition"]).Value;
                    }
                    if (InventoryItem.Contains("ber_quantity"))
                    {
                        InventoryItemQuantity = Convert.ToInt32(InventoryItem.Attributes["ber_quantity"]);
                    }

                    if (StockItemId == InventoryItemId && StockItemCondition == InventoryItemCondition)
                    {
                        inventorypresent = true;
                        Entity ResultingInventoryItem = new Entity();
                        ResultingInventoryItem.LogicalName = InventoryItem.LogicalName;
                        ResultingInventoryItem.Id = InventoryItem.Id;
                        if (stocktransferstatus == 278290001)
                        {
                            ResultingInventoryItem.Attributes["ber_quantity"] = InventoryItemQuantity - StockItemQuantity;
                        }
                        if (stocktransferstatus == 278290002)
                        {
                            ResultingInventoryItem.Attributes["ber_quantity"] = InventoryItemQuantity + StockItemQuantity;
                        }
                        service.Update(ResultingInventoryItem);
                    }
                }

                if (inventorypresent == false && stocktransferstatus == 278290002)
                {
                    Entity ResultingInventoryItem = new Entity();
                    ResultingInventoryItem.LogicalName = "ber_inventoryitem";
                    ResultingInventoryItem.Attributes["ber_item"] = new EntityReference("ber_item", StockItemId);
                    ResultingInventoryItem.Attributes["ber_inventorylocation"] = new EntityReference("ber_inventorylocation", DestInventoryId);
                    ResultingInventoryItem.Attributes["ber_quantity"] = StockItemQuantity;
                    ResultingInventoryItem.Attributes["ber_condition"] = new OptionSetValue(StockItemCondition);
                    service.Create(ResultingInventoryItem);
                }
            }
        }

        private EntityCollection RetrieveInventoryItems(EntityReference InventotyLocation, IOrganizationService service)
        {
            //Retrieve Inventory Items
            QueryExpression inventoryitemsquery = new QueryExpression();
            inventoryitemsquery.EntityName = "ber_inventoryitem";
            inventoryitemsquery.ColumnSet = new ColumnSet(true);


            ConditionExpression inventoryitemcondition = new ConditionExpression();
            inventoryitemcondition.AttributeName = "ber_inventorylocation";
            inventoryitemcondition.Operator = ConditionOperator.Equal;
            inventoryitemcondition.Values.Add(InventotyLocation.Id);


            FilterExpression inventoryitemfilter = new FilterExpression();
            inventoryitemfilter.FilterOperator = LogicalOperator.And;
            inventoryitemfilter.Conditions.Add(inventoryitemcondition);

            inventoryitemsquery.Criteria.Filters.Add(inventoryitemfilter);

            EntityCollection inventoryitem = service.RetrieveMultiple(inventoryitemsquery);

            return inventoryitem;
        }

        private EntityCollection RetrieveStockTransferItems(Entity StockTransfer, IOrganizationService service, string TransferType)
        {
            //Retrieve Stock Transfer Items
            QueryExpression stocktransferitemsquery = new QueryExpression();
            stocktransferitemsquery.EntityName = "ber_stocktransferitems";
            stocktransferitemsquery.ColumnSet = new ColumnSet(true);


            ConditionExpression stocktransferitemscondition = new ConditionExpression();
            stocktransferitemscondition.AttributeName = "ber_stocktransfer";
            stocktransferitemscondition.Operator = ConditionOperator.Equal;
            stocktransferitemscondition.Values.Add(StockTransfer.Id);

            ConditionExpression stocktransferitemstatuscondition = new ConditionExpression();
            stocktransferitemstatuscondition.AttributeName = "ber_transfertype";
            stocktransferitemstatuscondition.Operator = ConditionOperator.Equal;
            OptionSetValue osTransferType = new OptionSetValue();
            osTransferType.Value = Convert.ToInt32(TransferType);
            stocktransferitemstatuscondition.Values.Add(osTransferType.Value);

            FilterExpression stocktransferitemfilter = new FilterExpression();
            stocktransferitemfilter.FilterOperator = LogicalOperator.And;
            stocktransferitemfilter.Conditions.Add(stocktransferitemscondition);
            stocktransferitemfilter.Conditions.Add(stocktransferitemstatuscondition);


            stocktransferitemsquery.Criteria.Filters.Add(stocktransferitemfilter);

            EntityCollection stocktransferitem = service.RetrieveMultiple(stocktransferitemsquery);

            return stocktransferitem;
        }
    }
}
