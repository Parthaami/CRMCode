﻿using System.Data;
using System.Data.SqlClient;

namespace XpToolreRegistered
{
    class FetchDataFromSql
    {
        /// <summary>
        /// ExecuteProcedureReturnDataSet
        /// </summary>
        /// <param name="connString"></param>
        /// <param name="procName"></param>
        /// <param name="paramters"></param>
        /// <returns></returns>
        public static DataSet ExecuteProcedureReturnDataSet(string connString, string procName,
        params SqlParameter[] paramters)
        {
            DataSet result = null;
            using (var sqlConnection = new SqlConnection(connString))
            {
                using (var command = sqlConnection.CreateCommand())
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(command))
                    {
                        command.CommandType = System.Data.CommandType.StoredProcedure;
                        command.CommandText = procName;
                        if (paramters != null)
                        {
                            command.Parameters.AddRange(paramters);
                        }
                        result = new DataSet();
                        sda.Fill(result);
                    }
                }
            }
            return result;
        }

        /*
        /// <summary>
        /// ExecuteProcedureReturnString
        /// </summary>
        /// <param name="connString"></param>
        /// <param name="procName"></param>
        /// <param name="paramters"></param>
        /// <returns></returns>
        public static string ExecuteProcedureReturnString(string connString, string procName,
                params SqlParameter[] paramters)
        {
            string result = "";
            using (var sqlConnection = new SqlConnection(connString))
            {
                using (var command = sqlConnection.CreateCommand())
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (paramters != null)
                    {
                        command.Parameters.AddRange(paramters);
                    }
                    sqlConnection.Open();
                    var ret = command.ExecuteScalar();
                    if (ret != null)
                        result = Convert.ToString(ret);
                }
            }
            return result;
        }

        public struct ParamData
        {
            public string pName, pValue;
            public SqlDbType pDataType;
            public ParamData(string pName, SqlDbType pDataType, string pValue)
            {
                this.pName = pName;
                this.pDataType = pDataType;
                this.pValue = pValue;
            }
        }


        */

    }

    /*
    public class StoredProcedure
    {
        private string sProcName;
        private ArrayList sParams = new ArrayList();
        public void SetParam(string pName, SqlDbType pDataType, string pValue)
        {
            ParamData pData = new ParamData(pName, pDataType, pValue);
            sParams.Add(pData);
        }

        public ArrayList GetParams()
        {
            if (!(sParams == null))
            {
                return sParams;
            }
            else
            {
                return null;
            }
        }
        public string ProcName
        {
            get
            {
                return sProcName;
            }
            set
            {
                sProcName = value;
            }
        }
    }
*/

        /*
    public class StoredProcedureCollection : System.Collections.CollectionBase
    {
        public void add(StoredProcedure value)
        {
            List.Add(value);
        }
        public void Remove(int index)
        {
            if (index > Count - 1 || index < 0)
            {
                //ignore
                Console.WriteLine("No data to remove");
            }
            else
            {
                List.RemoveAt(index);
            }
        }

        public StoredProcedure Item(int Index)
        {
            return (StoredProcedure)List[Index];
        }
    }
    */
    /*
    public static DataSet ExecuteProcedureReturnDataSet(string connString, string procName,
            params SqlParameter[] paramters)
    {
        DataSet result = null;
        using (var sqlConnection = new SqlConnection(connString))
        {
            using (var command = sqlConnection.CreateCommand())
            {
                using (SqlDataAdapter sda = new SqlDataAdapter(command))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (paramters != null)
                    {
                        command.Parameters.AddRange(paramters);
                    }
                    result = new DataSet();
                    sda.Fill(result);
                }
            }
        }
        return result;
    }
    */

        /*
    public static string ExecuteProcedureReturnString(string connString, string procName,
            params SqlParameter[] paramters)
    {
        string result = "";
        using (var sqlConnection = new SqlConnection(connString))
        {
            using (var command = sqlConnection.CreateCommand())
            {
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.CommandText = procName;
                if (paramters != null)
                {
                    command.Parameters.AddRange(paramters);
                }
                sqlConnection.Open();
                var ret = command.ExecuteScalar();
                if (ret != null)
                    result = Convert.ToString(ret);
            }
        }
        return result;
    }

    */

}


