﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
//using Microsoft.Xrm.Client;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace XpToolreRegistered
{


    public class reRegistered : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static string logfilepath = string.Empty;
        public void Execute(IServiceProvider serviceProvider)
        {
            string configpath = string.Empty;
            string _dbConnectionString = string.Empty;
            int IsOldTool=0;
            string InsturmentSerialNo = string.Empty;

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = (IOrganizationService)serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            ExeConfigurationFileMap filemap = new ExeConfigurationFileMap();

            // ber_oldtool
            // ber_oldpainter


            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                //Entity entity = (Entity)context.InputParameters["Target"];
                //var InsturmentSerialNo = entity.GetAttributeValue<string>("ber_name");


                Entity targetEntity = (Entity)context.InputParameters["Target"];
                Entity oEntity = (Entity)context.PreEntityImages["ber_paintexpressitem"];

                if (targetEntity.Attributes.Contains("ber_oldtool"))
                     IsOldTool = (int)targetEntity.Attributes["ber_oldtool"];

                if (targetEntity.Attributes.Contains("ber_name"))
                    InsturmentSerialNo = (string)targetEntity.Attributes["ber_name"];


                //QueryExpression Contact = new QueryExpression { EntityName = entity.LogicalName, ColumnSet = new ColumnSet("ber_name") };
                //Contact.Criteria.AddCondition("ber_name", ConditionOperator.Equal, InsturmentSerialNo);
                //Contact.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                //EntityCollection RetrieveContact = service.RetrieveMultiple(Contact);

                //if (RetrieveContact.Entities.Count > 1)
                //{
                //    throw new InvalidPluginExecutionException("Following Record with Same Number Exists");

                //}
                //else if (RetrieveContact.Entities.Count == 0)
                //{
                //    return;
                //}

                configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                filemap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(filemap, ConfigurationUserLevel.None);

                logfilepath = config.AppSettings.Settings["loggerpath"].Value;
                int logfilelevel = Convert.ToInt32(config.AppSettings.Settings["loglevel"].Value);
                _dbConnectionString = config.ConnectionStrings.ConnectionStrings["Bergersqldbconnection"].ConnectionString.ToString();

                // Searching InsturmentSerialNo wheather it is associated with other painter or not 
                // Code for sp calling /execute 
                DataTable paintexpressitem = null;

                if (IsOldTool == 1)
                {
                    SqlParameter[] QueryPaintExpressItemParams =  {
                                                    new SqlParameter("@InsturmentSerialNo", InsturmentSerialNo),
                                                    //new SqlParameter("@", oEntity.Id)
                                                   };
                     paintexpressitem = FetchDataFromSql.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_reRegistered", QueryPaintExpressItemParams).Tables[0];
                }


                //ber_peitemnumber, --as xpitemnumber,
                //ber_name,-- as InsturmentSerialNo,
                //ber_dealer,
                //ber_painterid as Painterid,
                //1 as IsExit

                string Peitemnumber = string.Empty;
                string ber_name = string.Empty;
                string ber_dealer = string.Empty;
                string ber_painterid = string.Empty;
                int IsExit ;

                if (paintexpressitem.Rows.Count > 1)
                {
                    Peitemnumber = Convert.ToString(paintexpressitem.Rows[0]["ber_peitemnumber"]).Trim();
                    ber_name = Convert.ToString(paintexpressitem.Rows[0]["ber_name"]).Trim();
                    ber_dealer = Convert.ToString(paintexpressitem.Rows[0]["ber_dealer"]).Trim();
                    ber_painterid = Convert.ToString(paintexpressitem.Rows[0]["ber_painterid"]).Trim();
                    IsExit = Convert.ToInt32(paintexpressitem.Rows[0]["IsExit"]);

                    if (IsOldTool == 1 && IsExit ==1) 
                    {
                        //update Old  Contact / PanterExpress Item ?? ..........



                    }

                 }





            }
        }
    }
}
