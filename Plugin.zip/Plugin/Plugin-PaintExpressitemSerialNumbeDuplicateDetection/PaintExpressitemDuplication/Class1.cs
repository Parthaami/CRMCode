﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
//CRM SDK Namespace
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace PaintExpressitemDuplication
{
    public class Class1:IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = (IOrganizationService)serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                if (entity.Attributes.Contains("ber_name") && entity.Attributes.Contains("statuscode"))
                {
                var SerialNumber = entity.GetAttributeValue<string>("ber_name");
                //int status = (OptionSetValue)entity.Attributes["statuscode"];
                int status = ((OptionSetValue)entity["statuscode"]).Value;
                if (SerialNumber != null )
                {
                QueryExpression paintexpressitem = new QueryExpression { EntityName = entity.LogicalName, ColumnSet = new ColumnSet("ber_name","statuscode") };
                paintexpressitem.Criteria.AddCondition("ber_name", ConditionOperator.Equal, SerialNumber);
               // paintexpressitem.Criteria.AddCondition("statuscode", ConditionOperator.Equal, 1);
                paintexpressitem.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
               

                EntityCollection RetrieveContact = service.RetrieveMultiple(paintexpressitem);

                if (RetrieveContact.Entities.Count > 0)
                {
                    entity["ber_name"] = null;
                    entity["statuscode"] = new OptionSetValue(1);
                    entity["ber_checkduplicate"] = false;
                    
                    //service.Update(entity);                  
                                       
                    throw new InvalidPluginExecutionException(" Serial Number already Exists in system");
                   

                }
                else if ((RetrieveContact.Entities.Count == 0) && status == 278290000)
                {//setting the boolean value to true if no duplicate is found
                    entity["ber_checkduplicate"] = true;
                   // service.Update(entity); 
                   // return;
                }


               
                else if (entity["ber_name"] != null && status == 1)
                {
                    entity["ber_name"] = null;
                    //entity["statuscode"] = new OptionSetValue(1);
                    //entity["ber_checkduplicate"] = false;
                    // service.Update(entity); 
                    // return;
                }
                     
         

                }
                }

            }

        }

    }

}

