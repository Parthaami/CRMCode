﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.ServiceModel;

namespace Berger_AutoNumbering
{
    public class EntityAutoNumbering : IPlugin
    {
        #region Class Level Variables
        public static string _loggerPath = string.Empty;
        public System.Configuration.Configuration config;
        public static PragmasysLogger oLogger;
        public static string _organizationName = string.Empty;
        public static string _myPrefix = string.Empty;
        #endregion


        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext) serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationService service = ((IOrganizationServiceFactory) serviceProvider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(new Guid?(context.UserId));
            _organizationName = context.OrganizationName;

            if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is Entity))
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                try
                {

                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                    */

                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new PragmasysLogger(_organizationName, _loggerPath);
                         //   _myPrefix = config.AppSettings.Settings[entity.LogicalName.ToString()].Value.ToString() + "-";
                        }
                    }
                    #endregion

                    lock (this)
                    {
                        int num9;
                        int num = Convert.ToInt32("798330002");//Siffix Non Value
                        int num2 = Convert.ToInt32("798330001");//Prefix Value value
                        int num3 = Convert.ToInt32("798330002");//Prefix Expression value
                        Entity settings = GetSettings(service, entity.LogicalName);
                        if (settings == null)
                        {
                            return;
                        }

                        if (entity.Attributes.Contains(settings["pcl_fieldschemaname"].ToString()) && Convert.ToBoolean(settings["ber_editable"]))
                        {
                            return;
                        }

                        int next = Convert.ToInt32(settings["pcl_currentnumber"].ToString()) + 1;
                        //Increment(service, next, new Guid(settings["pcl_numberingschemeid"].ToString()));

                        int num6 = Convert.ToInt32((settings["pcl_prefixtype"] as OptionSetValue).Value);
                        int num7 = Convert.ToInt32((settings["pcl_suffixtype"] as OptionSetValue).Value);
                        int num8 = Convert.ToInt32(settings["pcl_autonumberlength"].ToString());
                        string str2 = DateTime.Today.ToString("dd");
                        string str3 = DateTime.Today.ToString("MM");
                        string str4 = DateTime.Today.ToString("yy");
                        string str5 = settings["pcl_prefix"].ToString().ToLower();
                        string str6 = next.ToString();
                        string str7 = "";
                        string str8 = "";
                        if (num7 != num)
                        {
                            str8 = settings["pcl_suffix"].ToString() + "-";
                        }
                        if (num6 == num2)
                        {
                            str7 = settings["pcl_prefix"].ToString();
                        }
                        else if (num6 == num3)
                        {
                            switch (str5)
                            {
                                case "dd":
                                    str7 = str2 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings,str6, str7,str8,num8,num9, next);
                                    break;

                                case "mm":
                                    str7 = str3 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings,str6, str7,str8,num8,num9, next);
                                    break;

                                case "ddmm":
                                    str7 = str2 + str3 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings,str6, str7,str8,num8,num9, next);
                                    break;

                                case "mmdd":
                                    str7 = str3 + str2 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings, str6, str7, str8, num8, num9, next);
                                    break;

                                case "mmyy":
                                    str7 = str3 + str4 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings, str6, str7, str8, num8, num9, next);
                                    break;

                                case "yymm":
                                    str7 = str4 + str3 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings, str6, str7, str8, num8, num9, next);
                                    break;
                                case "ddmmyy":
                                    str7 = str2 + str3 + str4 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings, str6, str7, str8, num8, num9, next);
                                    break;
                                case "yymmdd":
                                    str7 = str4 + str3 + str2 + "-";
                                    //goto Label_03C0;
                                    Label_03C0(service, settings,str6, str7,str8,num8,num9, next);
                                    break;
                            }
                            str7 = str2 + str3 + str4;
                        }

                        /*
                        Label_03C0:
                        num9 = num8 - next.ToString().Length;
                        for (int i = 0; i < num9; i++)
                        {
                            str6 = "0" + str6;
                        }
                        // str6 = str7 + str6 + str8;
                        str6 = str8 + str7 + str6;

                        if (this.Increment(service, next, new Guid(settings["pcl_numberingschemeid"].ToString())))
                        {
                            string str9 = settings["pcl_fieldschemaname"].ToString();
                            entity[str9] = str6;
                        }
                        */

                        // This feature is currently not in place, we will take care the same at the time of IFD.
                        // To get it work we need to update dll to latest.
                        // Increment(service, next, new Guid(settings["pcl_numberingschemeid"].ToString()), settings, str6);
                    }
                }
                catch (Exception exception)
                {
                    oLogger.Log("Autonumbering", "Execute", exception.Message, exception.StackTrace.ToString());
                }
            }
        }

        public static Entity GetSettings(IOrganizationService service, string entityName)
        {
            QueryExpression expression2 = new QueryExpression();
            expression2.EntityName = "pcl_numberingscheme";
            expression2.ColumnSet = new ColumnSet(true);
            expression2.Criteria.Conditions.Add(new ConditionExpression("pcl_name", ConditionOperator.Equal, entityName));
            QueryExpression query = expression2;
            DataCollection<Entity> entities = service.RetrieveMultiple(query).Entities;
            using (IEnumerator<Entity> enumerator = entities.GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    return enumerator.Current;
                }
            }
            return null;
        }

        public bool Increment(IOrganizationService service, int next, Guid Id)
        {
            try
            {
                Entity entity = new Entity("pcl_numberingscheme");
                entity.Id = Id;
                entity["pcl_currentnumber"] = next;
                service.Update(entity);
                return true;
            }
            catch (Exception exception)
            {
                oLogger.Log("Autonumbering", "Execute", exception.Message, exception.StackTrace.ToString());
                return false;
            }
        }



        /// <summary>
        ///  Label_03C0
        /// </summary>
        /// <param name="str6"></param>
        /// <param name="str7"></param>
        /// <param name="str8"></param>
        /// <param name="num9"></param>
        /// <param name="next"></param>
        public void Label_03C0(IOrganizationService service, Entity settings, string str6,string str7,string str8, int num8,  int num9,int next)
        {
            try
            {
                num9 = num8 - next.ToString().Length;
                for (int i = 0; i < num9; i++)
                {
                    str6 = "0" + str6;
                }
                // str6 = str7 + str6 + str8;
                str6 = str8 + str7 + str6;

                if (this.Increment(service, next, new Guid(settings["pcl_numberingschemeid"].ToString())))
                {
                    string str9 = settings["pcl_fieldschemaname"].ToString();
                    entity[str9] = str6;
                }
            }
            catch (Exception ex)
            {
            }
        }




        // public bool Update 
        // This feature is currently not in place, we will take care the same at the time of IFD.
        //public void Increment(IOrganizationService service, int next, Guid Id, Entity settings, string autoNumber)
        //{
        //    try
        //    {
        //        Entity entity = new Entity("pcl_numberingscheme");
        //        entity.Id = Id;
        //        entity["pcl_currentnumber"] = next;
        //        UpdateRequest updateRequest = new UpdateRequest();
        //        updateRequest.ConcurrencyBehavior = ConcurrencyBehavior.IfRowVersionMatches;
        //        updateRequest.Target = entity;
        //        updateRequest.Target.RowVersion = settings.RowVersion;
        //        service.Execute(updateRequest);
        //        string str9 = settings["pcl_fieldschemaname"].ToString();
        //        entity[str9] = autoNumber;
        //        oLogger.Log("Autonumbering", "Increment", str9, autoNumber.ToString());
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        if (ex.Code.Name.ToLowerInvariant() == "concurrencyversionmismatch")
        //        {
        //            oLogger.Log("Autonumbering", "Execute", ex.Message, ex.StackTrace.ToString());
        //            throw new InvalidPluginExecutionException("Can't create record due to an internal error, please try again later.");
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        oLogger.Log("Autonumbering", "Execute", exception.Message, exception.StackTrace.ToString());
        //        throw new InvalidPluginExecutionException("Can't create record due to an internal error, please try again later!");
        //    }
        //}


    }
}

