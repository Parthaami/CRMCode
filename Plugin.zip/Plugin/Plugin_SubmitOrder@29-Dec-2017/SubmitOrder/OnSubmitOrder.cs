﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.IO;
//using Microsoft.Xrm.Client;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Net;
using Microsoft.Crm.Sdk.Messages;

namespace SubmitOrder
{
    public class OnSubmitOrder : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static bool IsOrderSubmitted = false;
        public static PragmasysLogger oLogger = null;
        public static string logfilepath = string.Empty;
        public static string _dbConnectionString = string.Empty;
        public static string _webService = string.Empty;
        public static string _CustType = string.Empty;
        public static WebReference.BergerOracleService OracleConnectService = new WebReference.BergerOracleService();

        public void Execute(IServiceProvider serviceProvider)
        {
            bool ccUser = false;
            IsOrderSubmitted = false;

            IPluginExecutionContext context =
                        (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory factory =
            (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity targetEntity = (Entity)context.InputParameters["Target"];
                Entity oEntity = (Entity)context.PreEntityImages["order"];

                if (targetEntity.Attributes.Contains("ber_ordersubmitted"))
                    IsOrderSubmitted = (bool)targetEntity.Attributes["ber_ordersubmitted"];

                if ((IsOrderSubmitted) &&
                        (!(targetEntity.Attributes.Contains("ber_erporderstatus")) ||
                            (targetEntity.Attributes.Contains("ber_erporderstatus") &&
                                (targetEntity.Attributes["ber_erporderstatus"].ToString() == "TODEPOT" ||
                                targetEntity.Attributes["ber_erporderstatus"].ToString() == "ERROR"))))
                {

                    //RegistryKey rk = null;
                    //RegistryKey rk1 = null;
                    //RegistryKey rk2 = null;
                    //RegistryKey rk_dbpath = null;

                    //Object obj_dbpath = null;

                    string DB_path = string.Empty;
                    string configpath = string.Empty;
                    string rolename = string.Empty;
                    string orderItemQuery = string.Empty;
                    string onHoldReason = string.Empty;
                    string P_ATTRIBUTE1 = string.Empty;
                    string P_ATTRIBUTE2 = string.Empty;
                    string P_ATTRIBUTE3 = string.Empty;
                    string P_ATTRIBUTE4 = string.Empty;
                    string P_ATTRIBUTE5 = string.Empty;
                    string P_ATTRIBUTE6 = string.Empty;
                    string P_ATTRIBUTE7 = string.Empty;
                    string P_ATTRIBUTE8 = string.Empty;
                    string P_ATTRIBUTE9 = string.Empty;
                    string P_ATTRIBUTE10 = string.Empty;
                    string P_ATTRIBUTE11 = string.Empty;
                    string P_ATTRIBUTE12 = string.Empty;
                    string ordercode = string.Empty;
                    string orderguid = oEntity.Id.ToString();
                    string shipmentPriority = string.Empty;
                    string customerpo = string.Empty;
                    string P_ATTRIBUTE_CONTEXT = string.Empty;
                    string returnMessage = string.Empty;
                    string custType = string.Empty;
                    string assignmentReason = string.Empty;
                    string Totacreditlimit = string.Empty;
                    string AvaliableLimit = string.Empty;
                    string onHold = string.Empty;
                    string holdReason = string.Empty;
                    string oCustomerAccountNumber = string.Empty;
                    string oBillToAccountNumber = string.Empty;

                    string[] CustomerTypes = null;

                    decimal availTransacLimit = 0;
                    decimal totalamt = 0;

                    bool inDraft = false;


                    EntityReference Customer = new EntityReference();
                    EntityReference BillTo = new EntityReference();
                    Entity OCustomer = new Entity();
                    Entity OBillTo = new Entity();

                    DataTable orderItems = new DataTable();
                    DataSet FinDS = new DataSet();

                    ColumnSet accountColSet = new ColumnSet();

                    ExeConfigurationFileMap filemap = new ExeConfigurationFileMap();

                    QueryExpression query = null;

                    EntityCollection ec = new EntityCollection();


                    //CR-009 Order Split Requirement - Start of Change
                    EntityReference Depot = new EntityReference();
                    Entity OrderDepot = new Entity();

                    string sSplitOrder = string.Empty;
                    Boolean bSplitOrder = false;
                    ColumnSet depotColSet = new ColumnSet();

                    DataTable orderItemTypes = new DataTable();
                    DataTable orderItemsToBePushed = new DataTable();

                    //CR-009 Order Split Requirement - End of Change..

                    try
                    {
                        /*
                        rk = Registry.LocalMachine;
                        rk1 = rk.OpenSubKey("SOFTWARE");
                        rk2 = rk1.OpenSubKey("Microsoft");
                        rk_dbpath = rk2.OpenSubKey("MSCRM");
                        obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");
                        DB_path = obj_dbpath.ToString();

                        configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                        */
                        configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                        filemap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(filemap, ConfigurationUserLevel.None);

                        logfilepath = config.AppSettings.Settings["loggerpath"].Value;
                        int logfilelevel = Convert.ToInt32(config.AppSettings.Settings["loglevel"].Value);
                        _dbConnectionString = config.ConnectionStrings.ConnectionStrings["Bergersqldbconnection"].ConnectionString.ToString();
                        _webService = config.ConnectionStrings.ConnectionStrings["ERPConnectService"].ConnectionString.ToString();
                        _CustType = config.AppSettings.Settings["CustomerTypes"].Value;
                        oLogger = new PragmasysLogger(context.OrganizationName, logfilepath);

                        OracleConnectService.Url = _webService;



                        
                        // Comment Start Old Code 
                        /*
                        orderItemQuery = "select SUM(oli.quantity) as qty,prod.productnumber, newid() , prod.ProductId " + 
                                                " from SalesOrderDetailBase oli with (nolock)" +
                                                " inner join Product prod on oli.productid = prod.productid " +
                                                " where salesorderid = '" + oEntity.Id + "' " +
                                                " group by prod.productnumber,prod.ProductId";


                        orderItems = getDataFromSql(orderItemQuery, _dbConnectionString, logfilelevel);
                        */
                        //Comment End Old Code*/


                        SqlParameter[] orderItemQueryParams = { new SqlParameter("@salesorderid", oEntity.Id) };
                        orderItems = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_orderItemQuery", orderItemQueryParams).Tables[0];


                        inDraft = false;
                        query = new QueryExpression()
                        {
                            EntityName = "role",
                            ColumnSet = new ColumnSet("name"),
                            LinkEntities = 
						    {
							    new LinkEntity
							    {
								    LinkFromEntityName = "role",
								    LinkFromAttributeName = "roleid",
								    LinkToEntityName = "systemuserroles",
								    LinkToAttributeName = "roleid",
								    LinkCriteria = new FilterExpression
								    {
									    FilterOperator = LogicalOperator.And,
									    Conditions = 
									    {
										    new ConditionExpression
										    {
											    AttributeName = "systemuserid",
											    Operator = ConditionOperator.Equal,
        									    Values = { context.UserId }
										    }
									    }
								    }
							    }
                            }
                        };
                        ec = service.RetrieveMultiple(query);
                        for (int i = 0; i < ec.Entities.Count; i++)
                        {
                            rolename = ec.Entities[i]["name"].ToString();
                            if (rolename.ToLower() == "call center user" || rolename.ToLower() == "call center manager")
                            {
                                ccUser = true;
                                break;
                            }
                        }

                        ordercode = oEntity.Attributes["ordernumber"].ToString();
                        if (oEntity.Attributes.Contains("ber_customerpo"))
                            customerpo = oEntity.Attributes["ber_customerpo"].ToString();
                        if (oEntity.Attributes.Contains("ber_shipmentpriority"))
                        {
                            shipmentPriority = ((OptionSetValue)oEntity.Attributes["ber_shipmentpriority"]).Value.ToString();
                            if (Convert.ToInt32(shipmentPriority) == 1)
                                shipmentPriority = "NORMAL_C1";
                            else if (Convert.ToInt32(shipmentPriority) == 2)
                                shipmentPriority = "C4_PRIORITY";
                            else if (Convert.ToInt32(shipmentPriority) == 3)
                                shipmentPriority = "PRIORITISED_C1";
                        }
                        if (oEntity.Attributes.Contains("ber_dff"))
                            P_ATTRIBUTE_CONTEXT = RetrieveAttributeMetadataPicklistValue(service, ((OptionSetValue)oEntity.Attributes["ber_dff"]).Value, "salesorder", "ber_dff");

                        if (oEntity.Attributes.Contains("customerid"))
                            Customer = (EntityReference)oEntity.Attributes["customerid"];

                        if (oEntity.Attributes.Contains("ber_billto"))
                            BillTo = (EntityReference)oEntity.Attributes["ber_billto"];

                        if (oEntity.Contains("ber_consigneename"))
                            P_ATTRIBUTE1 = oEntity.Attributes["ber_consigneename"].ToString();
                        if (oEntity.Contains("ber_addressline1"))
                            P_ATTRIBUTE2 = oEntity.Attributes["ber_addressline1"].ToString();
                        if (oEntity.Contains("ber_addressline2"))
                            P_ATTRIBUTE3 = oEntity.Attributes["ber_addressline2"].ToString();
                        if (oEntity.Contains("ber_range"))
                            P_ATTRIBUTE4 = oEntity.Attributes["ber_range"].ToString();
                        if (oEntity.Contains("ber_adressofcedivision"))
                            P_ATTRIBUTE5 = oEntity.Attributes["ber_adressofcedivision"].ToString();
                        if (oEntity.Contains("ber_commissionerate"))
                            P_ATTRIBUTE6 = oEntity.Attributes["ber_commissionerate"].ToString();
                        if (oEntity.Contains("ber_eccno"))
                            P_ATTRIBUTE7 = oEntity.Attributes["ber_eccno"].ToString();
                        if (oEntity.Contains("ber_ceregnno"))
                            P_ATTRIBUTE8 = oEntity.Attributes["ber_ceregnno"].ToString();
                        if (oEntity.Contains("ber_thirdpartyname"))
                            P_ATTRIBUTE9 = oEntity.Attributes["ber_thirdpartyname"].ToString();
                        if (oEntity.Contains("ber_paymentmode"))
                            P_ATTRIBUTE10 = RetrieveAttributeMetadataPicklistValue(service, ((OptionSetValue)oEntity.Attributes["ber_paymentmode"]).Value, "salesorder", "ber_paymentmode").ToUpper();
                        if (oEntity.Contains("ber_chequenumber"))
                            P_ATTRIBUTE11 = oEntity.Attributes["ber_chequenumber"].ToString();
                        if (oEntity.Contains("ber_prolinkdetailsprojectcode"))
                            P_ATTRIBUTE12 = oEntity.Attributes["ber_prolinkdetailsprojectcode"].ToString();
                        if (oEntity.Contains("ber_prolinkdetailscontractorname"))
                            P_ATTRIBUTE2 = oEntity.Attributes["ber_prolinkdetailscontractorname"].ToString();
                        if (oEntity.Contains("ber_prolinkdetailsarchitectname"))
                            P_ATTRIBUTE3 = oEntity.Attributes["ber_prolinkdetailsarchitectname"].ToString();
                        if (oEntity.Contains("ber_prolinkdetailsbuildername"))
                            P_ATTRIBUTE4 = oEntity.Attributes["ber_prolinkdetailsbuildername"].ToString();

                        CustomerTypes = _CustType.Split(',');

                        accountColSet.AddColumns(new string[] { "customertypecode", "ber_availabletransactionlimit", "accountnumber" });

                        OCustomer = service.Retrieve("account", Customer.Id, accountColSet);
                        OBillTo = service.Retrieve("account", BillTo.Id, accountColSet);


                        // CR-009 Order Split Requirement - Start of Change
                        #region  "Ticket#1359:  Order New Order Split Base Logic.."
                        // Code will be modified....
                        // depotColSet.AddColumns(new string[] { "ber_spiltorder" });
                        depotColSet.AddColumns(new string[] { "ber_spiltorder", "ber_manufacturingsplit" });
                        #endregion

                        Depot = (EntityReference)oEntity.Attributes["ber_depotid"];
                        OrderDepot = service.Retrieve("ber_depot", Depot.Id, depotColSet);

                        if (OBillTo.Attributes.Contains("customertypecode"))
                            custType = RetrieveAttributeMetadataPicklistValue(service, ((OptionSetValue)OBillTo.Attributes["customertypecode"]).Value, "account", "customertypecode");

                        if (OCustomer.Attributes.Contains("accountnumber"))
                            oCustomerAccountNumber = OCustomer["accountnumber"].ToString();

                        if (OBillTo.Attributes.Contains("accountnumber"))
                            oBillToAccountNumber = OBillTo["accountnumber"].ToString();

                        if (OCustomer.Contains("ber_availabletransactionlimit"))
                            availTransacLimit = ((Money)OCustomer.Attributes["ber_availabletransactionlimit"]).Value;

                        if (oEntity.Attributes.Contains("totalamount"))
                            totalamt = ((Money)oEntity.Attributes["totalamount"]).Value;


                        #region  "Ticket#1359:  Order New Order Split Base Logic.."
                        
                        string billToDepotSplited = string.Empty;
                        string Ber_AcctIDSplit = string.Empty;
                        string ber_DepotIdSplit = string.Empty;
                        string ber_associatedtsiidSplit = string.Empty;
                        string ber_OwnerSplit = string.Empty;

                        if (((OptionSetValue)OrderDepot.Attributes["ber_spiltorder"]).Value.ToString() == "278290000" &&  ((OptionSetValue)OrderDepot.Attributes["ber_manufacturingsplit"]).Value.ToString() == "1")
                        {


                            //Comment start #17-Jan-2020
                            /*
                            // if "BER_DESTINATIONDEPOT" should not be NULL / BLANK  , Current Code is  Considered , it will be considered next...  
                            string QuerySplit = " Select count(*) cnt from SalesOrderDetail with (nolock) inner join Product with (nolock) on SalesOrderDetail.ProductId = product.ProductId " +
                                                " inner join ber_product_depot on ber_product_depot.ber_splittableproduct = SalesOrderDetail.ProductId where SalesOrderDetail.SalesOrderId = '" + oEntity.Id.ToString() + "' AND ber_product_depot.BER_SOURCEDEPOT = '" + OrderDepot.Id + "'";

                            DataTable orderItemsToBeSplit = getDataFromSql(QuerySplit, _dbConnectionString, logfilelevel);

                                                       */
                            //Comment End

                            SqlParameter[] QuerySplitParams =  {
                                                                 new SqlParameter("@salesorderid", oEntity.Id.ToString()),
                                                                 new SqlParameter("@BER_SOURCEDEPOT", oEntity.Id)
                                                               };
                            DataTable orderItemsToBeSplit = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_QuerySplit", QuerySplitParams).Tables[0];


                            //Comment start #17-Jan-2020
                            // Main Logic 
                            // Identifying Correct Bill To
                            // Dated : 11-NOV-2017 Suggested by Soumen

                            /*
                            string QuerybillToDepotSplited = " SELECT top 1 TT.AccountId,TT.AccountNumber,TT.ber_DepotId,TT.ber_associatedtsiid,TT.OwnerId FROM Account TT inner join (SELECT PT.AccountNumber,T.AccountNumber as ab,T.ber_L_BILL_TO FROM Account T " +
                                                             " INNER JOIN Account PT ON PT.AccountId=T.ParentAccountId WHERE T.ParentAccountId IS NOT NULL AND PT.AccountId='" + OCustomer.Id + "'" +
                                                             " AND T.AccountId ='" + OBillTo.Id + "' AND T.StateCode  = 0 AND PT.StateCode = 0) Mn on Mn.ber_L_BILL_TO=TT.AccountNumber AND TT.StateCode = 0 ";

                            */
                            //Comment End

                            SqlParameter[] QuerybillToDepotSplitedParams =  {
                                                                            new SqlParameter("@ParentAccountId", oEntity.Id.ToString()),
                                                                            new SqlParameter("@ChildAccoutId", OCustomer.Id)
                                                                           };

                          // DataTable orderItemsToBeSplit = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "Order_QuerySplit", QuerySplitParams).Tables[0];




                            oLogger.Log("Split order logic  ", "orderItemsToBeSplit", " No Of rows to be split ", orderItemsToBeSplit.Rows.Count.ToString());
                            
                            if (orderItemsToBeSplit.Rows.Count > 0)
                            {
                                if (Convert.ToInt32(orderItemsToBeSplit.Rows[0]["cnt"]) > 0)
                                {
                                    // bSplitOrder = true;
                                    // Need to retrive all information for split order ..................
                                    // DataTable dtbillToDepotSplited = getDataFromSql(QuerybillToDepotSplited, _dbConnectionString, logfilelevel);
                                    DataTable dtbillToDepotSplited = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_QuerybillToDepotSplited", QuerybillToDepotSplitedParams).Tables[0];

                                    oLogger.Log("Split order logic  ", "orderItemsToBeSplit", " No Of rows to be split ", dtbillToDepotSplited.Rows.Count.ToString());
                                    
                                    //if Different Product Type ....
                                    if (dtbillToDepotSplited.Rows.Count > 0)
                                    {
                                            Ber_AcctIDSplit = Convert.ToString(dtbillToDepotSplited.Rows[0]["AccountId"]).Trim();
                                            ber_DepotIdSplit = Convert.ToString(dtbillToDepotSplited.Rows[0]["ber_DepotId"]).Trim();
                                            ber_associatedtsiidSplit = Convert.ToString(dtbillToDepotSplited.Rows[0]["ber_associatedtsiid"]).Trim();
                                            ber_OwnerSplit = Convert.ToString(dtbillToDepotSplited.Rows[0]["OwnerId"]).Trim();
                                    }
                                    bSplitOrder = true;
                                }
                            }
                        }

                        #endregion

                        //For specific customer types order to be submitted without any validation to ERP in draft State. Such Customer Types are derived from config of plugin
                        foreach (string strCusttype in CustomerTypes)
                        {
                            if (strCusttype == custType)
                            {
                                inDraft = true;
                                break;
                            }
                        }
                        string BaseProductType = string.Empty;
                        DataTable NonSplittableProduct = new DataTable();

                        #region OrderSplittable
                        if (inDraft)
                        {
                            if (bSplitOrder)
                            {
                                string sqlQuery         = string.Empty;
                                string splitResponse    = string.Empty;
                                string ProductType      = string.Empty;

                               // check if product of multiple types present in the order? If present then split else do not split.
                               orderItemTypes = orderItems.DefaultView.ToTable(true, "productnumber");
                               if (orderItemTypes.Rows.Count > 0)
                               {
                                            targetEntity.Attributes["ber_ordersubmitted"] = false;
                                            targetEntity.Attributes["willcall"] = true;
                                            try
                                            {
                                                // Ticket#1359 : Commented Old Logic.....
                                                sqlQuery =  "select SalesOrderDetail.SalesOrderDetailId from SalesOrderDetail with (nolock) inner join Product with (nolock) on  SalesOrderDetail.ProductId = product.ProductId inner join ber_product_depot on ber_product_depot.ber_splittableproduct = SalesOrderDetail.ProductId where SalesOrderDetail.SalesOrderId = '" + oEntity.Id.ToString() + "' AND ber_product_depot.BER_SOURCEDEPOT = '" + OrderDepot.Id + "'";
                                                orderItemsToBePushed = getDataFromSql(sqlQuery, _dbConnectionString, logfilelevel);

                                        #region   NonSplitableProduct

                                        // Comment Start 
                                        /*

                                           string QueryNonSplittable = "select  SUM(oli.quantity) as qty,prod.productnumber, newid() , prod.ProductId " +
                                                                  " from SalesOrderDetailBase oli with (nolock) inner join Product prod on oli.productid = prod.productid " +
                                                                  " where salesorderid =  '" + oEntity.Id.ToString() + "'" +
                                                                  " And prod.ProductId not in (select ber_splittableproduct from ber_product_depot where  ber_product_depot.BER_SOURCEDEPOT = '" + OrderDepot.Id + "') " +
                                                                  " group by prod.productnumber,prod.ProductId ";
                                                NonSplittableProduct = getDataFromSql(QueryNonSplittable, _dbConnectionString, logfilelevel);

                                        */
                                        //Comment End 

                                        SqlParameter[] QueryNonSplittableParams =  {
                                                                 new SqlParameter("@salesorderid", oEntity.Id.ToString()),
                                                                 new SqlParameter("@BER_SOURCEDEPOT", oEntity.Id)
                                                               };
                                         NonSplittableProduct = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_QueryNonSplittable", QueryNonSplittableParams).Tables[0];



                                        oLogger.Log("Split order# ", "NonSplittableProduct", " rows to push: ", NonSplittableProduct.Rows.Count.ToString());

                                                #endregion

                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " rows to push: ", orderItemsToBePushed.Rows.Count.ToString());
                                                string itemIds = string.Empty;
                                                foreach (DataRow drow in orderItemsToBePushed.Rows)
                                                {
                                                    itemIds = itemIds + drow["SalesOrderDetailId"].ToString() + ",";
                                                }

                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " itemIds: ", itemIds);

                                                itemIds = itemIds.Substring(0, itemIds.Length - 1);

                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " itemIds: ", itemIds);
                                                OracleConnectService.Timeout = 20000; //100000
                                                try
                                                {
                                                   // Ticket#1359 : Commented Old Logic..... 
                                                   NewsplitOrder(service,orderguid, ProductType, itemIds, orderItemsToBePushed.Rows.Count, Ber_AcctIDSplit, ber_DepotIdSplit, ber_associatedtsiidSplit, ber_OwnerSplit);
                                                }
                                                catch (Exception ex)
                                                {
                                                    oLogger.Log("SubmitOrder", "executeOrderSubmit", targetEntity.Id.ToString() + "_" + ex.Message, ex.StackTrace.ToString());
                                                }
                                                
                                            }
                                            catch (Exception ex)
                                            {
                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " status: " + splitResponse, "Exception: " + ex.StackTrace);
                                            }

                                            oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, NonSplittableProduct.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, NonSplittableProduct);
                               }
                                else
                                {
                                     oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, orderItems.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, orderItems);
                                }
                            }
                            else
                            {
                                oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, orderItems.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, orderItems);
                            }
                        }
                        else
                        {
                            
                            inDraft = false;
                            if (totalamt > availTransacLimit && ccUser)
                                assignmentReason = "Order Value exceeds Available Transaction Limit in CRM.";

                            // check if product of multiple types present in the order? If present then split else do not split.
                            if (bSplitOrder)
                            {
                                string sqlQuery         = string.Empty;
                                string splitResponse    = string.Empty;
                                string ProductType      = string.Empty;
                                
                                // check if product of multiple types present in the order? If present then split else do not split.
                                orderItemTypes = orderItems.DefaultView.ToTable(true, "productnumber");
                                //oLogger.Log("insplit", orderItemTypes.Rows.Count.ToString(), "", "");
                                if (orderItemTypes.Rows.Count > 0)
                                {
                                            targetEntity.Attributes["ber_ordersubmitted"] = false;
                                            targetEntity.Attributes["willcall"] = true;
                                   
                                            try
                                            {

                                        //Comment Code
                                        /*
                                        // Ticket#1359 : Commented Old Logic.....
                                         sqlQuery = "select SalesOrderDetail.SalesOrderDetailId from SalesOrderDetail with (nolock) inner join Product with (nolock) on  SalesOrderDetail.ProductId = product.ProductId inner join ber_product_depot on ber_product_depot.ber_splittableproduct = SalesOrderDetail.ProductId where SalesOrderDetail.SalesOrderId = '" + oEntity.Id.ToString() + "'  AND ber_product_depot.BER_SOURCEDEPOT = '" + OrderDepot.Id + "'";
                                         orderItemsToBePushed = getDataFromSql(sqlQuery, _dbConnectionString, logfilelevel);
                                       */
                                        // Coment End

                                        SqlParameter[] QueryOrderItemsToBePushedParams =  {
                                                                 new SqlParameter("@salesorderid", oEntity.Id.ToString()),
                                                                 new SqlParameter("@BER_SOURCEDEPOT", oEntity.Id)
                                                               };
                                        DataTable orderItemsToBeSplit = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_QueryOrderItemsToBePushed", QueryOrderItemsToBePushedParams).Tables[0];


                                        oLogger.Log("Split order# ", "orderItemsToBePushed", " rows to push: ", orderItemsToBePushed.Rows.Count.ToString());


                                        //Comment Start
                                        /*
                                              #region   NonSplitableProduct
                                              string QueryNonSplittable = " select  SUM(oli.quantity) as qty,prod.productnumber, newid() , prod.ProductId " +
                                                                " from SalesOrderDetailBase oli with (nolock) inner join Product prod on oli.productid = prod.productid " +
                                                                " where salesorderid =  '" + oEntity.Id.ToString() + "'" +
                                                                " And prod.ProductId not in (select ber_splittableproduct from ber_product_depot where  ber_product_depot.BER_SOURCEDEPOT = '" + OrderDepot.Id + "') " +
                                                                " group by prod.productnumber ,prod.ProductId";

                                              NonSplittableProduct = getDataFromSql(QueryNonSplittable, _dbConnectionString, logfilelevel);

                                              oLogger.Log("Split order# ", "NonSplittableProduct", " rows to push: ", NonSplittableProduct.Rows.Count.ToString());
                                              #endregion
                                       */
                                        //Comment End


                                        SqlParameter[] QueryNonSplittableProductParams =  {
                                                                 new SqlParameter("@salesorderid", oEntity.Id.ToString()),
                                                                 new SqlParameter("@BER_SOURCEDEPOT", oEntity.Id)
                                                               };
                                        NonSplittableProduct = StoredProcGeneric.ExecuteProcedureReturnDataSet(_dbConnectionString, "BPIL_Order_QueryNonSplittableProduct", QueryNonSplittableProductParams).Tables[0];

                                        oLogger.Log("Split order# ","" /*e.ToString()*/, " rows to push: ", orderItemsToBePushed.Rows.Count.ToString());
                                                string itemIds = string.Empty;
                                                foreach (DataRow drow in orderItemsToBePushed.Rows)
                                                {
                                                    itemIds = itemIds + drow["SalesOrderDetailId"].ToString() + ",";
                                                }

                                                oLogger.Log("Split order# ","" /*e.ToString()*/, " itemIds: ", itemIds);
                                                itemIds = itemIds.Substring(0, itemIds.Length - 1);
                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " itemIds: ", itemIds);
                                                OracleConnectService.Timeout  =100000;  //= 20000;
                                                try
                                                {
                                                    //  billToDepotSplited
                                                    //  Ticket#1359 : Added Bill To ......
                                                    NewsplitOrder(service,orderguid, ProductType, itemIds, orderItemsToBePushed.Rows.Count, Ber_AcctIDSplit, ber_DepotIdSplit, ber_associatedtsiidSplit, ber_OwnerSplit);
                                                }
                                                catch (Exception ex)
                                                {
                                                    oLogger.Log("SubmitOrder", "executeOrderSubmit", targetEntity.Id.ToString() + "_" + ex.Message, ex.StackTrace.ToString());
                                                }
                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " status: ", splitResponse);
                                            }
                                            catch (Exception ex)
                                            {
                                                oLogger.Log("Split order# ", ""/*e.ToString()*/, " status: " + splitResponse, "Exception: " + ex.StackTrace);
                                            }
                                            //Submit Non-Splitable Item after Submit..
                                            oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, NonSplittableProduct.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, NonSplittableProduct);
                                }
                                else
                                {
                                    oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, orderItems.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, orderItems);
                                }
                            }
                            else
                            {
                                oEntity = submitOrderToErp(ordercode, oCustomerAccountNumber, oBillToAccountNumber, orderguid, shipmentPriority, orderItems.Rows.Count.ToString(), customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, assignmentReason, ccUser, oEntity, availTransacLimit, OCustomer.Id, service, orderItems);
                            }
                        }
                        #endregion

                    }
                    catch (Exception ex)
                    {
                        oEntity.Attributes["statecode"] = new OptionSetValue(0);
                        oEntity.Attributes["statuscode"] = new OptionSetValue(278290003);
                        oEntity.Attributes["ber_erporderstatus"] = "TODEPOT";
                        oEntity.Attributes["ber_integrationfaultcode"] = "08";
                        if (ccUser)
                            oEntity.Attributes["ber_userrole"] = "Call Center";
                        else
                            oEntity.Attributes["ber_userrole"] = "Others";
                        oLogger.Log("SubmitOrder", "executeOrderSubmit", targetEntity.Id.ToString() + "_" + ex.Message, ex.StackTrace.ToString());
                    }
                    finally
                    {
                        if (oEntity.Attributes.Contains("ber_erporderstatus"))
                            targetEntity.Attributes["ber_erporderstatus"] = oEntity["ber_erporderstatus"].ToString();
                        else
                            targetEntity.Attributes["ber_erporderstatus"] = string.Empty;

                        if (oEntity.Attributes.Contains("ber_integrationfaultcode"))
                            targetEntity.Attributes["ber_integrationfaultcode"] = oEntity["ber_integrationfaultcode"].ToString();
                        else
                            targetEntity.Attributes["ber_integrationfaultcode"] = string.Empty;

                        if (oEntity.Attributes.Contains("ber_userrole"))
                            targetEntity.Attributes["ber_userrole"] = oEntity["ber_userrole"].ToString();
                        else
                            targetEntity.Attributes["ber_userrole"] = string.Empty;

                        if (oEntity.Attributes.Contains("ber_dailylimitdeducted"))
                            targetEntity.Attributes["ber_dailylimitdeducted"] = oEntity["ber_dailylimitdeducted"];
                        else
                            targetEntity.Attributes["ber_userrole"] = false;

                        if (oEntity.Attributes.Contains("ber_ebizerror"))
                            targetEntity.Attributes["ber_ebizerror"] = oEntity["ber_ebizerror"].ToString();

                        targetEntity.Attributes["statecode"] = oEntity.Attributes["statecode"];
                        targetEntity.Attributes["statuscode"] = oEntity.Attributes["statuscode"];

                        if (oEntity.Attributes.Contains("ber_ordersubmitted") && oEntity.Attributes.Contains("ber_integrationfaultcode") && oEntity.Attributes["ber_integrationfaultcode"].ToString() != "00")
                            targetEntity.Attributes["ber_ordersubmitted"] = false;

                        //rk = null;
                        //rk1 = null;
                        //rk2 = null;
                        //rk_dbpath = null;

                        //obj_dbpath = null;

                        DB_path = string.Empty;
                        configpath = string.Empty;
                        rolename = string.Empty;
                        orderItemQuery = string.Empty;
                        onHoldReason = string.Empty;
                        P_ATTRIBUTE1 = string.Empty;
                        P_ATTRIBUTE2 = string.Empty;
                        P_ATTRIBUTE3 = string.Empty;
                        P_ATTRIBUTE4 = string.Empty;
                        P_ATTRIBUTE5 = string.Empty;
                        P_ATTRIBUTE6 = string.Empty;
                        P_ATTRIBUTE7 = string.Empty;
                        P_ATTRIBUTE8 = string.Empty;
                        P_ATTRIBUTE9 = string.Empty;
                        P_ATTRIBUTE10 = string.Empty;
                        P_ATTRIBUTE11 = string.Empty;
                        P_ATTRIBUTE12 = string.Empty;
                        ordercode = string.Empty;
                        orderguid = string.Empty;
                        shipmentPriority = string.Empty;
                        customerpo = string.Empty;
                        P_ATTRIBUTE_CONTEXT = string.Empty;
                        returnMessage = string.Empty;
                        custType = string.Empty;
                        assignmentReason = string.Empty;
                        Totacreditlimit = string.Empty;
                        AvaliableLimit = string.Empty;
                        onHold = string.Empty;
                        holdReason = string.Empty;
                        oCustomerAccountNumber = string.Empty;
                        oBillToAccountNumber = string.Empty;
                        logfilepath = string.Empty;
                        _dbConnectionString = string.Empty;
                        _webService = string.Empty;
                        _CustType = string.Empty;
                        CustomerTypes = null;
                        availTransacLimit = 0;
                        totalamt = 0;
                        inDraft = false;
                        Customer = null;
                        BillTo = null;
                        OCustomer = null;
                        OBillTo = null;
                        oEntity = null;
                        accountColSet = null;
                        filemap = null;
                        query = null;
                        ec = null;
                        config = null;
                        IsOrderSubmitted = false;
                        oLogger = null;

                        OracleConnectService.Dispose();
                        orderItems.Dispose();
                        FinDS.Dispose();

                    }
                }
                else if (targetEntity.Attributes.Contains("ber_erporderstatus") && (targetEntity.Attributes["ber_erporderstatus"].ToString() == "COMPLETED" || targetEntity.Attributes["ber_erporderstatus"].ToString() == "ERROR") && context.MessageName.ToLower() == "update")
                {
                    targetEntity.Attributes["statecode"] = new OptionSetValue(0);
                    targetEntity.Attributes["statuscode"] = new OptionSetValue(278290003);
                    oEntity = null;
                }
            }
        }       
        public static Entity submitOrderToErp(string ordercode, string customer, string billto, string orderguid, string shipmentPriority, string countOrderItems, string customerpo, string P_ATTRIBUTE_CONTEXT, string P_ATTRIBUTE1, string P_ATTRIBUTE2, string P_ATTRIBUTE3, string P_ATTRIBUTE4, string P_ATTRIBUTE5, string P_ATTRIBUTE6, string P_ATTRIBUTE7, string P_ATTRIBUTE8, string P_ATTRIBUTE9, string P_ATTRIBUTE10, string P_ATTRIBUTE11, string P_ATTRIBUTE12, bool inDraft, string assignmentReason, bool ccUser, Entity oEntity, decimal availTransacLimit, Guid customerId, IOrganizationService service, DataTable orderItems)
        {
            string faultCode = "00";
            string submitStatus = string.Empty;
            string orderResponse = string.Empty;
            string ordLineResponse = string.Empty;

            decimal trlimit = 0;
            decimal totalamount = 0;

            string[] stringSeprators = new string[] { "||" };
            string[] ouput = null;

            List<WebReference._OrderProduct> OrderProductList = new List<WebReference._OrderProduct>();
            WebReference._OrderProduct[] OrderProductArray;

            Entity UpAcc = new Entity();

            int i = 0;

            try
            {
                if (assignmentReason == null || assignmentReason == string.Empty)
                {
                    try
                    {
                        OracleConnectService.Timeout = 20000; //100000; //
                        orderResponse = OracleConnectService.CreateOrderMaster(ordercode, customer, billto, orderguid, countOrderItems.ToString(), shipmentPriority, customerpo, P_ATTRIBUTE_CONTEXT, P_ATTRIBUTE1, P_ATTRIBUTE2, P_ATTRIBUTE3, P_ATTRIBUTE4, P_ATTRIBUTE5, P_ATTRIBUTE6, P_ATTRIBUTE7, P_ATTRIBUTE8, P_ATTRIBUTE9, P_ATTRIBUTE10, P_ATTRIBUTE11, P_ATTRIBUTE12, inDraft, ((Money)oEntity.Attributes["totalamount"]).Value.ToString(), ccUser);
                    }
                    catch (Exception ex)
                    {
                        faultCode = "01";
                        oLogger.Log("SubmitOrder", "wsCallHeaderCreateSubmitOrder", orderguid + "_" + ex.Message, ex.StackTrace.ToString());
                    }
                    if (orderResponse.Contains("PUBLISHED"))
                    {

                        ouput = orderResponse.Split(stringSeprators, StringSplitOptions.None);

                        foreach (DataRow dr in orderItems.Rows)
                        {
                            WebReference._OrderProduct op = new WebReference._OrderProduct();
                            op.CRMOrderId = orderguid;
                            op.OrderItemGuid = orderItems.Rows[i].ItemArray[2].ToString();
                            op.ProductCode = orderItems.Rows[i].ItemArray[1].ToString();
                            op.Quantity = Convert.ToDecimal(orderItems.Rows[i].ItemArray[0].ToString());
                            OrderProductList.Add(op);
                            op = null;
                            i = i + 1;
                        }

                        OrderProductArray = OrderProductList.ToArray();
                        try
                        {
                            OracleConnectService.Timeout = 20000;//100000;
                            ordLineResponse = OracleConnectService.CreateOrderItem(ouput[1], OrderProductArray);
                            if (ordLineResponse != "SUCCESS")
                                faultCode = "02";
                        }
                        catch (Exception ex)
                        {
                            faultCode = "02";
                            oLogger.Log("SubmitOrder", "wsCallHeaderCreateSubmitOrder", orderguid + "_" + ex.Message, ex.StackTrace.ToString());
                        }
                        if (faultCode == "00")
                        {
                            oEntity.Attributes["statecode"] = new OptionSetValue(1);
                            oEntity.Attributes["statuscode"] = new OptionSetValue(3);
                            oEntity.Attributes["ber_erporderstatus"] = "SUBMITTED";
                            oEntity.Attributes["ber_integrationfaultcode"] = faultCode;
                            if (ccUser)
                                oEntity.Attributes["ber_userrole"] = "Call Center";
                            else
                                oEntity.Attributes["ber_userrole"] = "Others";
                            if (oEntity.Attributes.Contains("ber_dailylimitdeducted") && (bool)oEntity["ber_dailylimitdeducted"] == false)
                            {
                                if (oEntity.Attributes.Contains("totalamount"))
                                    totalamount = ((Money)oEntity.Attributes["totalamount"]).Value;

                                trlimit = availTransacLimit - totalamount;
                                UpAcc.LogicalName = "account";
                                UpAcc.Id = customerId;
                                UpAcc.Attributes["ber_availabletransactionlimit"] = new Money(trlimit);
                                service.Update(UpAcc);
                            }
                            oEntity.Attributes["ber_dailylimitdeducted"] = true;
                        }
                    }
                    else if (orderResponse.Contains("EXISTS"))
                    {
                        faultCode = "03";
                        oEntity.Attributes["ber_erporderstatus"] = "ALREADYEXISTS";
                        oEntity.Attributes["ber_integrationfaultcode"] = faultCode;
                        oEntity.Attributes["statecode"] = new OptionSetValue(1);
                        oEntity.Attributes["statuscode"] = new OptionSetValue(3);
                        if (ccUser)
                            oEntity.Attributes["ber_userrole"] = "Call Center";
                        else
                            oEntity.Attributes["ber_userrole"] = "Others";
                    }
                    //else
                    //{
                    //    faultCode = "04";
                    //}
                    if (faultCode != "00" && faultCode != "03")
                    {
                        oEntity.Attributes["statecode"] = new OptionSetValue(0);
                        oEntity.Attributes["statuscode"] = new OptionSetValue(278290003);
                        oEntity.Attributes["ber_erporderstatus"] = "TODEPOT";
                        oEntity.Attributes["ber_integrationfaultcode"] = faultCode;
                        if (ccUser)
                            oEntity.Attributes["ber_userrole"] = "Call Center";
                        else
                            oEntity.Attributes["ber_userrole"] = "Others";
                    }
                }
                else
                {
                    faultCode = "06";
                    oEntity.Attributes["statecode"] = new OptionSetValue(0);
                    oEntity.Attributes["statuscode"] = new OptionSetValue(278290000);
                    oEntity.Attributes["ber_erporderstatus"] = "TODEPOT";
                    oEntity.Attributes["ber_integrationfaultcode"] = faultCode;
                    oEntity.Attributes["ber_ebizerror"] = assignmentReason;
                    if (ccUser)
                        oEntity.Attributes["ber_userrole"] = "Call Center";
                    else
                        oEntity.Attributes["ber_userrole"] = "Others";
                }
            }
            catch (Exception ex)
            {
                faultCode = "05";
                oEntity.Attributes["statecode"] = new OptionSetValue(0);
                oEntity.Attributes["statuscode"] = new OptionSetValue(278290003);
                oEntity.Attributes["ber_erporderstatus"] = "TODEPOT";
                oEntity.Attributes["ber_integrationfaultcode"] = faultCode;
                if (ccUser)
                    oEntity.Attributes["ber_userrole"] = "Call Center";
                else
                    oEntity.Attributes["ber_userrole"] = "Others";
                oLogger.Log("SubmitOrder", "wsCallHeaderCreateSubmitOrder", orderguid + "_" + ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                UpAcc = null;
                OrderProductList = null;
                OrderProductArray = null;

                faultCode = "00";
                submitStatus = string.Empty;
                orderResponse = string.Empty;
                ordLineResponse = string.Empty;

                trlimit = 0;
                totalamount = 0;

                stringSeprators = null;
                ouput = null;

                i = 0;
            }
            return oEntity;
        }
        public DataTable getDataFromSql(string Query, string _dbConnectionString, int logfilelevel)
        {
            DataTable DT = new DataTable();
            SqlConnection connection = new SqlConnection(_dbConnectionString);
            SqlCommand command = new SqlCommand(Query, connection);
            SqlDataReader reader = null;
            try
            {
                command.CommandTimeout = 60;
                connection.Open();
                reader = command.ExecuteReader();
                DT.Load(reader);
                if (logfilelevel > 0)
                    oLogger.Log("SubmitOrder", "getDataFromSql", "SQL Query: " + Query, "Packet Size: " + connection.PacketSize.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving data from SQL", "getOrderItems: " + Query, ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                connection.Close();
                reader.Dispose();
                command.Dispose();
                connection.Dispose();
                Query = string.Empty;
            }
            return DT;
        }
        public string RetrieveAttributeMetadataPicklistValue(IOrganizationService crmService, int addTypeValue, string entityname, string OptionSetName)
        {
            string lblAddTypeLabel = string.Empty;
            int indexAddtypeCode = addTypeValue - 1;

            RetrieveAttributeRequest objRetrieveAttributeRequest = new RetrieveAttributeRequest();
            objRetrieveAttributeRequest.EntityLogicalName = entityname;
            objRetrieveAttributeRequest.LogicalName = OptionSetName;

            RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)crmService.Execute(objRetrieveAttributeRequest);
            PicklistAttributeMetadata objPckLstAttMetadata = new PicklistAttributeMetadata();
            ICollection<object> objCollection = attributeResponse.Results.Values;

            objPckLstAttMetadata.OptionSet = ((EnumAttributeMetadata)(objCollection.ElementAt(0))).OptionSet;
            OptionMetadataCollection OptionsetCollection = objPckLstAttMetadata.OptionSet.Options;

            foreach (OptionMetadata Option in OptionsetCollection)
            {
                if (Option.Value == addTypeValue)
                {
                    Microsoft.Xrm.Sdk.Label objLabel = Option.Label;
                    lblAddTypeLabel = objLabel.LocalizedLabels.ElementAt(0).Label;
                }
            }

            objRetrieveAttributeRequest = null;
            attributeResponse = null;
            objPckLstAttMetadata = null;
            objCollection = null;
            indexAddtypeCode = 0;
            OptionsetCollection = null;

            return lblAddTypeLabel;
        }
        
        #region "Ticket#1359: Logic for secondary bill to for splited order
        /// <summary>
        /// This Method is for Spliting functionalities  , below are all parameters ..
        /// </summary>
        /// <param name="service"> Iorganization Service  </param>
        /// <param name="orderid"> OrderId which need to split</param>
        /// <param name="productType">Product Type as String.Empy </param>
        /// <param name="orderItemstoprocess"> OrderItem</param>
        /// <param name="numOfItems"> Number of Item </param>
        /// <param name="ber_billto"> Bill to , Where Actual Billing </param>
        /// <param name="ber_DepotId"> Assign Depot  </param>
        /// <param name="ber_associatedtsiid"> Assign Associated Sid</param>
        /// <param name="ber_OwnerSplit">Owner of Splited Order</param>
        /// <returns> Return Success Or Fail</returns>
        public string NewsplitOrder(IOrganizationService service, string orderid, string productType, string orderItemstoprocess, int numOfItems, string ber_billto, string ber_DepotId, string ber_associatedtsiid, string ber_OwnerSplit)
        {
            string retStatus = string.Empty;
            string[] itemToProcess = orderItemstoprocess.Split(',');
            try
            {
                oLogger.Log("split order", "NewsplitOrder", "Order id : " + orderid + " numOfItems", numOfItems.ToString());

                Entity order = new Entity("salesorder");
                ColumnSet orderColumns = new ColumnSet(true);
                order = service.Retrieve(order.LogicalName, new Guid(orderid), orderColumns);
                oLogger.Log("split order", "3", "length of array", itemToProcess.Length.ToString());

                // If Guid Exists set New Guid 
                Entity newOrder =   order;  //EntityExtensions.Clone(order);
                
                newOrder.Attributes.Remove("salesorderid");
                newOrder.Attributes.Remove("ordernumber");
                newOrder.Attributes.Remove("statecode");
                newOrder.Attributes.Remove("statuscode");
                newOrder.Id = Guid.NewGuid();
                // make is submitted as false
                newOrder.Attributes.Remove("ber_ordersubmitted");
                newOrder.Attributes.Remove("willcall");

                oLogger.Log("split order", "4", "", "");

                //clone order items
                Entity orderItem = null;
                oLogger.Log("split order", "no fo lineS", numOfItems.ToString(), "");
                if (numOfItems > 0)
                {
                    Guid newOrderId = service.Create(newOrder);
                    Microsoft.Xrm.Sdk.EntityReference refParent = new Microsoft.Xrm.Sdk.EntityReference(newOrder.LogicalName, newOrderId);
                    foreach (string orderItemId in itemToProcess)
                    {
                        orderItem = new Entity();
                        orderItem.LogicalName = "salesorderdetail";
                        orderItem.Id = new Guid(orderItemId);
                        orderItem.Attributes["salesorderid"] = refParent;
                        service.Update(orderItem);
                        orderItem = null;
                    }
                    //submit order flag on order
                    newOrder = new Entity();
                    newOrder.LogicalName = "salesorder";
                    newOrder.Id = newOrderId;
                    newOrder.Attributes["willcall"] = true;

                    #region "Ticket#1359: Logic for secondary bill to for splited order
                    // Ticket#1359 : Added Bill to for ..... 
                    if (!string.IsNullOrEmpty(ber_billto))
                    {
                        Guid splitBillTo = new Guid(ber_billto);
                        Guid SplitDepot = new Guid(ber_DepotId); //Guid.Parse(ber_DepotId);//new Guid(ber_DepotId);  
                        Guid SplitTSi = new Guid(ber_associatedtsiid);
                        Guid SplitOwner = new Guid(ber_OwnerSplit);
                        
                        //Guid SplitCreatedBy = new Guid(createdby);     

                        newOrder.Attributes["ber_billto"] = new Microsoft.Xrm.Sdk.EntityReference("account", splitBillTo);
                        newOrder.Attributes["ber_depotid"] = new Microsoft.Xrm.Sdk.EntityReference("ber_depot", SplitDepot);
                        newOrder.Attributes["ber_associatedtsiid"] = new Microsoft.Xrm.Sdk.EntityReference("ber_tsi", SplitTSi);
                        
                        //newOrder.Attributes["createdby"] = new Microsoft.Xrm.Sdk.EntityReference("systemuser", SplitCreatedBy);
                        
                        //Assign Depot UserID
                        AssignRequest assign = new AssignRequest
                        {
                            Assignee = new Microsoft.Xrm.Sdk.EntityReference("systemuser", SplitOwner),
                            Target = new Microsoft.Xrm.Sdk.EntityReference("salesorder", newOrderId)
                        };
                        
                        // Execute the Request
                        service.Execute(assign);
                    }
                    #endregion
                    service.Update(newOrder);

                    oLogger.Log("split order", "NewsplitOrder", "Order id : " + newOrder.Id.ToString() + " numOfItems", numOfItems.ToString());
                }
                retStatus = "SUCCESS";
            }
            catch (System.ServiceModel.FaultException<OrganizationServiceFault> ex)
            {
                throw new InvalidPluginExecutionException("An error occurred in the FollowupPlugin plug-in." + ex.Message);
            }
            catch (Exception e)
            {
                oLogger.Log("splitOrder", "splitOrder" + orderid.ToString(), "prodType: " + productType, e.InnerException.Message);
                retStatus = "ERROR" + e.StackTrace;
            }
            return retStatus;
        }
        #endregion

    }
}