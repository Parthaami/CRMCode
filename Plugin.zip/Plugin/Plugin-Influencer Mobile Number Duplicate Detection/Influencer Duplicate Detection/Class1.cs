﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
//CRM SDK Namespace
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace Influencer_Duplicate_Detection
{
    public class Class1:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = (IOrganizationService)serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                var MobileNumber = entity.GetAttributeValue<string>("ber_mobilenumber");

                QueryExpression Contact = new QueryExpression { EntityName = entity.LogicalName, ColumnSet = new ColumnSet("ber_mobilenumber") };
                Contact.Criteria.AddCondition("ber_mobilenumber", ConditionOperator.Equal, MobileNumber);
                Contact.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                Contact.Criteria.AddCondition("ber_influencertype", ConditionOperator.In, 278290040, 278290041, 278290042, 278290043, 278290044);
                //  Contact.Criteria.AddCondition("ber_customertype", ConditionOperator.Equal, 278290001);

                EntityCollection RetrieveContact = service.RetrieveMultiple(Contact);

                if (RetrieveContact.Entities.Count > 1)
                {
                    throw new InvalidPluginExecutionException("Following Record with Same Number Exists");

                }
                else if (RetrieveContact.Entities.Count == 0)
                {
                    return;
                }

            }

        }

    }
}
