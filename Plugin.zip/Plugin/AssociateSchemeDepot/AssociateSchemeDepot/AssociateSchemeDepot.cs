﻿// =====================================================================
//  This file is a Template of Plug-in, Modify the code according to you.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;

namespace AssociateSchemeDepot
{
    public class AssociateSchemeDepot : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string _organizationName = context.OrganizationName;

                // The InputParameters collection contains all the data passed in the message request.
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {

                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                    */
                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    if (context.MessageName == "Create" && context.InputParameters["Target"] is Entity)
                    {
                        Entity targetEntity = (Entity)context.InputParameters["Target"];
                        if (targetEntity.Attributes.Contains("ber_schemeid") && targetEntity.Attributes.Contains("ber_depotid"))
                        {
                            EntityReference Scheme = (EntityReference)targetEntity["ber_schemeid"];
                            EntityReference Depot = (EntityReference)targetEntity["ber_depotid"];

                            AssociateRequest Entity1ToEntity2 = new AssociateRequest
                            {
                                Target = new EntityReference(Scheme.LogicalName, Scheme.Id),
                                RelatedEntities = new EntityReferenceCollection
                                {
                                    new EntityReference(Depot.LogicalName,Depot.Id)
                                },
                                Relationship = new Relationship("ber_campaign_depot")
                            };

                            service.Execute(Entity1ToEntity2);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception.
                //Log the Error Entry in Log Table.
                oLogger.Log("Plugin_AssociateSchemeDepot", "Execute", ex.Message, ex.StackTrace.ToString());
            }


        }
    }
}
