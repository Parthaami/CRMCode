﻿// =====================================================================
//  This plugin is used for Creating/Retriving Shade from shade master.
//  It is triggered on Pre event of Product Creation.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Query;

namespace CreateProductShade
{
    public class CreateShade : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;
      
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string _organizationName = context.OrganizationName;

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                    */

                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    Entity targetEntity = (Entity)context.InputParameters["Target"];
                    if (targetEntity.Attributes.Contains("ber_shade"))
                    {
                        string Shade = targetEntity["ber_shade"].ToString();

                        //Check the shade with above shade name is present in shade product or not.
                        ColumnSet ShadeCols = new ColumnSet();
                        Entity ShadeEntity = new Entity();
                        QueryExpression ShadeQry = null;
                        EntityCollection ec = new EntityCollection();
                        ShadeQry = new QueryExpression("ber_shade");
                        ShadeCols.AddColumns(new string[] { "ber_name"});
                        ShadeQry.Criteria.AddCondition("ber_name", ConditionOperator.Equal, Shade);
                        ShadeQry.ColumnSet = ShadeCols;
                        ec = service.RetrieveMultiple(ShadeQry);

                        //If shade is present append shade with product.
                        if (ec.Entities.Count > 0)
                        {
                            Guid ShadeID = ec.Entities[0].Id;
                            targetEntity.Attributes["ber_shadeid"] = new EntityReference("ber_shade", ShadeID);
                        }
                        else //Create new shade in shade master and append with product entity.
                        {
                            Entity newShade = new Entity("ber_shade");
                            newShade.Attributes["ber_name"] = Shade;
                            Guid ShadeID = service.Create(newShade);

                            targetEntity.Attributes["ber_shadeid"] = new EntityReference("ber_shade", ShadeID);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle the exception.
                //Log the Error Entry in Log Table.
                oLogger.Log("CreateProductShade", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
