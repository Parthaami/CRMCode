﻿// =====================================================================
//  This plugin triggers on updation of Meet Painter Record.
//  It calculates the Total Points of meet painter.
//  (Total Points = Regulaer pts + Group Bonus + Volume Bonus + Exceptional Pts.)
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.Win32;
using System.IO;

namespace Plugin_MeetPainterCalculateTotalPoints
{
    public class CalculateTotalPts : IPlugin
    {
        //Class Level Variables.
        public static System.Configuration.Configuration config;
        public static string oConfig = string.Empty;
        public static Logger oLogger;
    
   
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string _organizationName = context.OrganizationName;

                #region To Read Config File
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);                     
                    }
                }
                #endregion

                if (context.MessageName == "Update" && context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is Entity))
                {
                    Entity targetEntityPostImage = (Entity)context.InputParameters["Target"];

                    Entity targetEntityPreImage = (Entity)context.PreEntityImages["MeetPainter"];

                    Int32 TotalPoints = 0;
                    if (targetEntityPostImage.Attributes.Contains("ber_regularpoints"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPostImage["ber_regularpoints"]);
                    }
                    else if (targetEntityPreImage.Attributes.Contains("ber_regularpoints"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPreImage["ber_regularpoints"]);
                    }

                    if (targetEntityPostImage.Attributes.Contains("ber_volumebonus"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPostImage["ber_volumebonus"]);
                    }
                    else if (targetEntityPreImage.Attributes.Contains("ber_volumebonus"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPreImage["ber_volumebonus"]);
                    }

                    if (targetEntityPostImage.Attributes.Contains("ber_groupbonus"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPostImage["ber_groupbonus"]);
                    }
                    else if (targetEntityPreImage.Attributes.Contains("ber_groupbonus"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPreImage["ber_groupbonus"]);
                    }

                    if (targetEntityPostImage.Attributes.Contains("ber_benefitpoints"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPostImage["ber_benefitpoints"]);
                    }
                    else if (targetEntityPreImage.Attributes.Contains("ber_benefitpoints"))
                    {
                        TotalPoints = TotalPoints + Convert.ToInt32(targetEntityPreImage["ber_benefitpoints"]);
                    }
                    

                    Entity MeetPainter = new Entity("ber_paintermeetcontact");
                    MeetPainter.Id = targetEntityPreImage.Id;
                    MeetPainter["ber_totalpoint"] = TotalPoints;
                    service.Update(MeetPainter);
                }
             
            }
            catch (Exception ex)
            {
                //Print the exception in log file.
                oLogger.Log("Plugin_MeetPainterCalculateTotalPts", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
