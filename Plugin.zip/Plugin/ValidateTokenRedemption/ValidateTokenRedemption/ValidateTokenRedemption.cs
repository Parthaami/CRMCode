﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace ValidateTokenRedemption
{
    public class ValidateTokenRedemption:IPlugin
    {
        #region Private variable
         ITracingService tracingService;
         IOrganizationService service;
        #endregion

        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            Microsoft.Xrm.Sdk.IPluginExecutionContext context = (Microsoft.Xrm.Sdk.IPluginExecutionContext)serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));

            tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            // If the context has an InputParameters target and it is an entity then we continue, otherwise skip out 
            // of the plug-in.
            try
            {
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    // Obtain the target entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];
                    tracingService.Trace("Target Entity is {0} id {1}", entity.LogicalName, entity.Id);

                    // Verify that the target entity represents out configured entity.
                    // If not, this plug-in was not registered correctly.
                    if (entity.LogicalName == "ber_tokenredemption")
                    {
                        IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                        service = serviceFactory.CreateOrganizationService(context.UserId);
                        tracingService.Trace("Start verifying records");
                        if (context.MessageName == "Create")
                        {
                            if(!entity.Attributes.Contains("ber_token"))
                            {
                                throw new InvalidPluginExecutionException("Please define Token number");
                            }
                            
                            if(!entity.Attributes.Contains("ber_dealer") && !entity.Attributes.Contains("ber_painter") )
                            {
                                 throw new InvalidPluginExecutionException("Either Dealer or Painter need to define.");
                            }                         
                                 
                             Entity tokenEntity=service.Retrieve(((EntityReference)entity.Attributes["ber_token"]).LogicalName,((EntityReference)entity.Attributes["ber_token"]).Id,new ColumnSet(true));

                             if (tokenEntity == null)
                             {
                                 throw new InvalidPluginExecutionException("Invalid Token");
                             }

                             if (tokenEntity.Attributes.Contains("statuscode"))
                             {
                                  if(((OptionSetValue) tokenEntity.Attributes["statuscode"]).Value!=1)
                                  {
                                      throw new InvalidPluginExecutionException("Token already consumed");
                                  }
                             }

                             if (entity.Attributes.Contains("ber_painter"))
                             {
                                 tokenEntity.Attributes["ber_redeemedbypainter"] = entity.Attributes["ber_painter"];
                                //tokenEntity.Attributes["ber_redemptionpoint"] = Convert.ToInt64(((Money)tokenEntity["ber_denomination"]).Value);
                                tokenEntity.Attributes["ber_redemptionpoint"] = ((Money)tokenEntity["ber_denomination"]).Value;                 // Fixed for bug 22 in TFS
                                service.Update(tokenEntity);

                                 //StateCode = 1 and StatusCode = 2 for deactivating Account or Contact
                                 SetStateRequest setStateRequest = new SetStateRequest()
                                 {
                                     EntityMoniker = new EntityReference
                                     {
                                         Id = tokenEntity.Id,
                                         LogicalName = tokenEntity.LogicalName,
                                     },
                                     State = new OptionSetValue(1),
                                     Status = new OptionSetValue(2)
                                 };
                                 service.Execute(setStateRequest);
                             }
                             else if (entity.Attributes.Contains("ber_dealer"))
                             {
                                 tokenEntity.Attributes["ber_redeemedbydealer"] = entity.Attributes["ber_dealer"];
                                //tokenEntity.Attributes["ber_redemptionpoint"] = Convert.ToInt64(((Money)tokenEntity["ber_denomination"]).Value);
                                tokenEntity.Attributes["ber_redemptionpoint"] = ((Money)tokenEntity["ber_denomination"]).Value;
                                service.Update(tokenEntity);

                                 //StateCode = 1 and StatusCode = 2 for deactivating  
                                 SetStateRequest setStateRequest = new SetStateRequest()
                                 {
                                     EntityMoniker = new EntityReference
                                     {
                                         Id = tokenEntity.Id,
                                         LogicalName = tokenEntity.LogicalName,
                                     },
                                     State = new OptionSetValue(1),
                                     Status = new OptionSetValue(2)
                                 };
                                 service.Execute(setStateRequest);
                             }

                             
                       }
                  }

                }
            }
            catch(Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }
    }
}

 
