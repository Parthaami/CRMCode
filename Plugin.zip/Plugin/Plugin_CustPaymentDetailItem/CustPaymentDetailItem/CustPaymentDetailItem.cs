﻿// =====================================================================
//  This Plugin gets triggered on HD Customer Payment Create/Update Event.
//  It maintains the Collection Amt/Deposition Amt and Clearance Amt.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.IO;

namespace CustPaymentDetailItem
{
    public class CustPaymentDetailItem : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static PragmasysLogger oLogger = null;
        

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context =
                            (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();

                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                    */
                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data     
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                            oLogger = new PragmasysLogger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion

                    Entity targetEntity = new Entity();

                    if (context.MessageName == "Create")
                        targetEntity = (Entity)context.InputParameters["Target"];
                    else if (context.MessageName == "Update")
                        targetEntity = (Entity)context.PreEntityImages["CustPayItem"];

                    //Calculate total collection, Deposition and Pending

                    if (targetEntity.Attributes.Contains("ber_customerpaymentdetailitemid"))
                    {
                        //Find all quotation details and calculate total
                        ColumnSet custPaymentDetItemCols = new ColumnSet();
                        Entity custPaymentDetItemEntity = new Entity();
                        QueryExpression query = null;
                        EntityCollection ec = new EntityCollection();
                        query = new QueryExpression("ber_customerpaymentdetailitem");
                        custPaymentDetItemCols.AddColumns(new string[] { "ber_amount", "ber_collectiondate", "ber_depositiondate", "ber_clearancedate" });
                        query.Criteria.AddCondition("ber_estimatedetailsid", ConditionOperator.Equal, ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id.ToString());
                        query.ColumnSet = custPaymentDetItemCols;
                        ec = service.RetrieveMultiple(query);
                        decimal collectionAmount = 0;
                        decimal depositionAmount = 0;
                        decimal clearanceAmount = 0;

                        for (int i = 0; i < ec.Entities.Count; i++)
                        {
                            if (ec.Entities[i] != null)
                            {
                                if (ec.Entities[i].Attributes.Contains("ber_depositiondate"))
                                {
                                    if (ec.Entities[i]["ber_depositiondate"] != null)
                                    {
                                        depositionAmount = depositionAmount + ((Money)ec.Entities[i]["ber_amount"]).Value;
                                    }
                                }
                                if (ec.Entities[i].Attributes.Contains("ber_collectiondate"))
                                {
                                    if (ec.Entities[i]["ber_collectiondate"] != null)
                                    {
                                        collectionAmount = collectionAmount + ((Money)ec.Entities[i]["ber_amount"]).Value;
                                    }
                                }

                                if (ec.Entities[i].Attributes.Contains("ber_clearancedate"))
                                {
                                    if (ec.Entities[i]["ber_clearancedate"] != null)
                                    {
                                        clearanceAmount = clearanceAmount + ((Money)ec.Entities[i]["ber_amount"]).Value;
                                    }
                                }


                            }
                        }
                        //Calculate Pending Amount
                        //Find Net Amount
                        decimal NetAmount = 0;
                        decimal pendingAmount = 0;
                        ColumnSet custPaymentDetCols = new ColumnSet();
                        custPaymentDetCols.AddColumn("ber_netamount");                 

                        Entity entityEstimateDetails = new Entity();

                        entityEstimateDetails = service.Retrieve("ber_estimatedetails", ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id, custPaymentDetCols);
                        if (entityEstimateDetails.Attributes.Contains("ber_netamount"))
                        {
                            if (entityEstimateDetails.Attributes["ber_netamount"] != null)
                            {
                                NetAmount = ((Money)entityEstimateDetails.Attributes["ber_netamount"]).Value;
                            }
                        }


                        ////////////////////////////////////

                        pendingAmount = NetAmount - collectionAmount;

                        Entity UpEstimateDetail = new Entity();
                        UpEstimateDetail.LogicalName = "ber_estimatedetails";
                        UpEstimateDetail.Id = ((EntityReference)targetEntity.Attributes["ber_estimatedetailsid"]).Id;
                        UpEstimateDetail.Attributes["ber_collection"] = new Money(collectionAmount);
                        UpEstimateDetail.Attributes["ber_deposition"] = new Money(depositionAmount);
                        UpEstimateDetail.Attributes["ber_pending"] = new Money(pendingAmount);
                        UpEstimateDetail.Attributes["ber_clearedamount"] = new Money(clearanceAmount);
                        UpEstimateDetail.Attributes["ber_notcleared"] = new Money(collectionAmount - clearanceAmount);

                        service.Update(UpEstimateDetail);
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("CustPaymentDetailItem", "Execute", "Error on Create/Update of Payment Detail Item.",ex.Message.ToString());
            }
            finally
            { }
        }

    }
}