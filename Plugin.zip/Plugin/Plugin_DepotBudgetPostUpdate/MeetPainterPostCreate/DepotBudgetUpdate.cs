﻿

// Microsoft Dynamics CRM namespace(s)

[assembly: System.CLSCompliant(true)]

namespace DepotBudgetPostUpdate
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.IO;
    using System.Text;
    using System.Xml;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Win32;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Query;
    using Microsoft.Xrm.Sdk.Messages;

    /// <summary>
    /// Class Meet painter create meet planning update
    /// </summary>
    public class DepotBudgetUpdate : IPlugin
    {

       /// <summary>
       /// Declare config
       /// </summary>
        private static System.Configuration.Configuration config; 
        /// <summary>
        /// Declare Logger object.
        /// </summary>
        private static PragmasysLogger objLogger;  

                       
        /// <summary>
        /// Plugin main method
        /// </summary>
        /// <param name="serviceProvider">Service provider object</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context =
                (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Get a reference to the organization service.
            IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            // Get a reference to the tracing service.
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

           string organizationName = context.OrganizationName;
           
            /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");
                string db_Path = obj_dbpath.ToString();
                string configpath = db_Path + "\\CRMWeb\\ISV\\" + organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    ////  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        objLogger = new PragmasysLogger(organizationName, loggerPath);
                    }
                }



                if (context.PostEntityImages.Contains("PostImage") && context.PostEntityImages["PostImage"] is Entity)
                {
                    Entity entity = (Entity)context.PostEntityImages["PostImage"];

                    CalculateDepotAmount(entity, service);

                }

                                         


            }


            catch (Exception ex)
            {
                
                objLogger.Log("DepotBudgetUpdate", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Calculates the Depot Amount after adjusting the Redeemed Points Amount from the depotbudget
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="service"></param>
        /// <param name="tracingService"></param>
       public void CalculateDepotAmount(Entity entity,IOrganizationService service)
        {
            decimal totalAmount = 0;
            decimal total = 0;

            if (entity.GetAttributeValue<bool>("ber_firedepotplugin") == true)
            {

                EntityCollection filteredPainterMeetContacts = GetFilteredPainterMeetContacts(entity.Id, service);

                if (filteredPainterMeetContacts.Entities.Count > 0)
                {
                    foreach (var fpc in filteredPainterMeetContacts.Entities)
                    {

                        Money alrsperpoint = (Money)((AliasedValue)fpc.Attributes["ad.ber_rsperpoint"]).Value;
                        decimal rsperpoint = alrsperpoint != null ? alrsperpoint.Value : 0;

                        int limit = (int)((AliasedValue)fpc.Attributes["ad.ber_limitofredeemedpoint"]).Value;
                        int points = (int)((AliasedValue)fpc.Attributes["pointsredeemed"]).Value;
                        if (points != 0 && points >= limit)
                        {
                            total = rsperpoint * points;
                            totalAmount = totalAmount + total;
                        }


                    }

                }

                if (totalAmount > 0)
                {
                    Boolean check = false;
                    Money currentbudget = (Money)entity["ber_bdbudget"];
                    Money deductedAmount = null;//= new Money(currentbudget.Value - totalAmount);
                    Money remainingAmount = null;
                    if (!entity.Contains("ber_remainingdepotbudget"))
                    {
                        deductedAmount = new Money(currentbudget.Value - totalAmount);
                        remainingAmount = currentbudget;

                    }
                    else
                    {

                        deductedAmount = new Money(entity.GetAttributeValue<Money>("ber_remainingdepotbudget").Value - totalAmount);

                        check = true;
                    }
                    // UpdateDepot(entity, totalAmount, service);
                    UpdateDepot(entity.Id, entity.LogicalName, remainingAmount, deductedAmount, totalAmount, check, service);

                }
                else
                {
                    UpdateDepot(entity.Id, entity.LogicalName, service);
                }

               
            }
            


        }
        /// <summary>
        /// Method to update depot record.
        /// </summary>
        /// <param name="depotRef"></param>
        /// <param name="entityName"></param>
        /// <param name="amount"></param>
        /// <param name="service"></param>
        public void UpdateDepot(Guid depotRef, string entityName, Money amount,Money deductedAmt,decimal totamt,Boolean check, IOrganizationService service)
        {
            try
            {
               // decimal d = 1;
                Entity newDepot = new Entity();
                newDepot.Id = depotRef;
                newDepot.LogicalName = entityName;
                if (check != true)
                {
                    newDepot["ber_remainingdepotbudget"] = amount;

                }
                newDepot["ber_redeemedpointsamount"] = new Money(totamt);
                newDepot["ber_bdbudget"] = deductedAmt;
                newDepot["ber_firedepotplugin"] = false;
                service.Update(newDepot);
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "UpdateDepot", ex.Message, ex.StackTrace.ToString());
               
            }
        }


        /// <summary>
        /// Method to update depot record.
        /// </summary>
        /// <param name="depotRef"></param>
        /// <param name="entityName"></param>
        /// <param name="amount"></param>
        /// <param name="service"></param>
        public void UpdateDepot(Guid depotRef, string entityName, IOrganizationService service)
        {
            try
            {             
                Entity newDepot = new Entity();
                newDepot.Id = depotRef;
                newDepot.LogicalName = entityName;
                 newDepot["ber_firedepotplugin"] = false;
                service.Update(newDepot);
            }
            catch (Exception ex)
            {
                objLogger.Log("MeetPainterPostCreate", "UpdateDepot", ex.Message, ex.StackTrace.ToString());

            }
        }

        private static EntityCollection GetFilteredPainterMeetContacts(Guid depotId, IOrganizationService service)
        {
            EntityCollection returnCollection;
            EntityCollection PainterMeetCollections = new EntityCollection();
            int fetchCount = 5000;
            // Initialize the page number.
            int pageNumber = 1;
            // Initialize the number of records.
            int recordCount = 0;
            // Specify the current paging cookie. For retrieving the first page, 
            // pagingCookie should be null.
            string pagingCookie = null;

            string fetch = String.Format(@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='ber_paintermeetcontact'>
                                        <attribute name='createdon' />
                                        <attribute name='ber_contact' />
                                        <attribute name='ber_paintermeet' />
                                        <attribute name='ber_paintermeetcontactid' />
	                                     <attribute name='ber_redeemedpoint' alias='pointsredeemed' />
                                        <order attribute='ber_paintermeet' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statuscode' operator='eq' value='278290001' />
                                          <condition attribute='ber_redeemedpoint' operator='not-null' /> 
                                        </filter>
                                        <link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_paintermeet' alias='aa'>
                                          <attribute name='ber_meet' />
	                                      <attribute name='ber_depot' />
                                         <filter type='and'>
                                            <condition attribute='ber_depot' operator='eq' value='{0}' />
                                          </filter>
                                          <link-entity name='ber_meet' from='ber_meetid' to='ber_meet' alias='ad'>
	                                       <attribute name='ber_rsperpoint'/>
                                           <attribute name='ber_finalpointcalculated' />
                                            <attribute name='ber_limitofredeemedpoint' />  
	                                        <filter type='and'>
                                              <condition attribute='ber_finalpointcalculated' operator='eq' value='1' />
                                              <condition attribute='ber_schemerequired' operator='eq' value='1' />
                                              <condition attribute='ber_type' operator='eq' value='278290002' />
                                              <condition attribute='statecode' operator='eq' value='0' />        
                                              <condition attribute='ber_rsperpoint' operator='not-null' /> 
                                              <condition attribute='ber_limitofredeemedpoint' operator='not-null' /> 
                                           </filter>
                                          </link-entity>
                                        </link-entity>
                                      </entity>
                                    </fetch>", depotId);

            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetch, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)service.Execute(fetchRequest1)).EntityCollection;

                PainterMeetCollections.Entities.AddRange(returnCollection.Entities);
                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;

                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }



            }

            // EntityCollection PainterMeetContactResult = service.RetrieveMultiple(new FetchExpression(String.Format(fetch, depotId)));


            return PainterMeetCollections;

        }

        private static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }


        private static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }

    }
}
