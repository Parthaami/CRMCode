﻿// =====================================================================
// <copyright file="PragmasysLogger.cs" company="Pragmasys Consulting LLP">
//     Custom company copyright tag.
// </copyright>
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================
//// Microsoft Dynamics CRM namespace(s)

namespace DepotBudgetPostUpdate
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Data.SqlClient;
    using System.Diagnostics;
    using System.IO;
    using System.Text;
    using Microsoft.Win32;

    /// <summary>
    /// Class Logger
    /// </summary>
    public class PragmasysLogger
    {
        /// <summary>
        /// Variable to store organization name
        /// </summary>      
        private string organization;

        /// <summary>
        /// Variable to store logger file path
        /// </summary>
        private string filePath;

        /// <summary>
        /// Variable to store logger directory path
        /// </summary>
        private string folderPath = string.Empty;

        /// <summary>
        /// Class logger parameterized constructor
        /// </summary>
        /// <param name="orgnizationName">organization name</param>
        /// <param name="configfilepath">log file oath</param>
        public PragmasysLogger(string orgnizationName, string configfilepath)
        {
            this.organization = orgnizationName;
            this.folderPath = configfilepath;
        }

        /// <summary>
        /// Method Log to write log in text file
        /// </summary>
        /// <param name="sourceName">Log source name</param>
        /// <param name="methodName">Source method name</param>
        /// <param name="description">Log description</param>
        /// <param name="errorMessage">Error</param>
        public void Log(string sourceName, string methodName, string description, string errorMessage)
        {
            try
            {
                this.filePath = this.folderPath + "Log_Plugin_MeetPainterPostCreate_" + this.organization + ".txt";
                string[] errorLogs = { sourceName, methodName, description, errorMessage };
                if (!Directory.Exists(this.folderPath))
                {
                    Directory.CreateDirectory(this.folderPath);
                }

                if (!File.Exists(this.filePath))
                {
                    FileStream objFile = new FileStream(this.filePath, FileMode.Create, FileAccess.Write);
                    objFile.Close();
                    StreamWriter file = new StreamWriter(this.filePath);
                    file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.WriteLine(" S.No.       CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Write("*.");
                    file.Write("\t");
                    file.Write(System.DateTime.Now);
                    file.Write("\t\t");
                    foreach (string log in errorLogs)
                    {
                        file.Write(log);
                        file.Write("\t\t");
                    }

                    file.WriteLine(string.Empty);
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Close();
                }
                else
                {
                    File.AppendAllText(this.filePath, System.Environment.NewLine);
                    File.AppendAllText(this.filePath, "*.");
                    File.AppendAllText(this.filePath, "\t");
                    File.AppendAllText(this.filePath, System.DateTime.Now.ToString());
                    File.AppendAllText(this.filePath, "\t\t");
                    foreach (string log in errorLogs)
                    {
                        File.AppendAllText(this.filePath, log);
                        File.AppendAllText(this.filePath, "\t\t");
                    }

                    File.AppendAllText(this.filePath, System.Environment.NewLine);
                    File.AppendAllText(this.filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
