﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DepotBudgetPostUpdate;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Client;
using System.ServiceModel.Description;
using System.Configuration;
using Microsoft.Xrm.Sdk.Client;

namespace DepotBudgetUpdateTest
{
    [TestClass]
    public class DepotBudgetTest
    {
        IOrganizationService service;
        ITracingService tracingService;
        
        [TestInitialize]
        public void TestInit()
        {
            try
            {
                ClientCredentials credentials = new ClientCredentials();
                credentials.UserName.UserName = ConfigurationManager.AppSettings["username"];
                credentials.UserName.Password = ConfigurationManager.AppSettings["userpassword"];
                string SoapOrgServiceUri = ConfigurationManager.AppSettings["orgservurl"];
                Uri serviceUri = new Uri(SoapOrgServiceUri);
                OrganizationServiceProxy proxy = new OrganizationServiceProxy(serviceUri, null, credentials, null);
                proxy.EnableProxyTypes();
                service = (IOrganizationService)proxy;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

  

        [TestMethod]
        public void matchingDepotRecords()
        {

            DepotBudgetUpdate ds = new DepotBudgetUpdate();
            Entity eny = new Entity()
            {
                Id = Guid.Parse("D267ED5D-5EA9-E411-8A64-5CF3FC98C7B8"),
                LogicalName = "ber_depot"

            };
            eny["ber_firedepotplugin"] = true;
            eny["ber_bdbudget"] = new Money(50000);
            ds.CalculateDepotAmount(eny, service);
        }


        //[TestMethod]
        //public void matchingDepotRecords()
        //{

        //    DepotBudgetUpdate ds = new DepotBudgetUpdate();
        //    Entity eny = new Entity()
        //    {
        //        Id = Guid.Parse("D267ED5D-5EA9-E411-8A64-5CF3FC98C7B8"),
        //        LogicalName = "ber_depot"

        //    };
        //    eny["ber_firedepotplugin"] = true;
        //    eny["ber_bdbudget"] = new Money(50000);
        //    ds.CalculateDepotAmount(eny, service);
        //}
    }
}
