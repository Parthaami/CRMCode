﻿// =====================================================================
//  This Plugin is used to hide views from specified entities.
//  The target views of any entity that we are going to hide is passed as input
//  argument to this plugin in Non-Secure Configuration from registration tool.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Query;

namespace PluginHideSystemViews
{
    public class HideViews : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Dictionary<int, StringCollection> _hideViews;
        public static string oConfig = string.Empty;
        public static Logger oLogger;
        string Loggerpath = string.Empty;
        public static string _organizationName = string.Empty;
        /// <summary>
        /// A plugin Template that is get data fro configuration file present in CRMWeb\ISV folder
        /// And if it thorws any Error it write in LogFile by default in CRMWeb\ISV folder
        /// It checks also if non secure data present it get all data in Dictionary
        /// </summary>
        /// <remarks>Register this plug-in 
        /// and pre-event stage.
        /// </remarks>

        public HideViews(string Config)
        {
            oConfig = Config;
        }


        /// <summary>
        /// getNonSecureConfigData fetch data from Non Secure Field if Present        
        /// </summary>      
        public void getNonSecuredConfigData()
        {
            try
            {             
                _hideViews = new Dictionary<int, StringCollection>();
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(oConfig);

                foreach (XmlElement entityNode in doc.SelectNodes("/entities/entity"))
                    {
                        StringCollection sc = new StringCollection();
                        foreach (XmlNode viewNode in entityNode.ChildNodes)
                            sc.Add(viewNode.InnerText);
                        string sOTC = entityNode.GetAttribute("otc");
                        if (!String.IsNullOrEmpty(sOTC))
                        {
                            int otc = 0;
                            int.TryParse(sOTC, out otc);
                            if (otc != 0)
                                _hideViews.Add(otc, sc);
                        }
                    }
                
            }
            catch (Exception ex)
            {
                //Log the Error Entry in Log Table.
                oLogger.Log("PluginHideSystemViews", "getNonSecuredConfigData", ex.Message, ex.StackTrace.ToString());
            }
        }

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService Iservice = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                _organizationName = context.OrganizationName;
                Guid userId = context.InitiatingUserId;

                #region Code to access Config File and read Configuration Values
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");
                string DB_path = obj_dbpath.ToString();
                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        Loggerpath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        //Use Logger to Log Error Entry in ErrorLog Table.
                        //pass Log folder path Where want to put Logfile; By Default it is in CRMWeb\ISV folder
                        oLogger = new Logger(_organizationName, Loggerpath);
                    }
                }
                #endregion


                //This Methods checks for non Secure Data if Present 
                //it adds non secure data in a Dictionary Compare Data 
                //with this dictionary is it present in it or not
                getNonSecuredConfigData();
                
                
                if (!(context.MessageName == "RetrieveMultiple" && context.PrimaryEntityName == "savedquery" && context.InputParameters.Contains("Query") && context.OutputParameters.Contains("BusinessEntityCollection")))
                    return;
                QueryExpression qe = context.InputParameters["Query"] as QueryExpression;
                if (qe == null)  // Check it's a QueryExpression
                    return;

                ConditionExpression cond = GetCondition(qe.Criteria, "returnedtypecode");
                if (!(cond != null && cond.Operator == ConditionOperator.Equal && cond.Values.Count == 1 && cond.Values[0] is int))       // Check there is an equiality condition on returnedtypecode for an integer value
                    return;
                int otc = (int)cond.Values[0];
                if (!_hideViews.ContainsKey(otc))       // Check that we want to exclude views for this entity
                    return;
                EntityCollection becViews = (EntityCollection)context.OutputParameters["BusinessEntityCollection"];
                if (!(becViews != null && becViews.EntityName == "savedquery"))  // Check there are some views, and they are the right type
                    return;
                StringCollection scHide = _hideViews[otc];

                for (int i = becViews.Entities.Count - 1; i >= 0; i--)      // Iterate backwards, as items may be removed
                {
                    Entity de = (Entity)becViews.Entities[i]; // BusinessEntityCollection is of type DynamicEntity                
                    
                    if (de.Attributes.Contains("name") && scHide.Contains((string)de.Attributes["name"]))
                            becViews.Entities.RemoveAt(i);
                    else
                    {
                        if(de.Attributes.Contains("name") && scHide.Contains((string)de.Attributes["name"]))
                            becViews.Entities.RemoveAt(i);
                    }

                }
            }
            catch (Exception ex)
            {
                // Handle the exception.
                //Log the Error Entry in Log Table.
                oLogger.Log("PluginHideSystemViews", "Excitation.PluginHideSystemViews.Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
        private ConditionExpression GetCondition(FilterExpression Filter, string Attribute)
        {
            ConditionExpression ret = null;
            if (Filter != null && Filter.Conditions != null)
                for (int i = 0; i < Filter.Conditions.Count; i++)
                {
                    ConditionExpression cond = (ConditionExpression)Filter.Conditions[i];
                    if (cond.AttributeName == Attribute)
                    {
                        ret = cond;
                        break;
                    }
                }
            return ret;
        }
    }
}
