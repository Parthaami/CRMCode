﻿//This class contains required methods for Create Meet Painter class.

using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Xml;

namespace CreateMeetPainters
{
    class FetchData
    {
        /// <summary>
        /// Function to Share Record
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="assigneeUser">Assigned to user reference</param>
        /// <param name="entityName">Entity name which is assigned to user</param>
        /// <param name="entityId">Entity record unique id</param>        
        public static void ShareRecord(IOrganizationService crmService, EntityReference assigneeUser, string entityName, Guid entityId)
        {
            try
            {
                GrantAccessRequest shareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ReadAccess | AccessRights.WriteAccess | AccessRights.AppendAccess | AccessRights.AppendToAccess | AccessRights.ShareAccess,
                        Principal = assigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };

                crmService.Execute(shareRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Function to Retrieve Meet Planning of Uploading Painter.
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="uploadPainterId">Uploaded painter record unique id</param>
        /// <returns>Meet planning record</returns>
        public static Entity RetrieveMeetPlanning(IOrganizationService crmService, Guid uploadPainterId)
        {
            Entity meetPlanning = new Entity();
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='ber_paintermeet'>");
                query.Append("<attribute name='ber_name' />");
                query.Append("<attribute name='ber_depot' />");
                query.Append("<attribute name='ber_dealer' />");
                query.Append("<attribute name='ber_paintermeetid' />");
                query.Append("<attribute name='ownerid' />");
                query.Append("<attribute name='ber_meet' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("</filter>");
                query.Append("<link-entity name='ber_painterupload' from='ber_meetplanningid' to='ber_paintermeetid' alias='aa'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_painteruploadid' operator='eq' uitype='ber_painterupload' value='" + uploadPainterId + "' />");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("<link-entity name='ber_depot' from='ber_depotid' to='ber_depot' visible='false' link-type='outer' alias='depot_user'>");
                query.Append("<attribute name='ber_depotuser' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                if (result.Entities.Count > 0)
                {
                    meetPlanning = result.Entities[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return meetPlanning;
        }

        /// <summary>
        /// Function to get painter based on painter contact number
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="contactNumber">Painter contact number</param>
        /// <returns>Painter record</returns>        
        public static Guid GetPainter(IOrganizationService crmService, string contactNumber)
        {
            Guid contactId = Guid.Empty;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='contact'>");
                query.Append("<attribute name='fullname' />");
                query.Append("<attribute name='contactid' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<condition attribute='ber_customertype' operator='eq' value='278290001' />");
                query.Append("<condition attribute='mobilephone' operator='eq' value='" + contactNumber + "' />");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                if (result.Entities.Count > 0)
                {
                    contactId = result.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return contactId;
        }

        /// <summary>
        /// Function to get Dealer Details
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="dealerId">Dealer unique id</param>
        /// <returns>Dealer Record</returns>        
        public static Entity GetDealerDetails(IOrganizationService crmService, Guid dealerId)
        {
            Entity dealer = new Entity();
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='account'>");
                query.Append("<attribute name='name' />");
                query.Append("<attribute name='accountnumber' />");
                query.Append("<attribute name='ber_depotid' />");
                query.Append("<attribute name='accountid' />");
                query.Append("<attribute name='ber_region' />");
                query.Append("<attribute name='ber_preferredlanguage2' />");
                query.Append("<attribute name='ber_preferredlanguage1' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='accountid' operator='eq' uitype='account' value='" + dealerId + "' />");
                query.Append("</filter>");
                query.Append("<link-entity name='account' from='accountid' to='parentaccountid' visible='false' link-type='outer' alias='acc'>");
                query.Append("<attribute name='accountnumber' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                if (result.Entities.Count > 0)
                {
                    dealer = result.Entities[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return dealer;
        }

        /// <summary>
        /// Method to get user roles
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="userId">User unique id</param>
        /// <returns>Returns true if user has system administrator role</returns> 
        public static bool IsUserAdministrator(IOrganizationService crmService, Guid userId)
        {
            bool isUserAdmin = false;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='role'>");
                query.Append("<attribute name='name' />");
                query.Append("<link-entity name='systemuserroles' from='roleid' to='roleid'>");
                query.Append("<filter>");
                query.Append("<condition attribute='systemuserid' operator='eq' value='" + userId + "' />");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                foreach (Entity roles in result.Entities)
                {
                    if (roles.Attributes.Contains("name") && roles["name"].ToString() == "System Administrator")
                    {
                        isUserAdmin = true;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return isUserAdmin;
        }

        /// <summary>
        /// Method to verify the painter is present in existing meet painter record or not
        /// </summary>
        /// <param name="crmService">CRM Service object</param>
        /// <param name="painterId">Painter unique id</param>
        /// <param name="meetPlanningId">Meet planning unique id</param>
        /// <returns>Boolean value</returns>
        public static bool IsMeetPainterExist(IOrganizationService crmService, Guid painterId, Guid meetPlanningId)
        {
            try
            {
                bool isMeetPainterAlreadyExist = false;

                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='ber_paintermeetcontact'>");
                query.Append("<attribute name='createdon' />");
                query.Append("<attribute name='ber_contact' />");
                query.Append("<attribute name='ber_paintermeet' />");
                query.Append("<attribute name='ber_paintermeetcontactid' />");
                query.Append("<order attribute='ber_paintermeet' descending='false' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_contact' operator='eq' uitype='contact' value='" + painterId + "' />");
                query.Append("<condition attribute='ber_paintermeet' operator='eq' uitype='ber_paintermeet' value='" + meetPlanningId + "' />");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                if (result.Entities.Count > 0)
                {
                    isMeetPainterAlreadyExist = true;
                }

                return isMeetPainterAlreadyExist;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method to get upload painter meet planning meet details
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="painterUploadID">Upload painter unique id</param>
        /// <returns>Meet entity record</returns>
        public static Entity GetMeetConfigDetails(IOrganizationService crmService, Guid painterUploadID)
        {
            try
            {
                Entity meetDetails = new Entity();
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='ber_painterupload'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_painteruploadid' operator='eq' value='" + painterUploadID + "'/>");
                query.Append("</filter>");
                query.Append("<link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_meetplanningid' link-type='inner'>");
                query.Append("<link-entity name='ber_meet' from='ber_meetid' to='ber_meet' alias='meetconfig' link-type='inner'>");
                query.Append("<attribute name='ber_schemerequired'/>");
                query.Append("<attribute name='ber_type'/>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection result = Retrieve(crmService, query.ToString());
                if (result.Entities.Count > 0)
                {
                    meetDetails = result.Entities[0];
                }
                return meetDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method to get upload painter inclusion details.
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="painterUploadId">upload painter record unique id</param>
        /// <returns>Inclusion criteria collection</returns>
        public static EntityCollection GetUploadPainterInclusionDetails(IOrganizationService crmService, Guid painterUploadId, string schemeReq, string meetType)
        {
            try
            {
                EntityCollection result = null;
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='ber_painterupload'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_painteruploadid' operator='eq' value='" + painterUploadId + "'/>");
                query.Append("</filter>");
                query.Append("<link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_meetplanningid' alias='meetplanning' link-type='inner'>");
                query.Append("<link-entity name='ber_meet' from='ber_meetid' to='ber_meet' alias='meetconfig' link-type='inner'>");
                query.Append("<link-entity name='ber_meetinclusioncriteria' from='ber_meettype' to='ber_type' alias='meettype' link-type='inner'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_meettype' operator='eq' value='" + meetType + "'/>");
                query.Append("<condition attribute='ber_schemerequired' operator='eq' value='" + schemeReq + "'/>");
                query.Append("</filter>");
                query.Append("<link-entity name='ber_meetexclusioncriteria' from='ber_meetinclusioncriteriaid' to='ber_meetinclusioncriteriaid' alias='meetexclusion' link-type='inner'>");
                query.Append("<attribute name='ber_meettype'/>");
                query.Append("<attribute name='ber_schemerequired'/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='ber_meettype' operator='not-null'/>");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                return result = Retrieve(crmService, query.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Method to get painter existing meet planning inclusion details
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="painterId">Painter unique id</param>
        /// <returns>Painter meet planning details</returns>
        public static EntityCollection GetPaintersExistingMeetPlanningDetails(IOrganizationService crmService, Guid painterId)
        {
            try
            {
                EntityCollection result = null;
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='ber_paintermeetcontact'>");
                query.Append("<link-entity name='ber_paintermeet' from='ber_paintermeetid' to='ber_paintermeet' alias='meetplanning' link-type='inner'>");
                query.Append("<attribute name='ber_name'/>");
                query.Append("<link-entity name='ber_meet' from='ber_meetid' to='ber_meet' alias='meetconfig' link-type='inner'>");
                query.Append("<attribute name='ber_schemerequired'/>");
                query.Append("<attribute name='ber_type'/>");
                query.Append("<attribute name='ber_name'/>");
                query.Append("</link-entity>");
                query.Append("<link-entity name='ber_depot' from='ber_depotid' to='ber_depot' alias='meetdepot' link-type='inner'>");
                query.Append("<attribute name='ber_name'/>");
                query.Append("</link-entity>");
                query.Append("</link-entity>");
                query.Append("<link-entity name='contact' from='contactid' to='ber_contact' alias='painter' link-type='inner'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='contactid' operator='eq' value='" + painterId + "'/>");
                query.Append("</filter>");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                return result = Retrieve(crmService, query.ToString());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Function to Retrieve Data from Fetch XMl
        /// </summary>
        /// <param name="crmService">Organization service object</param>
        /// <param name="strFetchXML">Fetch xml</param>
        /// <returns>Result collection</returns>
        private static EntityCollection Retrieve(IOrganizationService crmService, string strFetchXML)
        {
            RetrieveMultipleResponse objResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)crmService.Execute(fetch);

                RetrieveMultipleRequest objRequest = new RetrieveMultipleRequest();
                objRequest.Query = qe.Query;

                objResponse = (RetrieveMultipleResponse)crmService.Execute(objRequest);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objResponse.EntityCollection;
        }
        /// <summary>
        /// Get configuration from unsecured config
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="label"></param>
        /// <returns></returns>
        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }

    }
}
