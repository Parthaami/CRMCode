﻿// =====================================================================
//  This plugin is executed on Painter Upload entity record creation event.
//  In Painter Meet while uploading enrolled painters in specified Meet Plaining
//  this plugin checks painter enrollment criterial mentioned in Inclusion Entity
//  and based on that if painter fulfills all criteria it will creates Meet Painter Record
//  else update remark on Painter Upload record.
//
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================

using System;
using System.Xml;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using System.Data;

namespace CreateMeetPainters
{
    public class CreateMeetPainters : IPlugin
    {
        private XmlDocument _pluginConfiguration;
        public CreateMeetPainters(string unsecureConfig, string secureConfig)
        {
            if (string.IsNullOrEmpty(unsecureConfig))
            {
                throw new InvalidPluginExecutionException("Unsecure configuration missing.");
            }
            _pluginConfiguration = new XmlDocument();
            _pluginConfiguration.LoadXml(unsecureConfig);
        }
        /// <summary>
        /// Configuration object
        /// </summary>
        private static Configuration config;

        /// <summary>
        /// Logger class object
        /// </summary>
        private static Logger objLogger;

        /// <summary>
        /// Method to create painter contact record
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="uploadPainter">Entity upload painter record</param>
        public static void CreatePainterContact(IOrganizationService crmService, Entity uploadPainter)
        {
            try
            {
                Entity painterContact = new Entity("contact");

                ////Set Painter as Customer Type.
                painterContact["ber_customertype"] = new OptionSetValue(278290001);

                if (uploadPainter.Attributes.Contains("ber_firstname"))
                {
                    painterContact["firstname"] = uploadPainter["ber_firstname"].ToString();
                }

                if (uploadPainter.Attributes.Contains("ber_lastname"))
                {
                    painterContact["lastname"] = uploadPainter["ber_lastname"].ToString();
                }

                if (uploadPainter.Attributes.Contains("ber_contactnumber"))
                {
                    painterContact["mobilephone"] = uploadPainter["ber_contactnumber"].ToString();
                }

                Entity meetPlaining = FetchData.RetrieveMeetPlanning(crmService, uploadPainter.Id);
                ////Guid depotId = Guid.Empty;

                if (meetPlaining.Attributes.Contains("ber_depot"))
                {
                    painterContact["ber_depotid"] = (EntityReference)meetPlaining["ber_depot"];
                }

                if (meetPlaining.Attributes.Contains("ber_dealer"))
                {
                    painterContact["ber_dealerid"] = (EntityReference)meetPlaining["ber_dealer"];

                    Entity entDealer = FetchData.GetDealerDetails(crmService, ((EntityReference)meetPlaining["ber_dealer"]).Id);

                    if (entDealer.Attributes.Contains("ber_region"))
                    {
                        painterContact["ber_regionid"] = entDealer["ber_region"];
                    }

                    if (entDealer.Attributes.Contains("ber_preferredlanguage1"))
                    {
                        painterContact["ber_preferredlanguage1"] = entDealer["ber_preferredlanguage1"];
                    }

                    if (entDealer.Attributes.Contains("ber_preferredlanguage2"))
                    {
                        painterContact["ber_preferredlanguage2"] = entDealer["ber_preferredlanguage2"];
                    }
                }

                ////Create new painter contact.
                Guid painterContactId = crmService.Create(painterContact);

                ////Create Meet Painters.
                CreateMeetPainter(crmService, painterContactId, meetPlaining.Id);
            }
            catch (InvalidCastException fex)
            {
                objLogger.Log("PluginCreateMeetPainters", "Execute", fex.Message, fex.StackTrace.ToString());
            }
            catch (Exception ex)
            {
                objLogger.Log("PluginCreateMeetPainters", "CreatePainterContact", "Error Creating Painter Contact", ex.Message.ToString());
            }
        }

        /// <summary>
        /// Method to create meet painter record
        /// </summary>
        /// <param name="crmService">CRM service object</param>
        /// <param name="painterId">Painter unique id</param>
        /// <param name="meetId">Meet unique id</param>
        public static void CreateMeetPainter(IOrganizationService crmService, Guid painterId, Guid meetId)
        {
            try
            {
                Entity meetPainter = new Entity("ber_paintermeetcontact");

                meetPainter["ber_contact"] = new EntityReference("contact", painterId);
                meetPainter["ber_paintermeet"] = new EntityReference("ber_paintermeet", meetId);

                crmService.Create(meetPainter);
            }
            catch (InvalidCastException fex)
            {
                objLogger.Log("PluginCreateMeetPainters", "Execute", fex.Message, fex.StackTrace.ToString());
            }
            catch (Exception ex)
            {
                objLogger.Log("PluginCreateMeetPainters", "CreateMeetPainter", "Error Creating Meet Painter", ex.Message.ToString());
            }
        }

        /// <summary>
        /// Plugin main method
        /// </summary>
        /// <param name="serviceProvider">IService provider object</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                string _organizationName = context.OrganizationName;
                ////Guid callingUserId = context.UserId;
                ////string primaryEntityName = context.PrimaryEntityName;
                ////Guid primaryEntityId = context.PrimaryEntityId;

                #region To Read Config File
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */

                //string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                //ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                //if (File.Exists(configpath))
                //{
                //    //  Get configration data     
                //    fileMap.ExeConfigFilename = configpath;
                //    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                //    if (config.AppSettings.Settings.Count > 0)
                //    {
                //        //string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                //        //oLogger = new Logger(_organizationName, _loggerPath);
                //        SQLConnStr = config.ConnectionStrings.ConnectionStrings["Bergersqldbconnection"].ConnectionString.ToString();
                //        tracingService.Trace("SQLConnStr: " + SQLConnStr);
                //    }
                //}

                string _loggerPath = FetchData.GetConfigDataString(_pluginConfiguration, "Loggerpath");
                objLogger = new Logger(_organizationName, _loggerPath);
                #endregion

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    Entity uploadPainterEntity = (Entity)context.InputParameters["Target"];
                    if (uploadPainterEntity.Attributes.Contains("ber_contactnumber") && uploadPainterEntity.Attributes.Contains("createdby"))
                    {
                        EntityReference uploadPainterCreatedby = (EntityReference)uploadPainterEntity["createdby"];
                        string painterContactNumber = uploadPainterEntity["ber_contactnumber"].ToString();

                        Guid painterId = FetchData.GetPainter(service, painterContactNumber);

                        ////If Upload Painter is Existing Painter Number
                        if (painterId != Guid.Empty)
                        {
                            Entity eMeetConfig = FetchData.GetMeetConfigDetails(service, uploadPainterEntity.Id);

                            if (eMeetConfig.Attributes.Contains("meetconfig.ber_schemerequired") && eMeetConfig.Attributes.Contains("meetconfig.ber_type"))
                            {
                                EntityCollection uploadPainterInclusionDtls = FetchData.GetUploadPainterInclusionDetails(service, uploadPainterEntity.Id, ((AliasedValue)eMeetConfig["meetconfig.ber_schemerequired"]).Value.ToString(), ((OptionSetValue)((AliasedValue)eMeetConfig["meetconfig.ber_type"]).Value).Value.ToString());
                                EntityCollection painterExistingMeetplanningDtls = FetchData.GetPaintersExistingMeetPlanningDetails(service, painterId);

                                if (painterExistingMeetplanningDtls.Entities.Count > 0 && uploadPainterInclusionDtls.Entities.Count > 0)
                                {
                                    foreach (Entity checkPainterExistingMeetPlanning in painterExistingMeetplanningDtls.Entities)
                                    {
                                        if (checkPainterExistingMeetPlanning.Attributes.Contains("meetconfig.ber_type") && checkPainterExistingMeetPlanning.Attributes.Contains("meetconfig.ber_schemerequired"))
                                        {
                                            int existingMeetType = ((OptionSetValue)((AliasedValue)checkPainterExistingMeetPlanning["meetconfig.ber_type"]).Value).Value;
                                            bool existingSchemeRequired = Convert.ToBoolean(((AliasedValue)checkPainterExistingMeetPlanning["meetconfig.ber_schemerequired"]).Value);

                                            foreach (Entity checkUploadPainterExclusionExist in uploadPainterInclusionDtls.Entities)
                                            {
                                                if (checkUploadPainterExclusionExist.Attributes.Contains("meetexclusion.ber_meettype") && checkUploadPainterExclusionExist.Attributes.Contains("meetexclusion.ber_schemerequired"))
                                                {
                                                    int meetType = ((OptionSetValue)((AliasedValue)checkUploadPainterExclusionExist["meetexclusion.ber_meettype"]).Value).Value;
                                                    bool schemeRequired = Convert.ToBoolean(((AliasedValue)checkUploadPainterExclusionExist["meetexclusion.ber_schemerequired"]).Value);

                                                    if (existingMeetType == meetType && existingSchemeRequired == schemeRequired)
                                                    {
                                                        tracingService.Trace("Painter already active in");
                                                        Entity updateRemark = new Entity("ber_painterupload");
                                                        updateRemark.Id = uploadPainterEntity.Id;
                                                        updateRemark["ber_remarks"] = "Painter already active in:- " + ((AliasedValue)checkPainterExistingMeetPlanning["meetplanning.ber_name"]).Value.ToString() + " running at " + ((AliasedValue)checkPainterExistingMeetPlanning["meetdepot.ber_name"]).Value.ToString() + ".";
                                                        service.Update(updateRemark);
                                                        return;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            //// if Painter is Existing but he/she is not involved in any existing Meet Painter. Create Meet Painter Record.
                            Entity meetPlaining = FetchData.RetrieveMeetPlanning(service, uploadPainterEntity.Id);

                            if (FetchData.IsUserAdministrator(service, uploadPainterCreatedby.Id) || (meetPlaining.Attributes.Contains("depot_user.ber_depotuser") &&
                                 ((EntityReference)((AliasedValue)meetPlaining["depot_user.ber_depotuser"]).Value).Id == uploadPainterCreatedby.Id))
                            {
                                ////Verify that the painter is already exist in same meet plainning or not
                                if (FetchData.IsMeetPainterExist(service, painterId, meetPlaining.Id))
                                {
                                    Entity updateRemark = new Entity("ber_painterupload");
                                    updateRemark.Id = uploadPainterEntity.Id;
                                    updateRemark["ber_remarks"] = "Painter is already present in this meet planning.";
                                    service.Update(updateRemark);
                                }
                                else
                                {
                                    if (meetPlaining.Attributes.Contains("depot_user.ber_depotuser"))
                                    {
                                        ////share Record with owner of Meet Planning
                                        FetchData.ShareRecord(service, new EntityReference("systemuser", ((EntityReference)((AliasedValue)meetPlaining["depot_user.ber_depotuser"]).Value).Id), "contact", painterId);
                                    }
                                    tracingService.Trace(meetPlaining.Id.ToString());
                                    CreateMeetPainter(service, painterId, meetPlaining.Id);
                                    service.Delete("ber_painterupload", uploadPainterEntity.Id);
                                }
                            }
                            else
                            {
                                Entity updateRemark = new Entity("ber_painterupload");
                                updateRemark.Id = uploadPainterEntity.Id;
                                updateRemark["ber_remarks"] = "Error: You are not authorized to upload painter in this Painter Meet.";
                                service.Update(updateRemark);
                            }
                        }
                        else if (painterId == Guid.Empty)
                        {
                            //// if Painter is Existing but he/she is not involved in any existing Meet Painter. Create Meet Painter Record.
                            Entity meetPlaining = FetchData.RetrieveMeetPlanning(service, uploadPainterEntity.Id);

                            if (FetchData.IsUserAdministrator(service, uploadPainterCreatedby.Id) || (meetPlaining.Attributes.Contains("depot_user.ber_depotuser") &&
                                   ((EntityReference)((AliasedValue)meetPlaining["depot_user.ber_depotuser"]).Value).Id == uploadPainterCreatedby.Id))
                            {
                                //// If Upload Painter is New Painter Create Contact for this Painter and Create Meet Painter Record.
                                //// Create New Painter in CRM. 
                                CreatePainterContact(service, uploadPainterEntity);

                                //// Delete Upload Painter Record.
                                service.Delete("ber_painterupload", uploadPainterEntity.Id);
                            }
                            else
                            {
                                Entity updateRemark = new Entity("ber_painterupload");
                                updateRemark.Id = uploadPainterEntity.Id;
                                updateRemark["ber_remarks"] = "Error: You are not authorized to upload painter in this Painter Meet.";
                                service.Update(updateRemark);
                            }
                        }
                    }
                }
            }
            catch (InvalidCastException fex)
            {
                objLogger.Log("PluginCreateMeetPainters", "Execute", fex.Message, fex.StackTrace.ToString());
            }
            catch (Exception ex)
            {
                objLogger.Log("PluginCreateMeetPainters", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }
    }
}
