﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Linq;
using System.Text;
//CRM SDK Namespace
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace ContactDuplicateDetection
{
    public class Class1 : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
             IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = (IOrganizationService)serviceFactory.CreateOrganizationService(context.UserId);
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity entity = (Entity)context.InputParameters["Target"];
                var MobileNumber = entity.GetAttributeValue<string>("mobilephone");

                QueryExpression Contact = new QueryExpression { EntityName = entity.LogicalName, ColumnSet = new ColumnSet("mobilephone") };
                Contact.Criteria.AddCondition("mobilephone", ConditionOperator.Equal, MobileNumber);
                Contact.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
                Contact.Criteria.AddCondition("ber_customertype", ConditionOperator.In, 278290005, 278290002, 278290003, 278290010, 278290011, 278290006, 278290007, 278290008, 278290009, 278290001);
              //  Contact.Criteria.AddCondition("ber_customertype", ConditionOperator.Equal, 278290001);

                EntityCollection RetrieveContact = service.RetrieveMultiple(Contact);

                if (RetrieveContact.Entities.Count > 1)
                {
                    throw new InvalidPluginExecutionException("Following Record with Same Number Exists");

                }
                else if (RetrieveContact.Entities.Count == 0)
                {
                    return;
                }

            }

        }

    }
}
