﻿//=============================================================================
//  This plugin is used to set FROM and TO inventory locations on Stock Transfer Entity.
//  Dependiing on Transfer type it sets FROM/TO values accordingly.
//
//
//  Copyright @ Pragmasys Consulting LLP.
//=============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Win32;
using System.Configuration;
using System.IO;


namespace SetStockTransferInventoryLocations
{
    public class SetSTInvLocations : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static Logger oLogger;

        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {

                IPluginExecutionContext context = (IPluginExecutionContext)
                    serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)
                    serviceProvider.GetService(typeof(IOrganizationServiceFactory));

                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                string _organizationName = context.OrganizationName;
                Guid CallingUserId = context.UserId;
                string PrimaryEntityName = context.PrimaryEntityName;
                Guid PrimaryEntityId = context.PrimaryEntityId;

                #region To Read Config File
                /*

                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string DB_path = obj_dbpath.ToString();

                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);
                    }
                }
                #endregion

                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {
                    // Obtain the target business entity from the input parameters.
                    Entity entity = (Entity)context.InputParameters["Target"];

                    // Verify that the entity represents a Stock Transfer.
                    if (entity.LogicalName != "ber_stocktransfer") { return; }

                    #region If Stock Transfer is for Installation Request
                    if (entity.Attributes.Contains("ber_installationrequestid"))
                    {
                        EntityReference BookingRequest = (EntityReference)entity["ber_installationrequestid"];

                        Entity BookingRequestEntity = RetrieveBookingRequest(service, BookingRequest.Id)[0];


                        if (BookingRequestEntity.Attributes.Contains("ber_depotinventorylocation") && BookingRequestEntity.Attributes.Contains("ber_dealerinventorylocation"))
                        {
                            Guid DepotInventoryLocationId = ((EntityReference)BookingRequestEntity["ber_depotinventorylocation"]).Id;
                            Guid DealerInventoryLocationId = ((EntityReference)BookingRequestEntity["ber_dealerinventorylocation"]).Id;
                            Entity UserEntity = RetrieveUserInventoryLocation(service, context.UserId)[0];

                            if (UserEntity.Attributes.Contains("ber_inventorylocation"))
                            {
                                Guid UserInventoryLocationId = ((EntityReference)UserEntity["ber_inventorylocation"]).Id;
                                entity["ber_from"] = new EntityReference()
                                {
                                    LogicalName = "ber_inventorylocation",
                                    Id = UserInventoryLocationId
                                };

                                if (UserInventoryLocationId == DepotInventoryLocationId)
                                {
                                    entity["ber_to"] = new EntityReference()
                                    {
                                        LogicalName = "ber_inventorylocation",
                                        Id = DealerInventoryLocationId
                                    };
                                }
                                else
                                {
                                    entity["ber_to"] = new EntityReference()
                                    {
                                        LogicalName = "ber_inventorylocation",
                                        Id = DepotInventoryLocationId
                                    };
                                }
                            }
                        }
                    }
                    #endregion
                    #region Stock Transfer is for Scheme.
                    else if (entity.Attributes.Contains("ber_schemeid") && ((OptionSetValue)entity["ber_type"]).Value == 278290001)
                    {
                        Entity UserEntity = RetrieveUserInventoryLocation(service, context.UserId)[0];

                        if (UserEntity.Attributes.Contains("ber_inventorylocation"))
                        {
                            Guid UserInventoryLocationId = ((EntityReference)UserEntity["ber_inventorylocation"]).Id;
                            entity["ber_from"] = new EntityReference()
                            {
                                LogicalName = "ber_inventorylocation",
                                Id = UserInventoryLocationId
                            };
                        }
                    }
                    #endregion
                    #region Stock Transfer is Adjustment type
                    else
                    {
                        Entity UserEntity = RetrieveUserInventoryLocation(service, context.UserId)[0];

                        if (UserEntity.Attributes.Contains("ber_inventorylocation"))
                        {
                            Guid UserInventoryLocationId = ((EntityReference)UserEntity["ber_inventorylocation"]).Id;
                           
                            //If Transfer type is Adjustment and Adjustment Reason is Receipt From Vendor.
                            if (((OptionSetValue)entity["ber_type"]).Value == 278290000 && ((OptionSetValue)entity["ber_adjustmentreason"]).Value == 278290002)
                            {
                                entity["ber_to"] = new EntityReference()
                                {
                                    LogicalName = "ber_inventorylocation",
                                    Id = UserInventoryLocationId
                                };
                            }
                            //If Transfer type is Adjustment and Adjustment Reason is Short Receipts.
                            else if (((OptionSetValue)entity["ber_type"]).Value == 278290000 && ((OptionSetValue)entity["ber_adjustmentreason"]).Value == 278290001)
                            {
                                entity["ber_from"] = new EntityReference()
                                {
                                    LogicalName = "ber_inventorylocation",
                                    Id = UserInventoryLocationId
                                };
                            }
                            //If Transfer type is Adjustment and Adjustment Reason is Adjustment In.
                            else if (((OptionSetValue)entity["ber_type"]).Value == 278290000 && ((OptionSetValue)entity["ber_adjustmentreason"]).Value == 278290000)
                            {
                                entity["ber_to"] = new EntityReference()
                                {
                                    LogicalName = "ber_inventorylocation",
                                    Id = UserInventoryLocationId
                                };
                            }
                            //If Reansfer type is Adjustment and Adjustment Reason is Adjustment Out.
                            else if (((OptionSetValue)entity["ber_type"]).Value == 278290000 && ((OptionSetValue)entity["ber_adjustmentreason"]).Value == 278290003)
                            {
                                entity["ber_from"] = new EntityReference()
                                {
                                    LogicalName = "ber_inventorylocation",
                                    Id = UserInventoryLocationId
                                };
                            }
                        }
                    }
                    #endregion
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                oLogger.Log("SetStockTransferInventoryLocations", "Execute", "Error:", ex.Message.ToString());
            }
            catch (Exception exc)
            {
                oLogger.Log("SetStockTransferInventoryLocations", "Execute", "Error:", exc.Message.ToString());
            }
        }       

        private static EntityCollection RetrieveBookingRequest(IOrganizationService service, Guid BookingRequestId)
        {            
            QueryExpression bookingRequestQry = new QueryExpression()
            {
                ColumnSet = new ColumnSet(true),
                EntityName = "ber_installationrequest"
            };

            ConditionExpression condition = new ConditionExpression()
            {
                AttributeName = "ber_installationrequestid",
                Operator = ConditionOperator.Equal,                
            };
            condition.Values.Add(BookingRequestId);

            FilterExpression filter = new FilterExpression()
            {
                FilterOperator = LogicalOperator.And
            };
            filter.Conditions.Add(condition);

            bookingRequestQry.Criteria.Filters.Add(filter);

            return service.RetrieveMultiple(bookingRequestQry);
        }

        private static EntityCollection RetrieveUserInventoryLocation(IOrganizationService service, Guid UserId)
        {            
            QueryExpression UserQuery = new QueryExpression()
            {
                EntityName = "systemuser",
                ColumnSet = new ColumnSet(true)
            };

            ConditionExpression condition = new ConditionExpression()
            {
                AttributeName = "systemuserid",
                Operator = ConditionOperator.Equal,
            };
            condition.Values.Add(UserId);

            FilterExpression filter = new FilterExpression()
            {
                FilterOperator = LogicalOperator.And
            };
            filter.Conditions.Add(condition);

            UserQuery.Criteria.Filters.Add(filter);

            return service.RetrieveMultiple(UserQuery);
        }
    }
}
