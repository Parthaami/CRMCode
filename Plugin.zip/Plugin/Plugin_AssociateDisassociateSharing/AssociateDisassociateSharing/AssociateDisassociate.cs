﻿//--------------------------------------------------------------------------------
// <copyright file="AssociateDisassociate.cs" company="Pragmasys Consulting LLP">
//  © Copyright Pragmasys Consulting LLP, 2012. All rights reserved.
// </copyright>
//--------------------------------------------------------------------------------

[assembly: System.CLSCompliant(true)]

namespace Berger.Plugin.AssociateDisassociateSharing
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Configuration;
    using System.Data;
    using System.IO;
    using System.Xml;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Win32;
    using Microsoft.Xrm.Sdk;    
    using Microsoft.Xrm.Sdk.Query;     

    /// <summary>
    /// Class AssociateDisassociate to share or un share records
    /// </summary>
    public class AssociateDisassociate : IPlugin
    {
        /// <summary>
        /// Configuration variable object
        /// </summary>
        private static System.Configuration.Configuration config;

        /// <summary>
        /// Logger class object
        /// </summary>
        private static PragmasysLogger objLogger;     
        
        /// <summary>
        /// Method Execute
        /// </summary>
        /// <param name="serviceProvider">CRM service provider object</param>
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                // Obtain the execution context from the service provider.
                IPluginExecutionContext context =
                    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                IOrganizationServiceFactory factory =
                    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                EntityReference target = (EntityReference)context.InputParameters["Target"];
                EntityReferenceCollection relatedentities = (EntityReferenceCollection)context.InputParameters["RelatedEntities"];

                if (relatedentities[0].LogicalName != "ber_depot")
                {
                    return;
                }

                string organizationName = context.OrganizationName;
                /*
                RegistryKey rk = Registry.LocalMachine;
                RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                string db_Path = obj_dbpath.ToString();

                string configpath = db_Path + "\\CRMWeb\\ISV\\" + organizationName + "\\Pragmasys.config";
                */
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    ////  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                        objLogger = new PragmasysLogger(organizationName, loggerPath);
                    }
                }

                ColumnSet depotColumns = new ColumnSet();
                depotColumns.AddColumn("ber_depotuser");
                depotColumns.AddColumn("ber_bdmid");

                Entity depotRecord = service.Retrieve(relatedentities[0].LogicalName, relatedentities[0].Id, depotColumns);

                if (depotRecord.Contains("ber_depotuser"))
                {
                    EntityReference depotUser = (EntityReference)depotRecord.Attributes["ber_depotuser"];

                    if (context.MessageName.ToLower() == "associate")
                    {
                        this.ShareRecord(target.LogicalName, target.Id, depotUser, service);
                    }
                    else if (context.MessageName.ToLower() == "disassociate")
                    {
                        this.UnShareRecord(target.LogicalName, target.Id, depotUser, service);
                    }
                }

                if (depotRecord.Contains("ber_bdmid"))
                {
                    EntityReference bdmUser = (EntityReference)depotRecord.Attributes["ber_bdmid"];

                    if (context.MessageName.ToLower() == "associate")
                    {
                        this.ShareRecord(target.LogicalName, target.Id, bdmUser, service);
                    }
                    else if (context.MessageName.ToLower() == "disassociate")
                    {
                        UnShareRecord(target.LogicalName, target.Id, bdmUser, service);
                    }
                }
            }
            catch (Exception ex)
            {
                //// Handle the exception.
                ////Log the Error Entry in Log Table.
                objLogger.Log("AssociateDisassociateSharing", "Execute", ex.Message, ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Shares Record with Read and Append Permissions
        /// </summary>
        /// <param name="entityName">Name of Entity whose record is to be shared</param>
        /// <param name="entityId">Unique id of entity</param>
        /// <param name="assigneeUser">Entity reference of User Record to share record with</param>
        /// <param name="service">CRM organization service object</param>  
        protected void ShareRecord(string entityName, Guid entityId, EntityReference assigneeUser, IOrganizationService service)
        {
            try
            {
                GrantAccessRequest shareRequest = new GrantAccessRequest
                {
                    PrincipalAccess = new PrincipalAccess
                    {
                        AccessMask = AccessRights.ReadAccess | AccessRights.AppendAccess | AccessRights.AppendToAccess,
                        Principal = assigneeUser
                    },
                    Target = new EntityReference(entityName, entityId)
                };
                service.Execute(shareRequest);
            }
            catch (Exception ex)
            {
                objLogger.Log("AssociateDisassociateSharing", "ShareRecord", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }

        /// <summary>
        /// Un share record if Shared with user
        /// </summary>
        /// <param name="entityName">Name of entity whose record is to be shared</param>
        /// <param name="entityId">Unique id of record whose record is to be shared</param>
        /// <param name="assigneeUser">Entity reference of User Record to share record with</param>
        /// <param name="service">CRM organization service object</param>        
        protected void UnShareRecord(string entityName, Guid entityId, EntityReference assigneeUser, IOrganizationService service)
        {
            try
            {
                RevokeAccessRequest revokeRequest = new RevokeAccessRequest()
                {
                    Target = new EntityReference(entityName, entityId),
                    Revokee = assigneeUser
                };
                service.Execute(revokeRequest);
            }
            catch (Exception ex)
            {
                objLogger.Log("AssociateDisassociateSharing", "UnShareRecord", ex.Message, ex.StackTrace.ToString());
                throw ex;
            }
        }      
    }
}
