﻿using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Extensions.Logging;
using System.Dynamic;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using Newtonsoft.Json.Bson;
using Newtonsoft.Json.Serialization;
using System.Linq;

namespace PluginCrmERPIntegration
{
    public class CrmERPIntegration : IPlugin
    {
        public static System.Configuration.Configuration config;
        public static ILogger oLogger = null;


        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationService service = ((IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(new Guid?(context.UserId));
                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is EntityReference))
                {
                    #region To Read Config File
                    /*
                    RegistryKey rk = Registry.LocalMachine;
                    RegistryKey rk1 = rk.OpenSubKey("SOFTWARE");
                    RegistryKey rk2 = rk1.OpenSubKey("Microsoft");
                    RegistryKey rk_dbpath = rk2.OpenSubKey("MSCRM");
                    Object obj_dbpath = rk_dbpath.GetValue("CRM_Server_InstallDir");

                    string DB_path = obj_dbpath.ToString();
                   
                    string configpath = DB_path + "\\CRMWeb\\ISV\\" + context.OrganizationName + "\\Pragmasys.config";
                    */
                    /*
                    string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";
                    ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                    if (File.Exists(configpath))
                    {
                        //  Get configration data    
                        fileMap.ExeConfigFilename = configpath;
                        config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                        if (config.AppSettings.Settings.Count > 0)
                        {
                            string _loggerPath = config.AppSettings.Settings["loggerpath"].Value.ToString();
                          //  oLogger = new Logger(context.OrganizationName, _loggerPath);
                        }
                    }
                    #endregion
                    */
                    Entity reference = (Entity)context.InputParameters["Target"];
                    if (reference["statuscode"].ToString() == "5")
                    {

                        var query = new QueryExpression("account");
                        query.ColumnSet = new ColumnSet();
                        query.ColumnSet.Columns.Add("name");
                        query.LinkEntities.Add(new LinkEntity("account", "contact", "primarycontactid", "contactid", JoinOperator.Inner));
                        query.LinkEntities[0].Columns.AddColumns("firstname");
                        query.LinkEntities[0].Columns.AddColumns("lastname");
                        query.LinkEntities[0].EntityAlias = "cnt";
                        query.Criteria = new FilterExpression();
                        // query.Criteria.AddCondition("accountnumber", ConditionOperator.Equal, "");
                        query.Orders.Add(new OrderExpression("name", OrderType.Descending));
                        query.Distinct = true;
                        EntityCollection ec = service.RetrieveMultiple(query);
                        Model _OutputDataModel = new Model();
                        string FieldsToDisplayValues = "AccountName, FirstName, LastName";
                        string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel, FieldsToDisplayValues);
                        string FirstName = _OutputDataModel.FirstName;
                        string LastName = _OutputDataModel.LastName;

                    }
                }
            }
            catch (Exception ex)
            {
              //  oLogger.Log("UpdateQuotationItem", "Execute", "Error on Delete of Quotation Item", ex.Message.ToString());
            }
        }
    }
}
