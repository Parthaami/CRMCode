﻿using Newtonsoft.Json;

namespace PluginCrmERPIntegration
{
    public class Model
    {
        [JsonProperty("name")]
        public string AccountName { get; set; }
        [JsonProperty("cnt.firstname")]
        public string FirstName { get; set; }
        [JsonProperty("cnt.lastname")]
        public string LastName { get; set; }
    }
}
