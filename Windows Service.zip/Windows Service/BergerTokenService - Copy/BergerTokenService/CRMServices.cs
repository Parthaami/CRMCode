﻿using System;
using System.Configuration;
using System.Net;
using System.ServiceModel.Description;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System.Data;
using System.Data.SqlClient;


namespace BergerTokenService
{
    public class BergerTokenServicef
    {       
        public static OrganizationServiceProxy _crmService;
        public static IOrganizationService _service;
        public static Guid _userID = Guid.Empty;
        private DataContract.Authenticate authenticate = new DataContract.Authenticate();
        private string DBConnectionString=string.Empty;

        #region public properties

        #region CRM Service Property
        public OrganizationServiceProxy Crmservice
        {
            get
            {
                return _crmService;
            }
        }

        public IOrganizationService Service
        {
            get
            {
                return _service;
            }
        }
        #endregion


        #endregion

        #region Authenticate User

        public DataContract.Authenticate AuthenticateUser()
        {
            string serverUrl = ConfigurationManager.AppSettings["ServerURL"].ToString();
            string orgName = ConfigurationManager.AppSettings["Orgname"].ToString();
            DataContract.Authenticate response = new DataContract.Authenticate();
            const string URL_PREFIX = "http://";
            const string CRM_SERVICE_SUFFIX_URL = "/XRMServices/2011/Organization.svc";
            bool valid = false;
            // Reset the user credentials for the CRM connections.            
            string _responseUri = string.Empty;

            if (!String.IsNullOrEmpty(serverUrl))
            {
                // Create the CRM service URL.
                serverUrl = serverUrl + "/" + orgName + CRM_SERVICE_SUFFIX_URL;
                if (!serverUrl.StartsWith(URL_PREFIX, StringComparison.OrdinalIgnoreCase))
                {
                    serverUrl = URL_PREFIX + serverUrl;
                }
                Uri url = new Uri(serverUrl);
                try
                {
                    Console.WriteLine("Authenticating with CRM");                   
                    Uri OrganizationUri = new Uri(ConfigurationManager.AppSettings["Service"].ToString());

                    ClientCredentials Credentials = new ClientCredentials();
                    Credentials.UserName.UserName = ConfigurationManager.AppSettings["Username"]; 
                    Credentials.UserName.Password = ConfigurationManager.AppSettings["Password"];
                    Uri HomeRealmUri = null;                    
                    OrganizationServiceProxy Service = new OrganizationServiceProxy(OrganizationUri, HomeRealmUri, Credentials, null);
                    IOrganizationService service = (IOrganizationService)Service;
                    _crmService = Service;
                    _service = service;
                    Guid userid = ((WhoAmIResponse)Service.Execute(new WhoAmIRequest())).UserId;
                    Console.WriteLine("Connected with User " + userid.ToString());
                    valid = true;
                    response.UserID = userid;
                }
                catch (WebException webEx)
                {
                    // error-handling code here
                    //logger.Log(webEx.Message.ToString());
                    string x = webEx.Message.ToString();
                    valid = false;
                }
                catch
                {
                    // Error-handling code here.
                    //logger.Log(ex.Message.ToString());

                    valid = false;
                    throw;
                }
                finally
                {
                      
                }
            }
            response.IsAuthenticated = valid;
            return response;
        }
             
        #endregion

        #region Create Token Redemption
        public string CreateTokenRedemtion(string Mobile, string TokenNumber, string Source)
        {
            string result = string.Empty;

            if (string.IsNullOrEmpty(TokenNumber) && string.IsNullOrEmpty(Mobile))
            {
                result = ConfigurationManager.AppSettings["MobileOrTokenNotProvide"].ToString();
                CreateTokenLog(result, Mobile, TokenNumber);
                return result;
            }

            #region [Check Token]
            QueryExpression tokenQuery = new QueryExpression("ber_tokenmaster");
            tokenQuery.ColumnSet = new ColumnSet(true);
            tokenQuery.Criteria.AddCondition(new ConditionExpression("ber_tokenkeyno", ConditionOperator.Equal, TokenNumber));
            EntityCollection tokenCollection = Service.RetrieveMultiple(tokenQuery);
            if (tokenCollection.Entities.Count <= 0)
            {
                result = ConfigurationManager.AppSettings["InvalidToken"].ToString();  //Return if token not found
                CreateTokenLog(result, Mobile, TokenNumber);
                return result;
            }
            else
            {
                if (((OptionSetValue)tokenCollection.Entities[0].Attributes["statuscode"]).Value != 1)
                {
                    result = ConfigurationManager.AppSettings["TokenConsumed"].ToString();  //Return if token already redemed 
                    CreateTokenLog(result, Mobile, TokenNumber);
                    return result;
                }
                else
                {
                    if (!tokenCollection.Entities[0].Attributes.Contains("ber_expiredate"))
                    {
                        result = ConfigurationManager.AppSettings["InvalidTokenExpireDateNotfound"].ToString();  //Return if ExpireDate not found 
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }

                    #region Check Token Expiry date
                    DateTime expireDate = Convert.ToDateTime(tokenCollection.Entities[0].Attributes["ber_expiredate"]);
                    DateTime today = DateTime.Today;
                    //string _today = today.ToString("MM/dd/yyyy");
                    //string _expireDate = expireDate.ToString("MM/dd/yyyy");
                    if (today > expireDate)
                    {
                        SetStateRequest setStateRequest = new SetStateRequest()
                        {
                            EntityMoniker = new EntityReference
                            {
                                Id = tokenCollection.Entities[0].Id,
                                LogicalName = tokenCollection.Entities[0].LogicalName,
                            },
                            State = new OptionSetValue(1),
                            Status = new OptionSetValue(278290000)
                        };
                        Service.Execute(setStateRequest);

                        result = ConfigurationManager.AppSettings["TokenExpired"].ToString();  //Return if token already redemed
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }
                    #endregion

                    #region Check Token Type
                    EntityReference tokenTypeMaster = null;
                    tokenTypeMaster = (EntityReference)tokenCollection.Entities[0].Attributes["ber_tokentype"];
                    if (tokenTypeMaster == null)
                    {
                        result = ConfigurationManager.AppSettings["InvalidToken"].ToString();  //Return if token type not found
                        CreateTokenLog(result, Mobile, TokenNumber);
                        return result;
                    }
                    int _tokenType = 0;
                    Entity tokenTypeMasterEntity = Service.Retrieve(tokenTypeMaster.LogicalName, tokenTypeMaster.Id, new ColumnSet(new string[] { "ber_customertype" }));
                    if (tokenTypeMasterEntity != null)
                    {
                        _tokenType = ((OptionSetValue)tokenTypeMasterEntity.Attributes["ber_customertype"]).Value;
                    }
                    #endregion

                    if (_tokenType == 1) //Check for Dealer
                    {
                        #region [Check Delear]

                        string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["InitialCatalog"] + ";Integrated Security=True";
                        using (SqlConnection con = new SqlConnection(dbConnectionString))
                        {
                            con.Open();
                            string command = "select accountid from Account where ParentAccountId is null and StateCode=0 and (Telephone1='" + Mobile + "' or  Telephone2='" + Mobile + "' or Address1_Telephone1='" + Mobile + "' or Telephone3='" + Mobile + "')";
                            SqlCommand cm = new SqlCommand(command, con);
                            SqlDataAdapter da = new SqlDataAdapter(cm);
                            DataTable DealerTable = new DataTable();
                            da.Fill(DealerTable);

                            if (DealerTable.Rows.Count <= 0 || DealerTable.Rows.Count > 1)
                            {
                                result = ConfigurationManager.AppSettings["DealerNotFound"].ToString();
                                CreateTokenLog(result, Mobile, TokenNumber);
                                return result;
                            }

                            try
                            {
                                Entity _tokenRedemtion = new Entity("ber_tokenredemption");
                                _tokenRedemtion.Attributes["ber_token"] = new EntityReference(tokenCollection.Entities[0].LogicalName, tokenCollection.Entities[0].Id);
                                _tokenRedemtion.Attributes["ber_dealer"] = new EntityReference("account", new Guid(DealerTable.Rows[0][0].ToString()));
                                _tokenRedemtion.Attributes["ber_tokennumber"] = TokenNumber;
                                switch (Source.ToLower())
                                {
                                    case "web": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(1); break;
                                    case "mobile": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(2); break;
                                    case "sms": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(3); break;
                                }

                                Service.Create(_tokenRedemtion);
                                result = ConfigurationManager.AppSettings["TokenConsumedSucess"].ToString();
                            }
                            catch (Exception ex)
                            {
                                result = ex.Message;
                                CreateTokenLog(result, Mobile, TokenNumber);
                                return ConfigurationManager.AppSettings["ErrorOccured"].ToString();
                            }

                        }
                        #endregion
                    }
                    else// check for Painter
                    {
                        Guid painterGuid = Guid.Empty;
                        Guid subPainterGuid = Guid.Empty;

                        try
                        {
                            #region [Check for Sub Painter]
                            DataTable subPainterTable = null;
                            string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["InitialCatalog"] + ";Integrated Security=True";
                            using (SqlConnection con = new SqlConnection(dbConnectionString))
                            {
                                con.Open();
                                string command = "select ber_parentpainter,contactid from Contact where StateCode=0 and mobilephone='" + Mobile + "' and (ber_subdealer=0 or ber_subdealer is null) and ber_customertype=278290001 and ber_parentpainter is not null";
                                SqlCommand cm = new SqlCommand(command, con);
                                SqlDataAdapter da = new SqlDataAdapter(cm);
                                subPainterTable = new DataTable();
                                da.Fill(subPainterTable);
                                if (subPainterTable.Rows.Count > 0)
                                {
                                    painterGuid = new Guid(subPainterTable.Rows[0][0].ToString());
                                    subPainterGuid = new Guid(subPainterTable.Rows[0]["contactid"].ToString());
                                }
                            }
                            #endregion

                            if (painterGuid == Guid.Empty)
                            {
                                #region [Check Painter]

                                DataTable PainterTable = null;
                                using (SqlConnection con = new SqlConnection(dbConnectionString))
                                {
                                    con.Open();
                                    string command1 = "select contactid from Contact where StateCode=0 and mobilephone='" + Mobile + "' and  ber_customertype=278290001 and (ber_subdealer=0 or ber_subdealer is null) ";
                                    SqlCommand cm = new SqlCommand(command1, con);
                                    SqlDataAdapter da = new SqlDataAdapter(cm);
                                    PainterTable = new DataTable();
                                    da.Fill(PainterTable);

                                    if (PainterTable.Rows.Count <= 0)
                                    {
                                        result = ConfigurationManager.AppSettings["PainterNotFound"].ToString();                                        
                                        CreateTokenLog(result, Mobile, TokenNumber);
                                        return result;
                                    }
                                    else
                                    {
                                        painterGuid = new Guid(PainterTable.Rows[0][0].ToString());
                                    }

                                }
                                #endregion
                            }
                            if (painterGuid != Guid.Empty)
                            {
                                #region [Get PainterMeet]
                                DataTable DealerTable = new DataTable();
                                DataTable PainterMeetTable = new DataTable();
                                string PainterMeetCommand = "select ber_paintermeetId from ber_paintermeet  as pm inner join ber_paintermeetcontact as pmc on pm.ber_paintermeetId=pmc.ber_PainterMeet " +
                                                            "inner join ber_meet as m on pm.ber_Meet=m.ber_meetId where pmc.statecode=0 and pmc.ber_Contact='" + painterGuid.ToString() + "' and m.ber_PainterCall=1 and m.ber_SchemeRequired=1" +
                                                            "or(m.ber_FinalPointCalculationDate > GETDATE() and m.ber_FinalPointCalculationDate is null) and pm.ber_MeetType=278290002";
                                using (SqlConnection con = new SqlConnection(dbConnectionString))
                                {
                                    con.Open();
                                    SqlCommand cm = new SqlCommand(PainterMeetCommand, con);
                                    SqlDataAdapter da = new SqlDataAdapter(cm);

                                    da.Fill(PainterMeetTable);
                                    if (PainterMeetTable.Rows.Count <= 0)
                                    {
                                        result = ConfigurationManager.AppSettings["PainterNotFound"].ToString();                                         
                                        CreateTokenLog(result, Mobile, TokenNumber);
                                        return result;
                                    }

                                    #region [Get linked Dealer]
                                    string dealerCommand = "select accountid from Account a inner join ber_depot as d on a.ber_DepotId=d.ber_depotId " +
                                                            "where a.ParentAccountId is null and a.StateCode=0 and a.accountclassificationcode=1 and a.ber_mpdealer=1 " +
                                                            "and d.ber_CityId=(select c.ber_cityId from ber_city as c inner join ber_depot as dp on c.ber_cityId=dp.ber_CityId " +
                                                            "where dp.ber_depotId=(select ber_depot from ber_paintermeet where ber_paintermeetId='" + new Guid(PainterMeetTable.Rows[0][0].ToString()) + "'))";

                                    SqlCommand cm1 = new SqlCommand(dealerCommand, con);
                                    SqlDataAdapter da1 = new SqlDataAdapter(cm1);

                                    da1.Fill(DealerTable);
                                    if (DealerTable.Rows.Count <= 0)
                                    {
                                        con.Close();
                                        con.Dispose();
                                    }
                                    #endregion
                                }
                                #endregion

                                #region [Create Redemption]
                                Entity _tokenRedemtion = new Entity("ber_tokenredemption");
                                _tokenRedemtion.Attributes["ber_token"] = new EntityReference(tokenCollection.Entities[0].LogicalName, tokenCollection.Entities[0].Id);
                                _tokenRedemtion.Attributes["ber_painter"] = new EntityReference("contact", painterGuid);
                                _tokenRedemtion.Attributes["ber_tokennumber"] = TokenNumber;
                                switch (Source.ToLower())
                                {
                                    case "web": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(1); break;
                                    case "mobile": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(2); break;
                                    case "sms": _tokenRedemtion.Attributes["ber_source"] = new OptionSetValue(3); break;
                                }
                                _tokenRedemtion.Attributes["ber_paintermeet"] = new EntityReference("ber_paintermeet", new Guid(PainterMeetTable.Rows[0][0].ToString()));
                                if (DealerTable.Rows.Count > 0)
                                {
                                    _tokenRedemtion.Attributes["ber_linkeddealer"] = new EntityReference("account", new Guid(DealerTable.Rows[0][0].ToString()));
                                }

                                if (subPainterGuid != Guid.Empty)
                                {
                                    _tokenRedemtion.Attributes["ber_subpainter"] = new EntityReference("contact", subPainterGuid);
                                }

                                Service.Create(_tokenRedemtion);
                                result = ConfigurationManager.AppSettings["TokenConsumedSucess"].ToString();
                                #endregion
                            }
                        }
                        catch (Exception ex)
                        {
                            result = ex.Message;
                            CreateTokenLog(result, Mobile, TokenNumber);
                            return ConfigurationManager.AppSettings["ErrorOccured"].ToString();
                        }
                    }
                }
            }

            #endregion

            CreateTokenLog(result, Mobile, TokenNumber);
            return result;
        }
        #endregion

        #region Create Token service log
        public void CreateTokenLog(string result,string mobile,string tokenNumber)
        {
            string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionDatabase"] + ";User ID=" + ConfigurationManager.AppSettings["UserID"] + ";Password=" + ConfigurationManager.AppSettings["Pwd"];
            using (SqlConnection con = new SqlConnection(dbConnectionString))
            {
                con.Open();
                string command = "insert into Token_Service_log (ID,CustomerMobile,CustomerToken,Status,CreatedOn) Values('" + Guid.NewGuid() + "','" + mobile + "','" + tokenNumber + "','" + result + "','" + DateTime.Now + "')";
                SqlCommand cm = new SqlCommand(command, con);
                int i = cm.ExecuteNonQuery();               
            }
        }         
        #endregion 

        #region CreateTokenMaster
        public String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate)
        {
            string mess = string.Empty;
            string DBConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionDatabase"] + ";User ID=" + ConfigurationManager.AppSettings["UserID"] + ";Password=" + ConfigurationManager.AppSettings["Pwd"];
            SqlConnection _sqlConnection = null;  
            try
            {
                Console.WriteLine("Inserting SubDealer data in Transaction table");
                _sqlConnection = new SqlConnection(DBConnectionString);
                _sqlConnection.Open();
                   try
                   {
                       #region Insert into Transaction Table     
                       string insertCommand = "INSERT INTO Token_Master_Integration ([SrlNo],[TokenType],[Product],[PackSize],[Denomination],[TokenMonth],[TokenYear],[TokenKeyNo],tokenExpireDate,[Status])";
                        insertCommand += "VALUES ('";
                        insertCommand += SrlNo;
                        insertCommand += "','" + TokenType;
                        insertCommand += "','" + Product;                       
                        insertCommand += "','" + PackSize;
                        insertCommand += "','" + Denomination;
                        insertCommand += "','" + TokenMonth;
                        insertCommand += "','" + TokenYear;
                        insertCommand += "','" + TokenKeyNo;
                        insertCommand += "','" + ExpireDate; 
                        insertCommand += "','R')";
                        SqlCommand sqlCmd = new SqlCommand(insertCommand,_sqlConnection);
                        int i = sqlCmd.ExecuteNonQuery();
                        mess= "Success";
                        #endregion 

                    }
                    catch (Exception ex)
                    {
                        return ex.Message;
                    }   
                    finally
                    {
                        _sqlConnection.Close();
                        _sqlConnection.Dispose();
                    }                               
            }
            catch
            {
                throw;
            }
            finally
            {
                if(_sqlConnection.State== ConnectionState.Open)
                {
                    _sqlConnection.Close();
                    _sqlConnection.Dispose();
                }                            
            }
            return mess;
        }
        #endregion
    }
}
