﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Activation;

namespace BergerTokenService
{
    //[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    //[ServiceBehavior(AddressFilterMode = AddressFilterMode.Any)]

    public class BergerTokenServices : IBergerTokenService
    {
        public DataContract.Authenticate AuthenticateUser()
        {
            BergerTokenServicef userEntity = new BergerTokenServicef();
            return userEntity.AuthenticateUser();
        }

        public string CreateTokenRedemtion(string Mobile, string TokenNumber,string Source)         
        {            
            BergerTokenServicef userEntity = new BergerTokenServicef();
            userEntity.AuthenticateUser();
            return userEntity.CreateTokenRedemtion(Mobile,TokenNumber,Source);
        }

        public String CreateTokenMaster(string SrlNo, string TokenType, string Product, string PackSize, decimal Denomination, string TokenMonth, string TokenYear, string TokenKeyNo, DateTime ExpireDate)
        {
            BergerTokenServicef userEntity = new BergerTokenServicef();
            return userEntity.CreateTokenMaster(SrlNo, TokenType, Product, PackSize, Denomination, TokenMonth, TokenYear, TokenKeyNo, ExpireDate);
        }

    }
}
