﻿//========================================================================
//  This service executes on Daily basis and sets Daily transaction limit of 
//  dealer.
//  Daily transaction limit is basically Credit limit of Dealer.
//
//  Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================

using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Data;
using System.Data.SqlClient;

namespace SetAvailableDailyTransLimit
{
    class Program
    {
        #region Class Level Variables
        static string _orgName = ConfigurationManager.AppSettings["OrgName"];
        static string PrintLog = ConfigurationManager.AppSettings["PrintLog"];
        private static IOrganizationService _service;
        static Logger oLogger;
        static string _loggerPath = string.Empty;
        static string _crmServerUrl = string.Empty;
        public static string SQLConnStr = string.Empty;
        static Configuration config;
        #endregion

        static void Main(string[] args)
        {
            try
            {

                #region Read Registry Key & get Pragmasys.config Path

                /*
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }

                */
                #endregion

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 
                //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _orgName + "\\Pragmasys.config";
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_orgName, _loggerPath);
                        _crmServerUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                        SQLConnStr = config.ConnectionStrings.ConnectionStrings["Bergersqldbconnection"].ConnectionString.ToString();
                    }
                }

                ////get CRM service
                _service = GetService();

                var query = "select ber_availablecreditlimit,accountnumber,Accountid from Account " +
                            "where ber_availablecreditlimit > 0 and StatusCode = 1 and ParentAccountId is null";

                DataTable dtDealerDetails = getDataFromSql(query, SQLConnStr, oLogger);

                if (PrintLog.ToLower() == "yes")
                    Console.WriteLine("Number Of Dealers Found : " + dtDealerDetails.Rows.Count);

                int count = 0;

                if (dtDealerDetails.Rows.Count > 0 && dtDealerDetails.Rows[0][0] != DBNull.Value)
                {
                    foreach (DataRow DR in dtDealerDetails.Rows)
                    {
                        count = count + 1;
                        Entity Account = new Entity();
                        Account.LogicalName = "account";
                        if (DR[2] != DBNull.Value)
                        {
                            Account.Id = new Guid(DR[2].ToString());
                            if (DR[0] != DBNull.Value)
                            {
                                Account.Attributes["ber_availabletransactionlimit"] = new Money(Convert.ToDecimal(DR[0]));
                                try
                                {
                                    _service.Update(Account);
                                    if (PrintLog.ToLower() == "yes")
                                        Console.WriteLine("Number Of Dealers Updated : " + count);
                                }
                                catch (Exception e)
                                {
                                    oLogger.Log("SetAvailableDailyTransLimit", "Main", e.Message, e.StackTrace.ToString());
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SetAvailableDailyTransLimit", "Main", ex.Message, ex.StackTrace.ToString());
            }
        }

        #region Function to Retrive Service
        public static IOrganizationService GetService()
        {
            IOrganizationService _service = null;
            try
            {

                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(_crmServerUrl));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                _service = (IOrganizationService)orgService;
                return _service;
            }
            catch (Exception ex)
            {
                oLogger.Log("SetAvailableDailyTransLimit", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return _service;
        }

        private static TProxy GetProxy<TService, TProxy>(
         IServiceManagement<TService> serviceManagement,
         AuthenticationCredentials authCredentials)
         where TService : class
         where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Function to get Data from SQL
        public static DataTable getDataFromSql(string Query, string _dbConnectionString, Logger oLogger)
        {
            DataTable DT = new DataTable();
            SqlConnection connection = new SqlConnection(_dbConnectionString);
            connection.Open();
            SqlCommand command = new SqlCommand(Query, connection);

            SqlDataReader reader = null;
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandTimeout = 120;
                reader = command.ExecuteReader();
                DT.Load(reader);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving data from SQL", "getDataFromSql: " + Query, ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                connection.Close();
                reader.Dispose();
                command.Dispose();
                connection.Dispose();
                Query = string.Empty;
            }
            return DT;
        }
        #endregion
    }
}
