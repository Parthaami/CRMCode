﻿//========================================================================
// This windows service executes on daily basis.
// It creates -
// 1) Phone call activity for dealer about payment reminder.
// 2) SMS Activity for TSI about Payment Collection of Dealer.
// 3) SMS activity for Dealer informing about his payment due date next day.
//
// Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Data.OleDb;
using System.Data;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Crm.Sdk.Messages;
using Oracle.DataAccess.Client;

namespace PaymentReminderCallBatchService
{
    class PaymentReminder
    {
        #region Class Level Members

        private static IOrganizationService _service;
        static Logger oLogger;
        static string _loggerPath = string.Empty;
        static string _crmServerUrl = string.Empty;
        static Configuration config;
        static string _orgName = ConfigurationManager.AppSettings["OrgName"];
        public static string conn = ConfigurationManager.ConnectionStrings["ORAProvider"].ConnectionString;//ConfigurationManager.AppSettings["ORAProvider"];
        static int oracleFetchSize = Convert.ToInt32(ConfigurationManager.AppSettings["oracleFetchSize"].ToString());
        

        static DateTime _DueDate;
        static DateTime _Today = DateTime.Now;
        static int _timeOfCall = 0;
       
            
        static Guid NewPhoneCallId = Guid.Empty;
        static EntityReference _CustomerPreferredLanguage = null;
        
        #endregion

        static void Main(string[] args)
        {
            DataSet Depots = new DataSet();
            DataSet DN1Customers = new DataSet();
            DataSet DN2Customers = new DataSet();
            

            try
            {
                Console.WriteLine("Execution Start...");

                #region Read Registry Key & get Pragmasys.config Path
                
                /*
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                } 
                */
                #endregion

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 
                //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _orgName + "\\Pragmasys.config";
               

                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_orgName, _loggerPath);
                        _crmServerUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                    }
                }

                Depots = RetriveFromOracle("select Depot_Code from xxcrm_depot_config where payment_reminder_sms = 'Y'");
                if (Depots.Tables.Count > 0 && Depots.Tables[0].Rows.Count > 0)
                { 
                  
                    for (int i = 0; i < Depots.Tables[0].Rows.Count; i++)
                    {
                        string DepotCode = Depots.Tables[0].Rows[i].ItemArray[0].ToString();
                        int count = 1;
                        DataSet dsTemp1 = RetriveFromOracle("select * from (select DUE, ACCOUNT_NUMBER, TO_CHAR(trunc(DN1_DATE), 'DD-MM-YYYY') DN1_DATE,  ACTIVITY,  DEPOT,  CAT,TO_CHAR(trunc(dn1_date -1), 'DD-MM-YYYY') activity_date, row_number() over (order by DUE  desc) row_num from XXCRM_PENDING_INVOICES_DN1 where Depot = '" + DepotCode + "' and activity = 'SMS' )  where row_num between " + count + " and " + (count + 50) + "");

                        while (dsTemp1.Tables[0].Rows.Count > 0)
                        {                            
                            //Function Call to retrive Dealers ERP DB for DN1_Date
                            //DN1Customers.Merge(RetriveFromOracle("select due, account_number, TO_CHAR(trunc(dn1_date), 'DD-MM-YYYY') dn1_date,activity,depot,cat,TO_CHAR(trunc(dn1_date -1), 'DD-MM-YYYY') activity_date from xxcrm_pending_invoices_dn1 where Depot = '" + DepotCode + "'"));
                            DN1Customers.Merge(dsTemp1);

                            count = count + 51;
                            dsTemp1 = RetriveFromOracle("select * from (select DUE, ACCOUNT_NUMBER, TO_CHAR(trunc(DN1_DATE), 'DD-MM-YYYY') DN1_DATE,  ACTIVITY,  DEPOT,  CAT,TO_CHAR(trunc(dn1_date -1), 'DD-MM-YYYY') activity_date, row_number() over (order by DUE  desc) row_num from XXCRM_PENDING_INVOICES_DN1 where Depot = '" + DepotCode + "' and activity = 'SMS' )  where row_num between " + count + " and " + (count + 50) + "");                       
                        }
                        dsTemp1.Clear();
                    }
                    //Function call to find dealer and Create Phone Call/ SMS as required.
                    FindDealer(DN1Customers, "1ST", "DN1");

                    for (int i = 0; i < Depots.Tables[0].Rows.Count; i++)
                    {
                        string DepotCode = Depots.Tables[0].Rows[i].ItemArray[0].ToString();
                        int count = 1;
                        DataSet dsTemp2 = RetriveFromOracle("select * from (select DUE, ACCOUNT_NUMBER, TO_CHAR(trunc(DN2_DATE), 'DD-MM-YYYY') DN2_DATE,  ACTIVITY,  DEPOT,  CAT,TO_CHAR(trunc(dn2_date -1), 'DD-MM-YYYY') activity_date, row_number() over (order by DUE  desc) row_num from XXCRM_PENDING_INVOICES_DN2 where Depot = '" + DepotCode + "' and activity = 'SMS' )  where row_num between " + count + " and " + (count + 50) + "");

                        while (dsTemp2.Tables[0].Rows.Count > 0)
                        {
                            //Function Call to retrive Dealers from ERP DB for DN2_Date
                            DN2Customers.Merge(dsTemp2);

                            count = count + 51;
                            dsTemp2 = RetriveFromOracle("select * from (select DUE, ACCOUNT_NUMBER, TO_CHAR(trunc(DN2_DATE), 'DD-MM-YYYY') DN2_DATE,  ACTIVITY,  DEPOT,  CAT,TO_CHAR(trunc(dn2_date -1), 'DD-MM-YYYY') activity_date, row_number() over (order by DUE  desc) row_num from XXCRM_PENDING_INVOICES_DN2 where Depot = '" + DepotCode + "' and activity = 'SMS' ) where row_num between " + count + " and " + (count + 50) + "");
                        }
                        dsTemp2.Clear();
                    }
                    //Function call to find dealer and Create Phone Call/ SMS as required.
                    FindDealer(DN2Customers, "2ND", "DN2");
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "Main", ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                Depots.Clear();
                DN1Customers.Clear();
                DN2Customers.Clear();    
            }
        }

        #region Function to Retrive Service
        public static IOrganizationService GetService()
        {
            IOrganizationService _service = null;
            try
            {
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(_crmServerUrl));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy organizationServiceProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                organizationServiceProxy.EnableProxyTypes();

                _service = (IOrganizationService)organizationServiceProxy;
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return _service;
        }

        private static TProxy GetProxy<TService, TProxy>(
         IServiceManagement<TService> serviceManagement,
         AuthenticationCredentials authCredentials)
         where TService : class
         where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Function to retrive Data from Oracle.
        public static DataSet RetriveFromOracle(string Query)
        {
            Console.WriteLine("Retrive From Oracle Method Start.");
            DataSet sds = new DataSet();
            OracleConnection connection = new OracleConnection(conn);
            OracleCommand command = new OracleCommand();
            OracleDataAdapter dataAdapter = new OracleDataAdapter(command);
            try
            {
                Console.WriteLine("Opening Oracle Connection...");
                connection.Open();
                Console.WriteLine("Oracle Connection opened.");
                command.Connection = connection;
                command.CommandText = Query;
                Console.WriteLine("Query : " + Query);
                command.CommandType = CommandType.Text;
                command.FetchSize = oracleFetchSize;
                dataAdapter.Fill(sds);

                if (sds.Tables.Count > 0 && sds.Tables[0].Rows.Count > 0)
                    Console.WriteLine("No. of dealers retrived :" + sds.Tables[0].Rows.Count.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "RetriveFromOracle", ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                connection.Close();
                dataAdapter.Dispose();
                command.Dispose();
                connection.Dispose();
            }
            return sds;
        }
        #endregion

        #region Function to find Dealers Detail using account number from crm
        public static void FindDealer(DataSet DS,string DealerSlab,string dn)
        {
            DataSet SiteDesc = null;
            try
            {
                //get CRM service
                _service = GetService();

                for (int i = 0; i < DS.Tables[0].Rows.Count; i++)
                {
                    string _CustomerNumber = string.Empty;
                    string _AmountDue = string.Empty;
                    string _DNDate;
                    string _ActivityType = string.Empty;


                    _AmountDue = DS.Tables[0].Rows[i].ItemArray[0].ToString();
                    _CustomerNumber = DS.Tables[0].Rows[i].ItemArray[1].ToString();
                    _DNDate = DS.Tables[0].Rows[i].ItemArray[6].ToString();
                    _ActivityType = DS.Tables[0].Rows[i].ItemArray[3].ToString();

                    
                    SiteDesc = new DataSet();
                    string PhoneCallDesc = string.Empty;
                    if (_ActivityType == "PHONECALL")
                    {
                        if (dn == "DN1")
                            SiteDesc = RetriveFromOracle("select * from XXCRM_PENDING_INV_DN1_SITEWISE where account_number ='" + _CustomerNumber + "'");

                        else if (dn == "DN2")
                            SiteDesc = RetriveFromOracle("select * from XXCRM_PENDING_INV_DN2_SITEWISE where account_number ='" + _CustomerNumber + "'");

                        if (SiteDesc.Tables.Count > 0)
                        {
                            for (int j = 0; j < SiteDesc.Tables[0].Rows.Count; j++)
                            {
                                PhoneCallDesc = PhoneCallDesc + "\r\n" + SiteDesc.Tables[0].Rows[j].ItemArray[0].ToString() + "," + SiteDesc.Tables[0].Rows[j].ItemArray[1].ToString() + "\t" + SiteDesc.Tables[0].Rows[j].ItemArray[2].ToString();
                            }
                        }
                        PhoneCallDesc = PhoneCallDesc + "\r\n" + "Total Amt Due : Rs." + _AmountDue;
                    }

                    EntityCollection EC = getDealers(_CustomerNumber);

                    if (EC.Entities.Count == 1)
                    {
                        Entity oCustomer = EC.Entities[0];
                        string _CustomerName = string.Empty;
                        string _CustomerPhoneNo = string.Empty;
                        string OtherPhoneNumbers = string.Empty;
                        string PreferredTimeofCall = string.Empty;
                        string _DealerRegion = string.Empty;
                        string _TSIMobileNo = string.Empty;
                        EntityReference _AssociatedTSI = null;

                        if (oCustomer.Attributes.Contains("name"))
                            _CustomerName = Convert.ToString(oCustomer.Attributes["name"]);

                        if (oCustomer.Attributes.Contains("telephone1"))
                            _CustomerPhoneNo = Convert.ToString(oCustomer.Attributes["telephone1"]);

                        if (oCustomer.Attributes.Contains("telephone2"))
                            OtherPhoneNumbers = Convert.ToString(oCustomer.Attributes["telephone2"]);

                        if (oCustomer.Attributes.Contains("telephone3"))
                            OtherPhoneNumbers = OtherPhoneNumbers + "\r\n" + Convert.ToString(oCustomer.Attributes["telephone3"]);

                        if (oCustomer.Attributes.Contains("address1_telephone1"))
                            OtherPhoneNumbers = OtherPhoneNumbers + "\r\n" + Convert.ToString(oCustomer.Attributes["address1_telephone1"]);

                       
                        if (oCustomer.Attributes.Contains("ber_associatedtsiid"))
                        {
                            _AssociatedTSI = (EntityReference)oCustomer.Attributes["ber_associatedtsiid"];
                            Entity TSI = _service.Retrieve("ber_tsi", _AssociatedTSI.Id, new ColumnSet(new string[] { "ber_mobilenumber" }));
                            if (TSI.Attributes.Contains("ber_mobilenumber"))
                                _TSIMobileNo = TSI.Attributes["ber_mobilenumber"].ToString();
                        }

                        if (oCustomer.Attributes.Contains("ber_region"))
                        {
                            EntityReference _Region = (EntityReference)oCustomer.Attributes["ber_region"];
                            _DealerRegion = _Region.Name;
                        }

                        #region Get Dealer Preferred time of Call
                        if (oCustomer.Attributes.Contains("preferredappointmenttimecode"))
                        {
                            OptionSetValue timeOfCall = (OptionSetValue)oCustomer.Attributes["preferredappointmenttimecode"];
                            Dictionary<string, int> timeOfCallDictionary = RetrieveAttributeMetadataPicklistValue(_service, "account", "preferredappointmenttimecode");
                            foreach (KeyValuePair<string, int> pair in timeOfCallDictionary)
                            {
                                if (pair.Value.Equals(timeOfCall.Value))
                                {
                                    _timeOfCall = pair.Value;
                                    PhoneCallDesc = PhoneCallDesc + "\r\nPreferred Time: " + pair.Key.ToString();
                                    break;
                                }
                            }
                            if (_timeOfCall == 1)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 09, 00, 00);

                            else if (_timeOfCall == 2)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 11, 00, 00);

                            else if (_timeOfCall == 3 || _timeOfCall == 9)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 13, 00, 00);

                            else if (_timeOfCall == 4)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 15, 00, 00);

                            else if (_timeOfCall == 5)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 17, 00, 00);

                            else if (_timeOfCall == 6)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 10, 00, 00);

                            else if (_timeOfCall == 7)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 16, 00, 00);

                            else if (_timeOfCall == 8)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 12, 00, 00);

                            else if (_timeOfCall == 9)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 00, 00, 00);
                        }
                        #endregion

                        #region Get Dealer Prefered Language and Language Queue.

                        if (oCustomer.Attributes.Contains("ber_preferredlanguage1"))
                            _CustomerPreferredLanguage = (EntityReference)oCustomer.Attributes["ber_preferredlanguage1"];

                        Guid AssigntoQueueId = Guid.Empty;
                        EntityReference WorkerId = null;
                        if (_CustomerPreferredLanguage != null)
                        {
                            EntityCollection QueueColl = RetriveQueue(_CustomerPreferredLanguage.Id, string.Empty);
                            if (QueueColl.Entities.Count > 0)
                            {
                                foreach (Entity oQueue in QueueColl.Entities)
                                {
                                    AssigntoQueueId = oQueue.Id;

                                    if (oQueue.Attributes.Contains("ownerid"))
                                        WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                                }
                            }
                            if (AssigntoQueueId == Guid.Empty)
                            {
                                string DefaultQueueName = ConfigurationManager.AppSettings["DefaultQueueName"];
                                EntityCollection DefaultQueueColl = RetriveQueue(Guid.Empty, DefaultQueueName);
                                foreach (Entity oQueue in DefaultQueueColl.Entities)
                                {
                                    AssigntoQueueId = oQueue.Id;

                                    if (oQueue.Attributes.Contains("ownerid"))
                                        WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                                }
                            }
                        }
                        if (AssigntoQueueId == Guid.Empty)
                        {
                            string DefaultQueueName = ConfigurationManager.AppSettings["DefaultQueueName"];
                            EntityCollection DefaultQueueColl = RetriveQueue(Guid.Empty, DefaultQueueName);
                            foreach (Entity oQueue in DefaultQueueColl.Entities)
                            {
                                AssigntoQueueId = oQueue.Id;

                                if (oQueue.Attributes.Contains("ownerid"))
                                    WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                            }
                        }
                        #endregion

                        #region if Dealer Due Date is today's date create phone call activity against dealer
                        if (_ActivityType == "PHONECALL")
                        {
                            if (_timeOfCall != 0)
                            {
                                //Create Phone Call
                                NewPhoneCallId = CreatePhoneCall(oCustomer.Id, _CustomerPhoneNo, _DueDate, AssigntoQueueId, OtherPhoneNumbers, dn, PhoneCallDesc);

                                //Create SMS Activity for Associated TSI.
                                if (_AssociatedTSI != null && _TSIMobileNo != string.Empty)
                                    CreateSMS(_AssociatedTSI.Id, "TSI", _TSIMobileNo, _AmountDue, _DNDate, _CustomerNumber, _CustomerName, DealerSlab);
                            }
                            else
                            {
                                //set due date as default morning datetime
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 10, 00, 00);
                                NewPhoneCallId = CreatePhoneCall(oCustomer.Id, _CustomerPhoneNo, _DueDate, AssigntoQueueId, OtherPhoneNumbers, dn, PhoneCallDesc);

                                //Create SMS Activity for Associated TSI.
                                if (_AssociatedTSI != null && _TSIMobileNo != string.Empty)
                                    CreateSMS(_AssociatedTSI.Id, "TSI", _TSIMobileNo, _AmountDue, _DNDate, _CustomerNumber, _CustomerName, DealerSlab);
                            }

                            //Assign Phone Call to queue
                            AssignPhoneCalltoQueue(AssigntoQueueId, NewPhoneCallId, WorkerId.Id);
                        }
                        #endregion
                        else if (_ActivityType == "SMS")
                        {
                            //Create SMS activity to alert dealer
                            CreateSMS(oCustomer.Id, "Dealer", _CustomerPhoneNo, _AmountDue, _DNDate, "NULL", "NULL", DealerSlab);
                        }
                    }
                    else if (EC.Entities.Count == 0)
                    {
                        oLogger.Log("PaymentReminderBatchService", "FindDealer", "Customer Not Found.", "Account No." + _CustomerNumber.ToString());
                    }
                    else
                    {
                        oLogger.Log("PaymentReminderBatchService", "FindDealer", "More than one customers fount with same account no.", "Account No." + _CustomerNumber.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "FindDealer", ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
                SiteDesc.Clear();
            }
        }
        #endregion

        #region Function to create phone call for payment reminder
        public static Guid CreatePhoneCall(Guid CustomerId, string CustomerPhoneNo, DateTime DueDate,Guid AssigntoQueueId,string CustomerOtherno,string subcategory,string Description)
        {
            Guid phonecallid = Guid.Empty;
            try
            {
                Entity phonecall = new Entity();
                phonecall.LogicalName = "phonecall";

                EntityCollection tocollection = new EntityCollection();

                Entity toentity = new Entity();
                toentity.LogicalName = "activityparty"; ;
                toentity.Attributes["partyid"] = new EntityReference("account", CustomerId);
                tocollection.Entities.Add(toentity);

                phonecall["to"] = tocollection;
                phonecall["phonenumber"] = CustomerPhoneNo;
                phonecall["regardingobjectid"] = new EntityReference("account", CustomerId);
                phonecall["subject"] = ConfigurationManager.AppSettings["Subject"];
                phonecall["category"] = ConfigurationManager.AppSettings["PhoneCallCategory"];
                phonecall["subcategory"] = subcategory;
                phonecall["scheduledend"] = DueDate;
                phonecall["description"] = "Alternate Contact no. " +CustomerOtherno + "\r\n" + Description + "\r\n" + ConfigurationManager.AppSettings["Description"];
                if(AssigntoQueueId != Guid.Empty)
                    phonecall["ber_assignedtoqueueid"] = new EntityReference("queue", AssigntoQueueId);
                phonecallid = _service.Create(phonecall);
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "CreatePhoneCall", ex.Message, ex.StackTrace.ToString());
            }
            return phonecallid;
        }
        #endregion

        #region Function to create and send SMS to dealer for payment reminder alert
        public static Guid CreateSMS(Guid CustomerId,string Type, string CustomerPhoneNo,string AmtDue,string DueDate,string CustNumber,string CustName,string slab)
        {
            Guid SMSId = new Guid();
            try
            {
                Entity SMS = new Entity();
                SMS.LogicalName = "pcl_sms";

                EntityCollection tocollection = new EntityCollection();
                Entity toentity = new Entity();
                toentity.LogicalName = "activityparty"; 
                 if (Type == "Dealer")
                 {
                    SMS["description"] = "PAYMENT OF RS " + AmtDue + " IS DUE ON " + DueDate + " FOR " + slab + " SLAB DISCOUNT. KINDLY MAKE THE PAYMENT WITHIN THE DUE DATE . PLEASE IGNORE THE MESSAGE  IF ALREADY PAID. THANK YOU. Berger Paints India";
                    toentity.Attributes["partyid"] = new EntityReference("account", CustomerId);
                    tocollection.Entities.Add(toentity);
                 }
                 else if (Type == "TSI")
                 {
                     SMS["description"] = "PAYMENT OF RS " + AmtDue + " IS DUE ON " + DueDate + " FOR CUSTOMER NUMBER " + CustNumber + ", NAME " + CustName + " " + slab + " SLAB DISCOUNT. KINDLY ENSURE PAYMENT IS MADE. THANK YOU.  Berger Paints India";
                     //toentity.Attributes["partyid"] = new EntityReference("ber_tsi", CustomerId);
                     //tocollection.Entities.Add(toentity);
                 }
               

                SMS["to"] = tocollection;
                SMS["pcl_mobilenumber"] = "91"+CustomerPhoneNo;
                SMS["subject"] = ConfigurationManager.AppSettings["Subject"];
                SMS["ber_smssource"] = new OptionSetValue(Convert.ToInt32(ConfigurationManager.AppSettings["SMSSource"]));
                SMSId = _service.Create(SMS);
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "CreateSMS", ex.Message, ex.StackTrace.ToString());
            }
            return SMSId;
        }
        #endregion

        #region Function to get Queue of Preferred language of Customer
        public static EntityCollection RetriveQueue(Guid LanguageId, string QueueName)
        {
            EntityCollection Resultset = null;
            try
            {
                QueryExpression query = new QueryExpression();
                query.EntityName = "queue";
                query.ColumnSet = new ColumnSet(true);

                ConditionExpression Language = new ConditionExpression();
                Language.AttributeName = "ber_languageid";
                Language.Operator = ConditionOperator.Equal;
                Language.Values.Add(LanguageId);

                ConditionExpression Queue = new ConditionExpression();
                Queue.AttributeName = "name";
                Queue.Operator = ConditionOperator.Equal;
                Queue.Values.Add(QueueName);

                FilterExpression filter = new FilterExpression();
                filter.FilterOperator = LogicalOperator.And;
                if (LanguageId != Guid.Empty)
                    filter.AddCondition(Language);

                else if (QueueName != string.Empty)
                    filter.AddCondition(Queue);

                query.Criteria.AddFilter(filter);

                Resultset = _service.RetrieveMultiple(query);
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to Retrive Queue", "RetriveQueue", ex.Message, ex.StackTrace.ToString());
            }

            return Resultset;
        }
        #endregion

        #region Function to Assign Phone call activity to queue
        public static void AssignPhoneCalltoQueue(Guid QueueId, Guid PhoneCallId, Guid WorkerId)
        {
            try
            {
                Entity QueueItem = new Entity("queueitem");
                QueueItem["queueid"] = new EntityReference("queue", QueueId);
                QueueItem["objectid"] = new EntityReference("phonecall", PhoneCallId);
                QueueItem["workerid"] = new EntityReference("systemuser", WorkerId);
                Guid ID = _service.Create(QueueItem);
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to add phone call in queue", "AssignPhoneCalltoQueue", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion

        #region Function to get Optionset facevalues
        public static Dictionary<string, int> RetrieveAttributeMetadataPicklistValue(IOrganizationService crmService, string EntityName, string FieldName)
        {
            Dictionary<string, int> Classification = new Dictionary<string, int>();
            try
            {
                RetrieveAttributeRequest objRetrieveAttributeRequest;
                objRetrieveAttributeRequest = new RetrieveAttributeRequest();
                objRetrieveAttributeRequest.EntityLogicalName = EntityName;
                objRetrieveAttributeRequest.LogicalName = FieldName;
                // Execute the request
                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)crmService.Execute(objRetrieveAttributeRequest);
                PicklistAttributeMetadata objPckLstAttMetadata = new PicklistAttributeMetadata();
                ICollection<object> objCollection = attributeResponse.Results.Values;

                objPckLstAttMetadata.OptionSet = ((EnumAttributeMetadata)(objCollection.ElementAt(0))).OptionSet;
                OptionMetadataCollection OptionsetCollection = objPckLstAttMetadata.OptionSet.Options;
                string lblAddTypeLabel = string.Empty;
                foreach (OptionMetadata Option in OptionsetCollection)
                {
                    Microsoft.Xrm.Sdk.Label objLabel = Option.Label;
                    lblAddTypeLabel = objLabel.LocalizedLabels.ElementAt(0).Label;
                    Classification.Add(lblAddTypeLabel, Convert.ToInt32(Option.Value));
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error retriving Metadate", "RetrieveAttributeMetadataPicklistValue", ex.Message, ex.StackTrace.ToString());
            }
            return Classification;
        }
        #endregion

        #region Function to Restrive Data from Fetch XMl
        public static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to get Account
        public static EntityCollection getDealers(string AccountNumber)
        {
            EntityCollection ResultSet = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='account'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='accountnumber' operator='eq' value='" + AccountNumber + "' />");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<condition attribute='parentaccountid' operator='null'/>");
                query.Append("</filter>");
                query.Append("<link-entity name='account' from='accountid' to='parentaccountid' visible='false' link-type='outer' >");
                query.Append(" <attribute name='accountnumber' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                ResultSet = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("PaymentReminderBatchService", "getDealers", ex.Message, ex.StackTrace.ToString());
            }
            return ResultSet;                
        }
        #endregion
    }
}
