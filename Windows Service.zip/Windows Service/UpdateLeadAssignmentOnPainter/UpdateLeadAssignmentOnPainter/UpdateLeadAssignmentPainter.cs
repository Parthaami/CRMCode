﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Data;

namespace UpdateLeadAssignmentOnPainter
{
    class UpdateLeadAssignmentPainter
    {
        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;



        static void Main(string[] args)
        {
            try
            {
                string conString = ConfigurationManager.ConnectionStrings["BergerCRMConnectionString"].ToString();
                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["DatabaseName"].ToString();
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString(); 
                string CommandTime = ConfigurationManager.AppSettings["CommandTime"].ToString();

                bergerlogger = new PragmasysLogger(org, logfilepath);
                /*
                ClientCredentials credentials = new ClientCredentials();
                //credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
                credentials.Windows.ClientCredential = new NetworkCredential(UserName,Password,Domain);
               // credentials.Windows.ClientCredential = new NetworkCredential("crmpgm", "berger@123", "bergerindia");
                Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
                Uri homeRealmUri = null;

                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                orgService.EnableProxyTypes();
                */
                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

                using (SqlConnection conn = new SqlConnection())
                {

                    //conn.ConnectionString = "Server=localhost;Database=" + DatabaseName + ";Trusted_Connection=true";
                    conn.ConnectionString = conString;
                    conn.Open();
                    try
                    {

                        SqlCommand Command = new SqlCommand("UPDATE dbo.Contact SET ber_leadsassignedcount = 0, ber_leadsclosedcount = 0", conn);
                        Command.CommandTimeout = Convert.ToInt32(CommandTime);
                         
                        Command.ExecuteNonQuery();
                    }
                    // catch block
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }



                EntityCollection PainterEntityCollection = RetrievePainter(orgService);
                decimal Total_lead_assigned = 0;
                decimal Total_Leads_Converted = 0;



                if (PainterEntityCollection.Entities.Count > 0)
                {
                    foreach (Entity Painter in PainterEntityCollection.Entities)
                    {
                        
                        string painterid = Painter.Id.ToString();

                        EntityCollection LeadEntityCollection = RetrieveLeads(orgService, painterid);
                        if (LeadEntityCollection.Entities.Count != 0)
                        {
                            Total_Leads_Converted = LeadEntityCollection.Entities.Count;
                        }

                        EntityCollection LeadEntityAssignedCollection = RetrieveAssignedLeads(orgService, painterid);
                        if (LeadEntityAssignedCollection.Entities.Count != 0)
                        {
                            Total_lead_assigned = LeadEntityAssignedCollection.Entities.Count;
                        }


                        UpdatePainter(painterid, orgService, Total_Leads_Converted, Total_lead_assigned);


                    }
                }


            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadAssignmentPainter", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        #region "Oragnization"

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion

        public static void UpdatePainter(string ID, IOrganizationService service, decimal Total_Leads_Converted, decimal Total_lead_assigned)
        {
            Entity Painter = new Entity("contact");
            Painter.Attributes["contactid"] = new Guid(ID);
            Painter.Attributes["ber_leadsassignedcount"] = Total_lead_assigned;
            Painter.Attributes["ber_leadsclosedcount"] = Total_Leads_Converted;

            service.Update(Painter);
        }




        public static EntityCollection RetrievePainter(OrganizationServiceProxy orgService)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='contact'>");
                strQuery.Append("<attribute name='fullname' />");
                strQuery.Append("<attribute name='ber_dealerid' />");
                strQuery.Append("<attribute name='ber_leadsassignedcount' />");
                strQuery.Append("<attribute name='ber_leadsclosedcount' />");
                strQuery.Append("<attribute name='ber_customertype' />");
                strQuery.Append("<attribute name='contactid' />");
                strQuery.Append(" <order attribute='fullname' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_customertype' operator='eq' value = '278290001' />");
                strQuery.Append("<condition attribute='statecode' operator='eq' value='0' />");
                strQuery.Append("</filter>");
                strQuery.Append(" <link-entity name='ber_city' from='ber_cityid' to='ber_cityid' visible='false' link-type='outer' alias='a_c86a88638b25e211a39f5ef3fc9cfc97'>");
                strQuery.Append("<attribute name='ber_name' />");
                strQuery.Append("</link-entity>");
                strQuery.Append("<link-entity name='lead' from='ber_masterpainterid' to='contactid' alias='aa'>");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("</filter>");
                strQuery.Append("</link-entity>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("UpdateLeadAssignmentPainter", "RetrievePainters", "Query Generated :" + strQuery, "");
                }

                EntityCollection PainterEntityCollection = Retrieve(orgService, strQuery.ToString());

                return PainterEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadAssignmentPainter", "RetrievePainters", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }


        public static EntityCollection RetrieveLeads(OrganizationServiceProxy orgService, string painterid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='lead'>");
                strQuery.Append("<attribute name='ber_masterpainterid' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("<condition attribute='ber_masterpainterid' value='" + painterid + "' operator='eq'/>");
                strQuery.Append("<condition attribute='statuscode' operator='in' >");
                strQuery.Append("<value>278290005</value>");
                strQuery.Append("<value>278290006</value>");
                strQuery.Append("<value>278290008</value>");
                strQuery.Append("</condition>");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("UpdateLeadAssignmentPainter", "RetrieveLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        public static EntityCollection RetrieveAssignedLeads(OrganizationServiceProxy orgService, string Painterid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='lead'>");
                strQuery.Append("<attribute name='ber_masterpainterid' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("<condition attribute='ber_masterpainterid' value='" + Painterid + "' operator='eq'/>");
                strQuery.Append("</filter>");
                strQuery.Append("</entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveAssignedLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityAssignedCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityAssignedCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveAssignedLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }



        public static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {

                EntityLogicalName = entityName,


                LogicalName = attributeName,


                RetrieveAsIfPublished = true


            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.

            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = string.Empty;
            foreach (Microsoft.Xrm.Sdk.Metadata.OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.UserLocalizedLabel.Label;


                }


            }
            return selectedOptionLabel;
        }

    }
}
