﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Configuration;
using Microsoft.Xrm.Sdk.Query;

namespace Berger.MSCRM.DataMigration
{
    class CRMDataType
    {
        public PragmasysLogger berglogger = null;
        public int loglevel = 0;

        public object getlookupvalue(string Name, string type, string DBConnectionString,string tblname,DataTable _fields,IOrganizationService crmService)
        {
            berglogger = new PragmasysLogger("Berger", ConfigurationManager.AppSettings["loggerpath"]);
            loglevel = Convert.ToInt32(ConfigurationManager.AppSettings["loglevel"]);

            if (String.IsNullOrEmpty(Name))
            {
                return "NULL";
            }
            
            SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();            
            StringBuilder _sqlQueryOptionSet = new StringBuilder();
            
            SqlDataAdapter _sqlAdapter = new SqlDataAdapter();
            StringBuilder _sqlQueryLookup = new StringBuilder();
                        
            string crmconnectionstring = ConfigurationManager.ConnectionStrings["BergerCRMConnectionString"].ConnectionString;
            // Framing the Query string for fetching the data from the corresponding entity staging table. 
            try
            {
                string _fieldsExpression = "fieldname = '" + type+"' and stgtblname = '"+tblname+"'";

                DataRow[] _fieldsdatarow = _fields.Select(_fieldsExpression);
                                
                //This converts values in rows ro aapripriate crm data types
                #region Switch case to conver value to appropriate CRM type
                switch (_fieldsdatarow[0].ItemArray[1].ToString())
                {
                    case "text":
                        try
                        {
                            return Name;
                        }
                        catch (Exception exe)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", exe.Message, exe.StackTrace);
                            return null;
                        }
                        //break;

                    case "optionset":                        
                        _sqlQueryOptionSet.Append("select AttributeValue from stringmap where attributename = '");
                        _sqlQueryOptionSet.Append(type);
                        _sqlQueryOptionSet.Append("' and ObjectTypeCode = '");
                        _sqlQueryOptionSet.Append(_fieldsdatarow[0].ItemArray[4].ToString());
                        _sqlQueryOptionSet.Append("' and Value = '");
                        _sqlQueryOptionSet.Append(Name);
                        _sqlQueryOptionSet.Append("'");

                        try
                        {
                            if (loglevel >= 3)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", "Query for optionset", _sqlQueryOptionSet.ToString());
                            SqlConnection sconn = new SqlConnection(crmconnectionstring);
                            if (string.IsNullOrEmpty(Name))
                            {
                                return "NULL";
                            }
                            sconn.Open();
                            SqlCommand sqlc = new SqlCommand(_sqlQueryOptionSet.ToString(), sconn);

                            SqlDataReader sd = sqlc.ExecuteReader();
                            if (sd.Read())
                            {
                                OptionSetValue op = new OptionSetValue();
                                op.Value = Convert.ToInt32(sd[0].ToString());
                                sconn.Close();
                                return op;
                            }
                        }
                        catch (Exception ex)
                        {
                            //logger
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", ex.Message, ex.StackTrace);
                            return null;
                        }
                        break;

                    case "lookup":
                        _sqlQueryLookup.Append("SELECT " + _fieldsdatarow[0].ItemArray[2].ToString() + "id" + " FROM ");
                        _sqlQueryLookup.Append(_fieldsdatarow[0].ItemArray[2].ToString());
                        _sqlQueryLookup.Append(" where " + _fieldsdatarow[0].ItemArray[3].ToString() + "='");
                        _sqlQueryLookup.Append(Name.Trim());
                        _sqlQueryLookup.Append("'");

                        try
                        {
                            
                            SqlConnection sconn = new SqlConnection(crmconnectionstring);
                            sconn.Open();
                            SqlCommand sqlc = new SqlCommand(_sqlQueryLookup.ToString(), sconn);
                            SqlDataReader sd = sqlc.ExecuteReader();
                            
                            if (sd.Read())
                            {                                
                                EntityReference etref = new EntityReference(_fieldsdatarow[0].ItemArray[2].ToString(), new Guid(sd[0].ToString()));
                                etref.Name = Name;
                                sconn.Close();
                                return etref;
                            }
                            #region Create New shade If Shade is not present in CRM.
                                /**
                            else if (_fieldsdatarow[0].ItemArray[2].ToString().ToLower() == "ber_shade")
                            {
                                if (loglevel >= 3)
                                    berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", "Shade " + Name.Trim() + " Is not present in CRM", "Creating new shade record...");

                                Guid NewShadeId = Guid.Empty;
                                //Check Shade is already present or not.
                                ColumnSet ShadeCols = new ColumnSet();
                                Entity ShadeEntity = new Entity();
                                QueryExpression ShadeQuery = null;
                                EntityCollection ShadeEntityColl = new EntityCollection();
                                ShadeQuery = new QueryExpression("ber_shade");
                                ShadeCols.AddColumns(new string[] { "ber_shadeid" });
                                ShadeQuery.Criteria.AddCondition("ber_name", ConditionOperator.Equal, Name.Trim());
                                ShadeQuery.ColumnSet = ShadeCols;
                                ShadeEntityColl = crmService.RetrieveMultiple(ShadeQuery);

                                if (ShadeEntityColl.Entities.Count > 0)
                                {
                                    EntityReference etref = new EntityReference(_fieldsdatarow[0].ItemArray[2].ToString(), ShadeEntityColl.Entities[0].Id);
                                    etref.Name = Name;
                                    sconn.Close();
                                    return etref;
                                }
                                else if (ShadeEntityColl.Entities.Count == 0)
                                {
                                    Entity newShade = new Entity("ber_shade");
                                    newShade.Attributes["ber_name"] = Name.Trim();
                                    NewShadeId = crmService.Create(newShade);

                                    if (loglevel >= 3)
                                        berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", "Shade created successfuly. ID: " + NewShadeId.ToString(), "New Shade created " + Name.Trim());

                                    EntityReference etref = new EntityReference(_fieldsdatarow[0].ItemArray[2].ToString(), NewShadeId);
                                    etref.Name = Name;
                                    sconn.Close();
                                    return etref;
                                }
                                else
                                {
                                    return null;
                                }
                            }
                                */
                            #endregion
                            else
                            {
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", "Attribute : " + _fieldsdatarow[0].ItemArray[2].ToString(), "Shade" + Name.Trim());
                                return null;
                            }
                        }
                        catch (Exception lookupE)
                        {
                            //logger
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", lookupE.Message, lookupE.StackTrace);
                            return null;
                        }

                    case "decimal":
                        try
                        {
                            if (String.IsNullOrEmpty(Name))
                            {
                                Name = "0";
                            }
                            return Convert.ToDecimal(Name);
                        }
                        catch (Exception decE)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", decE.Message, decE.StackTrace);
                        }
                        break;

                    case "number":
                        try
                        {
                            if (String.IsNullOrEmpty(Name))
                            {
                                Name = "0";
                            }
                            return Convert.ToInt32(Name);
                        }
                        catch (Exception numE)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", numE.Message, numE.StackTrace);
                        }
                        break;

                    case "float":
                        try
                        {
                            if (String.IsNullOrEmpty(Name))
                            {
                                Name = "0";
                            }
                            return Convert.ToDouble(Name);
                        }
                        catch (Exception floE)
                        {

                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", floE.Message, floE.StackTrace);
                        }
                        break;

                    case "datetime":
                        try
                        {
                            return Get_MMDDYY_Date(Name);
                        }
                        catch (Exception dtE)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", dtE.Message, dtE.StackTrace);
                        }
                        break;

                    case "money":
                        try
                        {
                            if (String.IsNullOrEmpty(Name))
                            {
                                Name = "0";
                            }
                            return new Money(Convert.ToDecimal(Name));
                        }
                        catch (Exception moneyE)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", moneyE.Message, moneyE.StackTrace);
                        }
                        break;

                    case "bool":
                        try
                        {
                            if (Name == "1")
                            {
                                return true;
                            }
                            else
                            {
                                return false;
                            }
                        }
                        catch (Exception bE)
                        {
                            if (loglevel >= 2)
                                berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", bE.Message, bE.StackTrace);
                        }
                        break;

                }
                #endregion
            }
            catch (Exception ex)
            {
                if (loglevel >= 1)
                    berglogger.Log("MSCRM.BERGER Data Migration", "CRMDataType", ex.Message, ex.StackTrace);
            }

            return null;
        }

        //For DateTime Type Value
        private DateTime Get_MMDDYY_Date(string datevalue)
        {
            DateTime thedate = DateTime.Now;

            string[] dateArray = datevalue.Split('-');
            try
            {
                if (dateArray.Length == 3 && dateArray.Length > 0)
                {
                    int year = Convert.ToInt32(dateArray[2]);
                    int month = Convert.ToInt32(dateArray[1]);
                    int date = Convert.ToInt32(dateArray[0]);
                    thedate = new DateTime(year, month, date);
                }
            }
            catch (Exception exception)
            {
                if (loglevel >= 2)
                    berglogger.Log("MSCRM.BERGER Data Migration", "Migrate", exception.Message, exception.StackTrace);

                return new DateTime();
            }            
            return thedate;

        }        
    }
}
