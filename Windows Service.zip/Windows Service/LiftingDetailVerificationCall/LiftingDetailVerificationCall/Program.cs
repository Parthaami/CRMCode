﻿// =====================================================================
// <copyright file="Program.cs" company="Pragmasys Consulting LLP">
//    Custom company copyright tag.
// </copyright>
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================
//// Microsoft Dynamics CRM namespace(s)

[assembly: System.CLSCompliant(true)]

namespace LiftingDetailVerificationCall
{
    using System;    
    using System.Collections;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;    
    using System.Net;
    using System.ServiceModel.Description;
    using System.Text;
    using Microsoft.Win32;
    using Microsoft.Xrm.Sdk;     
    using Microsoft.Xrm.Sdk.Client;
    using Microsoft.Xrm.Sdk.Messages;
    using Microsoft.Xrm.Sdk.Query;    
   
    /// <summary>
    /// Class program
    /// </summary>
    class Program
    {
        /// <summary>
        /// CRM organization service object
        /// </summary>
        private static IOrganizationService service;

        /// <summary>
        /// Logger class object
        /// </summary>
        private static Logger objLogger;
   
        /// <summary>
        /// Variable used to store server url
        /// </summary>
        private static string serverUrl = string.Empty;

        /// <summary>
        /// Configuration object
        /// </summary>
        private static Configuration config;

        /// <summary>
        /// Variable used to store organization name
        /// </summary>
        private static string organizationName = ConfigurationManager.AppSettings["OrganisationName"];              
       
        /// <summary>
        /// Main method
        /// </summary>        
       public static void Main()
        {
            try
            {     
                
                string crmPath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string db_Path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(crmPath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        db_Path = value64;
                    }
                }

                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(crmPath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        db_Path = value32;
                    }
                }

                 ////<summary>
                 ////Registry entry not required
                 ////If in code want to use configration file 
                 ////Add configration file in CRMWeb\ISV folder Pragmasys.config
                 ////if Configration file is not used comment the code.      
                 ////</summary>
                 
                string configpath = db_Path + "\\CRMWeb\\ISV\\" + organizationName + "\\Pragmasys.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    ////  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        objLogger = new Logger(organizationName, loggerPath);
                        serverUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                    }
                }            
                
                ////Get Organisation Service
                service = Program.GetService();

                ////Call CreatePhoneCall Method for Creating phone call activities.
                Program.CreatePhoneCall();
            }
            catch (Exception ex)
            {
                objLogger.Log("LiftingDetailVerificationCall", "Main", "Error : ", ex.Message.ToString());
            }
        }
            
        /// <summary>
        /// Function to get CRM service
        /// </summary>
        /// <returns>Organization service object</returns>
        public static IOrganizationService GetService()
        {
            IOrganizationService crmsvc = null;
            try
            {
                //For Development
                //Please comment the section before Production Deployment
                //========================================================
                //ClientCredentials credentials = new ClientCredentials();                
                //credentials.Windows.ClientCredential = new System.Net.NetworkCredential("crmadmqa", "neempata#1", "bergerindia");
                //string orgUrl = "http://10.62.163.60:6505/BergerQA/XRMServices/2011/Organization.svc";
                //string orgUrl = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
                //===================================================================================

                
                // For Production
                ClientCredentials credentials = new ClientCredentials();
                credentials.Windows.ClientCredential = (NetworkCredential)System.Net.CredentialCache.DefaultCredentials;  
                Uri organizationUri = new Uri(serverUrl);
                //====================================================================================

                
                //Uri organizationUri = new Uri(orgUrl);
                Uri homeRealmUri = null;
                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                //orgService.EnableProxyTypes();
                crmsvc = (IOrganizationService)orgService;
            }
            catch (Exception ex)
            {
                objLogger.Log("Error while retriving CRM Service", "GetService", ex.Message, ex.StackTrace.ToString());
            }

            return crmsvc;
        }       

        /// <summary>
        /// Function to retrieve lifting details,dealer details for phone call creation.
        /// </summary>
        public static void CreatePhoneCall()
        {
            try
            {
                EntityCollection liftingDetailsCollection = RetrieveActiveLiftingDetails(service);

                if (liftingDetailsCollection.Entities.Count > 0)
                {
                    ArrayList list = new ArrayList();
                    foreach (Entity e in liftingDetailsCollection.Entities)
                    {
                        if (e.Attributes.Contains("ber_dealerid"))
                        {
                            if (!list.Contains(((EntityReference)e.Attributes["ber_dealerid"]).Id))
                            {
                                string queueName = null;
                                ////adding to list
                                list.Add(((EntityReference)e.Attributes["ber_dealerid"]).Id);

                                ////Verify that their is any outbound phone call present for dealer or not.
                                ////If yes update Verify Lifting Details flag on the same phonecall activity
                                ////else create new phone call record.                                
                                Guid existingPhoneCallId = IsAnyPhoneCallOpen(((EntityReference)e.Attributes["ber_dealerid"]).Id);
                                if (existingPhoneCallId != Guid.Empty)
                                {
                                    ////Update Verify Lifting Details flag
                                    Entity phoneCall = new Entity("phonecall");
                                    phoneCall.Id = existingPhoneCallId;
                                    phoneCall["ber_verifyliftingdetails"] = true;
                                    service.Update(phoneCall);
                                }
                                else
                                {
                                    Entity dealer = service.Retrieve("account", ((EntityReference)e.Attributes["ber_dealerid"]).Id, new ColumnSet(true));
                                    EntityCollection queueCollection = new EntityCollection();
                                    if (dealer.Attributes.Contains("ber_preferredlanguage1"))
                                    {
                                        EntityReference lang1 = (EntityReference)dealer.Attributes["ber_preferredlanguage1"];
                                        queueCollection = FindQueue1(lang1, queueName);
                                    }
                                    else if (dealer.Attributes.Contains("ber_preferredlanguage2"))
                                    {
                                        EntityReference lang2 = (EntityReference)dealer.Attributes["ber_preferredlanguage2"];
                                        queueCollection = FindQueue1(lang2, queueName);
                                    }
                                    else
                                    {
                                        queueName = ConfigurationManager.AppSettings["DefaultQueueName"];
                                        queueCollection = FindQueue1(null, queueName);
                                    }

                                    ////Create phone call to verify lefting details from Dealer.
                                    Guid callGuid = CreateOutBoundPhoneRecord(((EntityReference)e.Attributes["ber_dealerid"]).Id, queueCollection);

                                    if (queueCollection != null && queueCollection.Entities.Count > 0)
                                    {
                                        CreateQueueItem(queueCollection.Entities[0], callGuid);
                                    }
                                }
                            }
                        }
                        else
                        {
                            objLogger.Log("LiftingDetailVarificationCall", "CreatePhoneCall", "Dealer is not present in this lifting details record", "Lifting Details Id: " + e.Id.ToString());
                        }
                    }
                }
                else
                {
                    objLogger.Log("LiftingDetailVarificationCall", "CreatePhoneCall", "Lifting Details not present for verification.", string.Empty);
                }
            }
            catch (Exception ex)
            {
                objLogger.Log("LiftingDetailVarificationCall", "CreatePhoneCall", "ERROR: ", ex.InnerException.ToString());
            }
        }

        /// <summary>
        /// Function to check open phone call activity for dealer
        /// </summary>
        /// <param name="customerId">Dealer unique id</param>
        /// <returns>Existing phone call unique id</returns>
        public static Guid IsAnyPhoneCallOpen(Guid customerId)
        {
            Guid existingPhoneCallRecordId = Guid.Empty;
            try
            {                
                EntityCollection entitiesCollection = new EntityCollection();
                QueryExpression retrievePhoneCall = new QueryExpression("phonecall");
                retrievePhoneCall.ColumnSet = new ColumnSet(true);

                ConditionExpression sortExpression1 = new ConditionExpression();
                sortExpression1.AttributeName = "regardingobjectid";
                sortExpression1.Operator = ConditionOperator.Equal;
                sortExpression1.Values.Add(customerId);

                ConditionExpression sortExpression2 = new ConditionExpression();
                sortExpression2.AttributeName = "statecode";
                sortExpression2.Operator = ConditionOperator.Equal;
                sortExpression2.Values.Add(0);

                ConditionExpression sortExpression3 = new ConditionExpression();
                sortExpression3.AttributeName = "category";
                sortExpression3.Operator = ConditionOperator.Equal;
                sortExpression3.Values.Add("Order Booking");               

                FilterExpression ofilter = new FilterExpression();
                ofilter.FilterOperator = LogicalOperator.And;
                ofilter.Conditions.Add(sortExpression1);
                ofilter.Conditions.Add(sortExpression2);
                ofilter.Conditions.Add(sortExpression3);

                retrievePhoneCall.Criteria.Filters.Add(ofilter);

                RetrieveMultipleRequest request = new RetrieveMultipleRequest();
                request.Query = retrievePhoneCall;
                RetrieveMultipleResponse response = null;
                response = (RetrieveMultipleResponse)service.Execute(request);

                if (response.EntityCollection.Entities.Count > 0)
                {
                    existingPhoneCallRecordId = response.EntityCollection.Entities[0].Id;
                }
            }
            catch (Exception ex)
            {
                objLogger.Log("Error retriving customer open phone calls", "IsAnyPhoneCallOpen", ex.Message, ex.StackTrace.ToString());
            }

            return existingPhoneCallRecordId;
        }

        /// <summary>
        /// Function to create phone call.
        /// </summary>
        /// <param name="guid">Receiver unique id</param>
        /// <param name="queueCollection">collection of CRM queue</param>
        /// <returns>New phone call unique id</returns>
        public static Guid CreateOutBoundPhoneRecord(Guid guid, EntityCollection queueCollection)
        {            
            Guid callGuid = new Guid();
            try
            {
                Entity dealer = service.Retrieve("account", guid, new ColumnSet(true));

                Entity phoneCall = new Entity("phonecall");
                
                EntityCollection toParty = new EntityCollection();
                Entity eref = new Entity("activityparty");
                eref["partyid"] = new EntityReference(dealer.LogicalName, dealer.Id);
                toParty.EntityName = "activityparty";
                toParty.Entities.Add(eref);

                phoneCall.Attributes["to"] = toParty;
                phoneCall.Attributes["regardingobjectid"] = new EntityReference(dealer.LogicalName, dealer.Id);
                phoneCall.Attributes["directioncode"] = Convert.ToBoolean(1);
                phoneCall.Attributes["subject"] = ConfigurationManager.AppSettings["Subject"];
                
                DateTime call_date = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 10, 00, 00);
                phoneCall.Attributes["scheduledend"] = call_date;

                phoneCall["ber_verifyliftingdetails"] = true;
                ////phoneCall.Attributes["category"] = ConfigurationManager.AppSettings["PhoneCallCategory"];
                ////phoneCall.Attributes["subcategory"] = ConfigurationManager.AppSettings["PhoneCallSubCategory"];

                if (dealer.Attributes.Contains("telephone1"))
                {
                    phoneCall.Attributes["phonenumber"] = dealer.Attributes["telephone1"];
                }

                if (queueCollection != null && queueCollection.Entities.Count > 0)
                {
                    phoneCall.Attributes["ber_assignedtoqueueid"] = new EntityReference("queue", queueCollection.Entities[0].Id);
                }

                string description = "Painter Lifting Verification \nDealer Details:\n Dealer:" + dealer.Attributes["name"];
                description = description + "\nContact Person:";

                string contPerson = null;
                if (dealer.Attributes.Contains("address1_name"))
                {
                    contPerson = dealer.Attributes["address1_name"].ToString();
                }

                if (contPerson != null)
                {
                    description = description + " " + contPerson;
                }

                if (dealer.Attributes.Contains("telephone1"))
                {
                    description = description + "\n " + dealer.Attributes["telephone1"].ToString();
                }

                if (dealer.Attributes.Contains("telephone2"))
                {
                    description = description + "\n " + dealer.Attributes["telephone2"].ToString();
                }

                phoneCall.Attributes["description"] = description;

                callGuid = service.Create(phoneCall);
            }
            catch (Exception ex)
            {
                objLogger.Log("LiftingDetailVarificationCall", "createOutBoundPhoneRecord", "Error : ", ex.Message.ToString());
            }            

            return callGuid;
        }

        /// <summary>
        /// Function to get queue collection from CRM based on language.
        /// </summary>
        /// <param name="pref_lang">Language lookup</param>
        /// <param name="queueName">Queue name</param>
        /// <returns>Entity collection</returns>
        public static EntityCollection FindQueue1(EntityReference pref_lang, string queueName)
        {
            try
            {
                QueryExpression retrieveQueue = new QueryExpression("queue");
                retrieveQueue.ColumnSet = new ColumnSet(true);
                FilterExpression ofilter = new FilterExpression();
                ofilter.FilterOperator = LogicalOperator.And;

                if (pref_lang != null && pref_lang.Id != null)
                {
                    ConditionExpression exp = new ConditionExpression();
                    exp.AttributeName = "ber_languageid";
                    exp.Operator = ConditionOperator.Equal;
                    exp.Values.Add(pref_lang.Id);
                    ofilter.Conditions.Add(exp);
                }

                if (pref_lang == null && queueName != null)
                {
                    ConditionExpression queue = new ConditionExpression();
                    queue.AttributeName = "name";
                    queue.Operator = ConditionOperator.Equal;
                    queue.Values.Add(queueName);
                    ofilter.Conditions.Add(queue);
                }

                retrieveQueue.Criteria.Filters.Add(ofilter);

                EntityCollection lang_queue = service.RetrieveMultiple(retrieveQueue);

                if (lang_queue.Entities != null && lang_queue.Entities.Count > 0)
                {
                    objLogger.Log("LiftingDetailVarificationCall", "FindQueue1", "No of queues found: " + lang_queue.Entities.Count.ToString(), "first queue id " + lang_queue.Entities[0].Id);
                    return lang_queue;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Function to add newly created phone call record into specific language queue.
        /// </summary>
        /// <param name="langQueue">Entity queue object</param>
        /// <param name="phoneCallGuid">Newly created phone call record unique id</param>
        public static void CreateQueueItem(Entity langQueue, Guid phoneCallGuid)
        {
            try
            {
                EntityReference workerId = null;
                if (langQueue.Attributes.Contains("ownerid"))
                {
                    workerId = (EntityReference)langQueue.Attributes["ownerid"];
                }

                Entity queueItem = new Entity();
                queueItem.LogicalName = "queueitem";
                queueItem.Attributes["queueid"] = new EntityReference("queue", langQueue.Id);
                queueItem.Attributes["objectid"] = new EntityReference("phonecall", phoneCallGuid);
                queueItem.Attributes["workerid"] = new EntityReference("systemuser", workerId.Id);
                service.Create(queueItem);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Function to retrieve lifting details which has status Entered
        /// </summary>
        /// <param name="service">Organization service object.</param>
        /// <returns>Lifting details collection</returns>
        public static EntityCollection RetrieveActiveLiftingDetails(IOrganizationService service)
        {
            try
            {
                EntityCollection entitiesCollection = new EntityCollection();
                QueryExpression retrieveQuery = new QueryExpression("ber_liftingdetails");
                retrieveQuery.ColumnSet = new ColumnSet(true);

                
                 // Comment for issue #A0824, blank phone call gets generated for lifting
                /*
                ConditionExpression sortExpression = new ConditionExpression();
                sortExpression.AttributeName = "statuscode";
                sortExpression.Operator = ConditionOperator.Equal;
                sortExpression.Values.Add(1);

                FilterExpression ofilter = new FilterExpression();
                ofilter.FilterOperator = LogicalOperator.And;
                ofilter.Conditions.Add(sortExpression);
                */
                
                
                // Code change Start Changed for A0824
                
                ConditionExpression statusCode = new ConditionExpression();
                statusCode.AttributeName = "statuscode";
                statusCode.Operator = ConditionOperator.Equal;
                statusCode.Values.Add(1);

                ConditionExpression isLiftingCreated = new ConditionExpression();
                isLiftingCreated.AttributeName = "ber_iscreated";
                isLiftingCreated.Operator = ConditionOperator.Equal;
                isLiftingCreated.Values.Add(true);

                FilterExpression ofilter = new FilterExpression();
                ofilter.FilterOperator = LogicalOperator.And;
                ofilter.Conditions.Add(statusCode);
                ofilter.Conditions.Add(isLiftingCreated);
                
                // Code change End Changed for A0824
                

                retrieveQuery.Criteria.Filters.Add(ofilter);

                RetrieveMultipleRequest request = new RetrieveMultipleRequest();
                request.Query = retrieveQuery;
                RetrieveMultipleResponse response = null;
                try
                {
                    response = (RetrieveMultipleResponse)service.Execute(request);
                }
                catch (Exception exception1)
                {
                    objLogger.Log("retrievecontacts", "Execute", "Error while retrieving lifting details ", exception1.Message);
                    throw new InvalidPluginExecutionException(exception1.Message, exception1);
                }

                entitiesCollection = response.EntityCollection;
                return entitiesCollection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
