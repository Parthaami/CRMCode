﻿// =====================================================================
// <copyright file="Logger.cs" company="Pragmasys Consulting LLP">
//     Custom company copyright tag.
// </copyright>
//  Pragmasys Consulting LLP (c).  All rights reserved.
// =====================================================================
//// Microsoft Dynamics CRM namespace(s)

namespace LiftingDetailVerificationCall
{
    using System;
    using System.IO;
    using System.Text;    

    /// <summary>
    /// Class Logger
    /// </summary>
    public class Logger
    {
        /// <summary>
        /// Private variable used to store organization name
        /// </summary>
        private string organization;

        /// <summary>
        /// Private variable used to store log file path
        /// </summary>
        private string filePath;

        /// <summary>
        /// Private variable used to store logger directory path
        /// </summary>
        private string folderpath = string.Empty;

        /// <summary>
        /// Initialize a new instance of the <see cref="Logger"/> class
        /// </summary>
        /// <param name="organizationName">Organization name</param>
        /// <param name="configurationfilepath">Logger file path</param>
        public Logger(string organizationName, string configurationfilepath)
        {
            this.organization = organizationName;
            this.folderpath = configurationfilepath;
        }

        /// <summary>
        /// Method to print log into text file
        /// </summary>
        /// <param name="sourceName">Source program name</param>
        /// <param name="methodName">Method name</param>
        /// <param name="description">Error description</param>
        /// <param name="errorMessage">Error</param>
        public void Log(string sourceName, string methodName, string description, string errorMessage)
        {
            try
            {
                this.filePath = this.folderpath + "Log_LiftingDetailVerificationCall_" + this.organization + ".txt";
                string[] errorLogs = { sourceName, methodName, description, errorMessage };
                if (!Directory.Exists(this.folderpath))
                {
                    Directory.CreateDirectory(this.folderpath);
                }

                if (!File.Exists(this.filePath))
                {
                    FileStream objFile = new FileStream(this.filePath, FileMode.Create, FileAccess.Write);
                    objFile.Close();
                    StreamWriter file = new StreamWriter(this.filePath);
                    file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.WriteLine(" S.No.       CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Write("*.");
                    file.Write("\t");
                    file.Write(System.DateTime.Now);
                    file.Write("\t\t");
                    foreach (string log in errorLogs)
                    {
                        file.Write(log);
                        file.Write("\t\t");
                    }

                    file.WriteLine(string.Empty);
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Close();
                }
                else
                {
                    File.AppendAllText(this.filePath, System.Environment.NewLine);
                    File.AppendAllText(this.filePath, "*.");
                    File.AppendAllText(this.filePath, "\t");
                    File.AppendAllText(this.filePath, System.DateTime.Now.ToString());
                    File.AppendAllText(this.filePath, "\t\t");
                    foreach (string log in errorLogs)
                    {
                        File.AppendAllText(this.filePath, log);
                        File.AppendAllText(this.filePath, "\t\t");
                    }

                    File.AppendAllText(this.filePath, System.Environment.NewLine);
                    File.AppendAllText(this.filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                }
            }
            catch (Exception)
            {
                ////throw ex;
            }
        }
    }
}
