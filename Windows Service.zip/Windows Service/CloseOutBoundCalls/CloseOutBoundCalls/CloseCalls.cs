﻿//========================================================================
//  CloseOutBoundCalls is a windows service which executes on daily basis.
//  The functionality of this service is it Close the existing Outbound phone call
//  which are created yesterday and not completed yet.
//
//  Copyright @ Pragmasys Consulting LLP
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Crm.Sdk.Messages;

namespace CloseOutBoundCalls
{
    class CloseCalls
    {

        #region Class Level Members

        private static IOrganizationService _service;

        static Logger oLogger;
        public static string _loggerPath = string.Empty;
        static string Loggerpath = string.Empty;
        static string serverUrl = string.Empty;
        static Configuration config;
        static string _organizationName = ConfigurationManager.AppSettings["OrganisationName"];
        static string _CrmServiceUrl = string.Empty;
        static string _callCategory = ConfigurationManager.AppSettings["Category"];
        static string _CustomerPhoneNo = string.Empty;
        static string _Description = string.Empty;
      

        #endregion
        static void Main(string[] args)
        {
            try
            {
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_organizationName, _loggerPath);
                    }
                }
            
                _service = GetService();

                EntityCollection OpenPhoneCalls = RetriveOutboundCalls(_service);
                foreach (Entity PhoneCall in OpenPhoneCalls.Entities)
                {
                    if (PhoneCall.Attributes.Contains("description"))
                        _Description = Convert.ToString(PhoneCall.Attributes["description"]);

                    //Update The phone call description Field
                    Entity NewPhoneCall = new Entity("phonecall");
                    NewPhoneCall.Id = PhoneCall.Id;
                    NewPhoneCall["description"] = _Description +"\r\n"+ ConfigurationManager.AppSettings["NewDescription"];
                    _service.Update(NewPhoneCall);

                    //Cancel the Phone Call Activity
                    CancelPhoneCall(_service, PhoneCall.Id);
                             
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Phone Calls", "Main Method", ex.Message, ex.StackTrace.ToString());
            }
        }

        #region Function to get CRM Service
        /// <summary>
        /// Get CRM Service.
        /// </summary>
        /// <returns></returns>
        public static IOrganizationService GetService()
        {
            IOrganizationService crmsvc = null;
            try
            {
                IServiceManagement<IOrganizationService> orgServiceManagement =
                  ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                  new Uri(ConfigurationManager.AppSettings["ServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy organizationServiceProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                organizationServiceProxy.EnableProxyTypes();
                crmsvc = (IOrganizationService)organizationServiceProxy;

            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving CRM Service", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return crmsvc;
        }

        private static TProxy GetProxy<TService, TProxy>(
        IServiceManagement<TService> serviceManagement,
        AuthenticationCredentials authCredentials)
        where TService : class
        where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Function to retrive Open Phone Calls
        public static EntityCollection RetriveOutboundCalls(IOrganizationService _service)
        {
            EntityCollection ResultSet = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='phonecall'>");
                query.Append("<attribute name='subject' />");
                query.Append("<attribute name='statecode' />");
                query.Append("<attribute name='scheduledend' />");
                query.Append("<attribute name='description' />");
                query.Append("<attribute name='activityid' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='directioncode' operator='eq' value='1' />");
                query.Append("<condition attribute='category' operator='eq' value='" + _callCategory + "' />");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                ResultSet = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Open Phone Calls", "RetriveOutboundCalls", ex.Message, ex.StackTrace.ToString());
            }
            return ResultSet;
        }
        #endregion

        #region Function to Restrive Phone Call from Fetch XMl
        private static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error In Fetch XML", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to Cancel Phone Calls Which are not completed by CSR
        private static void CancelPhoneCall(IOrganizationService _service, Guid PhoneCallId)
        {
            try
            {
                SetStateRequest request = new SetStateRequest();
                request.EntityMoniker = new EntityReference("phonecall", PhoneCallId);
                request.State = new OptionSetValue(2);
                request.Status = new OptionSetValue(3);

                SetStateResponse responce = (SetStateResponse)_service.Execute(request);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error in Canceling Open Phone Calls", "CancelPhoneCall", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion
    }
}
