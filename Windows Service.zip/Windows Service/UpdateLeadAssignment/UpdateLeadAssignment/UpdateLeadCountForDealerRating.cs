﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Data;

namespace UpdateLeadAssignment
{
    class UpdateLeadCountForDealerRating
    {

        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;


        static void Main(string[] args)
        {
            try
            {
                string conString = ConfigurationManager.ConnectionStrings["BergerCRMConnectionString"].ToString();
                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["DatabaseName"].ToString();

                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString(); 

                bergerlogger = new PragmasysLogger(org, logfilepath);

                /*
                ClientCredentials credentials = new ClientCredentials();
                //credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
                  credentials.Windows.ClientCredential = new NetworkCredential(UserName,Password,Domain);
                //credentials.Windows.ClientCredential = new NetworkCredential("crmpgm", "berger@123", "bergerindia");
                Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
                Uri homeRealmUri = null;

                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                orgService.EnableProxyTypes();
                */
                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

                using (SqlConnection conn = new SqlConnection())
                {

                    //conn.ConnectionString = "Server=localhost;Database="+DatabaseName+";Trusted_Connection=true";
                    conn.ConnectionString = conString;
                    conn.Open();
                    try
                    {
                       
                        SqlCommand Command = new SqlCommand("UPDATE account SET ber_leadsassigned = 0, ber_leadsclosed = 0", conn);
                        
                        Command.ExecuteNonQuery();
                    }
                    // catch block
                    catch (SqlException er)
                    {
                        
                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }



                EntityCollection DealerEntityCollection = RetrieveDealers(orgService);
                decimal Total_lead_assigned = 0;
                decimal Total_Leads_Converted = 0;



                if (DealerEntityCollection.Entities.Count > 0)
                {
                    foreach (Entity Dealer in DealerEntityCollection.Entities)
                    {

                        string dealerid = Dealer.Id.ToString();

                        EntityCollection LeadEntityCollection = RetrieveLeads(orgService, dealerid);
                        if (LeadEntityCollection.Entities.Count != 0)
                        {
                            Total_Leads_Converted = LeadEntityCollection.Entities.Count;
                        }

                        EntityCollection LeadEntityAssignedCollection = RetrieveAssignedLeads(orgService, dealerid);
                        if (LeadEntityAssignedCollection.Entities.Count != 0)
                        {
                            Total_lead_assigned = LeadEntityAssignedCollection.Entities.Count;
                        }

                       UpdateDealer(dealerid, orgService, Total_Leads_Converted, Total_lead_assigned);

                    }
                }


            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        #region "Oragnization"

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion

        public static void UpdateDealer(string ID, IOrganizationService service, decimal Total_Leads_Converted, decimal Total_lead_assigned)
        {
            Entity Dealer = new Entity("account");
            Dealer.Attributes["accountid"] = new Guid(ID);
            Dealer.Attributes["ber_leadsassigned"] = Total_lead_assigned;
            Dealer.Attributes["ber_leadsclosed"] = Total_Leads_Converted;

            service.Update(Dealer);
        }




        public static EntityCollection RetrieveDealers(OrganizationServiceProxy orgService)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='account'>");
                strQuery.Append("<attribute name='name' />");
                strQuery.Append("<attribute name='accountnumber' />");
                strQuery.Append("<attribute name='accountid' />");
                strQuery.Append(" <order attribute='name' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='parentaccountid' operator='null' />");
                strQuery.Append("<condition attribute='statecode' operator='eq' value='0' />");
                strQuery.Append("</filter>");
                strQuery.Append(" <link-entity name='account' from='accountid' to='parentaccountid' visible='false' link-type='outer' alias='a_57511732b5534cfbbcf2d280f9f8c6f1'>");
                strQuery.Append("<attribute name='accountnumber' />");
                strQuery.Append("</link-entity>");
                strQuery.Append("<link-entity name='lead' from='ber_dealerid' to='accountid' alias='aa'>");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("</filter>");
                strQuery.Append("</link-entity>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("DealerRating", "RetrieveDealers", "Query Generated :" + strQuery, "");
                }

                EntityCollection DealerEntityCollection = Retrieve(orgService, strQuery.ToString());

                return DealerEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveDealers", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }


        public static EntityCollection RetrieveLeads(OrganizationServiceProxy orgService, string Dealerid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='lead'>");
                strQuery.Append("<attribute name='ber_dealerid' />");
                strQuery.Append(" <filter type='and'>");               
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("<condition attribute='ber_dealerid' value='" + Dealerid + "' operator='eq'/>");
                strQuery.Append("<condition attribute='statuscode' operator='in' >");
                strQuery.Append("<value>278290005</value>");
                strQuery.Append("<value>278290006</value>");
                strQuery.Append("<value>278290008</value>");
                strQuery.Append("</condition>");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        public static EntityCollection RetrieveAssignedLeads(OrganizationServiceProxy orgService, string Dealerid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='lead'>");
                strQuery.Append("<attribute name='ber_dealerid' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='modifiedon' operator='this-month' />");
                strQuery.Append("<condition attribute='ber_dealerid' value='" + Dealerid + "' operator='eq'/>");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveAssignedLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityAssignedCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityAssignedCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadCountForDealerRating", "RetrieveAssignedLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }



        public static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {

                EntityLogicalName = entityName,


                LogicalName = attributeName,


                RetrieveAsIfPublished = true


            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.

            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = string.Empty;
            foreach (Microsoft.Xrm.Sdk.Metadata.OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.UserLocalizedLabel.Label;


                }


            }
            return selectedOptionLabel;
        }

    }
}
