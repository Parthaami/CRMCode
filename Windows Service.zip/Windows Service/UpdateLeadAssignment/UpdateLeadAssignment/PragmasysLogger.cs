﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace UpdateLeadAssignment
{
    public class PragmasysLogger
    {
        string _orgnisationName = string.Empty;
        string _filePath = string.Empty;
        private static Object _Lock = new object();

        public PragmasysLogger(string Orgnisation, string FilePath)
        {
            _orgnisationName = Orgnisation;
            _filePath = FilePath + "Log_UpdateLeadCountForDealerRating_" + Orgnisation + ".txt";
        }
        /// <summary>
        /// Adds a Log Entry to log file specified in File Path. 
        /// </summary>
        /// <param name="SourceName">Exception.Source</param>
        /// <param name="MethodName">The Method name in Which error has occured</param>
        /// <param name="description">Exception.message</param>
        /// <param name="ErrorMessage">Exception.stackTrace</param>
        public void Log(string SourceName, string MethodName, string description, string ErrorMessage)
        {

            try
            {
                lock (_Lock)
                {
                    string fullpath = Path.GetFullPath(_filePath);
                    string directory = Path.GetDirectoryName(fullpath);
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }
                    string[] ErrorLogs = { SourceName, MethodName, description, ErrorMessage };
                    if (!File.Exists(_filePath))
                    {
                        FileStream aFile = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                        aFile.Close();
                        StreamWriter file = new StreamWriter(_filePath);
                        file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        file.WriteLine(" S.No.       CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
                        file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        file.Write("*.");
                        file.Write("\t");
                        file.Write(System.DateTime.Now);
                        file.Write("\t\t");
                        foreach (string log in ErrorLogs)
                        {
                            file.Write(log);
                            file.Write("\t\t");
                        }
                        file.WriteLine("");
                        file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                        file.Close();
                    }
                    else
                    {
                        //string [] AllLines= File.ReadAllLines(_filePath);
                        //int totalLines = AllLines.GetLength(0);
                        //int newNumber = totalLines - 2;
                        File.AppendAllText(_filePath, System.Environment.NewLine);
                        File.AppendAllText(_filePath, "*.");
                        File.AppendAllText(_filePath, "\t");
                        File.AppendAllText(_filePath, System.DateTime.Now.ToString());
                        File.AppendAllText(_filePath, "\t\t");
                        foreach (string log in ErrorLogs)
                        {
                            File.AppendAllText(_filePath, log);
                            File.AppendAllText(_filePath, "\t\t");
                        }
                        File.AppendAllText(_filePath, System.Environment.NewLine);
                        File.AppendAllText(_filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void TimerLog(string Timer)
        {

            try
            {
                lock (_Lock)
                {
                    string fullpath = Path.GetFullPath(_filePath);
                    string directory = Path.GetDirectoryName(fullpath);
                    if (!Directory.Exists(directory))
                    {
                        Directory.CreateDirectory(directory);
                    }
                    string[] ErrorLogs = { Timer };
                    if (!File.Exists(_filePath))
                    {
                        FileStream aFile = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                        aFile.Close();
                        StreamWriter file = new StreamWriter(_filePath);
                        file.WriteLine("------------------------------------------------------------------------------");
                        file.WriteLine("\t\t Time ");
                        file.WriteLine("------------------------------------------------------------------------------");
                        file.Write("*.");
                        file.Write("\t\t");
                        foreach (string log in ErrorLogs)
                        {
                            file.Write(log);
                            file.Write("\t\t");
                        }
                        file.WriteLine("");
                        file.WriteLine("-----------------------------------------------------------------------------");
                        file.Close();
                    }
                    else
                    {
                        //string [] AllLines= File.ReadAllLines(_filePath);
                        //int totalLines = AllLines.GetLength(0);
                        //int newNumber = totalLines - 2;
                        File.AppendAllText(_filePath, System.Environment.NewLine);
                        File.AppendAllText(_filePath, "*.");
                        File.AppendAllText(_filePath, "\t\t");
                        foreach (string log in ErrorLogs)
                        {
                            File.AppendAllText(_filePath, log);
                            File.AppendAllText(_filePath, "\t\t");
                        }
                        File.AppendAllText(_filePath, System.Environment.NewLine);
                        File.AppendAllText(_filePath, "-------------------------------------------------------------");
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
