using System;
using System.Globalization;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

 

namespace Berger_SubDealerIntegration
{
    class DBHelper
    {
        #region declare all the local Variables

        string _sqlConnectionString = Program.DBConnectionString;
        string _OracleConnectionString = string.Empty;
        
        #endregion

        #region Opend DB Connection
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlConnectionString"></param>
        /// <returns>SqlConnection</returns>
        private SqlConnection OpenDBConnection(string sqlConnectionString)
        {
            SqlConnection _sqlConnection = null;
            try
            {

                _sqlConnection = new SqlConnection();
                _sqlConnection.ConnectionString = sqlConnectionString;
                _sqlConnection.Open();

            }
            catch (Exception ex)
            {
                //  string x= ex.ToString();
            }
            return _sqlConnection;
        }
        #endregion

        #region Close DB Connection
        private void CloseDBConnection(SqlConnection sqlConnection)
        {
            try
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                string x = ex.ToString();
                throw;
            }
        }
        #endregion

        #region Getting the record as DataTable from the Database
        public DataTable GetDataTable(string _sqlConnectionString)
        {
            DataTable _datatable = null;
            SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();
            StringBuilder _sqlQuery = new StringBuilder();             
            try
            {
                
                SqlDataAdapter _sqlAdapter = new SqlDataAdapter();
                StringBuilder _sqlQry = new StringBuilder();
                // Framing the Query string for fetching the data from the corresponding entity staging table. 
                _sqlQuery.Append("SELECT * FROM SubDealer_Contact where status='R'");                
                // Query the database for all of the data in the corresponding entity staging table.
                _sqlDbAdapter = new SqlDataAdapter(_sqlQuery.ToString(), _sqlConnectionString);
                // Create a data set containing the data from the corresponding entity staging table.
                DataSet _dataSet = new DataSet("Contact");
                _dataSet.Locale = CultureInfo.InvariantCulture;
                //Fill the DataSet
                _sqlDbAdapter.Fill(_dataSet, "Contact");
                // Return the file data as an ADO.NET DataTable.
                _datatable = _dataSet.Tables[0];
                Console.WriteLine("Total data retrieved" +_datatable.Rows.Count.ToString());
            }
            catch
            {
                throw new Exception("Exception occured while fetching data from staging table");
            }
            finally
            {
                _sqlDbAdapter.Dispose();
            }

            return _datatable;
        }
        #endregion       

        #region Getting the record as DataTable from the Oracle Database
        public DataTable GetOracleDataTable()
        {
            DataTable dt = new DataTable();
            OleDbConnection conn=null;
            OleDbCommand cm =null;
            OleDbDataAdapter da =null;
            int MaxId=0;

            try
            {
                #region Retrieving new records
                Console.WriteLine("Connecting Oracle to retrieve data");
                // _OracleConnectionString = "Provider=MSDAORA;Data Source=" + ConfigurationManager.AppSettings["OracleDataSource"] + ";User ID=" + ConfigurationManager.AppSettings["OracleUserId"] + ";Password=" + ConfigurationManager.AppSettings["OraclePwd"] + ";Unicode=True";
                _OracleConnectionString = "Provider=OraOLEDB.Oracle;Data Source=" + ConfigurationManager.AppSettings["OracleDataSource"] + ";User ID=" + ConfigurationManager.AppSettings["OracleUserId"] + ";Password=" + ConfigurationManager.AppSettings["OraclePwd"] + ";Unicode=True";

                
                 //Provider=MSDAORA;Data Source=BPQA;User ID=BPCRM
                 conn = new OleDbConnection(_OracleConnectionString);
                conn.Open();                
                cm = new OleDbCommand("SELECT ID,DEPOT_CODE,ACCT_NO,SUBDLR_NAME,SUBDLR_ADDR,STATE,DISTRICT,TOWN,PIN_CODE,CONTACT_NAME,CONTACT_NO,ACTIVE FROM BPIL.BPILMCC_SUBDLRMSTR where CRM_REQUEST_ID is null and CRM_STATUS is null", conn);               
                da= new OleDbDataAdapter(cm);               
                da.Fill(dt);
                Console.WriteLine("Total " + dt.Rows.Count.ToString() + " found");
                #endregion 

                #region Retrieving Last Request Id from Oracle to create new Id
                cm = null;                
                cm = new OleDbCommand("select MAX(CRM_REQUEST_ID) from BPIL.BPILMCC_SUBDLRMSTR", conn);
                object ID= cm.ExecuteScalar();
                if (ID.GetType() != typeof(DBNull))
                    MaxId = Convert.ToInt32(ID);

                Console.WriteLine("Max Id to update is " + MaxId.ToString());                
                #endregion

                #region Creating Request Id in Oracle
                cm = null;
                Console.WriteLine("Updating table to create Request Id");
                int _nextId = MaxId;
                Guid BatchGuid=Guid.NewGuid();
                foreach (DataRow r in dt.Rows)
                {
                    _nextId = _nextId + 1;
                    //cm = new OleDbCommand("update BPIL.BPILMCC_SUBDLRMSTR set CRM_REQUEST_ID=" + _nextId + ", Request_number='"+BatchGuid+"' where ID='" + r["ID"] + "' and CRM_REQUEST_ID is null and CRM_STATUS is null", conn);
                    cm = new OleDbCommand("update BPIL.BPILMCC_SUBDLRMSTR set CRM_REQUEST_ID=" + _nextId + " where ACCT_NO='" + r["ACCT_NO"] + "' and CRM_REQUEST_ID is null and CRM_STATUS is null", conn);
                    cm.ExecuteNonQuery();

                }
                #endregion

                #region Retrieve records to update in Transaction table
                dt.Dispose();
                dt = new DataTable();
                cm = new OleDbCommand("SELECT ID,DEPOT_CODE,ACCT_NO,SUBDLR_NAME,SUBDLR_ADDR,STATE,DISTRICT,TOWN,PIN_CODE,CONTACT_NAME,CONTACT_NO,ACTIVE,CRM_REQUEST_ID FROM BPIL.BPILMCC_SUBDLRMSTR where CRM_REQUEST_ID > " +Convert.ToInt32(MaxId), conn);
                da = new OleDbDataAdapter(cm);
                da.Fill(dt);
                Console.WriteLine("Total " + dt.Rows.Count.ToString() + " found");
                #endregion

                conn.Close();                
            }
            catch
            {
                throw new Exception("Exception occured while fetching data from staging table");
            }
            finally
            {
                conn.Dispose();
            }

            return dt;
        }
        #endregion       

        #region Updating Oracle Data in Trnsaction Table
        public void InsertRecord(DataTable oracleTable)
        {
            SqlConnection _sqlConnection = new SqlConnection();
            OleDbConnection _oracleConnection=new OleDbConnection();
            try
            {
                Console.WriteLine("Inserting SubDealer data in Transaction table");
                _sqlConnection = OpenDBConnection(Program.DBConnectionString);        
                foreach (DataRow r in oracleTable.Rows)
                {
                    try
                    {
                        #region Insert into Transaction Table                                       
                        string insertCommand = "insert into SubDealer_Contact ([ID],[DepoCode],[FirstName],[SubDealerName],[Address],[State],[District],[Town],[PinCode] ,[ContactNumber],[Active],[Acct_No],[sequence_no],[Status]) ";
                        insertCommand += "VALUES ('";
                        insertCommand += r["ID"].ToString();
                        insertCommand += "','" + r["DEPOT_CODE"].ToString();
                        insertCommand += "','" + r["CONTACT_NAME"].ToString();
                       // insertCommand += "','" + r["LastName"].ToString();
                        insertCommand += "','" + r["SUBDLR_NAME"].ToString();
                        insertCommand += "','" + r["SUBDLR_ADDR"].ToString();
                        insertCommand += "','" + r["STATE"].ToString();
                        insertCommand += "','" + r["DISTRICT"].ToString();
                        insertCommand += "','" + r["TOWN"].ToString();
                        insertCommand += "','" + r["PIN_CODE"].ToString();
                        insertCommand += "','" + r["CONTACT_NO"].ToString();
                        insertCommand += "','" + r["ACTIVE"].ToString();
                        insertCommand += "','" + r["ACCT_NO"].ToString();
                        insertCommand += "','" + r["CRM_REQUEST_ID"].ToString();
                        insertCommand += "','R')";
                        SqlCommand sqlCmd = new SqlCommand(insertCommand,_sqlConnection);

                        int i = sqlCmd.ExecuteNonQuery();
                        #endregion
 

                        #region Update Oracle status to "Picked"
                        _oracleConnection.ConnectionString=_OracleConnectionString;
                        _oracleConnection.Open();
                        OleDbCommand cm = new OleDbCommand("update BPIL.BPILMCC_SUBDLRMSTR set CRM_STATUS='Picked' where ID="+r["ID"].ToString()+"and CRM_REQUEST_ID=" + r["CRM_REQUEST_ID"].ToString(), _oracleConnection);
                        cm.ExecuteNonQuery();
                        _oracleConnection.Close();
                       // Console.WriteLine("update BPIL.BPILMCC_SUBDLRMSTR set CRM_STATUS='Picked' where ID=" + r["ID"].ToString() + "and CRM_REQUEST_ID=" + r["CRM_REQUEST_ID"].ToString());
                        

                        #endregion
                    }
                    catch (Exception ex)
                    {
                        #region Update Oracle status to "Failed"
                        _oracleConnection.ConnectionString = _OracleConnectionString;
                        _oracleConnection.Open();
                        OleDbCommand cm = new OleDbCommand("update BPIL.BPILMCC_SUBDLRMSTR set CRM_STATUS='Failed' where ID=" + r["ID"].ToString() + "and CRM_REQUEST_ID=" + r["CRM_REQUEST_ID"].ToString(), _oracleConnection);
                        cm.ExecuteNonQuery();
                        _oracleConnection.Close();
                        #endregion
                    }                    
                }                
            }
            catch
            {
                throw;
            }
            finally
            {
                CloseDBConnection(_sqlConnection);
                _oracleConnection.Dispose();                   
            }

        }
        #endregion
              
        #region Updateing the RecordStatus
        public void UpdateRecordStatus(string status, int recordId, string errorMessage)
        {
            SqlConnection _sqlConnection = new SqlConnection();
            try
            {
                string currentDate = DateTime.Now.ToString();
                _sqlConnection = OpenDBConnection(Program.DBConnectionString);
                StringBuilder _sqlQuery = new StringBuilder();

                _sqlQuery.Append("update ");
                _sqlQuery.Append("SubDealer_Contact");
                _sqlQuery.Append(" set Status='");
                _sqlQuery.Append(status);
                _sqlQuery.Append("',");
                _sqlQuery.Append(" ModifiedOn=getdate() ,");
                _sqlQuery.Append("ErrorMsg ='");
                _sqlQuery.Append(errorMessage.Replace("'", ""));
                _sqlQuery.Append("' where sequence_no=");
                _sqlQuery.Append(recordId);


                SqlCommand _sqlCmd = new SqlCommand(_sqlQuery.ToString(), _sqlConnection);
                int i = _sqlCmd.ExecuteNonQuery();

            }
            catch
            {
                throw;
            }
            finally
            {
                CloseDBConnection(_sqlConnection);
            }

        }
        #endregion
    }
}
