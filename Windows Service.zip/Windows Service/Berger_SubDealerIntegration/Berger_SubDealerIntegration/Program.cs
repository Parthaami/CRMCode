﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;


namespace Berger_SubDealerIntegration
{
    class Program
    {
        public static string DBConnectionString = string.Empty;
        public static IOrganizationService _crmService = null;
    
        static void Main(string[] args)
        {
             
            try
            {
                #region Private Variable
                string ServerURL = ConfigurationManager.AppSettings["ServerURL"];
                string _userName = "";
                string _password = "";
                string _domain = "";
                string Orgname = ConfigurationManager.AppSettings["Orgname"];
                EntityCollection ContactCollection = new EntityCollection();
               
                DataTable _contactTable = null; 


                CrmHelper _crmHelper = new CrmHelper();
                DBHelper _dbHelper = new DBHelper();
                #endregion

                DBConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["Database"] + ";Integrated Security=True";
                
                #region RetriveRequest from Oracle
                DataTable oracleTable= _dbHelper.GetOracleDataTable();
                if (oracleTable.Rows.Count > 0)
                {
                    _dbHelper.InsertRecord(oracleTable);
                }
                

                #endregion

                #region [Connect with CRM]

                Console.WriteLine("Starting process for migrating");  
                            
                _crmService = _crmHelper.GettCRMService();
                

                #endregion

                #region [Get Data and Create Contact]
               
                Console.WriteLine("Retrieving data from Transaction Table");
                _contactTable = _dbHelper.GetDataTable(DBConnectionString);

                if (_contactTable != null && _contactTable.Rows.Count > 0)
                {
                    Entity _contact=null;
                    foreach (DataRow r in _contactTable.Rows)
                    {
                        int pass = 0;
                        try
                        {
                            Console.WriteLine("Creating subdealer for " + r["sequence_no"].ToString() + " record");

                            #region[Check SubDealer]
                            QueryExpression subDealerQuery = new QueryExpression("contact");
                            subDealerQuery.ColumnSet = new ColumnSet(new string[] { "contactid" });
                            subDealerQuery.Criteria.AddCondition(new ConditionExpression("ber_oracleuniqueid", ConditionOperator.Equal, r["ID"].ToString()));
                            EntityCollection subDealerQueryCollection = _crmService.RetrieveMultiple(subDealerQuery);
                            #endregion

                            if (subDealerQueryCollection.Entities.Count > 0)
                            {
                                #region [update Contact]
                                Entity _subDealer = subDealerQueryCollection.Entities[0];                               
                                _subDealer.Attributes["firstname"] = r["FirstName"].ToString();
                                _subDealer.Attributes["lastname"] = r["LastName"].ToString();
                                _subDealer.Attributes["ber_shopname"] = r["SubDealerName"].ToString();
                                _subDealer.Attributes["address1_line1"] = r["Address"].ToString();
                                _subDealer.Attributes["address1_stateorprovince"] = r["State"].ToString();
                                _subDealer.Attributes["address1_city"] = r["District"].ToString();
                                _subDealer.Attributes["address1_line2"] = r["Town"].ToString();
                                _subDealer.Attributes["address1_postalcode"] = r["PinCode"].ToString();
                                _subDealer.Attributes["mobilephone"] = r["ContactNumber"].ToString();
                                if (r["Active"].ToString() == "Y")
                                {
                                    _subDealer.Attributes["statuscode"] = new OptionSetValue(1);
                                    _subDealer.Attributes["statecode"] = new OptionSetValue(0);
                                }
                                else
                                {
                                    _subDealer.Attributes["statuscode"] = new OptionSetValue(2);
                                    _subDealer.Attributes["statecode"] = new OptionSetValue(1);
                                }
                                                             

                                #region[Get Dealer]
                                if (!string.IsNullOrEmpty(r["Acct_No"].ToString()))
                                {
                                    QueryExpression acctQuery = new QueryExpression("account");
                                    acctQuery.ColumnSet = new ColumnSet(new string[] { "accountid" });
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("accountnumber", ConditionOperator.Equal, r["Acct_No"].ToString().Trim()));
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("parentaccountid", ConditionOperator.Null));
                                    EntityCollection accountCollection = _crmService.RetrieveMultiple(acctQuery);
                                    if (accountCollection.Entities.Count > 0)
                                    {
                                        _subDealer.Attributes["ber_dealerid"] = new EntityReference("account", accountCollection.Entities[0].Id);
                                    }
                                    else
                                    {
                                        _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), "Dealer not found");
                                        pass = 1;
                                    }
                                }
                                #endregion

                                if (pass == 0)
                                {
                                    #region [Get Depo]

                                    if (!string.IsNullOrEmpty(r["DepoCode"].ToString()))
                                    {
                                        string DepoKey = ConfigurationManager.AppSettings["DepoKey"];

                                        QueryExpression depoQuery = new QueryExpression("ber_depot");
                                        depoQuery.ColumnSet = new ColumnSet(new string[] { "ber_depotid", "ownerid" });
                                        depoQuery.Criteria.AddCondition(new ConditionExpression(DepoKey, ConditionOperator.Equal, r["DepoCode"].ToString().Trim()));
                                        depoQuery.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                                        EntityCollection depoCollection = _crmService.RetrieveMultiple(depoQuery);
                                        if (depoCollection.Entities.Count > 0)
                                        {
                                            _subDealer.Attributes["ber_depotid"] = new EntityReference("ber_depot", depoCollection.Entities[0].Id);
                                            _subDealer.Attributes["ownerid"] = depoCollection.Entities[0].Attributes["ownerid"];
                                        }
                                        else
                                        {
                                            _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), "Depo not found");
                                            pass = 1;

                                        }

                                    }
                                    #endregion
                                }

                                if (pass == 0)
                                {
                                    try
                                    {
                                        _crmService.Update(_subDealer);
                                        _dbHelper.UpdateRecordStatus("p", Convert.ToInt16(r["sequence_no"]), "");                                      
                                    }
                                    catch (Exception ex)
                                    {
                                        _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), ex.Message);
                                    }
                                }
                                _subDealer = null;
                                #endregion
                            }
                            else
                            {
                                #region [Create Contact]
                                _contact = new Entity("contact");
                                _contact.Attributes["ber_oracleuniqueid"] = r["ID"].ToString();
                                _contact.Attributes["firstname"] = r["FirstName"].ToString();
                                _contact.Attributes["lastname"] = r["LastName"].ToString();
                                _contact.Attributes["ber_shopname"] = r["SubDealerName"].ToString();
                                _contact.Attributes["address1_line1"] = r["Address"].ToString();
                                _contact.Attributes["address1_stateorprovince"] = r["State"].ToString();
                                _contact.Attributes["address1_city"] = r["District"].ToString();
                                _contact.Attributes["address1_line2"] = r["Town"].ToString();
                                _contact.Attributes["address1_postalcode"] = r["PinCode"].ToString();
                                _contact.Attributes["mobilephone"] = r["ContactNumber"].ToString();
                                if (r["Active"].ToString() == "Y")
                                {
                                    _contact.Attributes["statuscode"] = new OptionSetValue(1);
                                    _contact.Attributes["statecode"] = new OptionSetValue(0);
                                }
                                else
                                {
                                    _contact.Attributes["statuscode"] = new OptionSetValue(2);
                                    _contact.Attributes["statecode"] = new OptionSetValue(1);
                                }


                                _contact.Attributes["ber_subdealer"] = true;//r["SubDealer"].ToString();
                                _contact.Attributes["ber_customertype"] = new OptionSetValue(278290001); //r["CustomerType"].ToString();  

                                #region[Get Dealer]
                                if (!string.IsNullOrEmpty(r["Acct_No"].ToString()))
                                {
                                    QueryExpression acctQuery = new QueryExpression("account");
                                    acctQuery.ColumnSet = new ColumnSet(new string[] { "accountid" });
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("accountnumber", ConditionOperator.Equal, r["Acct_No"].ToString().Trim()));
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                                    acctQuery.Criteria.AddCondition(new ConditionExpression("parentaccountid", ConditionOperator.Null));
                                    EntityCollection accountCollection = _crmService.RetrieveMultiple(acctQuery);
                                    if (accountCollection.Entities.Count > 0)
                                    {
                                        _contact.Attributes["ber_dealerid"] = new EntityReference("account", accountCollection.Entities[0].Id);
                                    }
                                    else
                                    {
                                        _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), "Dealer not found");
                                        pass = 1;
                                    }
                                }
                                #endregion

                                if (pass == 0)
                                {
                                    #region [Get Depo]

                                    if (!string.IsNullOrEmpty(r["DepoCode"].ToString()))
                                    {
                                        string DepoKey = ConfigurationManager.AppSettings["DepoKey"];

                                        QueryExpression depoQuery = new QueryExpression("ber_depot");
                                        depoQuery.ColumnSet = new ColumnSet(new string[] { "ber_depotid", "ownerid" });
                                        depoQuery.Criteria.AddCondition(new ConditionExpression(DepoKey, ConditionOperator.Equal, r["DepoCode"].ToString().Trim()));
                                        depoQuery.Criteria.AddCondition(new ConditionExpression("statecode", ConditionOperator.Equal, 0));
                                        EntityCollection depoCollection = _crmService.RetrieveMultiple(depoQuery);
                                        if (depoCollection.Entities.Count > 0)
                                        {
                                            _contact.Attributes["ber_depotid"] = new EntityReference("ber_depot", depoCollection.Entities[0].Id);
                                            _contact.Attributes["ownerid"] = depoCollection.Entities[0].Attributes["ownerid"];
                                        }
                                        else
                                        {
                                            _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), "Depo not found");
                                            pass = 1;

                                        }

                                    }
                                    #endregion
                                }

                                if (pass == 0)
                                {
                                    try
                                    {
                                        _crmService.Create(_contact);
                                        _dbHelper.UpdateRecordStatus("p", Convert.ToInt16(r["sequence_no"]), "");
                                        _contact = null;

                                    }
                                    catch (Exception ex)
                                    {
                                        _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), ex.Message);
                                    }
                                }
                                #endregion
                            }

                            Console.WriteLine("Record migrated successfully");
                        }
                        catch (Exception ex)
                        {
                            _dbHelper.UpdateRecordStatus("F", Convert.ToInt16(r["sequence_no"]), ex.Message);
                        }
                    }
                   
                }
                #endregion
                
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            
        }


         
    }
}
