using System;
using System.Collections;
using System.Configuration;
using System.Net;
using System.IO;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Crm.Sdk.Messages;


namespace Berger_SubDealerIntegration
{
    public class CrmHelper
    {
        #region declare all the local Variables
        public static OrganizationServiceProxy _crmService;
        public static EntityMetadata _selectedEntity;
        public static IOrganizationService _service;
        OrganizationServiceProxy orgService = null;
        private Hashtable _entityAttributes = new Hashtable();
        private ArrayList _unsupportedTypes;
        public static Uri DiscoveryUri = null;


        #endregion

        #region Constructor
        public CrmHelper()
        {

            ////////string ServerUrl = Program.ServerURL;
            ////////ClientCredentials credentials = new ClientCredentials();

            ////////credentials.Windows.ClientCredential = new System.Net.NetworkCredential("administrator", "Pa$$w0rd", "crm2011");
            ////////Uri organizationUri = new Uri(ServerUrl + "/" + Program.Orgname + "/XRMServices/2011/Organization.svc");
            ////////Uri homeRealmUri = null;
            ////////_crmService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
            ////////_crmService.ServiceConfiguration.CurrentServiceEndpoint.Behaviors.Add(new ProxyTypesBehavior());


            // Load the list of unsupported attribute types for import.
            this._unsupportedTypes = new ArrayList(10);
            this._unsupportedTypes.AddRange
                (
                    new AttributeTypeCode[] 
                    {

                        AttributeTypeCode.CalendarRules,
                        //AttributeTypeCode.PartyList,
                        //AttributeTypeCode.State,
                        //AttributeTypeCode.Status,
                      //  AttributeTypeCode.Uniqueidentifier,
                        AttributeTypeCode.Virtual

                    }
                );




        }
        #endregion

        #region public properties

        #region CRM Service Property
        public OrganizationServiceProxy Crmservice
        {
            get
            {
                return _crmService;
            }
        }

        //public IOrganizationService Service
        //{
        //    get
        //    {
        //        return _service;
        //    }
        //}
        #endregion


        #endregion

        #region Connect to CRM Server with Corrsponding User name and Password
        public bool ConnectToCRM(string URLPath, string orgName, string UserName, string Password, string Domain)
        {
            try
            {
                bool validInfo = ValidateConnectionInformation(URLPath, orgName, UserName, Password, Domain);
                return validInfo;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        #endregion

        #region Validate the Connection Information against CRM Server
        /// <summary>
        /// Validates the user-entered connection information.
        /// </summary>
        /// <param name="serverUrl">Data in the CRM Server Url textbox</param>
        /// <param name="userId">Data in the User Id textbox</param>
        /// <param name="userPassword">Data in the Password textbox</param>
        /// <returns></returns>
        /// 

        public IOrganizationService GettCRMService()
        {
            try
            {
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["OrgService"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

                return (IOrganizationService)orgService;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region "Oragnization"

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion


        private bool ValidateConnectionInformation(string serverUrl, string orgName, string userId, string userPassword, string Domain)
        {
            const string URL_PREFIX = "http://";
            const string CRM_SERVICE_SUFFIX_URL = "/XRMServices/2011/Organization.svc";
            bool valid = false;
            // Reset the user credentials for the CRM connections.            
            string _responseUri = string.Empty;

            if (!String.IsNullOrEmpty(serverUrl))
            {
                // Create the CRM service URL.
                serverUrl = serverUrl + "/" + orgName + CRM_SERVICE_SUFFIX_URL;
                if (!serverUrl.StartsWith(URL_PREFIX, StringComparison.OrdinalIgnoreCase))
                {
                    serverUrl = URL_PREFIX + serverUrl;
                }
                Uri url = new Uri(serverUrl);
                // Create the CRM service credentials.
                NetworkCredential userCredentials;

                if ((String.IsNullOrEmpty(userId)) && (String.IsNullOrEmpty(userPassword)))
                {
                    // Use default credentials.
                    userCredentials = CredentialCache.DefaultNetworkCredentials;

                }
                else
                {
                    // Use user-entered credentials.
                    userCredentials = new NetworkCredential(userId, userPassword, Domain);
                }

                WebResponse crmResponse = null;
                StreamReader reader = null;

                try
                {
                    Console.WriteLine("Authenticating with CRM");
                    ClientCredentials Credentials = new ClientCredentials();
                    Uri OrganizationUri = new Uri(ConfigurationManager.AppSettings["OrgService"].ToString());
                    Credentials.Windows.AllowNtlm = true;    // new NetworkCredential(userId, userPassword, Domain);
                    Uri HomeRealmUri = null;
                    OrganizationServiceProxy orgservice = new OrganizationServiceProxy(OrganizationUri, HomeRealmUri, Credentials, null);
                    IOrganizationService service = (IOrganizationService)orgservice;
                    _crmService = orgservice;
                    _service = service;
                    Guid userid = ((WhoAmIResponse)orgservice.Execute(new WhoAmIRequest())).UserId;
                    Console.WriteLine("Connected with User " + userid.ToString());
                    valid = true;

                }
                catch (WebException webEx)
                {
                    // error-handling code here
                    //logger.Log(webEx.Message.ToString());
                    string x = webEx.Message.ToString();  
                    valid = false;
                }
                catch
                {
                    // Error-handling code here.
                    //logger.Log(ex.Message.ToString());

                    valid = false;
                    throw;
                }
                finally
                {
                    // Close the StreamReader object.
                    if (reader != null)
                    {
                        reader.Close();
                    }

                    // Close the WebResponse object.
                    if (crmResponse != null)
                    {
                        crmResponse.Close();
                    }
                }
            }

            return valid;
        }
        #endregion

    }   
}

