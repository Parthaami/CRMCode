﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Data;

namespace LeadAssignmentCountUpdateForCity
{
    class LeadAssignmentCountForCity
    {
        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;

        static void Main(string[] args)
        {
            try
            {

                string conString = ConfigurationManager.ConnectionStrings["BergerCRMConnectionString"].ToString();
                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString();

                bergerlogger = new PragmasysLogger(org, logfilepath);
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["APPServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                using (SqlConnection conn = new SqlConnection())
                {

                    
                    conn.ConnectionString = conString;
                    conn.Open();
                    try
                    {

                        SqlCommand Command = new SqlCommand("UPDATE ber_city SET ber_openjobs = 0 where ber_citytype = '278290001'", conn);

                        Command.ExecuteNonQuery();
                    }
                    // catch block
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }



                EntityCollection CityEntityCollection = RetrieveHomeDecorCity(orgService);
                decimal Total_lead_open = 0;

                if (CityEntityCollection.Entities.Count > 0)
                {
                    foreach (Entity City in CityEntityCollection.Entities)
                    {
                        string cityid = City.Id.ToString();

                        EntityCollection LeadEntityCollection = RetrieveLeads(orgService, cityid);
                        if (LeadEntityCollection.Entities.Count != 0)
                        {
                            Total_lead_open = LeadEntityCollection.Entities.Count;
                            UpdateCity(cityid, orgService, Total_lead_open);
                        }

                    }
                }


            }
            catch (Exception ex)
            {
                bergerlogger.Log("UpdateLeadAssignmentPainter", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static TProxy GetProxy<TService, TProxy>(
         IServiceManagement<TService> serviceManagement,
         AuthenticationCredentials authCredentials)
         where TService : class
         where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        public static void UpdateCity(string ID, IOrganizationService service, decimal Total_lead_open)
        {
            Entity City = new Entity("ber_city");
            City.Attributes["ber_cityid"] = new Guid(ID);
            City.Attributes["ber_openjobs"] = Total_lead_open;


            service.Update(City);
        }




        public static EntityCollection RetrieveHomeDecorCity(OrganizationServiceProxy orgService)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='ber_city'>");
                strQuery.Append("<attribute name='ber_cityid' />");
                strQuery.Append("<attribute name='ber_name' />");
                strQuery.Append("<attribute name='ber_citytype' />");
                strQuery.Append("<attribute name='ber_openjobs' />");
                strQuery.Append("<attribute name='ber_maxjobs' />");
                strQuery.Append(" <order attribute='ber_name' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_citytype' operator='eq' value = '278290001' />");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("LeadAssignmentCountForCity", "RetrieveHomeDecorCity", "Query Generated :" + strQuery, "");
                }

                EntityCollection CityEntityCollection = Retrieve(orgService, strQuery.ToString());

                return CityEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("LeadAssignmentCountForCity", "RetrieveHomeDecorCity", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }


        public static EntityCollection RetrieveLeads(OrganizationServiceProxy orgService, string cityid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='ber_estimatedetails'>");
                strQuery.Append("<attribute name='ber_name'/>");
                strQuery.Append("<attribute name='ber_customerid' />");
                strQuery.Append("<attribute name='ber_leadid' /> ");
                strQuery.Append("<attribute name='ownerid' />");
                strQuery.Append("<attribute name='ber_netamount'/>");
                strQuery.Append("<attribute name='ber_estimatedetailsid'/>");
                strQuery.Append("<filter type='and'>");
                strQuery.Append("<condition attribute='statuscode' operator='in'>");
                strQuery.Append("<value>1</value>");
                strQuery.Append("<value>278290000</value>");
                strQuery.Append("<value>278290001</value>");
                strQuery.Append("</condition>");
                strQuery.Append("</filter>");
                strQuery.Append("<link-entity name='lead' from='leadid' to='ber_leadid' alias='aa'>");
                strQuery.Append("<filter type='and'>");
                strQuery.Append(" <condition attribute='ber_cityid' operator='eq' value='" + cityid + "' />");
                strQuery.Append("</filter>");
                strQuery.Append("</link-entity>");
                strQuery.Append("</entity>");
                strQuery.Append("</fetch>");







                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("LeadAssignmentCountForCity", "RetrieveLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("LeadAssignmentCountForCity", "RetrieveLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }



        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }



    }
}
