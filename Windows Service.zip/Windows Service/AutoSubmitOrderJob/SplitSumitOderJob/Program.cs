using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.ServiceModel.Description;

namespace BPIL.SplitSumitOderJob
{
    internal class Program
    {
        public static SubmitLogger bergerlogger = SubmitLogger.Instance;
        public Program()
		{
		}

        #region "Oragnization"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static OrganizationServiceProxy CreateOrganizationServiceProxy()
		{
			OrganizationServiceProxy organizationServiceProxy;
			try
			{
                
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["ServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                organizationServiceProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                organizationServiceProxy.EnableProxyTypes();
            }
			catch (Exception exception)
			{
				throw exception;
			}
			return organizationServiceProxy;
		}

        private static TProxy GetProxy<TService, TProxy>(
          IServiceManagement<TService> serviceManagement,
          AuthenticationCredentials authCredentials)
          where TService : class
          where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        public static void Main(string[] args)
		{
			string orgName = ConfigurationManager.AppSettings["OrgName"];
            bergerlogger.Log("Split Submit Order Console for data ", "Main Start", "---:  Job Started :---", System.DateTime.Now.ToString());
            try
			{
				DataTable dtRecords = Program.RetrieveData();
				OrganizationServiceProxy orgService = Program.CreateOrganizationServiceProxy();
				
                
                foreach (DataRow drRow in dtRecords.Rows)
				{
                    // Create an ExecuteWorkflow request.
                    ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
                    {
                        WorkflowId = new Guid(ConfigurationManager.AppSettings["WorkflowId"].ToString()),
                        EntityId =   new Guid(drRow[ConfigurationManager.AppSettings["EntityIdColumn"].ToString()].ToString())
                    };
                   
                    ExecuteWorkflowResponse response = (ExecuteWorkflowResponse)orgService.Execute(request);
				}
			}
			catch (Exception exception)
			{
				//throw exception;
                bergerlogger.Log("Split Submit Order Console for data ", "Main", "---:  Error :---", exception.Message.ToString() );
			}
            bergerlogger.Log("Split Submit Order Console for data ", "Main End", "---:  Job End :---", System.DateTime.Now.ToString());
		}

        #region "Retrive Data from view"
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private static DataTable RetrieveData()
		{
			DataTable item;
			try
			{
				DataSet dsReturn = new DataSet();

                using (SqlConnection connection = new SqlConnection()
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings["StagingDBConnString"].ConnectionString
                })
                {
                    string commandText = string.Concat("select ", ConfigurationManager.AppSettings["EntityIdColumn"].ToString(), " from ", ConfigurationManager.AppSettings["ViewName"].ToString());
                    
                    //Time Out Configurable....   
                    SqlDataAdapter dadData = new SqlDataAdapter(commandText, connection);
                    dadData.SelectCommand.CommandTimeout = Convert.ToInt32(ConfigurationManager.AppSettings["CommandTimeOutAdapter"].ToString());
                    dadData.Fill(dsReturn);
                    //(new SqlDataAdapter(commandText, connection)).Fill(dsReturn);
                    
                    if (dsReturn.Tables.Count > 0)
                    {
                        item = dsReturn.Tables[0];
                        return item;
                    }
                }
			}
			catch (SqlException sqlException)
			{
				//throw sqlException;
                bergerlogger.Log("Split Submit Order Console for data ", "RetrieveData", "---:  Error :---", sqlException.Message.ToString());
			}
			item = new DataTable();
			return item;
        }
        #endregion

    }
}