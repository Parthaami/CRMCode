﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.ServiceModel;
using System.Xml;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;


namespace Pragmasys.BERGER.Plugins
{
    public class LeadAudit_Compare_HappyCode : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context =
                            (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory factory =
                (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                Entity PreImage;
                string CustomeCode = string.Empty;

                if (context.PreEntityImages.Contains("PreImage") && context.PreEntityImages["PreImage"] is Entity)
                {

                    PreImage = (Entity)context.PreEntityImages["PreImage"];
                    CustomeCode = (String)PreImage.Attributes["ber_customercode"];

                    
                }
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
                {


                   
                    string ReportedCode = string.Empty;

                    Entity leadauditentity = (Entity)context.InputParameters["Target"];
                    if (leadauditentity.LogicalName == "ber_leadaudit")
                    {
                        
                        

                        if (CustomeCode != null && CustomeCode != string.Empty)
                        {
                           
                            if (leadauditentity.Attributes.Contains("ber_reportedcode"))
                            {
                                
                                ReportedCode = leadauditentity.Attributes["ber_reportedcode"].ToString();


                                if (CustomeCode != ReportedCode)
                                {
                                    throw new InvalidPluginExecutionException("Reported Code Is Incorrect");
                                }
                            }
                        }




                    }

                }


                
            }
            finally
            {

            }
        }
    }
}
