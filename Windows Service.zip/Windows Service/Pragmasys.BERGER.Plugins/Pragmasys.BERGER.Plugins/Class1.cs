﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pragmasys.BERGER.Plugins
{
    public class Class1
    {
    }
}
