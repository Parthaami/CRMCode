﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Collections.Specialized;
using System.Configuration;
using Microsoft.Win32;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Net;

namespace Pragmasys.BERGER.Plugins
{
    public class LeadAudit_Compare : IPlugin
    {

       public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context =
                        (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory factory =
            (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = factory.CreateOrganizationService(context.UserId);

            throw new Exception("ashish");
        }

    }
}