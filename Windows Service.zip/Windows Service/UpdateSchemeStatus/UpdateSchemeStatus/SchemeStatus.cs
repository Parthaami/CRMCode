﻿//========================================================================
// This window service executes on Daily basis and changes the status of
//  BS Tracker Scheme Record.
//  -If Scheme Launch Date is todays date then it changes scheme status as Launched(Running)
//  -If scheme Redemption date is todays date then it changes scheme status to Pending Redemptions.
//
//  Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================
using System;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Text;

namespace UpdateSchemeStatus
{
    class SchemeStatus
    {
        #region Class Level Members

        private static IOrganizationService _service;

        static Logger oLogger;
        static string Loggerpath = string.Empty;
        static Configuration config;
        static string _CrmServiceUrl = string.Empty;
        public static string TodaysDate = Convert.ToString(DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day);
      

        static string _organizationName = ConfigurationManager.AppSettings["OrganisationName"];
        
        #endregion

        static void Main(string[] args)
        {
            #region Read Registry Key & get Pragmasys.config Path
            string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
            string keyValue = "CRM_Server_InstallDir";
            string value64 = string.Empty;
            string value32 = string.Empty;
            string DB_path = string.Empty;

            RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
            localKey = localKey.OpenSubKey(CRMpath);
            if (localKey != null)
            {
                if (localKey.GetValue(keyValue) != null)
                {
                    value64 = localKey.GetValue(keyValue).ToString();
                    DB_path = value64;
                }
            }
            RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
            localKey32 = localKey32.OpenSubKey(CRMpath);
            if (localKey32 != null)
            {
                if (localKey32.GetValue(keyValue) != null)
                {
                    value32 = localKey32.GetValue(keyValue).ToString();
                    DB_path = value32;
                }
            }
            #endregion

            /// <summary>
            /// Registry entry not required
            /// If in code want to use configration file 
            /// Add configration file in CRMWeb\ISV folder Pragmasys.config
            /// if Configration file is not used comment the code.      
            /// </summary>
            /// 
            string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";

            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            if (File.Exists(configpath))
            {
                //  Get configration data     
                fileMap.ExeConfigFilename = configpath;
                config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                if (config.AppSettings.Settings.Count > 0)
                {
                    Loggerpath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                    oLogger = new Logger(_organizationName, Loggerpath);               
                    _CrmServiceUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                }
            }
            //Loggerpath = "D:\\CRMLogs";
            //oLogger = new Logger(_organizationName, Loggerpath);
            //_CrmServiceUrl = "http://10.63.4.26:6666/BergerDev/XRMServices/2011/Organization.svc";

            _service = GetService();

            EntityCollection PedningRedemptionsSchemeColl = RetrievePedning4RedemptionsSchemes(_service);
            foreach (Entity eSchemeEndToday in PedningRedemptionsSchemeColl.Entities)
            {
                UpdateSchemeStatus(eSchemeEndToday.Id, 3);
            }

            EntityCollection LaunchedSchemes = RetrievePedning4LaunchSchemes(_service);
            foreach (Entity eSchemeLaunchToday in LaunchedSchemes.Entities)
            {
                UpdateSchemeStatus(eSchemeLaunchToday.Id, 2);
            }
        }

        #region Function to get CRM Service
        /// <summary>
        /// Get CRM Service.
        /// </summary>
        /// <returns></returns>
        public static IOrganizationService GetService()
        {
            IOrganizationService crmsvc = null;
            try
            {
                ClientCredentials credentials = new ClientCredentials();
                //credentials.Windows.ClientCredential = (NetworkCredential)System.Net.CredentialCache.DefaultCredentials;
                credentials.Windows.ClientCredential = new NetworkCredential("administrator","admin@123","bergerlewis");
                Uri organizationUri = new Uri(_CrmServiceUrl);
                Uri homeRealmUri = null;
                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                crmsvc = (IOrganizationService)orgService;
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving CRM Service", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return crmsvc;
        }
        #endregion

        #region Function to Restrive Phone Call from Fetch XMl
        private static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error In Fetch XML", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to Get Schemes From CRM whose End Date Is Today or Befor Today.
        public static EntityCollection RetrievePedning4RedemptionsSchemes(IOrganizationService Service)
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='campaign'>");
                query.Append("<attribute name='name' />");
                query.Append("<attribute name='actualstart' />");
                query.Append("<attribute name='actualend' />");
                query.Append("<attribute name='statecode' />");
                query.Append("<attribute name='statuscode' />");
                query.Append("<attribute name='campaignid' />");
                query.Append("<filter type='and'>");                
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='actualend' operator='on-or-before' value='"+ TodaysDate +"' />");
                query.Append("<condition attribute='statuscode' operator='not-in'>");
                query.Append("<value>3</value>");
                query.Append("<value>4</value>");
                query.Append("<value>5</value>");
                query.Append("</condition>");
                query.Append("</filter>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(Service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("Update Scheme Status", "RetrievePedning4RedemptionsSchemes", "Error Retriving Schemes", ex.Message.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to Get Schemes From CRM whose Start Date is Today or Before Today.
        public static EntityCollection RetrievePedning4LaunchSchemes(IOrganizationService Service)
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='campaign'>");
                query.Append("<attribute name='name' />");
                query.Append("<attribute name='actualstart' />");
                query.Append("<attribute name='actualend' />");
                query.Append("<attribute name='statecode' />");
                query.Append("<attribute name='statuscode' />");
                query.Append("<attribute name='campaignid' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='actualstart' operator='on-or-before' value='" + TodaysDate + "' />");
                query.Append("<condition attribute='statuscode' operator='not-in'>");
                query.Append("<value>3</value>");
                query.Append("<value>4</value>");
                query.Append("<value>5</value>");
                query.Append("</condition>");
                query.Append("</filter>");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(Service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("Update Scheme Status", "RetrievePedning4LaunchSchemes", "Error Retriving Schemes", ex.Message.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to Update Scheme Status
        public static void UpdateSchemeStatus(Guid SchemeId,int StatusCode)
        {
             try
            {
                SetStateRequest request = new SetStateRequest();
                request.EntityMoniker = new EntityReference("campaign", SchemeId);
                request.State = new OptionSetValue(0);
                request.Status = new OptionSetValue(StatusCode);

                SetStateResponse responce = (SetStateResponse)_service.Execute(request);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error in Updateing Scheme Status", "UpdateSchemeStatus", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion
    }
}
