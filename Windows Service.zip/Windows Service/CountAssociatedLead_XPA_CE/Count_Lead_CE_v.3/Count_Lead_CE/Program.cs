﻿using System;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Text;
using Microsoft.Xrm.Sdk.Query;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.ServiceModel;

namespace Count_Lead_CE
{
    class UpdateLeadCount_CE
    {

        #region "Oragnization"

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion

        static void Main(string[] args)
        {

            string org = ConfigurationManager.AppSettings["Org"].ToString();
            string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();

            //string serverurl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
            string server = ConfigurationManager.AppSettings["DBServer"].ToString();
            string DatabaseName = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
            string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
            string Password = ConfigurationManager.AppSettings["Password"].ToString();
            string Domain = ConfigurationManager.AppSettings["domain"].ToString();
            string CustomertypeXPAorCE = string.Empty;

            /*     
            ClientCredentials credentials = new ClientCredentials();
            //credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;                
            credentials.Windows.ClientCredential = new NetworkCredential(UserName, Password, Domain);
            Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
            Uri homeRealmUri = null;
            OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
            orgService.EnableProxyTypes();
            */

            OrganizationServiceProxy orgService = null;
            AuthenticationCredentials credentials = new AuthenticationCredentials();
            String orgUrl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
            AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
            IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
            credentials = GetCredentials(orgServiceManagement, endpointType);
            orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

            // To get the list of leads for individual CEs monthly basis
            DataTable LeadCollectionCE = RetrieveCE(orgService, DatabaseName, server);

            if (LeadCollectionCE.Rows.Count > 0)
            {
                CustomertypeXPAorCE = "DG-CSM";

                foreach (DataRow row in LeadCollectionCE.Rows) // Loop over the rows.
                {

                    string contactid = row["contactid"].ToString();
                    string MobilePhone = row["MobilePhone"].ToString();
                    string CELeadCount = row["LeadCount"].ToString();
                    int ldCEcount = int.Parse(CELeadCount);
                    //  string CustomerType = row["ber_CustomerType"].ToString(); 
                    //Here logic for Update CRM Lead Count..

                    // UpdateLeadCountCE();


                    UpdateContact(contactid, orgService, ldCEcount, CustomertypeXPAorCE);


                }

            }


            // To get the list of leads for individual XPAs monthly basis
            DataTable LeadCollectionXP = RetrieveXPA(orgService, DatabaseName, server);  // present month 

            DataTable LeadCollectiontotalXP = RetrievetotalXPA(orgService, DatabaseName, server);  // total painter

            if (LeadCollectionXP.Rows.Count > 0 && LeadCollectiontotalXP.Rows.Count > 0)
            {
                var totalPainter = LeadCollectiontotalXP.AsEnumerable().Select(row => row["contactid"]);
                var effectivePainter = LeadCollectionXP.AsEnumerable().Select(row => row["contactid"]);
                var paintersToBeReset = totalPainter.Except(effectivePainter);

                foreach (DataRow painter in LeadCollectionXP.Rows)
                {
                    string XPLeadCount = painter["LeadCount"].ToString();
                    int XPcount = int.Parse(XPLeadCount);
                    UpdateContact(painter["contactid"].ToString(), orgService, XPcount, string.Empty);
                }

                if (paintersToBeReset.ToList().Count > 0)
                {
                    foreach (var painter in paintersToBeReset.ToList())
                    {
                        int XPcount = 0;
                        UpdateContact(painter.ToString(), orgService, XPcount, string.Empty);
                    }
                }
            }

        }

        #region Lead count operation for CE
        public static DataTable RetrieveCE(OrganizationServiceProxy orgService, string DatabaseName, string server)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = "Server=" + server + ";Database=" + DatabaseName + ";Trusted_Connection=true";
                    // conn.ConnectionString = "Server=localhost;Database=" + DatabaseName + ";Trusted_Connection=true";
                    conn.Open();
                    try
                    {
                        string queryString = "select cnt.contactid,cnt.MobilePhone, count(ld.leadid) LeadCount from BPIL_MSCRM.dbo.contact cnt inner join BPIL_MSCRM.dbo.lead ld on ld.ber_dgcontact = cnt.ContactId where cnt.statecode = 0 and cnt.ber_customertype in (278290012,278290005,278290006) and (DATEDIFF ( MM ,ld.ber_CaptureCE , GETDATE())= 0) and ld.ber_Whowill in (0,1,2) group by cnt.contactid,cnt.MobilePhone";


                        SqlCommand cmd = new SqlCommand(queryString, conn);

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);
                    }
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }

                }
            }
            catch (Exception e)
            {

                dt = null;
            }

            return dt;

        }
        #endregion

        #region Lead count operation for XPA
        public static DataTable RetrieveXPA(OrganizationServiceProxy orgService, string DatabaseName, string server)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = "Server=" + server + ";Database=" + DatabaseName + ";Trusted_Connection=true";
                    // conn.ConnectionString = "Server=localhost;Database=" + DatabaseName + ";Trusted_Connection=true";
                    conn.Open();
                    try
                    {
                        string queryString = "select cnt.contactid,cnt.fullname,cnt.MobilePhone,count(ld.leadid) LeadCount from BPIL_MSCRM.dbo.contact cnt inner join BPIL_MSCRM.dbo.lead ld on ld.ber_XPA = cnt.ContactId where cnt.statecode = 0 and cnt.ber_customertype = 278290001 and cnt.ber_XPA = 1 and (DATEDIFF ( MM ,ld.ber_CaptureCE , GETDATE())= 0) and ld.ber_Whowill = 3 group by cnt.contactid, cnt.fullname,cnt.MobilePhone";


                        SqlCommand cmd = new SqlCommand(queryString, conn);

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);
                    }
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }

                }
            }
            catch (Exception e)
            {

                dt = null;
            }

            return dt;

        }
        #endregion

        #region Lead count operation for total XPA
        public static DataTable RetrievetotalXPA(OrganizationServiceProxy orgService, string DatabaseName, string server)
        {
            DataTable dt1 = new DataTable();
            try
            {
                using (SqlConnection conn1 = new SqlConnection())
                {
                    conn1.ConnectionString = "Server=" + server + ";Database=" + DatabaseName + ";Trusted_Connection=true";
                    // conn.ConnectionString = "Server=localhost;Database=" + DatabaseName + ";Trusted_Connection=true";
                    conn1.Open();
                    try
                    {
                        string queryString = "select cnt.contactid,cnt.fullname,cnt.MobilePhone from BPIL_MSCRM.dbo.contact cnt where cnt.statecode = 0 and cnt.ber_customertype = 278290001 and cnt.ber_XPA = 1 ";


                        SqlCommand cmd1 = new SqlCommand(queryString, conn1);

                        SqlDataAdapter sda1 = new SqlDataAdapter(cmd1);

                        sda1.Fill(dt1);
                    }
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }

                }
            }
            catch (Exception e)
            {

                dt1 = null;
            }

            return dt1;

        }
        #endregion

        public static void UpdateContact(string ID, IOrganizationService service, int value, string CustomertypeXPAorCE)
        {

            Entity Contact = new Entity("contact");
            //Contact.Id = new Guid(ID);
            Contact.Attributes["contactid"] = new Guid(ID);



            if (CustomertypeXPAorCE == "DG-CSM")
            {
                Contact.Attributes["ber_cemonthlyleadlimit"] = value;
                //ber_cemonthlyleadlimit1
            }

            else
            {
                Contact.Attributes["ber_xpamonthlyleadlimit"] = value;
            }
            //totalPainter

            service.Update(Contact);
        }
    }
}




/*
select 
cnt.contactid,
cnt.fullname,
cnt.MobilePhone,

count(ld.leadid) LeadCount
from BPIL_MSCRM.dbo.contact cnt 
              inner join BPIL_MSCRM.dbo.lead ld on ld.ber_dgcontact = cnt.ContactId
              where cnt.statecode = 0 
                    and cnt.ber_customertype in (278290012,278290005)
                    
 group by cnt.contactid,
cnt.fullname,
cnt.MobilePhone

*/
