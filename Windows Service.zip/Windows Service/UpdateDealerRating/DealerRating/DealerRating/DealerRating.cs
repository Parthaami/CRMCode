﻿
using System;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Data;
namespace DealerRating
{
    class DealerRating
    {
        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;


        static void Main(string[] args)
        {
            try
            {

                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                string server = ConfigurationManager.AppSettings["DBServer"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString(); 


                bergerlogger = new PragmasysLogger(org, logfilepath);
                ClientCredentials credentials = new ClientCredentials();
                //credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;                
                credentials.Windows.ClientCredential = new NetworkCredential(UserName,Password,Domain);
                Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
                Uri homeRealmUri = null;

                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                orgService.EnableProxyTypes();

                DataTable DealerCollection = RetrieveDealers(orgService, DatabaseName, server);



                if (DealerCollection.Rows.Count > 0)
                {
                    foreach (DataRow row in DealerCollection.Rows) // Loop over the rows.
                    {
                        int Total_lead_assigned = 0;
                        int Total_Leads_Converted = 0;
                        int clubclass = 0;

                        int B_Total_lead_assigned = 0;
                        int B_Total_Leads_Converted = 0;
                        int B_CSAT_Score = 0;
                        int B_Total_Painters = 0;
                        int leadCompleted = 0;
                        double Cal_Total_lead_assigned = 0;
                        double Cal_Total_Painters = 0;
                        double Cal_Total_Leads_Converted = 0;
                        double Cal_CSAT_Score = 0;
                        double rating = 0;
                        double Cal_clubclass = 0;

                        if (row.ItemArray[3] != null && row.ItemArray[3] != DBNull.Value)
                        {
                            string categorycode = row.ItemArray[3].ToString();

                            if (categorycode.Contains("STA"))
                            {
                                clubclass = 1;
                            }
                            if (categorycode.Contains("SC"))
                            {
                                clubclass = 3;
                            }
                            if (categorycode.Contains("GC"))
                            {
                                clubclass = 5;
                            }

                            Cal_clubclass = clubclass * 0.15;
                        }

                        //retrive number of lead assigned
                        if (row.ItemArray[4] != DBNull.Value)
                        {
                            Total_lead_assigned = Convert.ToInt16(row.ItemArray[4]);
                        }
                        if (Total_lead_assigned > 10)
                        {
                            B_Total_lead_assigned = 0;
                        }
                        if (Total_lead_assigned == 0)
                        {
                            B_Total_lead_assigned = 5;
                        }

                        Cal_Total_lead_assigned = B_Total_lead_assigned * 0.15;

                        //retrive number of Leads Converted
                        if (row.ItemArray[5] != DBNull.Value)
                        {
                            leadCompleted = Convert.ToInt16(row.ItemArray[5]);
                        }
                        if (Total_lead_assigned > 0)
                        {
                            Total_Leads_Converted = (100 - (Total_lead_assigned - leadCompleted) / Total_lead_assigned) * 100;
                        }

                        if (Total_Leads_Converted == 0)
                        {
                            B_Total_Leads_Converted = 0;
                        }
                        if (Total_Leads_Converted > 80)
                        {
                            B_Total_Leads_Converted = 5;


                        }
                        Cal_Total_Leads_Converted = B_Total_Leads_Converted * 0.30;

                        //retreive CSAT Score 

                        if (row.ItemArray[6] != DBNull.Value)
                        {
                            B_CSAT_Score = Convert.ToInt16(row.ItemArray[6]);
                        }
                        Cal_CSAT_Score = B_CSAT_Score * 0.20;

                        string dealerid = row.ItemArray[0].ToString();

                        EntityCollection PainterEntityCollection = RetrievePainters(orgService, dealerid);

                        B_Total_Painters = PainterEntityCollection.Entities.Count;

                        Cal_Total_Painters = B_Total_Painters * 0.20;


                        //calculate Rating
                        rating = Cal_Total_Leads_Converted + Cal_Total_Painters + Cal_CSAT_Score + Cal_Total_lead_assigned + Cal_clubclass;
                        //  Dealer.Attributes["ber_dealerrating"] = rating;

                        string Rate = Convert.ToString(rating);
                        decimal value;
                        if (decimal.TryParse(Rate, out value))
                        {
                            value = Math.Round(value);
                            //  Rate = value.ToString();

                        }
                        else
                        {
                            // Tell the user their input is invalid
                        }
                        if (value != Decimal.MinValue)
                        {
                            UpdateDealer(dealerid, orgService, value);
                        }

                    }



                }


            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        public static void UpdateDealer(string ID, IOrganizationService service, decimal value)
        {
            Entity Dealer = new Entity("account");
            Dealer.Attributes["accountid"] = new Guid(ID);
            Dealer.Attributes["ber_dealerrating"] = value;

            service.Update(Dealer);
        }


        public static DataTable RetrieveDealers(OrganizationServiceProxy orgService, string DatabaseName,string server)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = "Server="+ server + ";Database=" + DatabaseName + ";Trusted_Connection=true";
                    
                    //conn.ConnectionString = "Server=localhost;Database=" + DatabaseName + ";Trusted_Connection=true";
                    conn.Open();
                    try
                    {
                        string queryString = "Select DISTINCT  A.accountid,A.name,A.AccountCategoryCode,SM.Value,A.ber_leadsassigned,A.ber_leadsclosed,A.ber_csirating FROM FilteredAccount A Left Outer Join FilteredStringMap SM ON A.AccountCategoryCode = SM.AttributeValue Where ((SM.AttributeName = 'AccountCategoryCode') AND(A.statecode = 0) AND (A.parentaccountid IS NULL))";
                        SqlCommand cmd = new SqlCommand(queryString, conn);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);


                    }
                    // catch block
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }

                return dt;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveDealers", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }



        public static EntityCollection RetrievePainters(OrganizationServiceProxy orgService, string Dealerid)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='contact'>");
                strQuery.Append("<attribute name='fullname' />");
                strQuery.Append("<attribute name='telephone1' />");
                strQuery.Append("<attribute name='contactid' />");
                strQuery.Append("<order attribute='fullname' descending='false' />");
                strQuery.Append("<filter type='and'>");
                strQuery.Append("<condition attribute='ber_dealerid' value='" + Dealerid + "' operator='eq'/>");
                strQuery.Append("<condition attribute='ber_epstatus' operator='in'>");
                strQuery.Append("<value>278290003</value>");
                strQuery.Append("<value>278290000</value>");
                strQuery.Append("</condition>");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");



                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("DealerRating", "RetrievePainters", "Query Generated :" + strQuery, "");
                }

                EntityCollection DealerEntityCollection = Retrieve(orgService, strQuery.ToString());

                return DealerEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveDealers", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }




        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }



        public static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {

            RetrieveAttributeRequest retrieveAttributeRequest = new
            RetrieveAttributeRequest
            {

                EntityLogicalName = entityName,


                LogicalName = attributeName,


                RetrieveAsIfPublished = true


            };
            // Execute the request.
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            // Access the retrieved attribute.

            Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

            retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
            Microsoft.Xrm.Sdk.Metadata.OptionMetadata[] optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
            string selectedOptionLabel = string.Empty;
            foreach (Microsoft.Xrm.Sdk.Metadata.OptionMetadata oMD in optionList)
            {
                if (oMD.Value == selectedValue)
                {
                    selectedOptionLabel = oMD.Label.UserLocalizedLabel.Label;


                }


            }
            return selectedOptionLabel;
        }

    }
}

