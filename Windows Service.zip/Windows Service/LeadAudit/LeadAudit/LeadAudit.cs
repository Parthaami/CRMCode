﻿using System;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;

namespace LeadAudit
{
    class LeadAudit
    {

        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;



        static void Main(string[] args)
        {
            try
            {

                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["AppServerUrl"].ToString();
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString(); 


                bergerlogger = new PragmasysLogger(org, logfilepath);

                IServiceManagement<IOrganizationService> orgServiceManagement =
                 ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                 new Uri(ConfigurationManager.AppSettings["APPServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                EntityCollection ContactEntityCollection = RetrieveDGContact(orgService);


                if (ContactEntityCollection.Entities.Count > 0)
                {
                    foreach (Entity DGContact in ContactEntityCollection.Entities)
                    {
                        int Total_Lead = 0;
                        int iRecord = 0;
                        Guid DGid = Guid.Empty;
                        DGid = DGContact.Id;


                        string contactid = DGContact.Id.ToString();
                        EntityCollection LeadEntityCollection = RetrieveLeads(orgService, contactid);
                        Total_Lead = LeadEntityCollection.Entities.Count;
                        if (Total_Lead != 0)
                        {

                            foreach (Entity Lead in LeadEntityCollection.Entities)
                            {
                                if (iRecord <= 2)
                                {
                                    Guid LeadId = Guid.Empty;
                                    LeadId = Lead.Id;
                                    Guid AuditLead = CreateLeadAudit(LeadId, DGid, orgService);
                                    if (AuditLead != null)
                                    {
                                        UpdateLead(LeadId, orgService);
                                    }
                                    iRecord++;
                                }

                            }
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static TProxy GetProxy<TService, TProxy>(
        IServiceManagement<TService> serviceManagement,
        AuthenticationCredentials authCredentials)
        where TService : class
        where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        public static void UpdateLead(Guid ID, IOrganizationService service)
        {
            try
            {
                Entity Lead = new Entity("lead");
                Lead.Attributes["leadid"] = ID;
                Lead.Attributes["ber_isaudited"] = true;
                service.Update(Lead);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealeLeadAudit", "UpdateLead", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
        }

        public static Guid CreateLeadAudit(Guid LeadID, Guid DGid, IOrganizationService service)
        {
            try
            {
                Random random = new Random();
                int value = random.Next(10000);


                Entity LeadAudit = new Entity("ber_leadaudit");
                LeadAudit.Attributes["ber_lead"] = new EntityReference("lead", LeadID);
                LeadAudit.Attributes["ber_customercode"] = value.ToString();
                LeadAudit.Attributes["ber_dg"] = new EntityReference("contact", DGid);
                Guid AuditId = service.Create(LeadAudit);

                return AuditId;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealeLeadAudit", "CreateLeadAudit", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }




        }

        public static EntityCollection RetrieveDGContact(OrganizationServiceProxy orgService)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='contact'>");
                strQuery.Append("<attribute name='contactid' />");
                strQuery.Append("<attribute name='fullname' />");
                strQuery.Append(" <order attribute='fullname' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_customertype' operator='eq' value='278290005' />");
                strQuery.Append("</filter>");
                strQuery.Append("<link-entity name='lead' from='ber_bdodgid' to='contactid' alias='aa'>");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='statuscode' operator='not-in' >");
                strQuery.Append("<value>278290005</value>");
                strQuery.Append("<value>278290006</value>");
                strQuery.Append("</condition>");
                strQuery.Append("</filter>");
                strQuery.Append("</link-entity>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("LeadAudit", "RetrieveDGContact", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealeLeadAudit", "RetrieveDGContact", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }





        public static EntityCollection RetrieveLeads(OrganizationServiceProxy orgService, string ContactId)
        {
            try
            {
                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical'>");
                strQuery.Append("<entity name='lead'>");
                strQuery.Append("<attribute name='leadid' />");
                strQuery.Append("<attribute name='firstname' />");
                strQuery.Append("<attribute name='fullname' />");
                strQuery.Append("<order attribute='fullname' descending='false' />");
                strQuery.Append("<filter type='and'>");
                strQuery.Append("<condition attribute='ber_bdodgid' value='" + ContactId + "' operator='eq'/>");
                strQuery.Append("<condition attribute='ber_isaudited'  operator='eq' value='0'/>");
                strQuery.Append("<condition attribute='statecode' operator='eq' value='0' />");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("LeadAudit", "RetrieveLeads", "Query Generated :" + strQuery, "");
                }

                EntityCollection LeadEntityCollection = Retrieve(orgService, strQuery.ToString());

                return LeadEntityCollection;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("LeadAudit", "RetrieveLeads", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }




        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }

    }
}
