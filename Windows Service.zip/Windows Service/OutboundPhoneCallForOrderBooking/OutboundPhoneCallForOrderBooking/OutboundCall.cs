﻿//========================================================================
// This windows service executes on daily basis and creates Order booking phone calls
// for dealers based on dealer category.
// Dealer category is maintained in config file of this service.
//
// Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using System.IO;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel.Description;

namespace OutboundPhoneCallForOrderBooking
{
    class OutboundCall
    {
        #region Class Level Members

        private static IOrganizationService _service;

        static Logger oLogger;
        static string Loggerpath = string.Empty;
        static string serverUrl = string.Empty;
        static Configuration config;
        static string _organizationName = ConfigurationManager.AppSettings["OrganisationName"];
        static string _customerCategory = ConfigurationManager.AppSettings["CustomerCategory"];
        static string _existingPhoneCallCategory = ConfigurationManager.AppSettings["ExistingPhoneCallCategory"];
        static int _classificationTypeCode = 0;
        //static int _arrClassificationTypeCode
        List<Int32> _arrClassificationTypeCode = new List<int>();

        static DateTime _Today = DateTime.Now;
        static DateTime _DueDate;
                   
        
        #endregion

        #region Main Method
        static void Main(string[] args)
        {
            try
            {
                #region Read Registry Key & get Pragmasys.config Path

                /*
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }
                
                */

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 

                //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        Loggerpath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_organizationName, Loggerpath);
                        serverUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                    }
                }
                #endregion

                //CRM Service Call
                _service = GetService();


                // Code will be changed multiple  GC / SC / STA   
                // return keys.All(k => dictionary.ContainsKey(k));

                
                // Commented the below Code 
                /*
                Dictionary<string, int> classificationDictionary = RetrieveAttributeMetadataPicklistValue(_service, "account", "accountcategorycode");
                if (classificationDictionary.ContainsKey(_customerCategory))
                {
                    _classificationTypeCode = classificationDictionary[_customerCategory];
                }
                EntityCollection oCustomerEntColl = getCustomers(_classificationTypeCode);
                */

                EntityCollection oCustomerEntColl = getCustomers(_classificationTypeCode);

                foreach (Entity oCustomer in oCustomerEntColl.Entities)
                {
                    string _CustomerPhoneNo = string.Empty;
                    string _CustomerAccountNumber = string.Empty;
                    int _timeOfCall = 0;
                    Guid NewPhoneCallId = Guid.Empty;
                    EntityReference _CustomerPreferredLanguage = null;
                    string OtherPhoneNumbers = string.Empty;


                    if (oCustomer.Attributes.Contains("accountnumber"))
                        _CustomerAccountNumber = Convert.ToString(oCustomer.Attributes["accountnumber"]);

                    //Check that customer has already any phone call activity pending to call
                    //if (!IsAnyPhoneCallOpen(_CustomerAccountNumber))
                    {
                        #region Customer Datail
                        if (oCustomer.Attributes.Contains("telephone1"))
                            _CustomerPhoneNo = Convert.ToString(oCustomer.Attributes["telephone1"]);

                        if (oCustomer.Attributes.Contains("telephone2"))
                            OtherPhoneNumbers = Convert.ToString(oCustomer.Attributes["telephone2"]);

                        if (oCustomer.Attributes.Contains("telephone3"))
                            OtherPhoneNumbers = OtherPhoneNumbers + "\r\n" + Convert.ToString(oCustomer.Attributes["telephone3"]);

                        if (oCustomer.Attributes.Contains("address1_telephone1"))
                            OtherPhoneNumbers = OtherPhoneNumbers + "\r\n" + Convert.ToString(oCustomer.Attributes["address1_telephone1"]);


                        if (oCustomer.Attributes.Contains("preferredappointmenttimecode"))
                        {
                            OptionSetValue timeOfCall = (OptionSetValue)oCustomer.Attributes["preferredappointmenttimecode"];
                            Dictionary<string, int> timeOfCallDictionary = RetrieveAttributeMetadataPicklistValue(_service, "account", "preferredappointmenttimecode");
                            foreach (KeyValuePair<string, int> pair in timeOfCallDictionary)
                            {
                                if (pair.Value.Equals(timeOfCall.Value))
                                {
                                    _timeOfCall = pair.Value;
                                    OtherPhoneNumbers = OtherPhoneNumbers + "\r\nPreferred Time: " + pair.Key.ToString();
                                    break;
                                }
                            }
                            if (_timeOfCall == 1)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 09, 00, 00);

                            else if (_timeOfCall == 2)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 11, 00, 00);

                            else if (_timeOfCall == 3 || _timeOfCall == 9)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 13, 00, 00);

                            else if (_timeOfCall == 4)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 15, 00, 00);

                            else if (_timeOfCall == 5)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 17, 00, 00);

                            else if (_timeOfCall == 6)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 10, 00, 00);

                            else if (_timeOfCall == 7)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 16, 00, 00);

                            else if (_timeOfCall == 8)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 12, 00, 00);

                            else if (_timeOfCall == 9)
                                _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 00, 00, 00);
                        }
                        if (oCustomer.Attributes.Contains("ber_preferredlanguage1"))
                            _CustomerPreferredLanguage = (EntityReference)oCustomer.Attributes["ber_preferredlanguage1"];


                        Guid AssigntoQueueId = Guid.Empty;
                        EntityReference WorkerId = null;
                        if (_CustomerPreferredLanguage != null)
                        {
                            EntityCollection QueueColl = RetriveQueue(_CustomerPreferredLanguage.Id, string.Empty);
                            if (QueueColl.Entities.Count > 0)
                            {
                                foreach (Entity oQueue in QueueColl.Entities)
                                {
                                    AssigntoQueueId = oQueue.Id;

                                    if (oQueue.Attributes.Contains("ownerid"))
                                        WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                                }
                            }
                            if (AssigntoQueueId == Guid.Empty)
                            {
                                string DefaultQueueName = ConfigurationManager.AppSettings["DefaultQueueName"];
                                EntityCollection DefaultQueueColl = RetriveQueue(Guid.Empty, DefaultQueueName);
                                foreach (Entity oQueue in DefaultQueueColl.Entities)
                                {
                                    AssigntoQueueId = oQueue.Id;

                                    if (oQueue.Attributes.Contains("ownerid"))
                                        WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                                }
                            }
                        }
                        if (AssigntoQueueId == Guid.Empty)
                        {
                            string DefaultQueueName = ConfigurationManager.AppSettings["DefaultQueueName"];
                            EntityCollection DefaultQueueColl = RetriveQueue(Guid.Empty, DefaultQueueName);
                            foreach (Entity oQueue in DefaultQueueColl.Entities)
                            {
                                AssigntoQueueId = oQueue.Id;

                                if (oQueue.Attributes.Contains("ownerid"))
                                    WorkerId = (EntityReference)oQueue.Attributes["ownerid"];
                            }
                        }

                        if (_timeOfCall != 0)
                        {
                            //Create Phone Call
                            NewPhoneCallId = CreateOutboundCall(oCustomer.Id, _CustomerPhoneNo, _DueDate, AssigntoQueueId, OtherPhoneNumbers);
                        }
                        else
                        {
                            //set due date as default morning datetime
                            _DueDate = new DateTime(_Today.Year, _Today.Month, _Today.Day, 10, 00, 00);
                            NewPhoneCallId = CreateOutboundCall(oCustomer.Id, _CustomerPhoneNo, _DueDate, AssigntoQueueId, OtherPhoneNumbers);
                        }

                        //Assign Phone Call to queue
                        AssignPhoneCalltoQueue(AssigntoQueueId, NewPhoneCallId, WorkerId.Id);
                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving Customers", "Main Method", ex.Message, ex.StackTrace.ToString());
            }
            finally
            {
              
            }
        }
        #endregion

        #region Function to get CRM Service
        /// <summary>
        /// Get CRM Service.
        /// </summary>
        /// <returns></returns>
        public static IOrganizationService GetService()
        {
            IOrganizationService crmsvc = null;
            try
            {
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(serverUrl));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgservice = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgservice.EnableProxyTypes();
                crmsvc = (IOrganizationService)orgservice;
            }
            catch (Exception ex)
            {
                oLogger.Log("Error while retriving CRM Service", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return crmsvc;
        }

        private static TProxy GetProxy<TService, TProxy>(
         IServiceManagement<TService> serviceManagement,
         AuthenticationCredentials authCredentials)
         where TService : class
         where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Function to get specified customers basis on customer category
        public static EntityCollection getCustomers(int ClassificationType)
        {
            EntityCollection Resultset = null;
            try
            {
            //CUST_CAT_CARD
            //  STA
            //  SC-X
            //  STA-X
            //  SC
            //  GC-X
            //  GC
            //  SGC
            //  SGC-X
             StringBuilder query = new StringBuilder();
             query.Append("<fetch mapping='logical'>");
             query.Append("<entity name='account'>");
             query.Append("<all-attributes/>");
             query.Append("<filter type='and'>");
             query.Append("<condition attribute='statecode' operator='eq' value='0' />");
             query.Append("<condition attribute='parentaccountid' operator='null' />");
             query.Append("<condition attribute='accountcategorycode' operator='in'>");

             if (_customerCategory == "GC")
             {
                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["GC"]);
                    query.Append("</value>");

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["GC-X"]);
                    query.Append("</value>");

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["SGC"]);
                    query.Append("</value>");

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["SGC-X"]);
                    query.Append("</value>");
                }
             else if (_customerCategory == "SC")
             {
                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["SC"]);
                    query.Append("</value>");

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["SC-X"]);
                    query.Append("</value>");
             }
             else if (_customerCategory == "STA")
             {

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["STA"]);
                    query.Append("</value>");

                    query.Append("<value>");
                    query.Append(ConfigurationManager.AppSettings["STA-X"]);
                    query.Append("</value>");
             }

                //query.Append("<value>'"+ClassificationType+"'</value>");
                //query.Append("</condition>");
                //query.Append("<condition attribute='accountcategorycode' operator='eq' value='" + ClassificationType + "' />");

             query.Append("</condition>");
             query.Append("</filter>");
             query.Append("<link-entity name='account' from='accountid' to='parentaccountid' visible='false' link-type='outer' >");
             query.Append("<attribute name='accountnumber' />");
             query.Append("</link-entity>");
             query.Append("</entity>");
             query.Append("</fetch>");

             Resultset = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to get customers", "getCustomers", ex.Message, ex.StackTrace.ToString());
            }

            return Resultset;
        }
        #endregion

        #region Function to get Optionset facevalues
        public static Dictionary<string,int> RetrieveAttributeMetadataPicklistValue(IOrganizationService crmService,string EntityName,string FieldName)
        {
            Dictionary<string, int> Classification = new Dictionary<string, int>();              
            try
            {
                RetrieveAttributeRequest objRetrieveAttributeRequest;
                objRetrieveAttributeRequest = new RetrieveAttributeRequest();
                objRetrieveAttributeRequest.EntityLogicalName = EntityName;
                objRetrieveAttributeRequest.LogicalName = FieldName;
                // Execute the request
                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)crmService.Execute(objRetrieveAttributeRequest);
                PicklistAttributeMetadata objPckLstAttMetadata = new PicklistAttributeMetadata();
                ICollection<object> objCollection = attributeResponse.Results.Values;

                objPckLstAttMetadata.OptionSet = ((EnumAttributeMetadata)(objCollection.ElementAt(0))).OptionSet;
                OptionMetadataCollection OptionsetCollection = objPckLstAttMetadata.OptionSet.Options;
                string lblAddTypeLabel = string.Empty;
                foreach (OptionMetadata Option in OptionsetCollection)
                {
                    Microsoft.Xrm.Sdk.Label objLabel = Option.Label;
                    lblAddTypeLabel = objLabel.LocalizedLabels.ElementAt(0).Label;
                    Classification.Add(lblAddTypeLabel, Convert.ToInt32(Option.Value));
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Error retriving Metadate", "RetrieveAttributeMetadataPicklistValue", ex.Message, ex.StackTrace.ToString());
            }
            return Classification;
        }
        #endregion

        #region Function to create phonecall activity
        public static Guid CreateOutboundCall(Guid CustomerId,string CustomerPhoneNo,DateTime DueDate,Guid AssignToQueue,string desc)
        {
            Guid phonecallid = Guid.Empty;
            try
            {
                Entity phonecall = new Entity();
                phonecall.LogicalName = "phonecall";

                EntityCollection tocollection = new EntityCollection();

                Entity toentity = new Entity();
                toentity.LogicalName = "activityparty"; ;
                toentity.Attributes["partyid"] = new EntityReference("account", CustomerId);
                tocollection.Entities.Add(toentity);

                phonecall["to"] = tocollection;
                phonecall["phonenumber"] = CustomerPhoneNo;
                phonecall["regardingobjectid"] = new EntityReference("account", CustomerId);
                phonecall["subject"] = ConfigurationManager.AppSettings["Subject"];
                phonecall["category"] = ConfigurationManager.AppSettings["PhoneCallCategory"];
                phonecall["subcategory"] = ConfigurationManager.AppSettings["CustomerCategory"];
                phonecall["scheduledend"] = DueDate;
                phonecall["description"] = desc + "\r\n" + ConfigurationManager.AppSettings["Description"];
                if(AssignToQueue != Guid.Empty)
                  phonecall["ber_assignedtoqueueid"] = new EntityReference("queue", AssignToQueue);
                
                phonecallid = _service.Create(phonecall);
            }
            catch (Exception ex)
            {
                oLogger.Log("Error Creating Phone Call", "CreateOutboundCall", ex.Message, ex.StackTrace.ToString());
            }
            return phonecallid;
        }
        #endregion

        #region Function to get Queue of Preferred language of Customer
        public static EntityCollection RetriveQueue(Guid LanguageId,string QueueName)
        {
            EntityCollection Resultset = null;
            try
            {
                QueryExpression query = new QueryExpression();
                query.EntityName = "queue";
                query.ColumnSet = new ColumnSet(true);
                
                ConditionExpression Language = new ConditionExpression();
                Language.AttributeName = "ber_languageid";
                Language.Operator = ConditionOperator.Equal;
                Language.Values.Add(LanguageId);

                ConditionExpression Queue = new ConditionExpression();
                Queue.AttributeName = "name";
                Queue.Operator = ConditionOperator.Equal;
                Queue.Values.Add(QueueName);

                FilterExpression filter = new FilterExpression();
                filter.FilterOperator = LogicalOperator.And;
                if(LanguageId != Guid.Empty)
                    filter.AddCondition(Language);

                else if(QueueName != string.Empty)
                    filter.AddCondition(Queue);

                query.Criteria.AddFilter(filter);

                Resultset = _service.RetrieveMultiple(query);                              
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to Retrive Queue", "RetriveQueue", ex.Message, ex.StackTrace.ToString());
            }

            return Resultset;
        }
        #endregion

        #region Function to Assign Phone call activity to queue
        public static void AssignPhoneCalltoQueue(Guid QueueId, Guid PhoneCallId,Guid WorkerId)
        {
            try
            {
                Entity QueueItem = new Entity("queueitem");
                QueueItem["queueid"] = new EntityReference("queue", QueueId);
                QueueItem["objectid"] = new EntityReference("phonecall", PhoneCallId);
                QueueItem["workerid"] = new EntityReference("systemuser", WorkerId);
                Guid ID = _service.Create(QueueItem);
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to add phone call in queue", "AssignPhoneCalltoQueue", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion

        #region Function to Restrive Data from Fetch XMl
        public static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("OutboundPhoneCallForOrderBooking", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to check customer has already any phone call
        public static bool IsAnyPhoneCallOpen(string CustomerAccountNumber)
        {
            bool flag = false;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='phonecall'>");
                query.Append("<attribute name='subject' />");
                query.Append("<attribute name='statecode' />");
                query.Append("<attribute name='prioritycode' />");
                query.Append("<attribute name='scheduledend' />");
                query.Append("<order attribute='subject' descending='false' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<condition attribute='category' operator='eq' value='" + _existingPhoneCallCategory +"' />");
                query.Append("</filter>");
                query.Append("<link-entity name='account' from='accountid' to='regardingobjectid' alias='aa'>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='accountnumber' operator='eq' value='" + CustomerAccountNumber + "' />");
                query.Append("</filter>");
                query.Append("</link-entity>"); 
                query.Append("</entity>");
                query.Append("</fetch>");

                EntityCollection Resultset = Retrieve(_service, query.ToString());
                if (Resultset.Entities.Count > 0)
                    flag = true;
            }
            catch (Exception ex)
            {
                oLogger.Log("Error retriving customer open phone calls", "IsAnyPhoneCallOpen", ex.Message, ex.StackTrace.ToString());
            }
            return flag;
        }
        #endregion
    }
}
