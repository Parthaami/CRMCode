﻿using System;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace LeadConsolApplication
{

    class LeadPostponed
    {

        #region variable
        
        string CRMOrgServiceUrl = ConfigurationManager.AppSettings["CRMOrgServiceUrl"];
        string homeRealmUri = ConfigurationManager.AppSettings["homeRealmUri"];
        string credentials = ConfigurationManager.AppSettings["credentials"];
        public static string LoggerPath = ConfigurationManager.AppSettings["LoggerPath"].ToString();
        
        public static Logger Ologer = new Logger("BPILCRM", LoggerPath);
        

        #endregion
        static void Main(string[] args)
        {
            RetrieveLeadData();
            
        }


        #region Lead operation 
        public static void RetrieveLeadData()
        {

            try
            {

                EntityCollection Result = null;
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgServiceproxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgServiceproxy.EnableProxyTypes();

                IOrganizationService orgService = (IOrganizationService)orgServiceproxy;



                string query = @" 
                         <fetch mapping='logical'>
                             <entity name='lead'>
                            <attribute name='fullname' />
                             <attribute name='companyname' />
                             <attribute name='ber_leadtype' />
                              <attribute name='ber_whowill' />
                              <attribute name='ber_pincodeid' />
                             <attribute name='ber_quotationvalue' />
                             <attribute name='ber_lbhpquotationvalue' />
                             <attribute name='telephone1' />
                             <attribute name='ber_xpa' />
                            <attribute name='ber_tsiid2' />
                            <attribute name='ber_masterpainterid' />
                            <attribute name='ber_dgcontact' />
                            <attribute name='ber_dealerid' />
                            <attribute name='ber_masterpainterid' />
                               <attribute name='leadid' />
                              <attribute name='ber_wondate' />
                               <attribute name='ber_newdate' />
                            <attribute name='statuscode' />
                             <attribute name='statecode' />
                            <attribute name='ber_painterallocationdate' />
                         <attribute name='ber_capturece' />
                         <attribute name='ber_capturejobcompleteddate' />
                         <attribute name='ber_capturedealerallocateddate' />
                            <attribute name='createdon' />
                             <order attribute='fullname' descending='false' />
                             <filter type='and'>
                              <condition attribute='statecode' operator='eq' value='2' />
                              <condition attribute='statuscode' operator='eq' value='278290013' />
                            
                             <condition attribute='ber_postponeddate' operator='last - x - days' value='3'/>
    </filter></entity></fetch>";
                //<condition attribute='ber_postponeddate' operator='today' />

                Result = orgService.RetrieveMultiple(new FetchExpression(query));
                foreach (var c in Result.Entities)
                {

                    EntityReference DG = null;
                    EntityReference Dealer = null;
                    EntityReference Painter = null;
                    EntityReference TSI = null;
                    EntityReference XPA = null;
                    EntityReference Pincode = null;

                    Money Quotationvalue = c.GetAttributeValue<Money>("ber_quotationvalue");
                    
                    OptionSetValue leadtype = c.GetAttributeValue<OptionSetValue>("ber_leadtype");

                    OptionSetValue CustomerExecutive = c.GetAttributeValue<OptionSetValue>("ber_whowill");
                   
                    Money LBHPQuotationvalue = c.GetAttributeValue<Money>("ber_lbhpquotationvalue");

                    DateTime newdate = c.GetAttributeValue<DateTime>("createdon");
                    DateTime? newdateNullable = c.GetAttributeValue<DateTime?>("createdon");

                    DateTime capturedealerallocateddate = c.GetAttributeValue<DateTime>("ber_capturedealerallocateddate");
                   DateTime? capturedealerallocateddateNullable = c.GetAttributeValue<DateTime?>("ber_capturedealerallocateddate");

                    DateTime capturece = c.GetAttributeValue<DateTime>("ber_capturece");
                    DateTime? captureceNullable = c.GetAttributeValue<DateTime?>("ber_capturece");

                    DateTime painterallocationdate = c.GetAttributeValue<DateTime>("ber_painterallocationdate");
                    DateTime? painterallocationdateNullable = c.GetAttributeValue<DateTime?>("ber_painterallocationdate");

                    DateTime wondate = c.GetAttributeValue<DateTime>("ber_wondate");
                    DateTime? wondateNullable = c.GetAttributeValue<DateTime?>("ber_wondate");

                    if (c.Attributes.Contains("ber_pincodeid"))
                    {
                        Pincode = (EntityReference)c.Attributes["ber_pincodeid"];
                    }

                    if (c.Attributes.Contains("ber_dealerid"))
                    {
                         Dealer = (EntityReference)c.Attributes["ber_dealerid"];
                    }

                    if (c.Attributes.Contains("ber_masterpainterid"))
                    {
                         Painter = (EntityReference)c.Attributes["ber_masterpainterid"];
                    }

                    if (c.Attributes.Contains("ber_dgcontact"))
                    {
                         DG = (EntityReference)c.Attributes["ber_dgcontact"];
                    }

                    if (c.Attributes.Contains("ber_tsiid2"))
                    {
                         TSI = (EntityReference)c.Attributes["ber_tsiid2"];
                    }

                    if (c.Attributes.Contains("ber_xpa"))
                    {
                        XPA = (EntityReference)c.Attributes["ber_xpa"];
                    }

                    if (leadtype.Value == 278290002 )
                    {
                        // new date
                        if (newdate != null && Pincode == null && DG == null && TSI == null && Dealer == null && Painter == null)  // Your logic
                        {
                            ActivateRecord("lead", c.Id, orgService);
                            c["statecode"] = new OptionSetValue(0);
                            c["statuscode"] = new OptionSetValue(278290007);
                            orgService.Update(c);
                        }

                        else if (newdate != null && Pincode != null && DG == null && TSI == null && Dealer == null && Painter == null)  // Your logic
                        {
                            ActivateRecord("lead", c.Id, orgService);
                            c["statecode"] = new OptionSetValue(0);
                            c["statuscode"] = new OptionSetValue(1);
                            orgService.Update(c);
                        }

                        // CE = DG/CSM
                        else if ((CustomerExecutive != null) && ((CustomerExecutive.Value == 0) || (CustomerExecutive.Value == 1)) && Dealer == null)
                        {
                            if (DG != null && TSI != null)  // Your logic                    
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290032);
                                orgService.Update(c);
                            }
                        }

                        // CE = TSI
                        else if (CustomerExecutive != null && CustomerExecutive.Value == 2 && Dealer == null)
                        {
                            if (TSI != null)  // Your logic                    
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290032);
                                orgService.Update(c);
                            }
                        }
                        // CE = XPA
                        else if (CustomerExecutive != null && CustomerExecutive.Value == 3 && Dealer == null)
                        {
                            if (XPA != null)  // Your logic                    
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290032);
                                orgService.Update(c);
                            }
                        }

                        //dealer allocation date

                        else if (Dealer != null && Painter == null && wondateNullable == null)
                        {
                            if (Dealer.Id != null)  // Your logic                                                   
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290004);
                                orgService.Update(c);
                            }
                        }

                        // painter allocation

                        //checking (Painter != null)   before Id setting ....
                        else if (Painter != null && wondateNullable == null && Quotationvalue == null)
                        {
                            if (Painter.Id != null)  // Your logic
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290009);
                                orgService.Update(c);
                            }
                        }

                        //quotation given 

                        else if (Painter != null && Quotationvalue != null && wondateNullable == null)
                        {
                            if (Painter.Id != null)  // Your logic
                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290026);
                                orgService.Update(c);
                            }
                        }

                        // won date
                        else if (Painter != null && wondateNullable != null)
                        {
                            if (Painter.Id != null)  // Your logic

                            {
                                ActivateRecord("lead", c.Id, orgService);
                                c["statecode"] = new OptionSetValue(0);
                                c["statuscode"] = new OptionSetValue(278290005);
                                orgService.Update(c);
                            }

                        }
                                              
                }
                       
                   
               }
          }

            catch (Exception ex)
            {
                Ologer.Log("", "RetrieveLeadData", "Error on Lead Postponed", ex.Message.ToString());
            }


        }

       private static TProxy GetProxy<TService, TProxy>(
      IServiceManagement<TService> serviceManagement,
      AuthenticationCredentials authCredentials)
      where TService : class
      where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region ActivateRecord
        //public static  ActivateRecord(string entityName, Guid recordId, IOrganizationService organizationService)
        public static void ActivateRecord(string entityName, Guid recordId, IOrganizationService organizationService)
        {
            var cols = new ColumnSet(new[] { "statecode", "statuscode" });

            //Check if it is Inactive or not
            var entity = organizationService.Retrieve(entityName, recordId, cols);

            if (entity != null && entity.GetAttributeValue<OptionSetValue>("statecode").Value == 2)
            {
                //StateCode = 0 and StatusCode = 1 for activating Account or Contact
                SetStateRequest setStateRequest = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference
                    {
                        Id = recordId,
                        LogicalName = entityName,
                    },
                    State = new OptionSetValue(0),
                    Status = new OptionSetValue(1)
                };
                organizationService.Execute(setStateRequest);
            }
        }
        #endregion

    }
}


          
