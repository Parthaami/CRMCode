﻿using System;
using System.IO;

namespace LeadConsolApplication
{
    public class Logger
    {
        private string _organization;
        private string _filePath;
        private string Folder_path = string.Empty;
        public Logger(string OrgnizationName, string configfilepath)
        {
            _organization = OrgnizationName;
            Folder_path = configfilepath;
        }

        public void Log(string SourceName, string MethodName, string description, string ErrorMessage)
        {
            try
            {
                _filePath = Folder_path + "Log_LeadPostponed_" + _organization + ".txt";
                string[] ErrorLogs = { SourceName, MethodName, description, ErrorMessage };
                if (!Directory.Exists(Folder_path))
                {
                    Directory.CreateDirectory(Folder_path);
                }
                if (!File.Exists(_filePath))
                {
                    FileStream aFile = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                    aFile.Close();
                    StreamWriter file = new StreamWriter(_filePath);
                    file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.WriteLine(" S.No.       CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Write("*.");
                    file.Write("\t");
                    file.Write(System.DateTime.Now);
                    file.Write("\t\t");
                    foreach (string log in ErrorLogs)
                    {
                        file.Write(log);
                        file.Write("\t\t");
                    }
                    file.WriteLine("");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Close();
                }
                else
                {
                    File.AppendAllText(_filePath, System.Environment.NewLine);
                    File.AppendAllText(_filePath, "*.");
                    File.AppendAllText(_filePath, "\t");
                    File.AppendAllText(_filePath, System.DateTime.Now.ToString());
                    File.AppendAllText(_filePath, "\t\t");
                    foreach (string log in ErrorLogs)
                    {
                        File.AppendAllText(_filePath, log);
                        File.AppendAllText(_filePath, "\t\t");
                    }
                    File.AppendAllText(_filePath, System.Environment.NewLine);
                    File.AppendAllText(_filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
