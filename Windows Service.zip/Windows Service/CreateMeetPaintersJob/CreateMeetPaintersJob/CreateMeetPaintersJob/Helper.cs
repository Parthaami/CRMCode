﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateMeetPaintersJob
{
    class Helper
    {
        public static DataSet ConvertEntityCollectionToDataTable(EntityCollection EntCol)
        {
            if (EntCol.Entities.Count > 0)
            {
                DataSet dsEnt = new DataSet();
                foreach (Entity Ent in EntCol.Entities)
                {
                    dsEnt.Tables.Add(convertEntityToDataTable(Ent));
                }
                return dsEnt;
            }
            return null;
        }

        public static DataTable convertEntityToDataTable(Entity EntTemp)
        {
            DataTable dt = new DataTable();
            int total = EntTemp.Attributes.Count;
            for (int i = 0; i < total; i++)
            {
                DataRow row = dt.NewRow();

                var keys = EntTemp.Attributes.Keys;
                foreach (var item in keys)
                {
                    string columnName = item;
                    string value = getValuefromAttribute(EntTemp.Attributes[item]);
                    if (dt.Columns.IndexOf(columnName) == -1)
                    {
                        dt.Columns.Add(item, Type.GetType("System.String"));
                    }
                    row[columnName] = value;
                }
                dt.Rows.Add(row);
            }
            return dt;
        }

        private static string getValuefromAttribute(object p)
        {
            if (p.ToString() == "Microsoft.Xrm.Sdk.EntityReference")
            {
                return ((EntityReference)p).Name;
            }
            if (p.ToString() == "Microsoft.Xrm.Sdk.OptionSetValue")
            {
                return ((OptionSetValue)p).Value.ToString();
            }
            if (p.ToString() == "Microsoft.Xrm.Sdk.Money")
            {
                return ((Money)p).Value.ToString();
            }
            if (p.ToString() == "Microsoft.Xrm.Sdk.AliasedValue")
            {
                return ((Microsoft.Xrm.Sdk.AliasedValue)p).Value.ToString();
            }
            else
            {
                return p.ToString();
            }
        }

    }
}
