﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Configuration;
using System.Data;
using System.Net;
using System.ServiceModel.Description;
using System.Text.RegularExpressions;
using System.Xml;

namespace CreateMeetPaintersJob
{
    class Program
    {
        #region "Global Variable" 
            public static Configuration config;
            public static Logger oLogger;
            public static string SQLConnStr = string.Empty;
            private XmlDocument _pluginConfiguration;
            public static OrganizationServiceProxy _service;
            public static string UploadPainterQuery = ConfigurationManager.AppSettings["UploadPainterQuery"].ToString();
            public static string _sqlConnectionString = ConfigurationManager.ConnectionStrings["db_connection"].ConnectionString;
        #endregion


        static void Main(string[] args)
        {
            //All Plugin logic need to be implement this method  .....
            ExecuteJob();
        }



        /// <summary>
        /// GetCredentials
        /// </summary>
        /// <typeparam name="TService"></typeparam>
        /// <param name="service"></param>
        /// <param name="endpointType"></param>
        /// <returns></returns>
        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["Domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        /// <summary>
        /// GetProxy
        /// </summary>
        /// <typeparam name="TService"></typeparam>
        /// <typeparam name="TProxy"></typeparam>
        /// <param name="serviceManagement"></param>
        /// <param name="authCredentials"></param>
        /// <returns></returns>
        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        /// <summary>
        /// ExecuteJob
        /// </summary>
        private static void ExecuteJob()
        {
            try
            {
                #region "AllVariableHere"
                // Obtain the execution context from the service provider.
                //IPluginExecutionContext context =
                //    (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                // Get a reference to the organization service.
                //IOrganizationServiceFactory factory =
                //    (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                //IOrganizationService service = factory.CreateOrganizationService(context.UserId);

                // Get a reference to the tracing service.
                //ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

                //var organizationUri;
                //var homeRealmUri;
                //var credentials;

                string org                  = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath          = ConfigurationManager.AppSettings["loggerpath"].ToString();
                string serverurl            = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                string server               = ConfigurationManager.AppSettings["DBServer"].ToString();
                string DatabaseName         = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
                string UserName             = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password             = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain               = ConfigurationManager.AppSettings["domain"].ToString();

                //string UploadPainterQuery   = ConfigurationManager.AppSettings["UploadPainterQuery"].ToString();


                /*

                ClientCredentials credentials = new ClientCredentials();
                //credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;                
                credentials.Windows.ClientCredential = new NetworkCredential(UserName, Password, Domain);
                Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
                Uri homeRealmUri = null;

                _service = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                _service.EnableProxyTypes();
                */


                //OrganizationServiceProxy _service = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = serverurl;//ConfigurationManager.AppSettings["SoapUri"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                _service = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
               
                // _service = (IOrganizationService)orgService;


                //string _organizationName = context.OrganizationName;
                //Guid CallingUserId = context.UserId;
                //string PrimaryEntityName = context.PrimaryEntityName;
                //Guid PrimaryEntityId = context.PrimaryEntityId;

                creatUpdateMeetPainter(_sqlConnectionString);
                #endregion

                #region To Read Config File
                //string _loggerPath = GetConfigDataString(_pluginConfiguration, "Loggerpath");
                //oLogger = new Logger(_organizationName, _loggerPath);
                //SQLConnStr =   GetConfigDataString(_pluginConfiguration, "Bergersqldbconnection");
                //tracingService.Trace("SQLConnStr: {0}", SQLConnStr);
                #endregion

            }
            catch(Exception ex)
            {
            }
        }

        //Method "creatUpdateMeetPainter"   will triggered  when creation / Updatation 
        public static void creatUpdateMeetPainter(string SQLConnStr)
        {
            try
            {
                //Entity UploadPainterEntity = (Entity)context.InputParameters["Target"];
                //Uploading Entity 
                //EntityCollection ecResults = iOService.RetrieveMultiple(query);
                //Entity UploadPainterEntity = null;  //ber_painterupload  R => New, P => Pass, F => Failed

                /**************************************************************************************
                  278290000 = > P
                  278290001 = > R
                  278290002 = > F
                ***************************************************************************************/

                string sQuery = UploadPainterQuery; //"select * from ber_painterupload up where up.ber_ContactNumber = '9836984197' and convert(date,up.CreatedOn,101) = convert(date,getdate(),101)";
                DataTable UploadPainterEntity = FetchData.getDataFromSql(sQuery, SQLConnStr, oLogger);
                //DataSet dsEntity = Helper.ConvertEntityCollectionToDataTable(ecResults);

                string ber_contactnumber = string.Empty;
                Guid UploadPainterEntityGuid;
                foreach (DataRow dr in UploadPainterEntity.Rows)
                {
                    ber_contactnumber = Convert.ToString(dr["ber_contactnumber"]);
                    UploadPainterEntityGuid = new Guid(Convert.ToString(dr["ber_painteruploadId"]));

                    //Validated Create Painter  
                    if (IsValidateMobileNumber(ber_contactnumber))
                    {
                        ValidateCreateUpdateMeetPainter(UploadPainterEntity, ber_contactnumber, UploadPainterEntityGuid, SQLConnStr);
                    }
                }
            }
            catch(Exception ex)
            {
            }
        }

        /// <summary>
        /// IsValidateMobileNumber
        /// </summary>
        /// <param name="ber_contactnumber"></param>
        /// <returns></returns>
        private static bool IsValidateMobileNumber(string ber_contactnumber)
        {
            bool result = false;
            try
            {
                if (ber_contactnumber.Length > 10 && (Regex.Match(ber_contactnumber, @"^(\+[0-9])$").Success))
                {
                    result = false;
                }
                else
                {
                    result = true;
                }
            }
            catch(Exception ex)
            {
                result = false;
            }
            return result;
        }

       
        public static void ValidateCreateUpdateMeetPainter( DataTable UploadPainterEntity, string ber_contactnumber, Guid UploadPainterEntityGuid, string SQLConnStr)
        {

            // if (UploadPainterEntity.Attributes.Contains("ber_contactnumber"))
            if (UploadPainterEntity.Rows.Count > 0)
            {
                //string PainterQry = "select contactid from Contact (nolock) where (telephone1='" + UploadPainterEntity["ber_contactnumber"].ToString() + "' " +
                //                    "OR mobilephone='" + UploadPainterEntity["ber_contactnumber"].ToString() + "') " +
                //                    "and statecode = 0 and ber_CustomerType ='278290001'";
                //tracingService.Trace("PainterQry: " + PainterQry);


                string PainterQry = "select contactid from Contact (nolock) where (telephone1='" + ber_contactnumber + "' " +
                                    "OR mobilephone='" + ber_contactnumber + "') " +
                                    "and statecode = 0 and ber_CustomerType ='278290001'";


                DataTable dtPainterDetails = FetchData.getDataFromSql(PainterQry, SQLConnStr, oLogger);

                if (dtPainterDetails.Rows.Count > 0 && dtPainterDetails.Rows[0][0] != DBNull.Value)//If Upload Painter is Existing Painter Number
                {
                    string verifyPainterQry = "select mt.ber_Type as MeetType, mt.ber_SchemeRequired as SchemeRequired, 'Painter already active in: '+ t2.ber_name + ' running at ' + t2.ber_DepotName +'.' as ErrorMessage " +
                                              "from ber_paintermeetcontact t1 (nolock) inner join ber_paintermeet t2 (nolock) on t1.ber_PainterMeet =t2.ber_paintermeetId inner join ber_meet mt (nolock) on t2.ber_Meet = mt.ber_meetId " +
                                              "inner join Contact t4 (nolock) on t1.ber_Contact = t4.ContactId inner join ber_meetexclusioncriteria  meetin on mt.ber_Type = meetin.ber_MeetType  and mt.ber_SchemeRequired = meetin.ber_SchemeRequired and meetin.statecode=0 where t1.statecode=0 AND t4.StateCode=0 AND t1.statuscode = 1 and mt.statecode=0 AND mt.statuscode = 1 AND  t4.ContactId = '" + Convert.ToString(dtPainterDetails.Rows[0][0]) + "' AND " +
                                              "exists (select meetinclu.ber_MeetType, meetinclu.ber_SchemeRequired from ber_meetinclusioncriteria meetinclu (nolock)  inner join ( select m3.ber_Type, m3.ber_SchemeRequired from ber_painterupload p1 (nolock) " +
                                              "inner join ber_paintermeet t2 (nolock) on p1.ber_MeetPlanningId = t2.ber_paintermeetId inner join ber_meet m3 (nolock) on t2.ber_Meet = m3.ber_meetId where p1.ber_painteruploadId ='" + Convert.ToString(UploadPainterEntityGuid) + "') t5 on t5.ber_Type = meetinclu.ber_MeetType " +
                                              " and t5.ber_SchemeRequired = meetinclu.ber_SchemeRequired inner join ber_meetexclusioncriteria t6 (nolock) on meetinclu.ber_meetinclusioncriteriaId = t6.ber_MeetInclusionCriteriaId AND t6.statecode=0 AND t6.statuscode = 1)";

                    DataTable dtMeetPainters = FetchData.getDataFromSql(verifyPainterQry, SQLConnStr, oLogger);
                    //tracingService.Trace("RowCount: " + dtMeetPainters.Rows.Count);
                    if (dtMeetPainters.Rows.Count > 0)
                    {
                        Entity UpdateRemark = new Entity("ber_painterupload");
                        UpdateRemark.Id = UploadPainterEntityGuid;//UploadPainterEntity.Id;
                        UpdateRemark["ber_remarks"] = dtMeetPainters.Rows[0][2].ToString();
                        _service.Update(UpdateRemark);
                    }
                    else // if Painter is Existing but he/she is not involved in any existing Meet Painter. Create Meet Painter Record.
                    {
                        Entity MeetPlaining = FetchData.RetrieveMeetPlanning(_service, UploadPainterEntityGuid);//UploadPainterEntity.Id);
                        if (MeetPlaining != null && MeetPlaining.Attributes.Contains("ber_meettype") && MeetPlaining.GetAttributeValue<OptionSetValue>("ber_meettype").Value.Equals(278290002))
                        {
                            var depotId = MeetPlaining.Attributes.Contains("ber_depot") ? MeetPlaining.GetAttributeValue<EntityReference>("ber_depot").Id : Guid.Empty;
                            var dealerId = MeetPlaining.Attributes.Contains("ber_dealer") ? MeetPlaining.GetAttributeValue<EntityReference>("ber_dealer").Id : Guid.Empty;
                            var ownerId = MeetPlaining.Attributes.Contains("ownerid") ? MeetPlaining.GetAttributeValue<EntityReference>("ownerid").Id : Guid.Empty;
                            FetchData.UpdateContact(Convert.ToString(dtPainterDetails.Rows[0][0]), depotId, dealerId, ownerId, _service, oLogger);
                        }
                        //share Record with owner of Meet Planning
                        //FetchData.ShareRecord(service, new EntityReference("systemuser", ((EntityReference)MeetPlaining["ownerid"]).Id), "contact", new Guid(dtPainterDetails.Rows[0][0].ToString()));

                        //Create Meet Painter
                        CreateMeetPainter(_service, new Guid(Convert.ToString(dtPainterDetails.Rows[0][0])), MeetPlaining.Id);
                        _service.Delete("ber_painterupload", UploadPainterEntityGuid);//UploadPainterEntity.Id);
                    }
                }
                else // If Upload Painter is New Painter Create Contact for this Painter and Create Meet Painter Record.
                {

                    ////Retrive Data from painterupload  ........
                    QueryExpression query = new QueryExpression
                    {
                        EntityName = "ber_painterupload",
                        ColumnSet = new ColumnSet(new string[]
                    {
                    "ber_painteruploadid",
                    "ber_contactnumber",
                    "ber_firstname",
                    "ber_lastname",
                    "ber_remarks"
                    }),
                        Criteria =
                    {
                        Conditions =
                                {
                                    new ConditionExpression("ber_painteruploadid", ConditionOperator.Equal, UploadPainterEntityGuid),
                                    new ConditionExpression("ber_uploadedstatus", ConditionOperator.Equal, 278290001),

                                }
                    }
                    };

                    //Entity GettingLeadEntity = orgService.RetrieveMultiple(query).Entities[0];

                    //Create New Painter in CRM.
                    //QueryExpression query = new QueryExpression
                    //{
                    //    EntityName = "ber_painterupload",
                    //    ColumnSet = new ColumnSet("ber_painteruploadId", "ber_FirstName", "ber_LastName", "ber_Remarks"),
                    //    Criteria = //new FilterExpression
                    //    {
                    //        Conditions =
                    //        {
                    //            //new ConditionExpression { AttributeName = "ber_UploadedStatus", Operator = ConditionOperator.Equal, Values = { 278290001 } },
                    //            //new ConditionExpression { AttributeName = "ber_painteruploadId", Operator = ConditionOperator.Equal,Values = { UploadPainterEntityGuid } }
                                
                    //            new ConditionExpression("ber_painteruploadId", ConditionOperator.Equal, UploadPainterEntityGuid)
                    //            //new ConditionExpression("ber_UploadedStatus", ConditionOperator.Equal, 278290001)
                    //        }
                    //    }
                    //};

                    EntityCollection ecUploadPainterEntity = _service.RetrieveMultiple(query);

                    string teststring = "";

                    CreatePainterContact(_service, ecUploadPainterEntity.Entities[0], SQLConnStr);

                    //Delete Upload Painter Record.
                    _service.Delete("ber_painterupload", UploadPainterEntityGuid);//UploadPainterEntity.Id);
                }
            }

        }


        public static string GetConfigDataString(XmlDocument doc, string label)
        {
            return GetValueNode(doc, label);
        }
        private static string GetValueNode(XmlDocument doc, string key)
        {
            XmlNode node = doc.SelectSingleNode(String.Format("Settings/setting[@name='{0}']", key));
            if (node != null)
            {
                return node.SelectSingleNode("value").InnerText;
            }
            return string.Empty;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Service"></param>
        /// <param name="uploadPainter"></param>
        /// <param name="SQLConnStr"></param>
        public static void CreatePainterContact(IOrganizationService Service, Entity uploadPainter,string SQLConnStr)
        {
            try
            {
                #region Create New Painter Contact
                var ownerId = Guid.Empty;
                Entity PainterContact = new Entity("contact");

                PainterContact["ber_customertype"] = new OptionSetValue(278290001);//Set Painter as Customer Type.

                if (uploadPainter.Attributes.Contains("ber_firstname"))
                    PainterContact["firstname"] = uploadPainter["ber_firstname"].ToString();

                if (uploadPainter.Attributes.Contains("ber_lastname"))
                    PainterContact["lastname"] = uploadPainter["ber_lastname"].ToString();

                if (uploadPainter.Attributes.Contains("ber_contactnumber"))
                    PainterContact["mobilephone"] = uploadPainter["ber_contactnumber"].ToString();

                Entity MeetPlaining = FetchData.RetrieveMeetPlanning(Service, uploadPainter.Id);
                if (MeetPlaining != null) //&& MeetPlaining.GetAttributeValue<OptionSetValue>("ber_meettype").Value.Equals(278290002)
                {
                    ownerId = MeetPlaining.Attributes.Contains("ownerid") ? MeetPlaining.GetAttributeValue<EntityReference>("ownerid").Id : Guid.Empty;
                    if (MeetPlaining.Attributes.Contains("ber_depot"))
                    {
                        PainterContact["ber_depotid"] = (EntityReference)MeetPlaining["ber_depot"];
                    }
                    if (MeetPlaining.Attributes.Contains("ber_dealer"))
                    {
                        PainterContact["ber_dealerid"] = (EntityReference)MeetPlaining["ber_dealer"];

                        string dealerQry = "select ber_region,ber_preferredlanguage1,ber_preferredlanguage2 from account (nolock) " +
                                           "where accountid ='" + ((EntityReference)MeetPlaining["ber_dealer"]).Id.ToString() + "'";

                        DataTable dtDealer = FetchData.getDataFromSql(dealerQry, SQLConnStr, oLogger);

                        if (dtDealer.Rows.Count > 0)
                        {
                            if (dtDealer.Rows[0][0] != DBNull.Value)
                                PainterContact["ber_regionid"] = new EntityReference("ber_region", new Guid(dtDealer.Rows[0][0].ToString()));

                            if (dtDealer.Rows[0][1] != DBNull.Value)
                                PainterContact["ber_preferredlanguage1"] = new EntityReference("ber_language", new Guid(dtDealer.Rows[0][1].ToString()));

                            if (dtDealer.Rows[0][2] != DBNull.Value)
                                PainterContact["ber_preferredlanguage1"] = new EntityReference("ber_language", new Guid(dtDealer.Rows[0][2].ToString()));
                        }
                    }
                }


                //Create new painter contact.
                Guid PainterContactId = Service.Create(PainterContact);
                if (ownerId != Guid.Empty)
                {
                    FetchData.SetOwner(ownerId, PainterContactId, Service, oLogger);
                }
                #endregion

                // Create Meet Painters ................
                bool _flag = false;
                _flag = ValidateCostPerHead(MeetPlaining.Id);
                if(_flag)
                {
                    CreateMeetPainter(Service, PainterContactId, MeetPlaining.Id, 0);
                }
                else
                {
                    CreateMeetPainter(Service, PainterContactId, MeetPlaining.Id);
                }
                
            }
            catch (Exception ex)
            {
                oLogger.Log("PluginCreateMeetPainters", "CreatePainterContact", "Error Creating Painter Contact", ex.Message.ToString());
            }
        }

        /// <summary>
        /// ValidateCostPerHead
        /// </summary>
        /// <returns></returns>
        private static bool ValidateCostPerHead(Guid MeetId)
        {
            bool _flag = false;
            String _getCostPerPainter = string.Empty;
            String _totalBudget = "";
            Int32 _totalBudgetmodified = 0;
            Int32 _increamentenrolledpainters = 0;
            Int32 _totalAmount = 0;

            try
            {
                _increamentenrolledpainters = increamentenrolledpainters(MeetId);
                

                _getCostPerPainter          = getCostPerPainter(MeetId).Item1;
                _totalBudget                = getCostPerPainter(MeetId).Item2;

                //_totalBudgetmodified    = Convert.ToInt32(_totalBudget);    
                //_totalAmount            = Convert.ToInt32(_increamentenrolledpainters) * Convert.ToInt32(_getCostPerPainter);

                 _totalBudgetmodified  = int.Parse(_totalBudget.Split('.')[0]);
                 _totalAmount          = _increamentenrolledpainters * int.Parse(_getCostPerPainter.Split('.')[0]);

                if  (!(_totalBudgetmodified >= _totalAmount))
                {
                    _flag = true;
                }
                
                return _flag;
            }
            catch(Exception ex)
            {
                return _flag;
            }

        }

        /// <summary>
        /// CreateMeetPainter
        /// </summary>
        /// <param name="Service"></param>
        /// <param name="PainterId"></param>
        /// <param name="MeetId"></param>
        public static void CreateMeetPainter(IOrganizationService Service, Guid PainterId, Guid MeetId, int Val=1)
        {
            string strgetCostPerPainter = string.Empty;
            Int32 Incremenrolledpainters = 0;

            try
            {
                Entity MeetPainter = new Entity("ber_paintermeetcontact");
                MeetPainter["ber_contact"] = new EntityReference("contact", PainterId);
                MeetPainter["ber_paintermeet"] = new EntityReference("ber_paintermeet", MeetId);

                // ----------------------------------------------------------------------------
                // increamentenrolledpainters should be checke before strgetCostPerPainter
                // ------------------------------------------------------------------------



                strgetCostPerPainter = getCostPerPainter(MeetId).Item1;
                if (Val == 0)
                {
                    strgetCostPerPainter = "0";
                }

                if (!string.IsNullOrEmpty(strgetCostPerPainter))
                {
                    MeetPainter["ber_costperpainter"] = strgetCostPerPainter;//getCostPerPainter(MeetId);   // fetcing data from entity ber_paintermeet with MeetId //  new EntityReference("ber_paintermeet", MeetId);
                }
                
                    
                // Adding Price  neeeded
                Service.Create(MeetPainter);
                Incremenrolledpainters = increamentenrolledpainters(MeetId);

                //Entity of ber_paintermeet
                Entity _paintermeet = new Entity("ber_paintermeet");
                _paintermeet.Id = MeetId;
                _paintermeet.Attributes["ber_enrolledpainters"] = Incremenrolledpainters;
                Service.Update(_paintermeet);

            }
            catch (Exception ex)
            {
                oLogger.Log("PluginCreateMeetPainters", "CreateMeetPainter", "Error Creating Meet Painter", ex.Message.ToString());
                // throw ex;
            }
        }

        /// <summary>
        /// increamentenrolledpainters
        /// </summary>
        /// <param name="meetId"></param>
        private static Int32 increamentenrolledpainters(Guid meetId)
        {
            int Incrementenrolledpainters = 0;
            
            try
            {
                //string getCostPerPainterQry = " SELECT pm.ber_name,pm.ber_paintermeetId,pm.ber_CostPerHead,dd.ber_BDBudget,pm.ber_enrolledpainters FROM ber_paintermeet pm " +
                //              " INNER  join ber_depot dd on dd.ber_depotId=pm.ber_Depot where pm.ber_paintermeetId='" + meetId + "'";

                string getCostPerPainterQry = "SELECT pmx.ber_paintermeetid,COUNT(pmc.ber_paintermeetcontactId) AS count_pmc FROM ber_paintermeetcontact AS pmc " +
                                              "INNER JOIN ber_paintermeet  AS pmx ON pmx.ber_paintermeetid = pmc.ber_PainterMeet WHERE pmx.ber_paintermeetId = '" + meetId + "' " +
                                              " GROUP BY pmx.ber_paintermeetid";


                DataTable dtPainterDetails = FetchData.getDataFromSql(getCostPerPainterQry, _sqlConnectionString, oLogger);

                if (dtPainterDetails.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(Convert.ToString(dtPainterDetails.Rows[0]["count_pmc"])))
                    {
                        Incrementenrolledpainters = Convert.ToInt32(dtPainterDetails.Rows[0]["count_pmc"]);
                        Incrementenrolledpainters = Incrementenrolledpainters + 1;

                    }

                }
                return Incrementenrolledpainters;
            }
            catch (Exception ex)
            {
                return Incrementenrolledpainters;
            }
        }


        /// <summary>
        /// getCostPerPainter
        /// </summary>
        /// <param name="meetId"></param>
        /// <returns></returns>
        private static Tuple<string, string> getCostPerPainter(Guid meetId)
        {
            //string rsValue = string.Empty;
            //string[] arrVal;
            string _CostPerHead = string.Empty;
            string _BDBudget = string.Empty;
            try
            {
                //Logic Here......
                string getCostPerPainterQry = " SELECT pm.ber_name,pm.ber_paintermeetId,pm.ber_CostPerHead,dd.ber_BDBudget FROM ber_paintermeet pm " +
                                              " INNER  join ber_depot dd on dd.ber_depotId=pm.ber_Depot where pm.ber_paintermeetId='" + meetId + "'";

                DataTable dtPainterDetails = FetchData.getDataFromSql(getCostPerPainterQry, _sqlConnectionString, oLogger);

                if (dtPainterDetails.Rows.Count > 0)
                {
                    if (Convert.ToInt32(dtPainterDetails.Rows[0]["ber_CostPerHead"]) < Convert.ToInt32(dtPainterDetails.Rows[0]["ber_BDBudget"]))
                    {
                        _CostPerHead = Convert.ToString(dtPainterDetails.Rows[0]["ber_CostPerHead"]);
                        _BDBudget = Convert.ToString(dtPainterDetails.Rows[0]["ber_BDBudget"]);
                    }
                    else
                    {
                        _CostPerHead = "0";
                        _BDBudget = Convert.ToString(dtPainterDetails.Rows[0]["ber_BDBudget"]);
                    }
                }
                else
                {
                    _CostPerHead = "";
                    _BDBudget = Convert.ToString(dtPainterDetails.Rows[0]["ber_BDBudget"]);
                }
            }
            catch (Exception ex)
            {
                _CostPerHead = "";
                _BDBudget = "";
            }

            return new Tuple<string, string>(_CostPerHead, _BDBudget);
        }
        


    }
}
