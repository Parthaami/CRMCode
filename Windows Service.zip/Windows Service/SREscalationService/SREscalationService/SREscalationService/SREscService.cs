﻿//========================================================================
//  This window service executes on daily basis and checks SR records whose 
//  Escalation 1/2/3 date equal to todays date and SR is in active state.
//
//  If their is any SR fulfills this condition then it sends mail to assigned person
//  about escalation.
//  
//  Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Net.Mail;

namespace SREscalationService
{
    class SREscService
    {
        #region Class Level Members

        private static IOrganizationService _service;
        static PragmaLogger oLogger;
        static string _loggerPath = string.Empty;
        static string _crmServerUrl = string.Empty;
        static Configuration config;
        static string _orgName = ConfigurationManager.AppSettings["OrgName"];
        static string PrintLog = ConfigurationManager.AppSettings["PrintLog"];
        public static string _SRStatusReasonEsc1 = "798330002";
        public static string _SRStatusReasonEsc2 = "798330003";
        public static string _SRStatusReasonEsc3 = "278290000";
        public static string _SRStatusReasonFirstResponceMissed = "278290009";
        public static string _SRStatusReasonNotResolved = "278290010";
        public static string _SRStatusReasonStandByNotProvided = "278290011";
        
        public static string TodaysDate = Convert.ToString(DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day);
        public static string DateOnAfter = Convert.ToString(ConfigurationManager.AppSettings["DateOnAfter"]); // Added by Partha on 23-Dec-2020
        public static string EmailSenderQueueName = string.Empty;


        #endregion

        static void Main(string[] args)
        {
            try
            {

                #region Read Registry Key & get Pragmasys.config Path

                /*
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }
                */
                #endregion

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 

                //string configpath = DB_path + "\\CRMWeb\\ISV\\" + _orgName + "\\Pragmasys.config";
                string configpath = "C:\\Program Files\\Microsoft Dynamics CRM\\CRMWeb\\ISV\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();

                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new PragmaLogger(_orgName, _loggerPath);
                        _crmServerUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                        //Queue to send email
                        EmailSenderQueueName = config.AppSettings.Settings["EmailSenderQueueName"].Value.ToString();
                    }
                }



                //get CRM service
                _service = GetService();

                if (PrintLog.ToLower() == "yes")
                    oLogger.Log("SREscalationService", "Main", "CRM Service Retrived Successfuly.", "Service Url: " + _crmServerUrl);

                //Function to set SR Status Reason as Escalation 3
                SetStatusReason(_SRStatusReasonEsc3, SetStatusRegionofSRasEsc3(), "3");

                //Function to set SR Status Reason as Escalation 2
                SetStatusReason(_SRStatusReasonEsc2, SetStatusRegionofSRasEsc2(), "2");

                //Function to set SR Status Reason as Escalation 1
                SetStatusReason(_SRStatusReasonEsc1, SetStatusRegionofSRasEsc1(), "1");
            }

            catch (Exception ex)

            {
                oLogger.Log("SREscalationService", "Main", ex.Message, ex.StackTrace.ToString());
            }

        }

        #region Function to Retrive Service
        public static IOrganizationService GetService()
        {
            // if (PrintLog.ToLower() == "yes")
            //  oLogger.Log("SREscalationService", "GetService", "Retrieve CRM Service.", "Service Url: " + _crmServerUrl);

            IOrganizationService _service = null;
            try
            {
                //IServiceManagement<IOrganizationService> orgServiceManagement =
                //ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                //new Uri(ConfigurationManager.AppSettings["ServerUrl"].ToString()));

                //AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                //authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                //authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                //OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                //orgService.EnableProxyTypes();

                //_service = (IOrganizationService)orgService;

                //ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
                //ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;


                // ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                //CrmServiceClient Crmconn = new CrmServiceClient(ConfigurationManager.AppSettings["SoapUri"].ToString());
                //#endregion
                //if (!Crmconn.IsReady)
                //{
                //    Console.WriteLine(“No Connection was Made.”);
                //    return;
                //}


                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["SoapUri"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
                return (IOrganizationService)orgService;
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return _service;
        }

        //private static TProxy GetProxy<TService, TProxy>(
        //IServiceManagement<TService> serviceManagement,
        //AuthenticationCredentials authCredentials)
        //where TService : class
        //where TProxy : ServiceProxy<TService>
        //{
        //    Type classType = typeof(TProxy);

        //    if (serviceManagement.AuthenticationType !=
        //        AuthenticationProviderType.ActiveDirectory)
        //    {
        //        AuthenticationCredentials tokenCredentials =
        //            serviceManagement.Authenticate(authCredentials);
        //        // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
        //        // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
        //        return (TProxy)classType
        //            .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
        //            .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
        //    }

        //    // Obtain discovery/organization service proxy for ActiveDirectory environment.
        //    // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
        //    return (TProxy)classType
        //        .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
        //        .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        //}


        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["Domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }


        #endregion

        #region Function to set Status Reason as Escalation3
        public static EntityCollection SetStatusRegionofSRasEsc3()
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='incident'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='pcl_statusreason' operator='not-in' >");
                query.Append("<value>" + _SRStatusReasonEsc3 + "</value>");
                query.Append("<value>" + _SRStatusReasonStandByNotProvided + "</value>");
                query.Append("</condition>");
                query.Append("<condition attribute='ber_escalationdate3' operator='lt' value='" + TodaysDate + "' />");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<condition attribute='createdon'perator='on-or-after' value='"+ DateOnAfter + "' />"); // Added by Partha on 23-Dec-2020
                query.Append("</filter>");
                query.Append("<link-entity name='pcl_srtype' from='pcl_srtypeid' to='pcl_srtypeid' visible='false' link-type='outer' alias='srt'>");
                query.Append("<attribute name='ber_srtype' />");
                query.Append("<attribute name='pcl_name' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "SetStatusRegionofSRasEsc3", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to set Status Reason as Escalation2
        public static EntityCollection SetStatusRegionofSRasEsc2()
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='incident'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='pcl_statusreason' operator='not-in' >");
                query.Append("<value>" + _SRStatusReasonEsc2 + "</value>");
                query.Append("<value>" + _SRStatusReasonEsc3 + "</value>");
                query.Append("<value>" + _SRStatusReasonNotResolved + "</value>");
                query.Append("<value>" + _SRStatusReasonStandByNotProvided + "</value>");
                query.Append("</condition>");
                query.Append("<condition attribute='ber_escalationdate2' operator='lt' value='" + TodaysDate + "' />");
                query.Append("<condition attribute='createdon'perator='on-or-after' value='" + DateOnAfter + "' />"); // Added by Partha on 23-Dec-2020
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("</filter>");
                query.Append("<link-entity name='pcl_srtype' from='pcl_srtypeid' to='pcl_srtypeid' visible='false' link-type='outer' alias='srt'>");
                query.Append("<attribute name='ber_srtype' />");
                query.Append("<attribute name='pcl_name' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "SetStatusRegionofSRasEsc2", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to set Status Reason as Escalation1
        public static EntityCollection SetStatusRegionofSRasEsc1()
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='incident'>");
                query.Append("<all-attributes/>");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='pcl_statusreason' operator='not-in' >");
                query.Append("<value>" + _SRStatusReasonEsc1 + "</value>");
                query.Append("<value>" + _SRStatusReasonEsc2 + "</value>");
                query.Append("<value>" + _SRStatusReasonEsc3 + "</value>");
                query.Append("<value>" + _SRStatusReasonFirstResponceMissed + "</value>");
                query.Append("<value>" + _SRStatusReasonNotResolved + "</value>");
                query.Append("<value>" + _SRStatusReasonStandByNotProvided + "</value>");
                query.Append("</condition>");
                query.Append("<condition attribute='ber_escalationdate1' operator='lt' value='" + TodaysDate + "' />");
                query.Append("<condition attribute='createdon'perator='on-or-after' value='" + DateOnAfter + "' />"); // Added by Partha on 23-Dec-2020
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("</filter>");
                query.Append("<link-entity name='pcl_srtype' from='pcl_srtypeid' to='pcl_srtypeid' visible='false' link-type='outer' alias='srt'>");
                query.Append("<attribute name='ber_srtype' />");
                query.Append("<attribute name='pcl_name' />");
                query.Append("</link-entity>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Result = Retrieve(_service, query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "SetStatusRegionofSRasEsc1", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to set SR Status Reason
        public static void SetStatusReason(string StatusReason, EntityCollection SRColl, string EscLevel)
        {
            string emailAttribute = "ber_escalationemail" + EscLevel;
            try
            {
                if (PrintLog.ToLower() == "yes")
                {
                    oLogger.Log("SREscalationService", "SetStatusReason", "Escalation level: " + EscLevel, "SR Found: " + SRColl.Entities.Count);
                }

                foreach (Entity SR in SRColl.Entities)
                {
                    if (PrintLog.ToLower() == "yes")
                    {
                        oLogger.Log("SREscalationService", "SetStatusReason", "Escalation level: " + EscLevel, "SR Id: " + SR.Id);
                    }

                    string emailAddress = string.Empty;
                    string SRNumber = string.Empty;
                    string SRUrl = string.Empty;
                    EntityReference Customer = new EntityReference();
                    EntityReference SRType = new EntityReference();
                    EntityReference SubSRType = new EntityReference();

                    Entity TempSR = new Entity();
                    TempSR.Id = SR.Id;
                    TempSR.LogicalName = SR.LogicalName;
                    //// If SR is for CB
                    if (SR.Attributes.Contains("srt.ber_srtype") && ((OptionSetValue)((AliasedValue)SR.Attributes["srt.ber_srtype"]).Value).Value == 278290000)
                    {
                        //// (IF SR STATUS IS PENDING AND DEVIATION ALLOWED IS FALSE) OR (IF SR STATUS IS DESPUTED AND DEVIATION ALLOWED IS FALSE
                        // MARK SUCH SR AS CB ESCALATION SR's.
                        if (((SR.Attributes.Contains("pcl_statusreason") && ((OptionSetValue)SR.Attributes["pcl_statusreason"]).Value == 798330000) &&
                            (SR.Attributes.Contains("ber_deviationallowed") && ((bool)SR.Attributes["ber_deviationallowed"]) == false))
                            || ((SR.Attributes.Contains("pcl_statusreason") && ((OptionSetValue)SR.Attributes["pcl_statusreason"]).Value == 278290004)
                            && ((SR.Attributes.Contains("ber_deviationallowed") && ((bool)SR.Attributes["ber_deviationallowed"]) == false))))
                        {
                            if (EscLevel == "3")
                            {
                                TempSR.Attributes["pcl_statusreason"] = new OptionSetValue(Convert.ToInt32(_SRStatusReasonStandByNotProvided));
                            }
                            else if (EscLevel == "2")
                            {
                                TempSR.Attributes["pcl_statusreason"] = new OptionSetValue(Convert.ToInt32(_SRStatusReasonNotResolved));
                            }
                            else if (EscLevel == "1")
                            {
                                TempSR.Attributes["pcl_statusreason"] = new OptionSetValue(Convert.ToInt32(_SRStatusReasonFirstResponceMissed));
                            }
                        }
                    }
                    else
                    {
                        TempSR.Attributes["pcl_statusreason"] = new OptionSetValue(Convert.ToInt32(StatusReason));
                    }
                    _service.Update(TempSR);

                    if (PrintLog.ToLower() == "yes")
                    {
                        oLogger.Log("SREscalationService", "SetStatusReason", "Escalation level: " + EscLevel, "SR Status updated successfuly.SR Id: " + SR.Id);
                    }

                    //Send email to User
                    if (SR.Attributes.Contains(emailAttribute))
                    {
                        emailAddress = SR[emailAttribute].ToString();
                    }

                    if (PrintLog.ToLower() == "yes")
                    {
                        oLogger.Log("SREscalationService", "SetStatusReason", "Escalation level: " + EscLevel, "Email Adress: " + emailAddress);
                    }

                    EntityCollection UserDetails = GetUser(emailAddress);
                    string UserName = "User";
                    Guid UserId = Guid.Empty;
                    foreach (Entity eUser in UserDetails.Entities)
                    {
                        UserId = eUser.Id;

                        if (eUser.Attributes.Contains("fullname"))
                            UserName = eUser["fullname"].ToString();

                        if (PrintLog.ToLower() == "yes")
                            oLogger.Log("SREscalationService", "SetStatusReason", "Escalation level: " + EscLevel, "User Name:" + UserName);


                        break;
                    }

                    // sendEmail(_service, UserId, SR.Id, emailAddress);
                    sendEmail(_service, UserId, SR.Id, ((AliasedValue)SR["srt.pcl_name"]).Value.ToString(), emailAddress);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "SetStatusReason", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion

        #region Function to Restrive Data from Fetch XMl
        private static EntityCollection Retrieve(IOrganizationService _service, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to send escalation mail's
        public static void sendEmail(IOrganizationService oService, Guid UserId, Guid SRID, string srtype, string emailaddress)
        {
            try
            {
                //get default queue used to send email
                //   EmailSenderQueueName = "Berger India CRM";
                Guid QueueId = RetriveQueue(EmailSenderQueueName);

                if (PrintLog.ToLower() == "yes")
                    oLogger.Log("SREscalationService", "sendEmail", "Default Queue email id :" + EmailSenderQueueName, "Retrieved Queue Id: " + QueueId);

                //Create an Email
                EntityCollection fromPartyColl = new EntityCollection();
                Entity from = new Entity("activityparty");
                from["partyid"] = new EntityReference("queue", QueueId);
                fromPartyColl.Entities.Add(from);

                EntityCollection toPartyColl = new EntityCollection();
                Entity to = new Entity("activityparty");

                if (!(UserId == Guid.Empty))
                {
                    to["partyid"] = new EntityReference("systemuser", UserId);
                    toPartyColl.Entities.Add(to);
                }
                else
                {

                    to["addressused"] = emailaddress;
                    toPartyColl.Entities.Add(to);

                }

                Entity email = new Entity("email");

                email["to"] = toPartyColl;
                email["from"] = fromPartyColl;

                email["directioncode"] = true;


                ////Guid EscalationEmailId = oService.Create(email);

                ////if (PrintLog.ToLower() == "yes")
                ////    oLogger.Log("SREscalationService", "sendEmail", "Escalation email Successfuly created.", "Escalation email Id: " + EscalationEmailId);


                //Email template GUID taken as input paramter from common config.
                //  Guid  _Templete = new Guid(ConfigurationManager.AppSettings["_TempleteID"].ToString());
                Guid _Templete = Guid.Empty;
                if (srtype.Equals("XP LEAD") || srtype.Equals("IoT") || srtype.Equals("Home Decor") || srtype.Equals("End Customer - Generic"))
                {


                    _Templete = new Guid(ConfigurationManager.AppSettings["_TempleteID"].ToString());

                }

                else
                {
                    _Templete = new Guid(ConfigurationManager.AppSettings["_TempleteID2"].ToString());
                }

                SendEmailFromTemplateRequest emailUsingTemplateReq = new SendEmailFromTemplateRequest
                {

                    Target = email,

                    // Use a built-in Email Template of type "SR". passing the GUID of Templete
                    TemplateId = _Templete,

                    // The regarding Id is required, and must be of the same type as the Email Template.
                    RegardingId = SRID,
                    RegardingType = "incident"

                };
                SendEmailFromTemplateResponse emailUsingTemplateResp = (SendEmailFromTemplateResponse)oService.Execute(emailUsingTemplateReq);
                if (PrintLog.ToLower() == "yes")
                    oLogger.Log("SREscalationService", "sendEmail", "Email send Successfuly using template", "Template Id:" + _Templete);

            }
            catch (Exception ex)
            {
                oLogger.Log("SREscalationService", "sendEmail", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion

        #region Function to get Queue 
        public static Guid RetriveQueue(string QueueName)
        {
            EntityCollection Resultset = null;
            Guid QueueId = Guid.Empty;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='queue'>");
                query.Append("<attribute name='name' />");
                query.Append("<attribute name='emailaddress' />");
                query.Append("<attribute name='queueid' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='name' operator='eq' value='" + QueueName + "' />");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                Resultset = Retrieve(_service, query.ToString());

                foreach (Entity oQueue in Resultset.Entities)
                {
                    QueueId = oQueue.Id;
                    break;
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to Retrive Queue", "RetriveQueue", ex.Message, ex.StackTrace.ToString());
            }

            return QueueId;
        }
        #endregion

        #region Function to get User by using email address
        public static EntityCollection GetUser(string EmailAddress)
        {
            EntityCollection result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical' >");
                query.Append("<entity name='systemuser'>");
                query.Append("<attribute name='fullname' />");
                query.Append("<attribute name='businessunitid' />");
                query.Append("<attribute name='title' />");
                query.Append("<attribute name='address1_telephone1' />");
                query.Append("<attribute name='systemuserid' />");
                query.Append("<filter type='or'>");
                query.Append("<condition attribute='internalemailaddress' operator='eq' value='" + EmailAddress + "' />");
                query.Append("<condition attribute='personalemailaddress' operator='eq' value='" + EmailAddress + "' />");
                query.Append("<condition attribute='mobilealertemail' operator='eq' value='" + EmailAddress + "' />");
                query.Append("</filter>");
                query.Append("</entity>");
                query.Append("</fetch>");

                result = Retrieve(_service, query.ToString());

            }
            catch (Exception ex)
            {
                oLogger.Log("Unable to Retrive User", "GetUser", ex.Message, ex.StackTrace.ToString());
            }
            return result;
        }
        #endregion
    }
}
