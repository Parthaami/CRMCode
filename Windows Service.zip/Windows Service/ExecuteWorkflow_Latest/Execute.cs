﻿//---------------------------------------------------------------------------------------
// <copyright file="Execute.cs" company="Pragmasys Consulting LLP">
//     All rights reserverd.
// </copyright>
//---------------------------------------------------------------------------------------

namespace ExecuteWorkflow
{
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Net;
    using System.ServiceModel;
    using System.ServiceModel.Description;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;
    using Pragmasys.EscalateRecord;

    /// <summary>
    /// Base class for RSL.ExecuteWorkflow
    /// </summary>
    class Execute
    {
        /// <summary>
        /// Starts the execution
        /// </summary>
        /// <param name="args">no of arguments</param>
        public static void Main(string[] args)
        {
            string orgName = ConfigurationManager.AppSettings["OrgName"];
            int logLevel = int.Parse(ConfigurationManager.AppSettings["logLevel"]);
            string logFilePath = ConfigurationManager.AppSettings["logFilePath"];
            string logFileBaseName = ConfigurationManager.AppSettings["logFileBaseName"];

            PragmasysLogger logger = new PragmasysLogger(logFileBaseName + orgName, logFilePath, logLevel);

            try
            {
                OrganizationServiceProxy orgService = CreateOrganizationServiceProxy(logger);

                DataTable dtRecords = RetrieveData(logger, ConfigurationManager.AppSettings["EntityIdColumn"], ConfigurationManager.AppSettings["ViewName"]);
                ExecuteWorkflows(dtRecords, orgService, ConfigurationManager.AppSettings["EntityIdColumn"], ConfigurationManager.AppSettings["WorkflowId"], logger);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                logger.Log("RSL.ExecuteWorkflow", "Main()", string.Empty, "ExceptionMessage: " + ex.Message + "_StatckTrace_ :" + ex.StackTrace, 1);
                throw ex;
            }
        }

        /// <summary>
        /// Executes the workflows.
        /// </summary>
        /// <param name="dtRecords">The dt records.</param>
        /// <param name="orgService">The org service.</param>
        /// <param name="entityIdColumn">The entity identifier column.</param>
        /// <param name="workflowId">The workflow identifier.</param>
        /// <param name="logger">The logger.</param>
        private static void ExecuteWorkflows(DataTable dtRecords, OrganizationServiceProxy orgService, string entityIdColumn, string workflowId, PragmasysLogger logger)
        {
            try
            {
                foreach (DataRow drRow in dtRecords.Rows)
                {
                    int NumberOfTimesWorkFlowExecuted = 0;
                    ExecuteWorkflowRequest request = CreateExecuteWorkflowRequest(new Guid(drRow[entityIdColumn].ToString()), new Guid(workflowId));
                    NumberOfTimesWorkFlowExecuted++;
                    logger.Log("RSL.ExecuteWorkflow", "ExecuteWorkflows()", string.Empty, "WorkFlow Executed: " + NumberOfTimesWorkFlowExecuted, 1);
                    orgService.Execute(request);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                logger.Log("RSL.ExecuteWorkflow", "ExecuteWorkflows()", string.Empty, "ExceptionMessage: " + ex.Message + "_StatckTrace_ :" + ex.StackTrace, 1);
                throw ex;
            }
        }

        /// <summary>
        /// Retrieve Table Data
        /// </summary>
        /// <param name="logger">logger</param>
        /// <param name="entityIdColumn">The entity identifier column.</param>
        /// <param name="viewName">Name of the view.</param>
        /// <returns>
        ///   <c>datatable</c>
        /// </returns>
        private static DataTable RetrieveData(PragmasysLogger logger, string entityIdColumn, string viewName)
        {
            try
            {
                DataSet dsReturn = new DataSet();

                SqlConnection connection = new SqlConnection();
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["StagingDBConnString"].ConnectionString;

                string commandText = "select " + entityIdColumn + " from " + viewName;

                SqlDataAdapter adapter = new SqlDataAdapter(commandText, connection);

                logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Command: " + commandText, 1);
                logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Row Count Of Table: " + dsReturn.Tables.Count, 1);

                adapter.Fill(dsReturn);

                if (dsReturn.Tables.Count > 0)
                {
                    logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Command: " + commandText,1);
                    logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Row Count Of Table: " + dsReturn.Tables.Count,1);
                    return dsReturn.Tables[0];
                }

                logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Command: " + commandText, 1);
                logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "Row Count Of Table: " + dsReturn.Tables.Count, 1);

            }
            catch (SqlException ex)
            {
                logger.Log("RSL.ExecuteWorkflow", "RetrieveData()", string.Empty, "ExceptionMessage: " + ex.Message + "_StatckTrace_ :" + ex.StackTrace, 1);
                throw ex;
            }

            return new DataTable();
        }

        /// <summary>
        /// Creates and Returns Organization Service Proxy object
        /// </summary>
        /// <param name="logger"><c>PragmasysLogger</c> Instance</param>
        /// <returns>
        /// OrganizationServiceProxy Object
        /// </returns>
        private static OrganizationServiceProxy CreateOrganizationServiceProxy(PragmasysLogger logger)
        {
            try
            {
                string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();

                // create Organization Service            
                ClientCredentials credentials = new ClientCredentials();
                credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultNetworkCredentials;
                //credentials.Windows.ClientCredential = new NetworkCredential("soupau1", "1234#berger", "bergerindia");
                Uri organizationUri = new Uri(serverurl);
                Uri homeRealmUri = null;
                return new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
            }
            catch (Exception ex)
            {
                logger.Log("RSL.ExecuteWorkflow", "CreateOrganizationServiceProxy()", string.Empty, "ExceptionMessage: " + ex.Message + "_StatckTrace_ :" + ex.StackTrace, 1);
                throw ex;
            }
        }

        /// <summary>
        /// Creates and Returns workflow execution request object
        /// </summary>
        /// <param name="entityId">Entity record id</param>
        /// <param name="workflowId">Workflow id</param>
        /// <returns>
        /// ExecuteWorkflowRequest object
        /// </returns>
        private static ExecuteWorkflowRequest CreateExecuteWorkflowRequest(Guid entityId, Guid workflowId)
        {
            ExecuteWorkflowRequest request = new ExecuteWorkflowRequest()
            {
                EntityId = entityId,
                WorkflowId = workflowId
            };

            return request;
        }
    }
}
