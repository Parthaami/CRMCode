﻿//========================================================================
//  This windows service executes on daily and migrates Product/Prise List
//  from ERP Stagging to SQL Stagging tables.
//
//  Copyright @ PRagmasys Consulting LLP.
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data.OleDb;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using Oracle.DataAccess.Client;

namespace WrapperExecutorforDMUtility
{
    class DMWrapper
    {
        #region Call level Variables

        public static string ORAProvider = ConfigurationManager.ConnectionStrings["ORAProvider"].ConnectionString;
        public static string SQLProvider = ConfigurationManager.ConnectionStrings["SQLProvider"].ConnectionString;

        public static string OrganisationName = ConfigurationManager.AppSettings["OrgName"];
        public static string LoggerFilePath = ConfigurationManager.AppSettings["LoggerPath"];
        
        public static string DMExe = ConfigurationManager.AppSettings["DMExecutablePath"];
        public static string IsConfigId = ConfigurationManager.AppSettings["IDFromConfig"];
        public static string PId = ConfigurationManager.AppSettings["ProcessId"];
        public static string TimeOut = ConfigurationManager.AppSettings["TimeOut"];
        public static int loglevel = Convert.ToInt32(ConfigurationManager.AppSettings["loglevel"].ToString());
        static int oracleFetchSize = Convert.ToInt32(ConfigurationManager.AppSettings["oracleFetchSize"].ToString());
        public static int RowNum = Convert.ToInt32(ConfigurationManager.AppSettings["ROWNUM"].ToString());
      

        public static Logger oLogger;
        public static Guid ProcessId;
        public static int RecordsUpdated = 0;
        public static DataSet DSCreatedRecordInDM = new DataSet();

        #endregion
   
        static void Main(string[] args)
        {
            try
            {
                string inputstring = args[0].ToString();
                
                oLogger = new Logger(OrganisationName, LoggerFilePath);

                if (IsConfigId.ToLower() == "yes")
                    ProcessId = new Guid(PId);
                else
                    ProcessId = Guid.NewGuid();

                if (loglevel >= 1)
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Processing Table : " + inputstring.ToLower(), "Process Id: " + ProcessId.ToString());

       
                #region Code for xxcrm_product_interface table for Product tbl in DM
                try
                {
                    if (inputstring.ToLower() == "product" && ProcessId != Guid.Empty)
                    {
                        string ProductQry = "update xxcrm_product_interface t1 SET STATUS = 'WIP' ,REQUEST_ID =  '" + ProcessId + "' " + 
                            "where PACK_SIZE IS NOT NULL AND STATUS IN ('NEW') AND REQUEST_ID IS NULL and SHADE IS NOT NULL AND " +
                            "EXISTS  (select * from XXCRM_PRODUCT_PRICE t2 where t1.product_code = t2.product_code) AND ROWNUM <= " + RowNum +"";                        

                        RecordsUpdated = SetProcessId(ProductQry);
                        while (RecordsUpdated > 0)
                        {
                            DSCreatedRecordInDM.Clear();
                            DSCreatedRecordInDM = GetRecordsFromOracle(ProcessId, "xxcrm_product_interface", false);

                            //Call Function to Create record in Data Migration DB
                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForProduct(DSCreatedRecordInDM, "Product");
                                ExecuteDM(ProcessId.ToString(), "Product");
                            }
                            ProcessId = Guid.NewGuid();

                            ProductQry = "update xxcrm_product_interface t1 SET STATUS = 'WIP' ,REQUEST_ID =  '" + ProcessId + "' " +
                            "where PACK_SIZE IS NOT NULL AND STATUS IN ('NEW') AND REQUEST_ID IS NULL and SHADE IS NOT NULL AND " +
                            "EXISTS  (select * from XXCRM_PRODUCT_PRICE t2 where t1.product_code = t2.product_code) AND ROWNUM <= " + RowNum + "";

                            RecordsUpdated = SetProcessId(ProductQry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing Product staging tbl", ex.Message.ToString());
                }

                #endregion

                #region Code for xxcrm_dual_product_interface table for Product tbl in DM
                try
                {
                    if (inputstring.ToLower() == "dualproduct" && ProcessId != Guid.Empty)
                    {
                        string DualPackQry = "update xxcrm_dual_product_interface t1 SET STATUS = 'WIP' , REQUEST_ID =  '" + ProcessId + "' " + 
                                             "where PACK_SIZE IS NOT NULL AND STATUS = 'NEW' AND REQUEST_ID IS NULL and " + 
                                             "PARENT_PRODUCT = PRODUCT_CODE and SHADE IS NOT NULL AND " +
                                             "EXISTS  (select * from XXCRM_PRODUCT_PRICE t2 where t1.parent_product = t2.product_code) AND ROWNUM <= " + RowNum + "";
                        

                        RecordsUpdated = SetProcessId(DualPackQry);
                        while (RecordsUpdated > 0)
                        {
                            DSCreatedRecordInDM.Clear();
                            //Call Function to Retrive Data from oracle for inserting in DM Database
                            DSCreatedRecordInDM = GetRecordsFromOracle(ProcessId, "xxcrm_dual_product_interface", false);

                            //Call Function to Create record in Data Migration DB
                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForDualPack(DSCreatedRecordInDM, "Product");
                                ExecuteDM(ProcessId.ToString(), "Product");
                            }
                            ProcessId = Guid.NewGuid();
                            DualPackQry = "update xxcrm_dual_product_interface t1 SET STATUS = 'WIP' , REQUEST_ID =  '" + ProcessId + "' " +
                                          "where PACK_SIZE IS NOT NULL AND STATUS = 'NEW' AND REQUEST_ID IS NULL and " +
                                          "PARENT_PRODUCT = PRODUCT_CODE and SHADE IS NOT NULL AND " +
                                          "EXISTS  (select * from XXCRM_PRODUCT_PRICE t2 where t1.parent_product = t2.product_code) AND ROWNUM <= " + RowNum + "";

                            RecordsUpdated = SetProcessId(DualPackQry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing Dual Pack(Product) staging tbl", ex.Message.ToString());
                }

                #endregion

                #region Code for xxcrm_product_price table for productpricelevel tbl in DM
                try
                {
                    if (inputstring.ToLower() == "productprice" && ProcessId != Guid.Empty)
                    {
                        string PriceListQry = "update xxcrm_product_price SET STATUS = 'WIP' ,REQUEST_ID =  '" + ProcessId + "' " +
                                              "where STATUS IN ('NEW') AND REQUEST_ID IS NULL and SHADE IS NOT NULL AND " +
                                              "PACK_SIZE IS NOT NULL AND ROWNUM <= " + RowNum + "";

                        RecordsUpdated = SetProcessId(PriceListQry);
                        while (RecordsUpdated > 0)
                        {
                            DSCreatedRecordInDM.Clear();
                            //Call Function to Retrive Data from oracle for inserting in DM Database
                            DSCreatedRecordInDM = GetRecordsFromOracle(ProcessId, "xxcrm_product_price", false);
                            //Call Function to Create record in Data Migration DB
                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForPrice(DSCreatedRecordInDM, "productpricelevel");
                                ExecuteDM(ProcessId.ToString(), "productpricelevel");
                            }
                            ProcessId = Guid.NewGuid();
                            PriceListQry = "update xxcrm_product_price SET STATUS = 'WIP' ,REQUEST_ID =  '" + ProcessId + "' " +
                                           "where STATUS IN ('NEW') AND REQUEST_ID IS NULL and SHADE IS NOT NULL AND " +
                                           "PACK_SIZE IS NOT NULL AND ROWNUM <= " + RowNum + "";

                            RecordsUpdated = SetProcessId(PriceListQry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing ProductPriceLevel staging tbl", ex.Message.ToString());
                }
                #endregion             

                #region Code to Retrive/Update Color Bank Data from Oracle and Stg DB.
                try
                {
                    if (inputstring.ToLower() =="cb" && ProcessId != Guid.Empty)
                    {
                        string CBQry =  "update bpil.bpil_mcc_crm_cb t1 set STATUS='WIP',REQUEST_ID = '"+ ProcessId +"' " + 
                                        "where STATUS='NEW' and exists (select * from xxcrm_depot_config t2 " +
                                        "where t1.depo_code = t2.depot_code) and ROWNUM <= " + RowNum + "";

                        RecordsUpdated = SetProcessId(CBQry);
                        while (RecordsUpdated > 0)
                        {
                            DSCreatedRecordInDM.Clear();
                            DSCreatedRecordInDM = GetRecordsFromOracle(ProcessId, "bpil.bpil_mcc_crm_cb", false);

                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForCB(DSCreatedRecordInDM, "BPIL_MCC_CRM_CB");
                                string UpdateQry = "update BPIL.bpil_mcc_crm_cb set STATUS='COMPLETED' where STATUS='WIP' and REQUEST_ID = '" + ProcessId + "'";
                                SetProcessId(UpdateQry);
                            }
                            RecordsUpdated = SetProcessId(CBQry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing Color Bank tbl", ex.Message.ToString());
                }
                #endregion

                #region Code to Retrive/Update Primary Sales Data from Oracle and Stg DB.
                try
                {
                    if (inputstring.ToLower() == "sellin" && ProcessId != Guid.Empty)
                    {
                        string SellinQry = "update BPIL.bpil_mcc_pm_sellin t1 set STATUS='WIP',REQUEST_ID = '" + ProcessId + "' " +
                                           "where STATUS='NEW' and exists (select * from xxcrm_depot_config t2 " +
                                           "where t1.depo_code = t2.depot_code) and ROWNUM <= " + RowNum + "";

                        RecordsUpdated = SetProcessId(SellinQry);
                        while (RecordsUpdated > 0)
                        {
                            DSCreatedRecordInDM.Clear();
                            DSCreatedRecordInDM = GetRecordsFromOracle(ProcessId, "bpil.BPIL_MCC_PM_SELLIN", false);

                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForSELLIN(DSCreatedRecordInDM, "BPIL_MCC_PM_SELLIN");
                                string UpdateQry = "update BPIL.bpil_mcc_pm_sellin set STATUS='COMPLETED' where STATUS='WIP' and REQUEST_ID = '" + ProcessId + "'";
                                SetProcessId(UpdateQry);
                            }
                            RecordsUpdated = SetProcessId(SellinQry);
                        }
                    }
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing Color Bank tbl", ex.Message.ToString());
                }
                #endregion
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "Main", "", ex.Message.ToString());

            }
        }

        #region Function to set Process Id in Oracle
        public static int SetProcessId(string query)
        {            
            int nowofRowsOracleUpdate = 0;
            if (loglevel >= 3)
                oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Update Query: ", query);

            OracleConnection connection = new OracleConnection(ORAProvider);
            connection.Open();
            OracleCommand command = connection.CreateCommand();
            try
            {
                command.CommandType = CommandType.Text;
                command.CommandText = query;
                nowofRowsOracleUpdate = command.ExecuteNonQuery();

                if (loglevel >= 2)
                    oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Records updated in ERP: ", nowofRowsOracleUpdate.ToString());

                return nowofRowsOracleUpdate;
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Query : " + query, " Exception: " + ex.Message.ToString());
            }
            finally
            {
                command.Dispose();
                connection.Close();
                connection.Dispose();
            }
            return nowofRowsOracleUpdate;
        }                    
        #endregion

        #region Function to retrive records from oracle and insert into DM Table
        public static DataSet GetRecordsFromOracle(Guid PId, string TableName,bool IsSite)
        {
            string query = string.Empty;

            if (TableName.ToLower() == "xxcrm_product_interface")
            {
                query = "select ROWID,PRODUCT_CODE,SUBSTR(PRODUCT_CODE,1,6) PROD,SUBSTR(PRODUCT_CODE,1,10) PRODSHADE,SUBSTR(PRODUCT_CODE,7,4) SHADECODE ," +
                        "DESCRIPTION, PRODUCT, SHADE SHADEID, SHADE SHADETEXT,'Pack' as PRY_UOM, concat(Concat(PACK_SIZE,' '),SEC_UOM) as UNIT," +
                        "PACK_PER_CARTON, '0.00' as Price,'0' as Dual_Pack, 'R' as Import_status,REQUEST_ID as CRM_REQUEST_ID, 'Sales Order' PRODUCT_TYPECODE,"+
                        "'2' DescimalSupported, '' ProductSortCode,CB_NCB from xxcrm_product_interface where REQUEST_ID = '" + PId + "'";
            }

            else if (TableName.ToLower() == "xxcrm_dual_product_interface")
            {
                query = "select ROWID,PARENT_PRODUCT,SUBSTR(PARENT_PRODUCT,1,6) PROD,SUBSTR(PARENT_PRODUCT,1,10) PRODSHADE,SUBSTR(PARENT_PRODUCT,7,4) SHADECODE ," +
                        "DESCRIPTION, PRODUCT, SHADE SHADEID, SHADE SHADETEXT,'Pack' as PRY_UOM, concat(Concat(PACK_SIZE,' '),SEC_UOM) as UNIT," +
                        "PACK_PER_CARTON, '0.00' as Price,'1' as Dual_Pack, 'R' as Import_status,REQUEST_ID as CRM_REQUEST_ID, 'Sales Order' PRODUCT_TYPECODE," +
                        "'2' DescimalSupported, '' ProductSortCode,'0' as CB_NCB from xxcrm_dual_product_interface where REQUEST_ID = '" + PId + "'";
            }

            else if (TableName.ToLower() == "xxcrm_product_price")
            {
                query = "select ROWID,PRODUCT_CODE, 'Dealer Price List' as Price_List, concat(Concat(PACK_SIZE,' '),SEC_UOM) as UNIT," +
                    "Price as Price,'R' as Import_status,REQUEST_ID as CRM_REQUEST_ID from xxcrm_product_price where " +
                    "REQUEST_ID = '" + PId + "'";
            }     
            else if (TableName.ToLower() == "bpil.bpil_mcc_crm_cb")
            {
                query = "Select ROWID,DEPO_CODE,DLR_CODE,TRX_DATE,TOTAL_VOL, TOTAL_VAL, CB_VOL, CB_VAL, EMLSN_VOL, EMLSN_VAL, LB_VOL," +
                        "CREATION_DATE,STATUS,REQUEST_ID,trunc(sysdate) as CREATED_ON from BPIL.BPIL_MCC_CRM_CB where  STATUS = 'WIP' and REQUEST_ID = '" + PId + "'";
            }

            else if (TableName.ToLower() == "bpil.bpil_mcc_pm_sellin")
            {
                query = "Select ROWID,DEPO_CODE,DLR_CODE,TRX_DATE,PRODUCT,VOLUME,CREATION_DATE,STATUS,REQUEST_ID,trunc(sysdate) as CREATED_ON " +
                        "from BPIL.BPIL_MCC_PM_SELLIN where STATUS = 'WIP' and REQUEST_ID = '" + PId + "'";
            }

            DataSet sds = new DataSet();
            if (loglevel >= 3)
                oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Select Query: "+query);

            OracleConnection connection = new OracleConnection(ORAProvider);
            OracleCommand command = new OracleCommand();
            OracleDataAdapter dataAdapter = new OracleDataAdapter(command);
            try
            {
                if (loglevel >= 4)
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Open Connection");
                connection.Open();
                if (loglevel >= 4)
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Connection Open Successfuly.");
                command.Connection = connection;
                command.CommandText = query;
                command.CommandType = CommandType.Text;
                command.FetchSize = oracleFetchSize;
                if (loglevel >= 4)
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Fill data in Datatable");

                dataAdapter.Fill(sds);

                if (loglevel >= 4)
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", "Records Filled into DataTable", "Row Count : " + sds.Tables[0].Rows.Count.ToString());


                try
                {
                    if (loglevel >= 2)
                        oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Count for Records selected: " + sds.Tables[0].Rows.Count.ToString());
                }
                catch (Exception exp)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", TableName, "Count of Tables in DataSet: " + sds.Tables.Count.ToString() + "Exception : " + exp.ToString());
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", "Query : " + query, " Exception: " + ex.Message.ToString());
            }
            finally
            {
                connection.Close();
                dataAdapter.Dispose();
                command.Dispose();
                connection.Dispose();
            }
            return sds;
        }
        #endregion  

        #region Function to execute DM exe and wait until process gets completed
        public static void ExecuteDM(string ProcessID,string DestinationTblName)
        {
            try
            {
                if (loglevel >= 1)
                    oLogger.Log("WrapperExecutorforDMUtility", "ExecuteDM", "Process Id: " + ProcessID, "Destination Table Name: " + DestinationTblName);
                //Call DM Exe                
                ProcessStartInfo startInfo = new ProcessStartInfo();
                startInfo.CreateNoWindow = true;
                startInfo.UseShellExecute = false;
                startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                startInfo.FileName = DMExe;
                startInfo.Arguments = ProcessID + "|" + DestinationTblName;

                // Start the process with the info we specified.
                // Call WaitForExit and then the using statement will close.
                using (Process exeProcess = Process.Start(startInfo))
                {
                    exeProcess.WaitForExit();
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "ExecuteDM", "Process Id : " + ProcessID + "Destination Tbl :" + DestinationTblName, " Exception: " + ex.Message.ToString());       
            }
        }
        #endregion  
  
        #region Function to Create record in Data Migration DB in Product Table
        public static void CreateRecordInDMForProduct(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy copy = null;

            try
            {
                if (loglevel >= 3)
                    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForProduct", "Destination Table Name", DestinationTable);
               
                using (copy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    copy.BulkCopyTimeout = Convert.ToInt32(TimeOut);
                    copy.ColumnMappings.Add("Import_status", "Import_Status");
                    copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");

                    copy.ColumnMappings.Add("ROWID", "oracle_row_id");
                    copy.ColumnMappings.Add("PRODUCT_CODE", "productnumber");
                    copy.ColumnMappings.Add("PROD", "ber_productcode");
                    copy.ColumnMappings.Add("PRODSHADE", "ber_productshadecode");
                    copy.ColumnMappings.Add("SHADECODE", "ber_shadecode");
                    //copy.ColumnMappings.Add("SHADEID", "ber_shadeid");
                    copy.ColumnMappings.Add("SHADETEXT", "ber_shade");
                    copy.ColumnMappings.Add("PRODUCT_TYPECODE", "producttypecode");
                    copy.ColumnMappings.Add("DescimalSupported", "quantitydecimal");
                    copy.ColumnMappings.Add("ProductSortCode", "ber_productsortcode");
                    copy.ColumnMappings.Add("CB_NCB", "ber_colorbankitem");
                    copy.ColumnMappings.Add("PRODUCT", "name");                    
                    copy.ColumnMappings.Add("DESCRIPTION", "description");
                    copy.ColumnMappings.Add("PRY_UOM", "defaultuomscheduleid");
                    copy.ColumnMappings.Add("PACK_PER_CARTON", "ber_cartonsize");
                    copy.ColumnMappings.Add("UNIT", "defaultuomid");
                    copy.ColumnMappings.Add("Price", "price");
                    copy.ColumnMappings.Add("Dual_Pack", "ber_dualpack");

                    copy.DestinationTableName = DestinationTable;
                    copy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForProduct", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                copy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion

        #region Function to Create record in Data Migration DB in Dual Pack(Product) Table
        public static void CreateRecordInDMForDualPack(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy copy = null;
            try
            {               
                if (loglevel >= 3)
                    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForDualPack", "Destination Table Name", DestinationTable);
                using (copy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    copy.BulkCopyTimeout = Convert.ToInt32(TimeOut);
                    copy.ColumnMappings.Add("Import_status", "Import_Status");
                    copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");

                    copy.ColumnMappings.Add("ROWID", "oracle_row_id");
                    copy.ColumnMappings.Add("PARENT_PRODUCT", "productnumber");
                    copy.ColumnMappings.Add("PROD", "ber_productcode");
                    copy.ColumnMappings.Add("PRODSHADE", "ber_productshadecode");
                    copy.ColumnMappings.Add("SHADECODE", "ber_shadecode");
                    //copy.ColumnMappings.Add("SHADEID", "ber_shadeid");
                    copy.ColumnMappings.Add("SHADETEXT", "ber_shade");
                    copy.ColumnMappings.Add("PRODUCT_TYPECODE", "producttypecode");
                    copy.ColumnMappings.Add("DescimalSupported", "quantitydecimal");
                    copy.ColumnMappings.Add("ProductSortCode", "ber_productsortcode");
                    copy.ColumnMappings.Add("CB_NCB", "ber_colorbankitem");
                    copy.ColumnMappings.Add("PRODUCT", "name");
                    //copy.ColumnMappings.Add("SHADE", "ber_shadeid");   // Code change for Dual Product  
                    copy.ColumnMappings.Add("DESCRIPTION", "description");
                    copy.ColumnMappings.Add("PRY_UOM", "defaultuomscheduleid");
                    copy.ColumnMappings.Add("PACK_PER_CARTON", "ber_cartonsize");
                    copy.ColumnMappings.Add("UNIT", "defaultuomid");
                    copy.ColumnMappings.Add("Price", "price");
                    copy.ColumnMappings.Add("Dual_Pack", "ber_dualpack");

                    copy.DestinationTableName = DestinationTable;
                    copy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForDualPack", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                copy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion

        #region Function to Create record in Data Migration DB in Price Table
        public static void CreateRecordInDMForPrice(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy copy = null;
              
            try
            {
                if (loglevel >= 3)
                    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForPrice", "Destination Table Name", DestinationTable);
                using (copy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    copy.BulkCopyTimeout = Convert.ToInt32(TimeOut);

                    copy.ColumnMappings.Add("Import_status", "Import_Status");
                    copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");

                    copy.ColumnMappings.Add("ROWID", "oracle_row_id");
                    copy.ColumnMappings.Add("PRODUCT_CODE", "productid");
                    copy.ColumnMappings.Add("Price_List", "pricelevelid");
                    copy.ColumnMappings.Add("UNIT", "uomid");
                    copy.ColumnMappings.Add("Price", "amount");
                    
                    copy.DestinationTableName = DestinationTable;
                    copy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForPrice", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                copy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion    
    
        #region Function to Create record in Data Migration DB in Color Bank Table
        public static void CreateRecordInDMForCB(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy bulkCopy = null;
            try
            {
                if (loglevel >= 3)
                    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForCB", "Destination Table Name", DestinationTable);
                using (bulkCopy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    bulkCopy.BulkCopyTimeout = Convert.ToInt32(TimeOut);
                    bulkCopy.ColumnMappings.Add("ROWID", "ORACLE_ROW_ID");
                    bulkCopy.ColumnMappings.Add("DEPO_CODE", "DEPO_CODE");
                    bulkCopy.ColumnMappings.Add("DLR_CODE", "DLR_CODE");
                    bulkCopy.ColumnMappings.Add("TRX_DATE", "TRX_DATE");
                    bulkCopy.ColumnMappings.Add("TOTAL_VOL", "TOTAL_VOL");
                    bulkCopy.ColumnMappings.Add("TOTAL_VAL", "TOTAL_VAL");
                    bulkCopy.ColumnMappings.Add("CB_VOL", "CB_VOL");
                    bulkCopy.ColumnMappings.Add("CB_VAL", "CB_VAL");
                    bulkCopy.ColumnMappings.Add("EMLSN_VOL", "EMLSN_VOL");
                    bulkCopy.ColumnMappings.Add("EMLSN_VAL", "EMLSN_VAL");
                    bulkCopy.ColumnMappings.Add("LB_VOL", "LB_VOL");
                    bulkCopy.ColumnMappings.Add("CREATION_DATE", "ORCL_CREATION_DATE");
                    //bulkCopy.ColumnMappings.Add("STATUS", "STATUS");
                    bulkCopy.ColumnMappings.Add("REQUEST_ID", "REQUEST_ID");
                    bulkCopy.ColumnMappings.Add("CREATED_ON", "CREATED_ON");

                    bulkCopy.DestinationTableName = DestinationTable;
                    bulkCopy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForCB", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                bulkCopy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion

        #region Function to Create record in Data Migration DB in Color Bank Table
        public static void CreateRecordInDMForSELLIN(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy bulkCopy = null;
            try
            {
                if (loglevel >= 3)
                    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForSELLIN", "Destination Table Name", DestinationTable);
                using (bulkCopy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    bulkCopy.BulkCopyTimeout = Convert.ToInt32(TimeOut);
                    bulkCopy.ColumnMappings.Add("ROWID", "ORACLE_ROW_ID");
                    bulkCopy.ColumnMappings.Add("DEPO_CODE", "DEPO_CODE");
                    bulkCopy.ColumnMappings.Add("DLR_CODE", "DLR_CODE");
                    bulkCopy.ColumnMappings.Add("TRX_DATE", "TRX_DATE");
                    bulkCopy.ColumnMappings.Add("PRODUCT", "PRODUCT");
                    bulkCopy.ColumnMappings.Add("VOLUME", "VOLUME");
                    bulkCopy.ColumnMappings.Add("CREATION_DATE", "ORCL_CREATION_DATE");
                   // bulkCopy.ColumnMappings.Add("STATUS", "STATUS");
                    bulkCopy.ColumnMappings.Add("REQUEST_ID", "REQUEST_ID");
                    bulkCopy.ColumnMappings.Add("CREATED_ON", "CREATED_ON");

                    bulkCopy.DestinationTableName = DestinationTable;
                    bulkCopy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForSELLIN", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                bulkCopy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion
    }
}
