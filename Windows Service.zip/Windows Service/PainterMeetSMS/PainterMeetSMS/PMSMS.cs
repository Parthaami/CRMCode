﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using System.Linq.Expressions;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Win32;
using System.IO;

namespace PainterMeetSMS
{
    class PMSMS
    {
        public static CRMContext _CRMContext;
        public static PragmasysLogger oLogger;
        public static string _organizationName = ConfigurationManager.AppSettings["OrgName"].ToString();
        static Configuration config;
        public static string orgUrl = string.Empty;

        static void Main(string[] args)
        {
            try
            {
                #region Read Registry Key & get Pragmasys.config Path
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 
                string configpath = DB_path + "\\CRMWeb\\ISV\\" + _organizationName + "\\Pragmasys.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        string Loggerpath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new PragmasysLogger(_organizationName, Loggerpath);
                        orgUrl = config.AppSettings.Settings["CrmServiceUrl"].Value.ToString();
                    }
                }
                #endregion
                
                PMSMS SMSObj = new PMSMS();                
                _CRMContext = SMSObj.RetrieveCRMContext();
                SMSObj.GetPaintersList();
            }
            catch (Exception ex)
            {
                oLogger.Log("PainterMeetSMS", "Main", "ERROR: ", ex.Message.ToString());
            }
        }

        protected void GetPaintersList()
        {
            try
            {
                # region ticket A0774
                        /*
                        var TotalPointsQuery = from pmc in _CRMContext.ber_paintermeetcontactSet
                                               join c in _CRMContext.ContactSet
                                               on pmc.ber_Contact.Id equals c.ContactId.Value
                                               where pmc.ber_TotalPoint.Value > 0
                                               where pmc.statuscode.Value == 1 || pmc.statuscode.Value == 278290000 || pmc.statuscode.Value == 278290003   //278290000=Pending ML Approval || Final Points Calculated = 278290003                              
                                               select new
                                               {
                                                   ContactId = pmc.ber_Contact.Id,
                                                   ContactName = pmc.ber_Contact.Name,
                                                   MobilePhone = c.MobilePhone,
                                                   TotalPoints = pmc.ber_TotalPoint.Value
                                               };

                        var SMSTobeGeneratedList = TotalPointsQuery.ToList();                

                        var FinalListQuery = from t in SMSTobeGeneratedList
                                        group t by new { t.ContactId, t.ContactName, t.MobilePhone} into t2
                                        select new
                                        {
                                            CId = t2.Key.ContactId,
                                            CName = t2.Key.ContactName,
                                            CMno = t2.Key.MobilePhone,                                    
                                            CTotalPoints = t2.Sum(t4 => t4.TotalPoints)
                                        };

                        var FinalList = FinalListQuery.ToList();

                        foreach (var f in FinalList)
                        {
                            CreateSMS(f.CId, f.CMno, f.CTotalPoints, f.CName);
                        }   */

                #endregion  

                
                var TotalPointsQuery = from pmc in _CRMContext.ber_paintermeetcontactSet
                                       join c in _CRMContext.ContactSet on pmc.ber_Contact.Id equals c.ContactId.Value
                                       join pm in _CRMContext.ber_paintermeetSet on pmc.ber_PainterMeet.Id equals pm.ber_paintermeetId.Value
                                       where pmc.ber_TotalPoint.Value > 0
                                       where pmc.statuscode.Value == 1 || pmc.statuscode.Value == 278290000 || pmc.statuscode.Value == 278290003   //278290000=Pending ML Approval || Final Points Calculated = 278290003                              

                                       select new
                                       {
                                           ContactId = pmc.ber_Contact.Id,
                                           ContactName = pmc.ber_Contact.Name,
                                           MobilePhone = c.MobilePhone,
                                           TotalPoints = pmc.ber_TotalPoint.Value,
                                           MeetName = pm.ber_Meet.Name,//"Meet Name",//m.ber_name,
                                       };

                var SMSTobeGeneratedList = TotalPointsQuery.ToList();

                var FinalListQuery = from t in SMSTobeGeneratedList
                                     group t by new { t.ContactId, t.ContactName, t.MobilePhone, t.MeetName } into t2
                                     select new
                                     {
                                         CId = t2.Key.ContactId,
                                         CName = t2.Key.ContactName,
                                         CMno = t2.Key.MobilePhone,
                                         CTotalPoints = t2.Sum(t4 => t4.TotalPoints),
                                         CMeetName=t2.Key.MeetName
                                     };

                var FinalList = FinalListQuery.ToList();

                foreach (var f in FinalList)
                {
                    CreateSMS(f.CId, f.CMno, f.CTotalPoints, f.CName,f.CMeetName);
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("PainterMeetSMS", "GetPaintersList", ex.Message, ex.Source);
            }
        }

        protected void CreateSMS(Guid contactid,string mobileno,int totalpoints,string ContactName, string MeetName)
        {
            try
            {
                pcl_sms SMSObj = new pcl_sms();

                ActivityParty SMSTo = new ActivityParty();
                SMSTo.PartyId = new EntityReference("contact", contactid);

                List<ActivityParty> SMSToList = new List<ActivityParty>();
                SMSToList.Add(SMSTo);

                SMSObj.pcl_mobilenumber = mobileno;
                SMSObj.Subject = "Painter Point Update - "+ContactName;
                SMSObj.ber_smssource= new OptionSetValue(Convert.ToInt32(ConfigurationManager.AppSettings["SMSSource"]));

                # region ticket A0774
                    //SMSObj.Description = "DEAR "+ContactName+", YOUR TOTAL EARNED POINTS UNTILL "+DateTime.Now.ToShortDateString().ToString()+" ARE "+totalpoints.ToString()+".";
                #endregion                

                SMSObj.Description = "DEAR " + ContactName + ", YOUR EARNED POINTS FOR " + MeetName.ToString() + " TILL " + DateTime.Now.ToShortDateString().ToString() + " IS " + totalpoints.ToString() + " POINTS. - BERGER PAINTS";

                SMSObj.RegardingObjectId = new EntityReference("contact", contactid);

                SMSObj.To = SMSToList;

                SMSObj.Id = Guid.NewGuid();

                _CRMContext.AddObject(SMSObj);
                _CRMContext.SaveChanges();
            }
            catch(Exception ex)
            {
                oLogger.Log("PainterMeetSMS", "CreateSMS", ex.Message, ex.Source);
            }
        }

        public CRMContext RetrieveCRMContext()
        {
            try
            {
                ClientCredentials credentials = new ClientCredentials();
                credentials.Windows.ClientCredential = (NetworkCredential)System.Net.CredentialCache.DefaultCredentials;
                //credentials.Windows.ClientCredential = new System.Net.NetworkCredential("crmadm","berger@123","bergerindia");                               
                Uri organizationUri = new Uri(orgUrl);
                Uri homeRealmUri = null;
                OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);
                orgService.EnableProxyTypes();
                return new CRMContext(orgService);                
            }
            catch (Exception ex)
            {
                oLogger.Log("PainterMeetSMS", "RetrieveCRMContext", ex.Message, ex.Source);
                throw ex;
            }
        }
    }
}
