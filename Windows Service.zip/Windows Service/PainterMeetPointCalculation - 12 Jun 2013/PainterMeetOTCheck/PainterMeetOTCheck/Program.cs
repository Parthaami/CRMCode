﻿//********************************** OVERT TRADE LIMIT CHECK*********************************************************//
//vw_OTLimitConfig = Active Meet having sales consideration date less than equal to today
//vw_OTLiftingDetailsTotal = Lifting Details Sum of verfieid quantity group by meet, dealer, painter, product having status not equal to entered or dropped
//vw_PrimarySellsIn = Primary Sales data group by Dealer, Product
//******************************************************************************************************************//
// 1. Meet records having final calculation date earlier than today
// 2. Primary Sales data having sales in consideration date between sales in consideration date of meet and Today
// 3. Lifting details records having status other than Entered or Dropped
// ******************************************************************************************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using System.Net;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Messages;

namespace PainterMeetOTCheck
{
    class Program
    {
        public static PragmasysLogger bergerlogger = null;
        static void Main(string[] args)
        {
            string connString = ConfigurationManager.AppSettings["StaggingDBConnectionString"].ToString();
            string org = ConfigurationManager.AppSettings["Org"].ToString();
            string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
            string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
            int OTHold = Convert.ToInt32(ConfigurationManager.AppSettings["OTHold"].ToString());
            int OTPass = Convert.ToInt32(ConfigurationManager.AppSettings["OTPass"].ToString());

            //Ticket # A0594
            int OTVerified = Convert.ToInt32(ConfigurationManager.AppSettings["Verified"].ToString());

            bergerlogger = new PragmasysLogger(org, logfilepath);

            #region Create CRM Service Object

            ClientCredentials credentials = new ClientCredentials();
            //credentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, domain, Password);
            credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
            Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
            Uri homeRealmUri = null;
            OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);


            #endregion

            DataTable dtOTConfigData = RetrieveOTConfigData(connString);
            DataTable dtLiftingDetailsData = RetrieveLiftingDetailsData(connString);
            DataTable dtOTLiftingDetailsData = RetrieveOTLiftingDetailsData(connString);

            foreach (DataRow drOTConfigData in dtOTConfigData.Rows)
            {
                int nOTLimit = (Int32)drOTConfigData["OT_LIMIT"];

                DataRow[] drSelectedLiftingDetails = dtOTLiftingDetailsData.Select("MEET_ID ='" + drOTConfigData["MEET_ID"].ToString() + "' AND PRODUCT_ID ='" + drOTConfigData["PRODUCT_ID"] + "'");

                for (int i = 0; i < drSelectedLiftingDetails.Length; i++)
                {
                    DateTime SalesInDate = (DateTime)drOTConfigData["SELL_IN_DATE"];
                    int nSecondarySalesTotal = 0;

                    if (int.TryParse(drSelectedLiftingDetails[i]["SELLS_TOTAL"].ToString(), out nSecondarySalesTotal))
                    {
                        string strProduct = (string)drSelectedLiftingDetails[i]["PRODUCT_NUM"];
                        string strDealer = (string)drSelectedLiftingDetails[i]["ACCOUNT_NUM"];

                        DataTable dtPrimarySales = RetrievePrimarySalesData(connString, SalesInDate.ToLocalTime(), strProduct, strDealer);

                        if (dtPrimarySales.Rows.Count > 0)
                        {
                            DataRow drPrimarySales = dtPrimarySales.Rows[0];

                            decimal nPrimarySalesTotal = (decimal)drPrimarySales["TOTAL"];

                            //Retrieve lifting details to update the status
                            DataRow[] drLDs = dtLiftingDetailsData.Select("MEET_ID ='" + drOTConfigData["MEET_ID"].ToString() + "' AND ACCOUNT_NUM ='" + strDealer + "' AND PRODUCT_NUM ='" + strProduct + "'");

                            for (int k = 0; k < drLDs.Length; k++)
                            {
                                //Update Status to OTHold
                                //==============================
                                #region Ticket # A0594

                                //if ((nSecondarySalesTotal / nPrimarySalesTotal) * 100 > nOTLimit)
                                //{
                                //    //UpdateLiftingDetailStatus(orgService, "", 278290001);
                                //    UpdateLiftingDetailStatus(orgService, drLDs[i]["LIFTING_DETAILS_ID"].ToString(), OTHold);
                                //}
                                //else if ( !(Convert.ToInt32(drLDs[k]["STATUS"]) != 278290002)) //staus is not OTPass
                                //{
                                //    UpdateLiftingDetailStatus(orgService, drLDs[i]["LIFTING_DETAILS_ID"].ToString(), OTPass);
                                //}
                                #endregion

                                if (Convert.ToInt32(drLDs[k]["STATUS"]) == OTVerified && nPrimarySalesTotal > 0) // If Verified
                                {
                                    if ((nSecondarySalesTotal / nPrimarySalesTotal) * 100 > nOTLimit)
                                    {
                                        //int oth = OTHold;
                                        UpdateLiftingDetailStatus(orgService, drLDs[i]["LIFTING_DETAILS_ID"].ToString(), OTHold); // Update Status to OT Hold
                                    }
                                    else
                                    {
                                        //int otp = OTPass;
                                        UpdateLiftingDetailStatus(orgService, drLDs[i]["LIFTING_DETAILS_ID"].ToString(), OTPass); //Update status to OT Pass
                                    }

                                }
                                
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Retrieve OT Configuration Data
        /// </summary>
        /// <returns></returns>
        public static DataTable RetrieveOTConfigData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_OTLimitConfig";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrieveOTConfigData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        public static DataTable RetrieveLiftingDetailsData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_OTLiftingDetails";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrieveLiftingDetailsData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        /// <summary>
        /// Retrieve Lifting Details Data : Sum of Verified product quanity for each customer where status is not Entered or Dropped
        /// </summary>
        /// <param name="connString"></param>
        /// <returns></returns>
        public static DataTable RetrieveOTLiftingDetailsData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_OTLiftingDetailsTotal";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrieveLiftingDetailsData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        /// <summary>
        /// Retrieve Primary Sales data with Sales In Date and Current Date group by Dealer and Product. 
        /// </summary>
        /// <param name="connString"></param>
        /// <param name="SalesInDate"></param>
        /// <param name="strProduct"></param>
        /// <param name="strDealer"></param>
        /// <returns></returns>
        public static DataTable RetrievePrimarySalesData(string connString, DateTime SalesInDate, string strProduct, string strDealer)
        {
            DataTable dt = new DataTable();
            try
            {

                #region Reference Ticket # A0594

                //string strSalesInDate = SalesInDate.Day.ToString() + "/" + SalesInDate.Month.ToString() + "/" + SalesInDate.Year.ToString();
                //string strToday = DateTime.Now.Day.ToString() + "/" + DateTime.Now.Month.ToString() + "/" + DateTime.Now.Year.ToString();
                //string query = "select DLR_CODE, PRODUCT, SUM(TOTAL_SELL_IN) TOTAL from dbo.vw_PrimarySellsIn " +
                //                "where CONVERT(VARCHAR(10),TRX_DATE,101) between '" + strSalesInDate + "' and '" + strToday + "' " +
                //                "group by DLR_CODE, PRODUCT " +
                //                "having DLR_CODE = '" + strDealer + "' AND PRODUCT = '" + strProduct + "' " +
                //                "order by DLR_CODE, PRODUCT";
                #endregion

                string strSalesInDate = SalesInDate.Year.ToString() + "-" + SalesInDate.Month.ToString() + "-" + SalesInDate.Day.ToString();
                string strToday = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                string query = "select DLR_CODE, PRODUCT, SUM(TOTAL_SELL_IN) TOTAL from dbo.vw_PrimarySellsIn " +
                                "where TRX_DATE between '" + strSalesInDate + "' and '" + strToday + "' " +
                                "group by DLR_CODE, PRODUCT " +
                                //Triming first character Zero from field DLR_Code of view vw_PrimarySellsIn, because CRM Account Number does not start with zero.
                                "having (SUBSTRING(DLR_CODE,2,(LEN(DLR_CODE)-1)) = '" + strDealer + "' OR DLR_CODE = '" + strDealer + "') AND PRODUCT = '" + strProduct + "' " +
                                "order by DLR_CODE, PRODUCT";

                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrievePrimarySalesData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        public static void UpdateLiftingDetailStatus(OrganizationServiceProxy orgService, string LiftingDetialsId, int OTStatus)
        {
            try
            {
                
                SetStateRequest request = new SetStateRequest();

                request.State = new OptionSetValue()
                {
                    Value = 0
                };
                request.Status = new OptionSetValue()
                {
                    Value = OTStatus
                };

                request.EntityMoniker = new EntityReference()
                {
                    Id = new Guid(LiftingDetialsId),
                    LogicalName = "ber_liftingdetails"
                };

                SetStateResponse response = (SetStateResponse)orgService.Execute(request);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrievePrimarySalesData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }
    }
}
