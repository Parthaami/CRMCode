﻿//*********************************************************************************************//
//PreCondition : 1. Meet Product Group's Point Calculation Date is today.
//               2. Point Calculated flag is false on Meet Product Group.
//               3. Lifting Details Staus is Accumulated
//               4. Lifting Details is created between start date and end date specified in Meet Product Group
//Action       : 1. Calculate and Update Product Group Volume on Meet Painter Record
//               2. Set Points Calculated flag on Meet Product Group to true
//********************************************************************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk;

namespace PainterMeetGroupBonus
{
    class Program
    {
        public static PragmasysLogger bergerlogger = null;

        static void Main(string[] args)
        {
            string connString = ConfigurationManager.AppSettings["StaggingDBConnectionString"].ToString();
            string org = ConfigurationManager.AppSettings["Org"].ToString();
            string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
            string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
            int OTHold = Convert.ToInt32(ConfigurationManager.AppSettings["OTHold"].ToString());
            int OTPass = Convert.ToInt32(ConfigurationManager.AppSettings["OTPass"].ToString());
            bergerlogger = new PragmasysLogger(org, logfilepath);

            #region Create CRM Service Object

            ClientCredentials credentials = new ClientCredentials();
            //credentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, domain, Password);
            credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
            Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
            Uri homeRealmUri = null;
            OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);

            #endregion

            DataTable dtGPLiftingDetails = RetrieveGroupBonusLiftingDetails(connString);
            DataTable dtGroupBonus = dtGPLiftingDetails.GetDistinctRecords(new string[] { "MEET_GROUP_ID" });
            DataTable dtDistinctLiftingDetails = dtGPLiftingDetails.GetDistinctRecords(new string[] { "MEET_ID", "PRODUCT_ID", "ACCOUNT_NUM" });

            foreach (DataRow drDistinctLiftingDetails in dtDistinctLiftingDetails.Rows)
            {
                string Filter = @"ACCOUNT_NUM = " + drDistinctLiftingDetails["ACCOUNT_NUM"].ToString() + " and PRODUCT_ID = '" +
                                drDistinctLiftingDetails["PRODUCT_ID"].ToString() + "' and MEET_ID ='" +
                                drDistinctLiftingDetails["MEET_ID"].ToString() + "'";

                int nQuantity = Convert.ToInt32(dtGPLiftingDetails.Compute("SUM(VERIFIED_QTY)", Filter));

                DataRow[] drTemp = dtGPLiftingDetails.Select(Filter);

                int nVolume, nPoint, nMinVolume, nCalculatedPoints = 0;

                if (drTemp.Length > 0)
                {
                    nPoint = Convert.ToInt32(drTemp[0]["POINTS"]);
                    nMinVolume = Convert.ToInt32(drTemp[0]["MIN_VOLUME"]);
                    nVolume = Convert.ToInt32(drTemp[0]["VOLUME"]);

                    if (nQuantity >= nMinVolume)
                    {
                        nCalculatedPoints = ((nQuantity / nVolume) * nPoint);
                    }                   

                    if (nCalculatedPoints > 0)
                    {
                        UpdateMeetPainter(orgService, new Guid(drTemp[0]["PAINTER_MEET_ID"].ToString()), nCalculatedPoints);
                    }
                }
            }

            foreach (DataRow drGroupBonus in dtGroupBonus.Rows)
            {
                UpdateProductGroupPointsCalculated(orgService, new Guid(drGroupBonus["MEET_GROUP_ID"].ToString()));
            }    

        }

        private static DataTable RetrieveGroupBonusLiftingDetails(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_GBLiftingDetails";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetGroupBonus", "RetrieveGroupBonusLiftingDetails", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        private static void UpdateMeetPainter(OrganizationServiceProxy serviceProxy, Guid PainterMeetId, int volumebonus)
        {
            try
            {
                Entity mpainter = new Entity();
                mpainter.LogicalName = "ber_paintermeet";
                mpainter.Id = PainterMeetId;
                mpainter["ber_groupbonus"] = volumebonus;
                serviceProxy.Update(mpainter);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetGroupBonus", "UpdateMeetPainter", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static void UpdateProductGroupPointsCalculated(OrganizationServiceProxy serviceProxy, Guid ProductGroupId)
        {
            try
            {
                Entity productGroup = new Entity();
                productGroup.LogicalName = "ber_meetproductgroup";
                productGroup.Id = ProductGroupId;
                productGroup["ber_pointcalculated"] = true;
                serviceProxy.Update(productGroup);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetGroupBonus", "UpdateMeetGroupPointsCalculated", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }
    }
}
