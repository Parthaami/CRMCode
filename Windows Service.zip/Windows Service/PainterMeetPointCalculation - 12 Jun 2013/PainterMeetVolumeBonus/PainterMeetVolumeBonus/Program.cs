﻿//*********************************************************************************************//
//PreCondition : 1. Volume Bonus Record's Bonus Calculation Date is today.
//               2. Point Calculated flag is false on Volume Bonus Record.
//               3. Lifting Details Staus is Accumulated.
//               4. Lifting Details is created between start date and end date specified in Volume Bonus Record.
//Action       : 1. Calculate and Update Volume Bonus on Meet Painter Record
//               2. Set Points Calculated flag on Volume Bonus Record
//********************************************************************************************//
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PainterMeetVolumeBonus
{
    class Program
    {
        public static PragmasysLogger bergerlogger = null;

        static void Main(string[] args)
        {
            string connString = ConfigurationManager.AppSettings["StaggingDBConnectionString"].ToString();
            string org = ConfigurationManager.AppSettings["Org"].ToString();
            string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
            string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
            int OTHold = Convert.ToInt32(ConfigurationManager.AppSettings["OTHold"].ToString());
            int OTPass = Convert.ToInt32(ConfigurationManager.AppSettings["OTPass"].ToString());
            bergerlogger = new PragmasysLogger(org, logfilepath);

            #region Create CRM Service Object

            ClientCredentials credentials = new ClientCredentials();
            //credentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, domain, Password);
            credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
            Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
            Uri homeRealmUri = null;
            OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);

            #endregion

            try
            {

                DataTable dtLiftingDetails = RetrieveVolumeBonusLiftingDetails(connString);
                DataTable dtVolumeBonus = dtLiftingDetails.GetDistinctRecords(new string[] { "MEET_VOLUME_BONUS_ID" });
                DataTable dtDistinctLiftingDetails = dtLiftingDetails.GetDistinctRecords(new string[] { "MEET_ID", "PRODUCT_ID", "ACCOUNT_NUM" });

                foreach (DataRow drDistinctLiftingDetails in dtDistinctLiftingDetails.Rows)
                {
                    string Filter = @"ACCOUNT_NUM = " + drDistinctLiftingDetails["ACCOUNT_NUM"].ToString() + " and PRODUCT_ID = '" +
                                    drDistinctLiftingDetails["PRODUCT_ID"].ToString() + "' and MEET_ID ='" +
                                    drDistinctLiftingDetails["MEET_ID"].ToString() + "'";

                    int nQuantity = Convert.ToInt32(dtLiftingDetails.Compute("SUM(VERIFIED_QTY)", Filter));

                    DataRow[] drTemp = dtLiftingDetails.Select(Filter);

                    int nVolume, nPoint, nMaxVolume, nCalculatedPoints = 0;

                    if (drTemp.Length > 0)
                    {
                        nPoint = Convert.ToInt32(drTemp[0]["POINTS"]);
                        nMaxVolume = Convert.ToInt32(drTemp[0]["MAX_VOLUME"]);
                        nVolume = Convert.ToInt32(drTemp[0]["VOLUME"]);

                        if (nQuantity >= nMaxVolume)
                        {
                            nCalculatedPoints = ((nMaxVolume / nVolume) * nPoint);
                        }
                        else
                        {
                            nCalculatedPoints = ((nQuantity / nVolume) * nPoint);
                        }

                        if (nCalculatedPoints > 0)
                        {
                            UpdateMeetPainter(orgService, new Guid(drTemp[0]["PAINTER_MEET_ID"].ToString()), nCalculatedPoints);
                        }
                    }
                }

                foreach (DataRow drVolumeBonus in dtVolumeBonus.Rows)
                {
                    UpdateMeetVolumePointsCalculated(orgService, new Guid(drVolumeBonus["MEET_VOLUME_BONUS_ID"].ToString()));
                }
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetVolumeBonus", "RetrieveVolumeBonusLiftingDetails", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }       

        private static DataTable RetrieveVolumeBonusLiftingDetails(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = @"select * from dbo.vw_VBLiftingDetails";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetVolumeBonus", "RetrieveVolumeBonusLiftingDetails", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }       


        private static void UpdateMeetPainter(OrganizationServiceProxy serviceProxy, Guid PainterMeetId, int volumebonus)
        {
            try
            {
                Entity mpainter = new Entity();
                mpainter.LogicalName = "ber_paintermeet";
                mpainter.Id = PainterMeetId;
                mpainter["ber_volumebonus"] = volumebonus;
                serviceProxy.Update(mpainter);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetVolumeBonus", "UpdateMeetPainter", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static void UpdateMeetVolumePointsCalculated(OrganizationServiceProxy serviceProxy, Guid MeetVolumeBonusId)
        {
            try
            {
                Entity meetvolumebonus = new Entity();
                meetvolumebonus.LogicalName = "ber_meetvolumebonus";
                meetvolumebonus.Id = MeetVolumeBonusId;  
                meetvolumebonus["ber_pointcalculated"] = true;
                serviceProxy.Update(meetvolumebonus);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetVolumeBonus", "UpdateMeetVolumePointsCalculated", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }
    }
}
