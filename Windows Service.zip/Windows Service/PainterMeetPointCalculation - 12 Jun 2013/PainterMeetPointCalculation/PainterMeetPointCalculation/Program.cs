﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Configuration;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Net;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;

namespace PainterMeetPointCalculation
{
    class Program
    {
        public static PragmasysLogger bergerlogger = null;

        static void Main(string[] args)
        {
            string connString = ConfigurationManager.AppSettings["StaggingDBConnectionString"].ToString();
            string org = ConfigurationManager.AppSettings["Org"].ToString();
            string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
            string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
            int OTHold = Convert.ToInt32(ConfigurationManager.AppSettings["OTHold"].ToString());
            int OTPass = Convert.ToInt32(ConfigurationManager.AppSettings["OTPass"].ToString());
            int Accumulated = Convert.ToInt32(ConfigurationManager.AppSettings["Accumulated"].ToString());
            bergerlogger = new PragmasysLogger(org, logfilepath);

            #region Create CRM Service Object

            ClientCredentials credentials = new ClientCredentials();
            //credentials.Windows.ClientCredential = new System.Net.NetworkCredential(username, domain, Password);
            credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
            Uri organizationUri = new Uri(serverurl + "/" + org + "/XRMServices/2011/Organization.svc");
            Uri homeRealmUri = null;
            OrganizationServiceProxy orgService = new OrganizationServiceProxy(organizationUri, homeRealmUri, credentials, null);

            #endregion

            DataTable dtRegularPointConfigData = RetrieveRegularConfigData(connString);
            DataTable dtLiftingDetailsData = RetrieveLiftingDetailsData(connString);

            foreach (DataRow drRegularPointData in dtRegularPointConfigData.Rows)
            {
                int nPoints = Convert.ToInt32(drRegularPointData["POINTS"]);
                DataRow[] drSelectedLiftingDetails = dtLiftingDetailsData.Select("PRODUCT_ID ='" + drRegularPointData["PRODUCT_ID"] + "' AND MEET_ID ='" + drRegularPointData["MEET_ID"] + "'");

                for (int i = 0; i < drSelectedLiftingDetails.Length; i++)
                {
                    int nVerifiedQty = Convert.ToInt32(drSelectedLiftingDetails[i]["VERIFIED_QTY"]);
                    if (nVerifiedQty > 0)
                    {
                        //UpdateLiftingDetails(orgService, new Guid(drSelectedLiftingDetails[i]["LIFTING_DETAILS_ID"].ToString()), nVerifiedQty * nPoints);
                        //Update Regular Points on Meet Painter
                        UpdateMeetPainter(orgService, new Guid(drSelectedLiftingDetails[i]["PAINTER_MEET_ID"].ToString()), nVerifiedQty * nPoints);

                        //Update Status to "ACCUMULDATED" on Lifting Details
                        UpdateLiftingDetailStatus(orgService, drSelectedLiftingDetails[i]["LIFTING_DETAILS_ID"].ToString(), Accumulated);
                    }
                }

                //Update Final Point Calculated Flag on Meet when final point calculation date reached
                DateTime finalDate = Convert.ToDateTime(drRegularPointData["POINT_CALC_DATE"].ToString());
                if (finalDate.ToShortDateString() == DateTime.Now.ToShortDateString())
                {
                    UpdateCalculationFlagOnMeet(orgService, new Guid(drRegularPointData["MEET_ID"].ToString()));
                }
            }
        }

        private static DataTable RetrieveRegularConfigData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_RegularPointConfig";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "RetrieveRegularConfigData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        private static DataTable RetrieveLiftingDetailsData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_LiftingDetails where STATUS = '278290002'"; // OTPass Status
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "RetrieveLiftingDetailsData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            return dt;
        }

        private static void UpdateLiftingDetails(OrganizationServiceProxy serviceProxy, Guid LiftingDetailsId, int Point)
        {
            try
            {
                Entity LiftingDetails = serviceProxy.Retrieve("ber_liftingdetails", LiftingDetailsId, new ColumnSet(true));
                LiftingDetails["ber_totalpoint"] = Point;
                serviceProxy.Update(LiftingDetails);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "UpdateLiftingDetails", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static void UpdateMeetPainter(OrganizationServiceProxy serviceProxy, Guid PainterMeetId, int Point)
        {
            try
            {
                Entity mpainter = new Entity();
                mpainter.LogicalName = "ber_paintermeet";
                mpainter.Id = PainterMeetId;
                mpainter["ber_regularpoints"] = Point;
                serviceProxy.Update(mpainter);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "UpdateMeetPainter", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        private static void UpdateCalculationFlagOnMeet(OrganizationServiceProxy serviceProxy, Guid MeetId)
        {
            try
            {
                Entity meet = new Entity();
                meet.LogicalName = "ber_meet";
                meet.Id = MeetId;
                meet["ber_finalpointcalculated"] = true;
                serviceProxy.Update(meet);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "UpdateCalculationFlagOnMeet", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        public static void UpdateLiftingDetailStatus(OrganizationServiceProxy orgService, string LiftingDetialsId, int OTStatus)
        {
            try
            {
                SetStateRequest request = new SetStateRequest();

                request.State = new OptionSetValue()
                {
                    Value = 0
                };
                request.Status = new OptionSetValue()
                {
                    Value = OTStatus
                };

                request.EntityMoniker = new EntityReference()
                {
                    Id = new Guid(LiftingDetialsId),
                    LogicalName = "ber_liftingdetails"
                };

                SetStateResponse response = (SetStateResponse)orgService.Execute(request);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetPointCalculation", "RetrievePrimarySalesData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }
    }
}
