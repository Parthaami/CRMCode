using System;
using System.IO;

namespace DataMigrationExecutorService
{
	internal class Logger
	{
		private string _organization;

		private string _filePath;

		private string Folder_path = string.Empty;

		public Logger(string OrgnizationName, string configfilepath)
		{
			this._organization = OrgnizationName;
			this.Folder_path = configfilepath;
		}

		public void Log(string SourceName, string MethodName, string description, string ErrorMessage)
		{
			string[] strArrays;
			int i;
			try
			{
				this._filePath = string.Concat(this.Folder_path, "Log_DataMigrationExecutorServiceForSalesOrder_", this._organization, ".txt");
				string[] ErrorLogs = new string[] { SourceName, MethodName, description, ErrorMessage };
				if (!Directory.Exists(this.Folder_path))
				{
					Directory.CreateDirectory(this.Folder_path);
				}
				if (!File.Exists(this._filePath))
				{
					(new FileStream(this._filePath, FileMode.Create, FileAccess.Write)).Close();
					StreamWriter file = new StreamWriter(this._filePath);
					file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
					file.WriteLine(" CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
					file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
					file.Write("*.");
					file.Write("\t");
					file.Write(DateTime.Now);
					file.Write("\t\t");
					strArrays = ErrorLogs;
					for (i = 0; i < (int)strArrays.Length; i++)
					{
						file.Write(strArrays[i]);
						file.Write("\t\t");
					}
					file.WriteLine("");
					file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
					file.Close();
				}
				else
				{
					File.AppendAllText(this._filePath, Environment.NewLine);
					File.AppendAllText(this._filePath, "*.");
					File.AppendAllText(this._filePath, "\t");
					File.AppendAllText(this._filePath, DateTime.Now.ToString());
					File.AppendAllText(this._filePath, "\t\t");
					strArrays = ErrorLogs;
					for (i = 0; i < (int)strArrays.Length; i++)
					{
						string log = strArrays[i];
						File.AppendAllText(this._filePath, log);
						File.AppendAllText(this._filePath, "\t\t");
					}
					File.AppendAllText(this._filePath, Environment.NewLine);
					File.AppendAllText(this._filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
				}
			}
			catch (Exception exception)
			{
				throw exception;
			}
		}
	}
}