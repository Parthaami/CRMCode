using Oracle.DataAccess.Client;
using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Diagnostics;

namespace DataMigrationExecutorService
{
	internal class DMExecutor
	{
		public static string ORAProvider;

		public static string OrganisationName;

		public static string LoggerFilePath;

		public static string SQLProvider;

		public static string DMExe;

		private static int oracleFetchSize;

		public static int loglevel;

		public static Logger oLogger;

		public static Guid ProcessId;

		public static int RecordsUpdated;

		public static DataSet DSCreatedRecordInDM;

		static DMExecutor()
		{
			DMExecutor.ORAProvider = ConfigurationManager.ConnectionStrings["ORAProvider"].ConnectionString;
			DMExecutor.OrganisationName = ConfigurationManager.AppSettings["OrgName"];
			DMExecutor.LoggerFilePath = ConfigurationManager.AppSettings["LoggerPath"];
			DMExecutor.SQLProvider = ConfigurationManager.ConnectionStrings["SQLProvider"].ConnectionString;
			DMExecutor.DMExe = ConfigurationManager.AppSettings["DMExecutablePath"];
			DMExecutor.oracleFetchSize = Convert.ToInt32(ConfigurationManager.AppSettings["oracleFetchSize"].ToString());
			DMExecutor.loglevel = Convert.ToInt32(ConfigurationManager.AppSettings["loglevel"].ToString());
			DMExecutor.RecordsUpdated = 0;
			DMExecutor.DSCreatedRecordInDM = new DataSet();
		}

		public DMExecutor()
		{
		}

		public static bool CreateRecordInDM(DataSet DS)
		{
			Console.WriteLine("Create Records In DM Start.");
			bool isError = true;
			DataTable DT = DS.Tables[0];
			SqlConnection cn = new SqlConnection(DMExecutor.SQLProvider);
			SqlBulkCopy copy = null;
			try
			{
				try
				{
					Console.WriteLine("Opening SQL Connection.");
					cn.Open();
					Console.WriteLine("SQL Connection opened.");
					SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(cn);
					copy = sqlBulkCopy;
					using (sqlBulkCopy)
					{
						Console.WriteLine("Bulk Copy Start.");
						copy.ColumnMappings.Add("ROWID", "ORACLE_ROW_ID");
						copy.ColumnMappings.Add("ORDER_GUID", "salesorderid");
						copy.ColumnMappings.Add("ORDER_NUMBER", "ber_erporderno");
						copy.ColumnMappings.Add("STATUS", "ber_erporderstatus");
						copy.ColumnMappings.Add("REMARKS", "ber_ebizerror");
						copy.ColumnMappings.Add("Import Status", "Import_Status");
						copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");
						copy.ColumnMappings.Add("HEADER_ID", "ber_erpheaderid");
						copy.DestinationTableName = "salesorder";
						copy.WriteToServer(DT);
						Console.WriteLine("Bulk Copy End.");
						isError = false;
						if (DMExecutor.loglevel >= 3)
						{
							Logger logger = DMExecutor.oLogger;
							int count = DT.Rows.Count;
							logger.Log("DataMigrationExecutorService", "CreateRecordInDM", "Records Success fuly Copied in Staging DB ", string.Concat("No. Of Rows Created in staging DB : ", count.ToString()));
						}
					}
				}
				catch (Exception exception)
				{
					Exception ex = exception;
					isError = true;
					DMExecutor.oLogger.Log("DataMigrationExecutorService", "CreateRecordInDM", "Unable to create record in Data Migration DB", ex.Message.ToString());
				}
			}
			finally
			{
				copy.Close();
				cn.Close();
				cn.Dispose();
				DT.Clear();
				Console.WriteLine("SQL Connection Closed.");
			}
			return isError;
		}

		public static DataSet GetRecordsFromOracle(Guid PId)
		{
			Exception exp;
			int count;
			Console.WriteLine("Get Records From Oracle Method Start.");
			string query = string.Concat("select ROWID,CRM_REQUEST_ID, ORDER_GUID,HEADER_ID,ORDER_NUMBER,STATUS,REMARKS,'R' as \"Import Status\"  from xxcrm_order_header where CRM_REQUEST_ID ='", PId, "'");
			DataSet sds = new DataSet();
			OracleConnection connection = new OracleConnection(DMExecutor.ORAProvider);
			OracleCommand command = new OracleCommand();
			OracleDataAdapter dataAdapter = new OracleDataAdapter(command);
			if (DMExecutor.loglevel >= 3)
			{
				DMExecutor.oLogger.Log("DataMigrationExecutorService", "GetRecordsFromOracle", "Select Query: ", query);
			}
			try
			{
				try
				{
					Console.WriteLine("Opening Oracle Connection");
					connection.Open();
					Console.WriteLine("Oracle Connection Opened.");
					command.Connection = connection;
					command.CommandText = query;
					command.CommandType = CommandType.Text;
					command.FetchSize = (long)DMExecutor.oracleFetchSize;
					dataAdapter.Fill(sds);
					try
					{
						if (DMExecutor.loglevel >= 2)
						{
							Logger logger = DMExecutor.oLogger;
							count = sds.Tables[0].Rows.Count;
							logger.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", "TableName : xxcrm_order_header", string.Concat("Count for Records selected: ", count.ToString()));
							count = sds.Tables[0].Rows.Count;
							Console.WriteLine(string.Concat("Count of Records selected: ", count.ToString()));
						}
					}
					catch (Exception exception)
					{
						exp = exception;
						Logger logger1 = DMExecutor.oLogger;
						count = sds.Tables.Count;
						logger1.Log("WrapperExecutorforDMUtility", "GetRecordsFromOracle", "TableName : xxcrm_order_header", string.Concat("Count of Tables in DataSet: ", count.ToString(), "Exp: ", exp.ToString()));
					}
				}
				catch (Exception exception1)
				{
					exp = exception1;
					Logger logger2 = DMExecutor.oLogger;
					object[] rowSize = new object[] { "Query : ", query, "Row Size: ", command.RowSize, "Fetch Size: ", command.FetchSize };
					logger2.Log("DataMigrationExecutorService", "GetRecordsFromOracle", string.Concat(rowSize), string.Concat(" Exception: ", exp.ToString(), exp.StackTrace.ToString()));
				}
			}
			finally
			{
				connection.Close();
				dataAdapter.Dispose();
				command.Dispose();
				connection.Dispose();
				Console.WriteLine("Oracle Connection Closed.");
			}
			return sds;
		}

		private static void Main(string[] args)
		{
			Console.WriteLine("Execution Start...");
			string oraReturnMessage = string.Empty;
			try
			{
				try
				{
					DMExecutor.oLogger = new Logger(DMExecutor.OrganisationName, DMExecutor.LoggerFilePath);
					DMExecutor.ProcessId = Guid.NewGuid();
					if (DMExecutor.loglevel >= 1)
					{
						DMExecutor.oLogger.Log("DataMigrationExecutorService", "Main", "Process Id: ", DMExecutor.ProcessId.ToString());
					}
					Console.WriteLine("Calling Set Process Id Method.");
					oraReturnMessage = DMExecutor.SetProcessId(DMExecutor.ProcessId);
					Console.WriteLine(string.Concat("Set Process Id Method Result :", oraReturnMessage));
					DMExecutor.RecordsUpdated = Convert.ToInt32(oraReturnMessage);
					if (DMExecutor.RecordsUpdated > 0)
					{
						Console.WriteLine("Calling Get Records From Oracle Method.");
						DMExecutor.DSCreatedRecordInDM = DMExecutor.GetRecordsFromOracle(DMExecutor.ProcessId);
						if (DMExecutor.DSCreatedRecordInDM.Tables.Count <= 0)
						{
							throw new Exception("No records to update from Oracle staging table.");
						}
						Console.WriteLine("Calling Create Record in DM Method.");
						bool ProceedDataMigration = DMExecutor.CreateRecordInDM(DMExecutor.DSCreatedRecordInDM);
						Console.WriteLine(string.Concat("Create Records In DM Result : ", ProceedDataMigration));
						if (ProceedDataMigration)
						{
							throw new Exception("Error creating records in staging table.");
						}
						Process.Start(DMExecutor.DMExe, string.Concat(DMExecutor.ProcessId, "|salesorder"));
					}
				}
				catch (Exception exception)
				{
					Exception exp = exception;
					DMExecutor.oLogger.Log("DataMigrationExecutorService", "Main_exp", string.Concat("OraReturnMessage: ", oraReturnMessage), exp.Message.ToString());
					throw exp;
				}
			}
			finally
			{
				Environment.Exit(1);
			}
		}

		public static string SetProcessId(Guid PId)
		{
			Console.WriteLine("Set Process Id Method Start.");
			bool isError = true;
			string errorMessage = string.Empty;
			string query = string.Concat("update xxcrm_order_header SET CRM_STATUS = 'WIP',CRM_REQUEST_ID = '", PId, "' where STATUS ='COMPLETED' AND CRM_STATUS='ERROR' AND CRM_REQUEST_ID IS NULL AND  ROWNUM < 50");
			int nowofRowsOracleUpdate = 0;
			OracleConnection connection = new OracleConnection(DMExecutor.ORAProvider);
			Console.WriteLine("Opening Oracle Connection.");
			connection.Open();
			Console.WriteLine("Oracle Connection Opende.");
			OracleCommand command = connection.CreateCommand();
			try
			{
				try
				{
					command.CommandType = CommandType.Text;
					command.CommandText = query;
					nowofRowsOracleUpdate = command.ExecuteNonQuery();
					Console.WriteLine(string.Concat("No. Of Orders Updated : ", nowofRowsOracleUpdate.ToString()));
					if (DMExecutor.loglevel >= 3)
					{
						DMExecutor.oLogger.Log("DataMigrationExecutorService", "SetProcessId", string.Concat("Update Query: ", query), string.Concat("No. Of Records Updated : ", nowofRowsOracleUpdate.ToString()));
					}
					isError = false;
				}
				catch (Exception exception)
				{
					Exception ex = exception;
					DMExecutor.oLogger.Log("DataMigrationExecutorService", "SetProcessId", string.Concat("Query : ", query), string.Concat(" Exception: ", ex.Message.ToString()));
					isError = true;
					errorMessage = ex.ToString();
				}
			}
			finally
			{
				connection.Close();
				command.Dispose();
				connection.Dispose();
				Console.WriteLine("Closed,Disposed Oracle Connection.");
			}
			Console.WriteLine("Set Process Id Method End.");
			return (!isError ? nowofRowsOracleUpdate.ToString() : errorMessage);
		}
	}
}