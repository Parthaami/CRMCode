﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk;
using System.Xml;
using System.IO;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Data;

namespace PainterRating
{
    class PainterRating
    {
        private static PragmasysLogger bergerlogger = null;
        private static string printLog = string.Empty;



        static void Main(string[] args)
        {
            try
            {

                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                string server = ConfigurationManager.AppSettings["DBServer"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
                string ConditionItems = ConfigurationManager.AppSettings["PainterItems"];
                int PainterItemCount = Convert.ToInt16(ConfigurationManager.AppSettings["PainterItemCount"]);
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString(); 
                
                string JW = ConfigurationManager.AppSettings["JW"];
                string AS = ConfigurationManager.AppSettings["AS"];
                string AR = ConfigurationManager.AppSettings["AR"];
                string HHS = ConfigurationManager.AppSettings["HHS"];
                string LHS = ConfigurationManager.AppSettings["LHS"];


                bergerlogger = new PragmasysLogger(org, logfilepath);

                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["APPServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                DataTable PainterCollection = RetrievePainters(orgService, DatabaseName, server);

                if (PainterCollection.Rows.Count > 0)
                {
                    foreach (DataRow row in PainterCollection.Rows) // Loop over the rows.
                    {

                        int Total_lead_assigned = 0;
                        int Total_Leads_Converted = 0;
                        int B_Total_lead_assigned = 0;
                        int B_Total_Leads_Converted = 0;
                        int B_CSAT_Score = 0;
                        int Express_Items = 0;
                        int leadCompleted = 0;
                        int ExteriorPainter_Tool_Rating = 0;
                        int Interior_Both_Painter_Tool_Rating = 0;
                        int Express_Item_RatingCount = 0;
                        double Cal_Total_lead_assigned = 0;
                        double Cal_Total_Items = 0;
                        double Cal_Total_Leads_Converted = 0;
                        double Cal_CSAT_Score = 0;
                        double CAl_ExteriorPainter_Rating = 0;
                        double CAL_Interior_Both_Painter_Rating = 0;
                        double Exterior_rating = 0;
                        double InteriorExterior_rating = 0;
                       

                        //retrive number of lead assigned
                        if (row.ItemArray[2] != DBNull.Value)
                        {
                            Total_lead_assigned = Convert.ToInt16(row.ItemArray[2]);
                        }
                        if (Total_lead_assigned > 10)
                        {
                            B_Total_lead_assigned = 0;
                        }
                        if (Total_lead_assigned == 0)
                        {
                            B_Total_lead_assigned = 5;
                        }

                        Cal_Total_lead_assigned = B_Total_lead_assigned * 0.10;

                        //retrive number of Leads Converted
                        //100 - ((total leads assigned - total lead conv)/total lead assigned)*100
                        if (row.ItemArray[3] != DBNull.Value)
                        {
                            leadCompleted = Convert.ToInt16(row.ItemArray[3]);
                        }
                        if (Total_lead_assigned > 0)
                        {
                            Total_Leads_Converted = (100 - (Total_lead_assigned - leadCompleted) / Total_lead_assigned) * 100;
                        }

                        if (Total_Leads_Converted == 0)
                        {
                            B_Total_Leads_Converted = 0;
                        }
                        if (Total_Leads_Converted > 80)
                        {
                            B_Total_Leads_Converted = 5;


                        }
                        Cal_Total_Leads_Converted = B_Total_Leads_Converted * 0.20;
                        //retreive CSAT Score 

                        if (row.ItemArray[4] != DBNull.Value)
                        {
                            B_CSAT_Score = Convert.ToInt16(row.ItemArray[4]);
                        }
                        Cal_CSAT_Score = B_CSAT_Score * 0.20;

                        
                        string painterid = row.ItemArray[0].ToString();

                        ExteriorPainter_Tool_Rating = RetrieveExteriorTools(orgService, painterid, JW, AS);
                        CAl_ExteriorPainter_Rating = ExteriorPainter_Tool_Rating * 0.30;

                        Interior_Both_Painter_Tool_Rating = RetrieveInteriorTools(orgService, painterid, AR, HHS, LHS);
                        CAL_Interior_Both_Painter_Rating = Interior_Both_Painter_Tool_Rating * 0.30;
                        
                        DataTable PaintExpressItemsEntityCollection = RetrievePaintExpressItems(orgService, painterid, ConditionItems, DatabaseName, server);
                        
                        

                        if (PaintExpressItemsEntityCollection.Rows.Count >= PainterItemCount)
                        {
                            bool MaxSetcontrol = true;
                            bool MinSetcontrol = true;
                            foreach (DataRow paintitemrow in PaintExpressItemsEntityCollection.Rows) // Loop over the rows.
                            {
                               
                               Express_Items = Convert.ToInt16(paintitemrow.ItemArray[0]);
                               if (Express_Items < 4) { MaxSetcontrol = false; break; }
                            }

                            if (MaxSetcontrol == true)
                            {
                                Express_Item_RatingCount = 5;
                            }
                            else
                            {
                                foreach (DataRow paintitemrow in PaintExpressItemsEntityCollection.Rows) // Loop over the rows.
                                {

                                    Express_Items = Convert.ToInt16(paintitemrow.ItemArray[0]);
                                    if (Express_Items != 1 && Express_Items < 4) { MinSetcontrol = false; break; }
                                }
                                if (MinSetcontrol == true)
                                {
                                    Express_Item_RatingCount = 1;
                                }
                            }

                        }
                        
                        Cal_Total_Items = Express_Item_RatingCount * 0.20;


                        //calculate Rating


                        Exterior_rating = Cal_Total_Leads_Converted + Cal_Total_Items + Cal_CSAT_Score + Cal_Total_lead_assigned + CAl_ExteriorPainter_Rating;
                        InteriorExterior_rating = Cal_Total_Leads_Converted + Cal_Total_Items + Cal_CSAT_Score + Cal_Total_lead_assigned + CAL_Interior_Both_Painter_Rating;

                        string ExteriorRate = Convert.ToString(Exterior_rating);
                        string InteriorBothRate = Convert.ToString(InteriorExterior_rating);
                        decimal Exteriorvalue;
                        decimal Interiorvalue;
                        if (decimal.TryParse(ExteriorRate, out Exteriorvalue))
                        {
                            Exteriorvalue = Math.Round(Exteriorvalue);
                        }
                        if (decimal.TryParse(InteriorBothRate, out Interiorvalue))
                        {
                            Interiorvalue = Math.Round(Interiorvalue);
                        }


                        if (Exteriorvalue != Decimal.MinValue && Interiorvalue!= decimal.MinValue)
                        {
                            UpdatePainter(painterid, orgService, Exteriorvalue, Interiorvalue);
                        }

                    }
                }

                // }
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

       private static TProxy GetProxy<TService, TProxy>(
       IServiceManagement<TService> serviceManagement,
       AuthenticationCredentials authCredentials)
       where TService : class
       where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        public static void UpdatePainter(string ID, IOrganizationService service, decimal Exteriorvalue, decimal Interiorvalue)
        {
            Entity Painter = new Entity("contact");
            Painter.Attributes["contactid"] = new Guid(ID);
            Painter.Attributes["ber_painterrating"] = Interiorvalue;
            Painter.Attributes["ber_exteriorpainterrating"] = Exteriorvalue;

            service.Update(Painter);
        }

        public static DataTable RetrievePainters(OrganizationServiceProxy orgService, string DatabaseName, string server)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection conn = new SqlConnection())
                {

                    conn.ConnectionString = "Server=" + server + ";Database=" + DatabaseName + ";User ID=" + ConfigurationManager.AppSettings["DBUserName"] + "; Password=" + ConfigurationManager.AppSettings["DBPassword"] + ";";
                    conn.Open();
                    try
                    {
                        string queryString = "select distinct ContactId,FullName,ber_leadsassignedcount,ber_leadsclosedcount,ber_csirating,ber_customertype from dbo.FilteredContact where ((ber_CustomerType = 278290001) AND (ber_epstatus = 278290003 OR ber_epstatus = 278290000))";
                        SqlCommand cmd = new SqlCommand(queryString, conn);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);


                    }
                    // catch block
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }

                return dt;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterRatingRating", "RetrievePainters", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }



        public static DataTable RetrievePaintExpressItems(IOrganizationService Service, string Painterid, String ConditionItems, String DatabaseName, string server)
        {
            try
            {
                DataTable dt = new DataTable();
                using (SqlConnection conn = new SqlConnection())
                {
                    
                    conn.ConnectionString = "Server="+server+";Database=" + DatabaseName + ";User ID=" + ConfigurationManager.AppSettings["DBUserName"] + "; Password=" + ConfigurationManager.AppSettings["DBPassword"] + ";";
                    conn.Open();
                    try
                    {
                        string queryString = "select COUNT(ber_ItemId) as expressitemcount,ber_ItemId from dbo.Filteredber_paintexpressitem where ber_painterid ='" + Painterid + "'AND ber_ItemId IN(" + ConditionItems + ") group by (ber_ItemId)";
                        SqlCommand cmd = new SqlCommand(queryString, conn);
                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);


                    }
                    // catch block
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }
                }

                return dt;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterRatingRating", "RetrievePainters", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
        }

        public static int RetrieveExteriorTools(OrganizationServiceProxy orgService,string Painterid,string JW,string AS)
        {
            try
            {
                int ratingfortool = 0;

                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='ber_paintexpressitem'>");
                strQuery.Append("<attribute name='ber_name' />");
                strQuery.Append("<attribute name='ber_paintexpressitemid' />");
                strQuery.Append(" <order attribute='ber_name' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_painterid' value='" + Painterid + "' operator='eq' />");
                strQuery.Append("<condition attribute='statecode' operator='eq' value='0' />");
                strQuery.Append("<condition attribute='ber_itemid' value='" + JW + "' operator='eq' />");
                strQuery.Append("<condition attribute='ber_itemid' value='" + AS + "' operator='eq' />");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                EntityCollection PainterWithBothToolCollection = Retrieve(orgService, strQuery.ToString());
                if (PainterWithBothToolCollection.Entities.Count != 0)
                {
                    ratingfortool = 5;
                    
                }
                else
                {
                    StringBuilder strQuery2 = new StringBuilder();
                    strQuery2.Append("<fetch mapping='logical' distinct = 'true'>");
                    strQuery2.Append("<entity name='ber_paintexpressitem'>");
                    strQuery2.Append("<attribute name='ber_name' />");
                    strQuery2.Append("<attribute name='ber_paintexpressitemid' />");
                    strQuery2.Append(" <order attribute='ber_name' descending='false' />");
                    strQuery2.Append(" <filter type='and'>");
                    strQuery2.Append("<condition attribute='ber_painterid' value='" + Painterid + "' operator='eq' />");
                    strQuery2.Append("<condition attribute='statecode' operator='eq' value='0' />");
                    strQuery2.Append(" <filter type='or'>");
                    strQuery2.Append("<condition attribute='ber_itemid' value='" + JW + "' operator='eq' />");
                    strQuery2.Append("<condition attribute='ber_itemid' value='" + AS + "' operator='eq' />");
                    strQuery2.Append("</filter>");
                    strQuery2.Append("</filter>");
                    strQuery2.Append(" </entity>");
                    strQuery2.Append("</fetch>");

                    EntityCollection PainterWithAnyToolCollection = Retrieve(orgService, strQuery2.ToString());
                    if (PainterWithAnyToolCollection.Entities.Count != 0)
                    {
                        ratingfortool = 3;
                    }
                    else
                    {
                        ratingfortool = 0;
                    }
                }

                return ratingfortool;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealeLeadAudit", "RetrieveDGContact", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        

        public static int RetrieveInteriorTools(OrganizationServiceProxy orgService,string Painterid,string AR,string HHS,string LHS)
        {
            try
            {
                int InteriorOrBothtool = 0;

                StringBuilder strQuery = new StringBuilder();
                strQuery.Append("<fetch mapping='logical' distinct = 'true'>");
                strQuery.Append("<entity name='ber_paintexpressitem'>");
                strQuery.Append("<attribute name='ber_name' />");
                strQuery.Append("<attribute name='ber_paintexpressitemid' />");
                strQuery.Append(" <order attribute='ber_name' descending='false' />");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_painterid' value='" + Painterid + "' operator='eq' />");
                strQuery.Append("<condition attribute='statecode' operator='eq' value='0' />");
                strQuery.Append(" <filter type='or'>");
                strQuery.Append(" <filter type='and'>");
                strQuery.Append("<condition attribute='ber_itemid' value='" + AR + "' operator='eq' />");
                strQuery.Append("<condition attribute='ber_itemid' value='" + HHS + "' operator='eq' />");
                strQuery.Append("</filter>");
                strQuery.Append("<condition attribute='ber_itemid' value='" + LHS + "' operator='eq' />");
                strQuery.Append("</filter>");
                strQuery.Append("</filter>");
                strQuery.Append(" </entity>");
                strQuery.Append("</fetch>");

                EntityCollection InteriorExteriorToolCollection = Retrieve(orgService, strQuery.ToString());
                if (InteriorExteriorToolCollection.Entities.Count != 0)
                {
                    InteriorOrBothtool = 5;
                    
                }
                else
                {
                    StringBuilder strQuery2 = new StringBuilder();
                    strQuery2.Append("<fetch mapping='logical' distinct = 'true'>");
                    strQuery2.Append("<entity name='ber_paintexpressitem'>");
                    strQuery2.Append("<attribute name='ber_name' />");
                    strQuery2.Append("<attribute name='ber_paintexpressitemid' />");
                    strQuery2.Append(" <order attribute='ber_name' descending='false' />");
                    strQuery2.Append(" <filter type='and'>");
                    strQuery2.Append("<condition attribute='ber_painterid' value='" + Painterid + "' operator='eq' />");
                    strQuery2.Append("<condition attribute='statecode' operator='eq' value='0' />");
                    strQuery2.Append("<condition attribute='ber_itemid' value='" + AR + "' operator='eq' />");
                    strQuery2.Append(" <filter type='or'>");
                    strQuery2.Append("<condition attribute='ber_itemid' value='" + HHS + "' operator='eq' />");
                    strQuery2.Append("<condition attribute='ber_itemid' value='" + LHS + "' operator='eq' />");
                    strQuery2.Append("</filter>");
                    strQuery2.Append("</filter>");
                    strQuery2.Append(" </entity>");
                    strQuery2.Append("</fetch>");

                    EntityCollection ToolCollection = Retrieve(orgService, strQuery2.ToString());
                    if (ToolCollection.Entities.Count != 0)
                    {
                        InteriorOrBothtool = 3;
                    }
                    else
                    {
                        InteriorOrBothtool = 0;
                    }
                }

                return InteriorOrBothtool;

            }
            catch (Exception ex)
            {
                bergerlogger.Log("painterrating", "RetrieveInteriorTools", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }

        }

        public static Microsoft.Xrm.Sdk.EntityCollection Retrieve(OrganizationServiceProxy orgService, string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;
                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)orgService.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)orgService.Execute(oRequest);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("DealerRating", "RetrieveEntityCollection", "Failed:", ex.StackTrace.ToString());
                throw ex;
            }
            return oResponse.EntityCollection;
        }



        
    }
}
