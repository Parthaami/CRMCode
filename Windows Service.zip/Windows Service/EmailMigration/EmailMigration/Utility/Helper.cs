﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Configuration;
using System.ServiceModel.Description;

namespace EmailMigration.Utility
{
   internal class Helper
    {
        internal static IOrganizationService ConnectToCRM()
        {
            try
            {
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string SoapOrgServiceUri = ConfigurationManager.AppSettings["SoapUri"].ToString();
                ClientCredentials credentials = new ClientCredentials();
                credentials.UserName.UserName = UserName;
                credentials.UserName.Password = Password;
                Uri serviceUri = new Uri(SoapOrgServiceUri);
                OrganizationServiceProxy proxy = new OrganizationServiceProxy(serviceUri, null, credentials, null);
                proxy.EnableProxyTypes();
                return (IOrganizationService)proxy;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error trying to connect CRM " + ex.Message);
                throw ex;
            }
        }

        internal static void UpdateStatus(Guid id, IOrganizationService _service)
        {
            try
            {
                Entity party = new Entity("email", id);
                party["statecode"] = new OptionSetValue(2); //Status
                party["statuscode"] = new OptionSetValue(5); //Status reason
                _service.Update(party);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error trying to update email " + ex.Message);
                throw ex;
            }
        }

        internal static EntityCollection RetrievePendingMessages(IOrganizationService _service)
        {
            try
            {
                QueryExpression qe = new QueryExpression
                {
                    EntityName = "email",
                    ColumnSet = new ColumnSet(true),
                    Criteria = new FilterExpression
                    {
                        FilterOperator = LogicalOperator.Or,
                        Conditions =
                        {
                        new ConditionExpression ("statuscode", ConditionOperator.Equal, 6),
                        new ConditionExpression ("statuscode", ConditionOperator.Equal, 7)
                        }
                    }
                };
                return _service.RetrieveMultiple(qe);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error trying to get email " + ex.Message);
                throw ex;
            }
        }
    }
}
