﻿using Microsoft.Xrm.Sdk;
using EmailMigration.Utility;
using System;

namespace EmailMigration
{
    class Program
    {
        private static IOrganizationService _service = Helper.ConnectToCRM();

        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Successfully connected to CRM.");
                var emailMessages = Helper.RetrievePendingMessages(_service);
                Console.WriteLine("Emails to be migratated: " + emailMessages.Entities.Count);
                if (emailMessages.Entities.Count > 0)
                {
                    foreach (var item in emailMessages.Entities)
                    {
                        Helper.UpdateStatus(item.Id, _service);
                    }
                }
                Console.WriteLine("Job successfully completed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occured in email migration " + ex.Message);
                throw ex;
            }
        }
    }
}
