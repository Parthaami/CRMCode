﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Net;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel;



namespace ServiceRequestVoucher
{
    class Program
    {
        #region declare all the local/Global Variables

        //public static IOrganizationService _service;
        public static OrganizationServiceProxy _service = null;
        public static VoucherLogger bergerlogger = VoucherLogger.Instance;
        public static string _sqlConnectionString = ConfigurationManager.ConnectionStrings["db_connection"].ConnectionString;
        public static string createdby = ConfigurationManager.AppSettings["createdby"].ToString();
        public static string organizationURL = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
        #endregion

        static void Main(string[] args)
        {
            bergerlogger.Log("Voucher Console for MCC SR data ", "Main Start", "---:  Voucher Job Started :---", System.DateTime.Now.ToString());
            try
            {
                ConnectToMSCRM(organizationURL);
                OpenDBConnection(_sqlConnectionString);
                DataTable dt = GetDataTable(_sqlConnectionString);

                string leadId = "";
                string VoucherName = "";
                string SrInfoLead = "";
                DateTime _Expirydate;
                

                //Parallel.ForEach(dt.AsEnumerable(), drow =>
                foreach (DataRow drow in dt.Rows)
                {
                    leadId = drow["MCC_LEAD_ID"].ToString();
                    VoucherName = drow["MCC_Voucher_ID"].ToString();
                    _Expirydate = Convert.ToDateTime(drow["MCC_Voucher_ExpiryDate"]);
                    SrInfoLead = GetVoucherInfonNSRinCRM(leadId, VoucherName, _Expirydate, createdby, _service);

                    if (SrInfoLead == "SUCCESS")
                    {
                        UpdateRecordStatus("P", leadId, VoucherName, "", _sqlConnectionString);
                    }
                    else
                    {
                        UpdateRecordStatus("F", leadId, VoucherName, "Voucher Id Not found", _sqlConnectionString);
                    }
                }
                //);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "Main", "---: Voucher JOB STATUS Error :---", ex.Message.ToString());
            }

            bergerlogger.Log("Voucher Console for MCC SR data", "Main End", "---: Voucher JOB End :---", System.DateTime.Now.ToString());

        }

        #region Opend DB Connection
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlConnectionString"></param>
        /// <returns>SqlConnection</returns>
        static private SqlConnection OpenDBConnection(string sqlConnectionString)
        {
            SqlConnection _sqlConnection = null;
            try
            {
                _sqlConnection = new SqlConnection();
                _sqlConnection.ConnectionString = sqlConnectionString;
                _sqlConnection.Open();

            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "OpenDBConnection", "---: Voucher JOB STATUS Error Open connection:---", ex.Message.ToString());
            }
            return _sqlConnection;
        }
        #endregion

        #region Close DB Connection
        private static void CloseDBConnection(SqlConnection sqlConnection)
        {
            try
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                //string x = ex.ToString();
                bergerlogger.Log("ServiceRequestVoucher", "CloseDBConnection", "---: Voucher JOB STATUS Error Colse connection:---", ex.Message.ToString());
                //throw;
            }
        }
        #endregion

        #region Getting the record as DataTable from the Database
        public static DataTable GetDataTable(string _sqlConnectionString)
        {
            DataTable _datatable = null;
            SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();
            StringBuilder _sqlQuery = new StringBuilder();
            try
            {

                SqlDataAdapter _sqlAdapter = new SqlDataAdapter();
                StringBuilder _sqlQry = new StringBuilder();
                // Framing the Query string for fetching the data from the corresponding entity staging table. 
                _sqlQuery.Append("select * from MCC_Voucher_ServReq where MCC_Voucher_STATUS='R'");
                // Query the database for all of the data in the corresponding entity staging table.
                _sqlDbAdapter = new SqlDataAdapter(_sqlQuery.ToString(), _sqlConnectionString);
                // Create a data set containing the data from the corresponding entity staging table.
                DataSet _dataSet = new DataSet("MCC_Voucher");
                _dataSet.Locale = CultureInfo.InvariantCulture;
                //Fill the DataSet
                _sqlDbAdapter.Fill(_dataSet, "MCC_VoucherID");
                // Return the file data as an ADO.NET DataTable.
                _datatable = _dataSet.Tables[0];
                Console.WriteLine("Total data retrieved" + _datatable.Rows.Count.ToString());
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "GetDataTable", "Error while fatching data from Stagging Table", ex.Message.ToString());
            }
            finally
            {
                _sqlDbAdapter.Dispose();
            }
            return _datatable;
        }
        #endregion

        #region Updateing the RecordStatus
        public static void UpdateRecordStatus(string status, string recordId, string MCC_Voucher_ID, string errorMessage, string _sqlConnectionString)
        {
            SqlConnection _sqlConnection = new SqlConnection();
            try
            {
                string currentDate = DateTime.Now.ToString();
                _sqlConnection = OpenDBConnection(_sqlConnectionString);
                StringBuilder _sqlQuery = new StringBuilder();

                _sqlQuery.Append("update ");
                _sqlQuery.Append("MCC_Voucher_ServReq");
                _sqlQuery.Append(" set MCC_Voucher_STATUS ='");
                _sqlQuery.Append(status);
                _sqlQuery.Append("', ");
                //_sqlQuery.Append("MCC_LEAD_GUID='");
                //_sqlQuery.Append(recordId.Trim());
                //_sqlQuery.Append("',");
                _sqlQuery.Append("MCC_Voucher_ModifiedOn = getdate() ,");
                _sqlQuery.Append("MCC_Voucher_ErrorMsg ='");
                _sqlQuery.Append(errorMessage.Replace("'", ""));
                _sqlQuery.Append("' where MCC_Voucher_ID ='");
                _sqlQuery.Append(MCC_Voucher_ID.Trim());
                _sqlQuery.Append("' AND MCC_LEAD_ID ='");
                _sqlQuery.Append(recordId.Trim());
                _sqlQuery.Append("'");   //adddddd

                SqlCommand _sqlCmd = new SqlCommand(_sqlQuery.ToString(), _sqlConnection);
                int i = _sqlCmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                //throw;
                bergerlogger.Log("ServiceRequestVoucher", "UpdateRecordStatus", "Error while Updating status in Stagging Table", ex.Message.ToString());
            }
            finally
            {
                CloseDBConnection(_sqlConnection);
            }

        }
        #endregion

        #region CRM Connection
        public static void ConnectToMSCRM(/*string UserName, string Password,*/ string SoapOrgServiceUri)
        {
            try
            {
                /*
                ClientCredentials credentials = new ClientCredentials();
                credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
                Uri serviceUri = new Uri(SoapOrgServiceUri);
                Uri homeRealmUri = null;
                OrganizationServiceProxy proxy = new OrganizationServiceProxy(serviceUri, homeRealmUri, credentials, null);
                proxy.EnableProxyTypes();
                _service = (IOrganizationService)proxy;
                */
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                _service = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
                
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "ConnectToMSCRM", "---: Voucher JOB STATUS Error Oranization service :---", ex.Message.ToString());
            }

        }
        #endregion

        #region Organisation

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }


        #endregion

        #region  voucherdetail exits or not
        public static string VoucherExistInCRM( string LeadID, string VoucherName,IOrganizationService orgService)
        {
            string result = String.Empty;
            string VoucherID = String.Empty;
            string resultdepotid = String.Empty;
            string resultownerid = String.Empty;

            try
            {
                //Retrive Data from Lead ID ........
                QueryExpression query = new QueryExpression
                {
                    EntityName = "ber_voucherdetail",
                    ColumnSet = new ColumnSet(new string[]
                {
                    "ber_name",
                    "ber_leadassociated"
                }),
                    Criteria =
                    {
                        Conditions = 
                                {
                                    new ConditionExpression("ber_leadassociated", ConditionOperator.Equal, LeadID),
                                    new ConditionExpression("ber_name",ConditionOperator.Equal, VoucherName)
                                }
                    }
                };

                Entity GettingLeadEntity = orgService.RetrieveMultiple(query).Entities[0];
                if (!string.IsNullOrEmpty(GettingLeadEntity["ber_name"].ToString()))
                {
                    VoucherID = GettingLeadEntity["ber_name"].ToString();
                    //result = VoucherID;
                    result = "SUCCESS";
                }
                else
                {
                    result = "FAIL";
                    // result = string.Empty;
                }
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "GetLeadInfoCRM", "---: Voucher JOB End :---", ex.Message.ToString());
                result = "FAIL";
            }
            finally
            {
            }
            return result;
        }
        #endregion

        #region Insert Voucher Info from CRM Application
        public static string GetVoucherInfonNSRinCRM(string LeadID, string VoucherName,DateTime _Expirydate, string createdby, IOrganizationService orgService)
        {
            string result = string.Empty;
            try
            {
                // Comments the Validation 

                // Checking Validation 
                //if (VoucherExistInCRM(LeadID, VoucherName, orgService) == "SUCCESS")
                //{
                //    return result;
                //}


                //Create Voucher Data in  in CRM .........
                Entity _voucherdetail = new Entity("ber_voucherdetail");

                _voucherdetail.Attributes["ber_name"] = VoucherName;
                _voucherdetail.Attributes["ber_leadassociated"] = new EntityReference("lead", new Guid(LeadID)); //new EntityReference("lead", new Guid(resultleadid));
                _voucherdetail.Attributes["createdon"]          = DateTime.Today;
                _voucherdetail.Attributes["ber_expirydate"] = _Expirydate;

                
                //_incident.Attributes["ber_depot"] = new EntityReference("ber_depot", new Guid(resultdepotid));
                //_incident.Attributes["ownerid"] = new Guid(createdby);
                //_incident.Attributes["ber_iotserialkey"] = srmcckey;//ADDED BY SOUMEN
                //_incident.Attributes["customerid"] = new EntityReference("account", new Guid(CustomerID));

                //_incident.Attributes["pcl_srtypeid"] = new EntityReference("pcl_srtype", new Guid(SrType));
                //_incident.Attributes["pcl_subsrtypeid"] = new EntityReference("pcl_subsrtype", new Guid(subSrtype));
                //_incident.Attributes["pcl_resolutiontype"] = new OptionSetValue(Convert.ToInt32(resolutionType));
                //_incident.Attributes["prioritycode"] = new OptionSetValue(Convert.ToInt32(priority));

                orgService.Create(_voucherdetail);
                result = "SUCCESS";

            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "GetLeadInfoCRM", "---: Voucher JOB End :---", ex.Message.ToString());
                result = "FAIL";
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestVoucher", "GetLeadInfoCRM", "---: Voucher JOB End :---", ex.Message.ToString());
                result = "FAIL";
            }
            finally
            {

            }

            return result;
        }
        #endregion
    } 
}
