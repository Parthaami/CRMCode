﻿using System;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Text;
using Microsoft.Xrm.Sdk.Query;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.ServiceModel;


/**********************
 Created By: Madhumita
 Date: 14th June,2019
 Functionlity: Deactivate all the leads having status reason as dealer allocated/Painter allocated/CE Assign/Quotation Given/New
 having new date older than 90 days  
 * ********************/

namespace AutoLeadLost
{
    class AutoLeadLost
    {


        #region  Declare all global variable/local variable
        public static string _sqlConnectionString = ConfigurationManager.ConnectionStrings["db_connection"].ConnectionString;
        public static IOTLogger bergerlogger = IOTLogger.Instance;
        #endregion


        // Validating Authentication from Activedirectory or else looking for token details

        #region "Oragnization"

        private static AuthenticationCredentials GetCredentials<TService>(IServiceManagement<TService> service, AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            string _userName = ConfigurationManager.AppSettings["UserName"].ToString();
            string _password = ConfigurationManager.AppSettings["Password"].ToString();
            string _domain = ConfigurationManager.AppSettings["domain"].ToString();

            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(_userName,
                            _password,
                            _domain);

                    break;
                default: // For Federated and OnlineFederated environments.                    
                    authCredentials.ClientCredentials.UserName.UserName = _userName;
                    authCredentials.ClientCredentials.UserName.Password = _password;
                    break;
            }

            return authCredentials;
        }

        private static TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService> 
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        #endregion

        static void Main(string[] args)
        {

            bergerlogger.Log("Auto Lost Lead Console ", "Main Start", "---: Job Started :---", System.DateTime.Now.ToString());

            // Pulling configuration details from app config file

            try
            {

                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();

                //string serverurl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                string server = ConfigurationManager.AppSettings["DBServer"].ToString();
                string DatabaseName = ConfigurationManager.AppSettings["CRMOrgDbName"].ToString();
                string UserName = ConfigurationManager.AppSettings["UserName"].ToString();
                string Password = ConfigurationManager.AppSettings["Password"].ToString();
                string Domain = ConfigurationManager.AppSettings["domain"].ToString();
                string CustomertypeXPAorCE = string.Empty;


                OrganizationServiceProxy orgService = null;
                AuthenticationCredentials credentials = new AuthenticationCredentials();
                String orgUrl = ConfigurationManager.AppSettings["APPServerUrl"].ToString();
                AuthenticationProviderType endpointType = AuthenticationProviderType.Federation;
                IServiceManagement<IOrganizationService> orgServiceManagement = ServiceConfigurationFactory.CreateManagement<IOrganizationService>(new Uri(orgUrl));
                credentials = GetCredentials(orgServiceManagement, endpointType);
                orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);

                //Get the lead collection in terms of data table

                DataTable LeadCollectionCE = RetrieveLead(orgService, DatabaseName, server);

                // If record count exist in the table
                if (LeadCollectionCE.Rows.Count > 0)
                {
                    OptionSetValue statecode = null;
                    OptionSetValue statuscode = null;

                    // iterate idividual record and deactivate same
                    foreach (DataRow row in LeadCollectionCE.Rows) // Loop over the rows.
                    {

                        string leadid = row["leadid"].ToString();
                        Guid LeadId = Guid.Parse(leadid);
                        string MobilePhone = row["telephone1"].ToString();


                        DeactivateRecord("lead", LeadId, orgService);
                        statecode = new OptionSetValue(2);
                        statuscode = new OptionSetValue(278290023);

                        // update lead entity w.r.t to the specific context
                        Updatelead(leadid, orgService);
                    }
                }
                bergerlogger.Log("No of lead lost to Non responsice is:", "Main End", "---: JOB End :---", LeadCollectionCE.Rows.Count.ToString());
            }

            catch (Exception ex)
            {

                bergerlogger.Log("ServiceRequestIOT", "GetDataTable", "Error while retrieving lead data ", ex.Message.ToString());
            }

            
            bergerlogger.Log("Auto Lost Lead Console", "Main End", "---: JOB End :---", System.DateTime.Now.ToString());
        }


        // Retrieve all lead details with statuscode as dealer allocated(278290004)/painter allocated(278290009)/ New(1)/Quotation Given(278290026)/CE Assign(278290032)
        public static DataTable RetrieveLead(OrganizationServiceProxy orgService, string DatabaseName, string server)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = new SqlConnection())
                {
                    conn.ConnectionString = _sqlConnectionString;                   
                    conn.Open();
                    try
                    {
                        string queryString = "select ld.fullname,ld.telephone1,ld.leadid,ld.statuscode,ld.statecode, ld.ber_newdate from BPIL_MSCRM.dbo.lead ld where ld.statecode = 0 and ld.ber_leadtype = 278290002 and convert(date,ld.ber_newdate,101) < convert(date, getdate() - 90, 101) and ld.statuscode in (1,278290032,278290004,278290009,278290026)";


                        SqlCommand cmd = new SqlCommand(queryString, conn);

                        SqlDataAdapter sda = new SqlDataAdapter(cmd);

                        sda.Fill(dt);
                    }
                    catch (SqlException er)
                    {

                        Console.WriteLine("There was an error reported by SQL Server, " + er.Message);
                    }

                }
            }
            catch (Exception ex)
            {


                bergerlogger.Log("ServiceRequestIOT", "GetDataTable", "Error while fatching data from Stagging Table", ex.Message.ToString());
                dt = null;
            }

            return dt;

        }

        //Deactivate a record to non responsive status
        public static void DeactivateRecord(string entityName, Guid recordId, IOrganizationService organizationService)
        {
            try
            {
                var cols = new ColumnSet(new[] { "statecode", "statuscode" });

                //Check if it is Active or not
                var entity = organizationService.Retrieve(entityName, recordId, cols);

                if (entity != null && entity.GetAttributeValue<OptionSetValue>("statecode").Value == 0)
                {
                    //StateCode = 1 and StatusCode = 2 for deactivating Account or Contact
                    SetStateRequest setStateRequest = new SetStateRequest()
                    {
                        EntityMoniker = new EntityReference
                        {
                            Id = recordId,
                            LogicalName = entityName,
                        },
                        State = new OptionSetValue(2),
                        Status = new OptionSetValue(278290023)
                    };
                    organizationService.Execute(setStateRequest);
                }
            }

            catch (Exception ex)
            {

                bergerlogger.Log("ServiceRequestIOT", "GetDataTable", "Error while deactivating lead data to auto responsive ", ex.Message.ToString());
            }

        }

    public static void Updatelead(string ID, IOrganizationService service)
        {
            try
            {
                Entity ld = new Entity("lead");

                ld.Attributes["leadid"] = new Guid(ID);

                service.Update(ld);
            }

            catch (Exception ex)
            {

                bergerlogger.Log("ServiceRequestIOT", "GetDataTable", "Error while updating lead data ", ex.Message.ToString());
            }
        }
        

    }
}
