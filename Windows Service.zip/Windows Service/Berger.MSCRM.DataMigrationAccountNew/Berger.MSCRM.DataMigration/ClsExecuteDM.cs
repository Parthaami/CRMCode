﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Oracle.DataAccess.Client;
using System.Globalization;
using Microsoft.Crm.Sdk.Messages;

namespace Berger.MSCRM.DataMigration
{
    public static class  ClsExecuteDM
    {
            #region Static Vairables
            public static System.Data.DataTable UniqueIdentifierTable = null;
            public static DataTable _fields = null;
           // private static ManualResetEvent[] resetEvents;
            public static int loglevel = 0;
            public static string tablename = String.Empty;
            public static int NumberOfThreads = 0;
            //public static PragmasysLogger bergerlogger = null;
            public static PragmasysLogger bergerlogger = PragmasysLogger.Instance;
            public static PragmasysLogger Timerlogger = null;
            #endregion

            #region Global Variables
            private static Object _ThreadLock = new object();
            public static int transactioncounter = 0;
            public static int CountOfThreads = 0;
            #endregion


            public static string DebugMode = ConfigurationManager.AppSettings["DebugMode"].ToString();
            public static string guid = string.Empty;
            public static string DBConnectionString = string.Empty;

            #region FirstMethodOfExecuteDM
            public static void ExecuteDM(string guid)
            {
                try
                {
                string  dtToday = DateTime.Now.ToString("yyyy-MM-dd");
                DBConnectionString = ConfigurationManager.ConnectionStrings["StaggingDBConnectionString"].ConnectionString;
                IOrganizationService _service;

                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["CRMService"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                _service = (IOrganizationService)orgService;

                //To fetch data from stagging table
                #region To fetch data from stagging table to process
                StringBuilder _sqlQuery = new StringBuilder();

                    _sqlQuery.Append("SELECT * FROM ");
                    _sqlQuery.Append(tablename);
                    _sqlQuery.Append(" where Import_Status='");
                    _sqlQuery.Append("R");
                    _sqlQuery.Append("' and crm_request_id = '");
                    _sqlQuery.Append(guid);
                    
                    //Adding the Date filter  
                    //---------------------------------------------------------------------------
                    _sqlQuery.Append("' AND Convert(date,CRMSTG_CREATEDON,101) = '");
                    _sqlQuery.Append(dtToday);
                    _sqlQuery.Append("' and oracle_row_id is not null order by Sequence_NO");
                    //---------------------------------------------------------------------------
                    
                    System.Data.DataTable _data = null;
                    _data = FetchDataFromStagging(_sqlQuery.ToString(), tablename, DBConnectionString);
                    #endregion                  
                    int rowcount = _data.Rows.Count;
                    #region If data present
                    if (rowcount > 0)
                    {
                        //int startindex = Convert.ToInt32(_data.Rows[0].ItemArray[3].ToString());
                        //int Endindex = Convert.ToInt32(_data.Rows[rowcount - 1].ItemArray[3].ToString());

                        SqlDataAdapter _sqlDbAdapter1 = new SqlDataAdapter();
                        StringBuilder _sqlQry1 = new StringBuilder();

                        //This fetches data for Uniqueidentifiers which will decide whether record is present in the CRM
                        #region To fetch data of UniqueIdentifier
                        // Framing the Query string for fetching the data from the corresponding entity staging table. 
                        _sqlQry1.Append("SELECT * FROM ");
                        _sqlQry1.Append("uniqueidentifier");
                        _sqlQry1.Append(" where tblname='");
                        _sqlQry1.Append(tablename);
                        _sqlQry1.Append("'");

                        //UniqueIdentifierTable = DataMigrationObj.FetchDataFromStagging(_sqlQry1.ToString(), "UniqueIdentifier", DBConnectionString);
                        UniqueIdentifierTable = FetchDataFromStagging(_sqlQry1.ToString(), "UniqueIdentifier", DBConnectionString);
                        #endregion

                        #region To fetch Fields data
                        StringBuilder _sqlQueryBuilderFields = new StringBuilder();

                        _sqlQueryBuilderFields.Append("SELECT * FROM fields where stgtblname='");
                        _sqlQueryBuilderFields.Append(tablename);
                        _sqlQueryBuilderFields.Append("'");

                        //_fields = DataMigrationObj.FetchDataFromStagging(_sqlQueryBuilderFields.ToString(), tablename, DBConnectionString);
                        _fields = FetchDataFromStagging(_sqlQueryBuilderFields.ToString(), tablename, DBConnectionString);
                        #endregion
                        Migrate(_data, UniqueIdentifierTable, DBConnectionString, _fields);

                    }
                    else
                    {
                    }
                    #endregion
                }
                catch (Exception ex)
                {

                    bergerlogger.Log("MSCRM.BERGER Data Migration1", "Migrate", "Exception occured while fetching data from staging table", ex.Message);
                    
                }

            }

        private static TProxy GetProxy<TService, TProxy>(
           IServiceManagement<TService> serviceManagement,
           AuthenticationCredentials authCredentials)
           where TService : class
           where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion


        /// <summary>
        /// Primary method which creates entities and CREATES/UPDATES it in the CRM
        /// </summary>
        /// <param name="_dataTable"></param>
        /// <param name="UniqueIdentifierTable"></param>
        /// <param name="DBConnectionString"></param>
        /// <param name="_fieldsTable"></param>
        public static void Migrate(System.Data.DataTable _dataTable, System.Data.DataTable UniqueIdentifierTable, string DBConnectionString, DataTable _fieldsTable)
            {
                try
                {
                    IOrganizationService service;
                    IServiceManagement<IOrganizationService> orgServiceManagement =
                    ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                    new Uri(ConfigurationManager.AppSettings["CRMService"].ToString()));

                    AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                    authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                    authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                    OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                    orgService.EnableProxyTypes();

                    service = (IOrganizationService)orgService;

                    StringBuilder OracleUpdateQry = new StringBuilder();
                    int nowofRowsOracleUpdate = 0;
                    Guid responce = Guid.Empty;
                    CRMDataType CRMDataTypeValue = new CRMDataType();
                    uniqueidentifier ui = new uniqueidentifier();
                    StringBuilder updatestringbuilder = new StringBuilder();
                    SqlCommand updcmd = new SqlCommand();
                    EntityCollection depotcollection = new EntityCollection();
                    
                    string oracleupdatecommand = string.Empty;
                    
                    object EntityTypeObject = new object();

                    //This traverses every row so as to create Entity type objedct to CREATE/UPDATE in CRM
                    foreach (DataRow dr in _dataTable.Rows)
                    {
                        #region Traversing every recieved row
                        try
                        {
                            Entity et = new Entity();
                            if (tablename.ToLower() == "account" || tablename.ToLower() == "site")
                            {
                                et.LogicalName = "account";
                            }
                            else
                            {
                                et.LogicalName = tablename.ToLower();
                            }

                            //This block creates the list of columns that will include list of columns
                            //which should be excluded while creating an entity type object which would be used to CREATE/UPDATE
                            #region Adding name of columns to be excluded
                            List<string> ExcludedColumns = new List<string>();

                            ExcludedColumns.Add("Import_Status");
                            ExcludedColumns.Add("Error_Details");
                            ExcludedColumns.Add("Transaction_Type");
                            ExcludedColumns.Add("Sequence_No");
                            ExcludedColumns.Add("CreatedOn");
                            ExcludedColumns.Add("CreatedBy");
                            ExcludedColumns.Add("ModifiedOn");
                            ExcludedColumns.Add("ModifiedBy");
                            ExcludedColumns.Add("Job_id");
                            ExcludedColumns.Add("ber_shadeidname");
                            ExcludedColumns.Add("crm_request_id");
                            ExcludedColumns.Add("error_msg");
                            ExcludedColumns.Add("salesorderid");
                            ExcludedColumns.Add("ORACLE_ROW_ID");
                            ExcludedColumns.Add("oracle_row_id");
                            ExcludedColumns.Add("CRMSTG_CREATEDON");  // Removing Columns from Stagging .......
                            #endregion

                            //This will create an object of entity type which would be used to create/Update into CRM
                            #region Creation of Entity
                            foreach (DataColumn dc in _dataTable.Columns)
                            {
                                if (!ExcludedColumns.Contains(dc.ColumnName))
                                {
                                    EntityTypeObject = CRMDataTypeValue.getlookupvalue(dr[dc.ColumnName].ToString(), dc.ColumnName, DBConnectionString, tablename, _fieldsTable, service);
                                    if (EntityTypeObject != null && EntityTypeObject.ToString() != "NULL")
                                    {
                                        et.Attributes.Add(new KeyValuePair<string, object>(dc.ColumnName, EntityTypeObject));
                                    }
                                    else if (EntityTypeObject != "NULL")
                                    {
                                        //logger : unable to create attribute
                                        //if (loglevel >= 1)
                                        
                                        bergerlogger.Log("MSCRM.BERGER Data Migration1", "Migrate", "Exception occured while fetching data from staging table", dc.ColumnName);
                                        et = new Entity();
                                        et.LogicalName = "Value: " + dr[dc.ColumnName].ToString() + " not resolved for field: " + dc.ColumnName;
                                        break;
                                    }
                                }
                            }
                            #endregion
                            if (et.Attributes.Count > 0)
                            {
                                //If table is not salesorder then for others Record is checked whether is it present in the crm
                                //then accordingly CREATE/UPDATE is fired
                                #region If table is not salesorder
                                if (tablename != "salesorder")
                                {
                                    int statusreason = 0;
                                    string errorresponce = string.Empty;
                                    int counter = 0;
                                    QueryExpression checkquery = new QueryExpression();
                                    checkquery.EntityName = et.LogicalName;
                                    checkquery.ColumnSet.AllColumns = true;

                                    FilterExpression Filterexp = new FilterExpression();
                                    Filterexp.FilterOperator = LogicalOperator.And;

                                    //Filter Condition for parentaccountid is null then primary :Primary
                                    FilterExpression Filterexp1 = new FilterExpression();
                                    Filterexp1.FilterOperator = LogicalOperator.And;
                                    ConditionExpression conditionExp1 = null;

                                    //Filter Condition for  is null : Site
                                    //FilterExpression Filterexp2 = new FilterExpression();
                                    //Filterexp2.FilterOperator = LogicalOperator.And;
                                    //ConditionExpression conditionExp2 = null;


                                    #region "Checking Filterization" 
                                    object uniqueidentifierobj = new object();
                                    EntityCollection ecd = new EntityCollection();
                                    if (UniqueIdentifierTable.Rows.Count > 0)
                                    {
                                        foreach (DataRow row in UniqueIdentifierTable.Rows)
                                        {
                                            counter++;
                                            uniqueidentifierobj = et.Attributes[row.ItemArray[0].ToString()];
                                            ConditionExpression conditionEXP = new ConditionExpression();
                                            conditionEXP.AttributeName = row.ItemArray[0].ToString();
                                            conditionEXP.Operator = ConditionOperator.Equal;
                                            conditionEXP.Values.Add(ui.uniqueidentifiercall(uniqueidentifierobj.GetType().Name, (et.Attributes[row.ItemArray[0].ToString()])));
                                            
                                            //  parentaccountid is null then Primary Account
                                            if (UniqueIdentifierTable.Rows.Count == 1)
                                            {
                                                conditionExp1 = new ConditionExpression();
                                                conditionExp1.AttributeName = "parentaccountid";
                                                conditionExp1.Operator = ConditionOperator.Null;
                                                //conditionExp1.Values.Add(null);
                                            }
                                            
                                            Filterexp.Conditions.Add(conditionEXP);
                                            //  parentaccountid is null then Primary Account
                                            if (UniqueIdentifierTable.Rows.Count == 1)
                                            {
                                                Filterexp1.Conditions.Add(conditionExp1);
                                            }
                                        }
                                        checkquery.Criteria.AddFilter(Filterexp);
                                        //  parentaccountid is null then Primary Account
                                        if (UniqueIdentifierTable.Rows.Count == 1)
                                        {
                                            checkquery.Criteria.AddFilter(Filterexp1);
                                        }

                                        ecd = service.RetrieveMultiple(checkquery);
                                    }
                                    
                                    #endregion

                                    if (ecd.Entities.Count > 0)
                                    {
                                        try
                                        {
                                            et.Id = ecd.Entities[0].Id;
                                            service.Update(et);
                                            responce = ecd.Entities[0].Id;
                                            if (et.Attributes.Contains("statecode"))
                                            {
                                                if (((OptionSetValue)et.Attributes["statecode"]).Value.ToString() == "0")
                                                {
                                                    statusreason = Convert.ToInt32(ConfigurationManager.AppSettings["Activestatusreason"].ToString());
                                                }
                                                else
                                                {
                                                    statusreason = Convert.ToInt32(ConfigurationManager.AppSettings["Inactivestatusreason"].ToString());
                                                }
                                                errorresponce = setStatus(service, et, et.Id, statusreason);
                                                if (errorresponce != "1")
                                                {
                                                    et.LogicalName = errorresponce;
                                                    responce = Guid.Empty; //This is to fail record in the ms crm
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            if (loglevel >= 1)
                                                bergerlogger.Log("MSCRM.BERGER Data Migration1.1", "Migrate", "Exception occured while Updating Record in CRM", "Unable to Update record:  " + ex.Message);
                                        }
                                    }
                                    else
                                    {
                                        try
                                        {
                                            responce = service.Create(et);
                                            if (et.Attributes.Contains("statecode"))
                                            {
                                                if (((OptionSetValue)et.Attributes["statecode"]).Value.ToString() == "0")
                                                {
                                                    statusreason = Convert.ToInt32(ConfigurationManager.AppSettings["Activestatusreason"].ToString());
                                                }
                                                else
                                                {
                                                    statusreason = Convert.ToInt32(ConfigurationManager.AppSettings["Inactivestatusreason"].ToString());
                                                }
                                                errorresponce = setStatus(service, et, responce, statusreason);
                                                if (errorresponce != "1")
                                                {
                                                    et.LogicalName = errorresponce;
                                                    responce = Guid.Empty; //This is to fail record in the ms crm
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            if (loglevel >= 1)
                                                bergerlogger.Log("MSCRM.BERGER Data Migration1.2", "Migrate", "Exception occured while Creating Record in CRM", "Unable to create record:  " + ex.Message);
                                        }
                                    }
                                }
                                #endregion

                                //If Record Created/Updated successfully then Stagging table is update with Import_Status = 'P'
                                //and corresponding Oracle Interface is also updated
                                #region If record Updated/Created Sucessfully
                                if (responce != Guid.Empty && tablename.ToLower() != "salesorder")
                                {
                                    updatestringbuilder = new StringBuilder();
                                    updatestringbuilder.Append("Update ");
                                    updatestringbuilder.Append(tablename);
                                    updatestringbuilder.Append(" SET Import_Status = 'P'");
                                    updatestringbuilder.Append(" where Sequence_No = '");
                                    updatestringbuilder.Append(dr["Sequence_No"].ToString());
                                    updatestringbuilder.Append("'");

                                    SqlUpdate(updatestringbuilder.ToString(), DBConnectionString);

                                    if (tablename.ToLower() == "account" || tablename.ToLower() == "site")
                                    {
                                        OracleUpdateQry = new StringBuilder();
                                        OracleUpdateQry.Append("Update XXCRM_ACCOUNTS_INTERFACE SET STATUS = 'COMPLETED' where rowid='");
                                        OracleUpdateQry.Append(dr["oracle_row_id"].ToString());
                                        OracleUpdateQry.Append("'");
                                    }
                                    if (tablename.ToLower() != "salesorder")
                                    {
                                        nowofRowsOracleUpdate = OracleUpdate(OracleUpdateQry.ToString());
                                        OracleUpdateQry = new StringBuilder();
                                    }

                                }
                                #endregion

                                //If Record Creation/Updation fails then Stagging table is update with Import_Status = 'F'
                                //and corresponding Oracle Interface is also updated
                                #region If Exception during Update/Create of a record
                                else if (tablename.ToLower() != "salesorder")
                                {
                                    updatestringbuilder = new StringBuilder();
                                    updatestringbuilder.Append("Update ");
                                    updatestringbuilder.Append(tablename);
                                    updatestringbuilder.Append(" SET Import_Status = 'F' , error_msg = '");
                                    updatestringbuilder.Append(et.LogicalName);
                                    updatestringbuilder.Append("' where Sequence_No = '");
                                    updatestringbuilder.Append(dr["Sequence_No"].ToString());
                                    updatestringbuilder.Append("'");

                                    SqlUpdate(updatestringbuilder.ToString(), DBConnectionString);

                                    if (tablename.ToLower() == "account" || tablename.ToLower() == "site")
                                    {
                                        OracleUpdateQry = new StringBuilder();
                                        OracleUpdateQry.Append("Update XXCRM_ACCOUNTS_INTERFACE SET STATUS = 'ERROR' , REMARKS = 'Field not resolved " + et.LogicalName + "' where  rowid='");
                                        OracleUpdateQry.Append(dr["oracle_row_id"].ToString());
                                        OracleUpdateQry.Append("'");
                                    }
                                    if (tablename.ToLower() != "salesorder")
                                    {
                                        nowofRowsOracleUpdate = OracleUpdate(OracleUpdateQry.ToString());
                                        OracleUpdateQry = new StringBuilder();
                                    }
                                }
                                #endregion
                            }
                            else
                            {
                                //If Record Creation/Updation fails then Stagging table is update with Import_Status = 'F'
                                //and corresponding Oracle Interface is also updated
                                #region If error occured while creating any entity record from staging table
                                updatestringbuilder = new StringBuilder();
                                updatestringbuilder.Append("Update ");
                                updatestringbuilder.Append(tablename);
                                updatestringbuilder.Append(" SET Import_Status = 'F' , error_msg ='");
                                updatestringbuilder.Append(et.LogicalName);
                                updatestringbuilder.Append("'");
                                updatestringbuilder.Append(" where Sequence_No = '");
                                updatestringbuilder.Append(dr["Sequence_No"].ToString());
                                updatestringbuilder.Append("'");

                                SqlUpdate(updatestringbuilder.ToString(), DBConnectionString);

                                if (tablename.ToLower() == "account" || tablename.ToLower() == "site")
                                {
                                    OracleUpdateQry = new StringBuilder();
                                    OracleUpdateQry.Append("Update XXCRM_ACCOUNTS_INTERFACE SET STATUS = 'ERROR' , REMARKS = 'Field not resolved " + et.LogicalName + "' where rowid='");
                                    OracleUpdateQry.Append(dr["oracle_row_id"].ToString());
                                    OracleUpdateQry.Append("'");
                                }

                                nowofRowsOracleUpdate = OracleUpdate(OracleUpdateQry.ToString());
                                OracleUpdateQry = new StringBuilder();

                                bergerlogger.Log("MSCRM.BERGER Data Migration2", "Migrate", "Lookup not resolved Column: ", et.LogicalName);

                                #endregion
                            }
                        }
                        catch (Exception ex)
                        {
                            bergerlogger.Log("MSCRM.BERGER Data Migration3", "Migrate", "Lookup not resolved Column: ", ex.Message);
                        }
                        #endregion
                    }
                }

                catch (Exception e)
                {
                    bergerlogger.Log("MSCRM.BERGER Data Migration4", "Migrate", "Exception occured while fetching data from staging table", e.Message.ToString());
                }

            }

            /// <summary>
            /// Method used for executing oracle interface table
            /// </summary>
            /// <param name="UpdateQry"></param>
            /// <returns></returns>
            public static int OracleUpdate(string UpdateQry)
            {
                try
                {
                    //string oracleconnectionstring = ""; //ConfigurationManager.AppSettings["OracleDBConnectionxx"].ToString();            // Wrong   Connection String .......
                   
                     string oracleconnectionstring =  ConfigurationManager.ConnectionStrings["OracleDBConnection"].ConnectionString;   // Right Connection String .......
                    
                    //lock (_ThreadLock)
                    //{
                        using (OracleConnection OracleConnection = new OracleConnection(oracleconnectionstring))
                        {
                            OracleConnection.Open();

                            OracleCommand OracleUpdateCommand = OracleConnection.CreateCommand();
                            OracleTransaction OracleTransaction;

                            using (OracleTransaction = OracleConnection.BeginTransaction())
                            {
                                int nowofRowsOracleUpdate = 0;

                                OracleUpdateCommand.CommandType = CommandType.Text;
                                OracleUpdateCommand.Connection = OracleConnection;
                                //OracleUpdateCommand.Transaction = OracleTransaction;                        

                                try
                                {
                                    OracleUpdateCommand.CommandText = UpdateQry;
                                    nowofRowsOracleUpdate = OracleUpdateCommand.ExecuteNonQuery();

                                    OracleTransaction.Commit();

                                   // if (loglevel >= 3)
                                        bergerlogger.Log("MSCRM.BERGER Data Migration", "OracleCommand", "Oracle Interface Update Query: ", UpdateQry);

                                    return nowofRowsOracleUpdate;
                                }
                                catch (Exception ex)
                                {
                                    bergerlogger.Log("MSCRM.BERGER Data Migration3", "OracleCommand", "Exception while Updating Oracle Interface", ex.Message.ToString());
                                    return 0;
                                }
                            }
                        }
                    //}
                }
                catch (Exception ex)
                {
                    bergerlogger.Log("MSCRM.BERGER Data Migration", "OracleCommand", "Not Updated Oracle RowID ", ex.Message);
                }
                return 0;
            }

            /// <summary>
            /// Method used for executing Queries on the staging table
            /// </summary>
            /// <param name="qry"></param>
            /// <param name="DBConnectionString"></param>
            public static void SqlUpdate(string qry, string DBConnectionString)
            {
                //lock (_ThreadLock)
                //{
                    
                    using (SqlConnection connection = new SqlConnection(DBConnectionString))
                    {
                        transactioncounter++;

                        connection.Open();
                        SqlCommand command = connection.CreateCommand();
                        SqlTransaction transaction;

                        using (transaction = connection.BeginTransaction(transactioncounter.ToString()))
                        {
                            command.Connection = connection;
                            command.Transaction = transaction;

                            try
                            {
                                command.CommandText = qry;
                                command.ExecuteNonQuery();

                                transaction.Commit();

                                //if (loglevel >= 3)
                                  //  bergerlogger.Log("MSCRM.BERGER Data Migration", "SqlUpdate", "Stagging Table Update Query: ", qry);

                            }
                            catch (Exception ex)
                            {

                                bergerlogger.Log("MSCRM.BERGER Data Migration", "SqlUpdate", "Exception while Updating Stagging DB", ex.Message.ToString());
                            }
                        }
                    }
                //}
            }

            
            /// <summary>
            /// Method used for fetching data from stagging table
            /// </summary>
            /// <param name="_sqlQuery"></param>
            /// <param name="tablename"></param>
            /// <param name="DBConnectionString"></param>
            /// <returns></returns>
            public static DataTable FetchDataFromStagging(string _sqlQuery, string tablename, string DBConnectionString)
            {

                int _CommandTimeOut = Convert.ToInt32(ConfigurationManager.AppSettings["CommandTimeOut"].ToString()); // Code is added For Timeout Issues on 04-April-2018
                                                                                                                  // by Partha
                SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();
                DataSet _dataSet = new DataSet(tablename);
                try
                {
                    _sqlDbAdapter = new SqlDataAdapter(_sqlQuery, DBConnectionString);
                    _sqlDbAdapter.SelectCommand.CommandTimeout = _CommandTimeOut;                                    // Code is added For Timeout Issues on 04-April-2018
                                                                                                                 // by Partha
                    _dataSet.Locale = CultureInfo.InvariantCulture;
                    _sqlDbAdapter.Fill(_dataSet, tablename);
                }
                catch (Exception ex)
                {
                    bergerlogger.Log("MSCRM.BERGER Data Migration", "FetchDataFromStagging", "Error while fetching data", ex.Message);
                }

                if (loglevel >= 3)
                {
                    if (_dataSet.Tables.Count > 0)
                    {
                        bergerlogger.Log("MSCRM.BERGER Data Migration", "FetchDataFromStagging", "Count of rows for Table: " + tablename + ":: ", _dataSet.Tables[0].Rows.Count.ToString());
                    }
                    else
                    {
                        bergerlogger.Log("MSCRM.BERGER Data Migration", "FetchDataFromStagging", "Count of Tables:", _dataSet.Tables.Count.ToString());
                    }
                    bergerlogger.Log("MSCRM.BERGER Data Migration", "FetchDataFromStagging", "Stagging Select Query: :", _sqlQuery);
                }
                return _dataSet.Tables[0];
            }

            
            /// <summary>
            /// Set Status
            /// </summary>
            /// <param name="service"></param>
            /// <param name="Record"></param>
            /// <param name="Id"></param>
            /// <param name="statusreason"></param>
            /// <returns></returns>
            public static string setStatus(IOrganizationService service, Entity Record, Guid Id, int statusreason)
            {
                try
                {
                    SetStateRequest StatusRequest = new SetStateRequest();

                    //the entity you want to change the state of
                    StatusRequest.EntityMoniker = new EntityReference(Record.LogicalName, Id);

                    //what should the new state be
                    StatusRequest.State = (OptionSetValue)Record.Attributes["statecode"];

                    if (Record.Attributes.Contains("statuscode"))
                    {
                        //Pick an option from the status reason picklist to specify reason for state change
                        StatusRequest.Status = (OptionSetValue)Record.Attributes["statuscode"];
                    }
                    else
                    {
                        StatusRequest.Status = new OptionSetValue(statusreason);
                    }

                    SetStateResponse resp = (SetStateResponse)service.Execute(StatusRequest);

                    return "1";
                }
                catch (Exception ex)
                {
                    bergerlogger.Log("MSCRM.BERGER Data Migration", "setStatus", ex.Message, ex.StackTrace);
                    return ex.Message;
                }
            }

    }
}
