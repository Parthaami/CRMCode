﻿using Microsoft.Xrm.Sdk;

namespace Berger.MSCRM.DataMigration
{
    class uniqueidentifier
    {
        //Used to to return entityreference in case of lookup
        public object uniqueidentifiercall(string type,object attribute)
        {
            switch (type)
            {
                case "EntityReference":
                    return ((EntityReference)attribute).Id;                    
            }

            return attribute;
        }
    }
}
