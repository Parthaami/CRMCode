﻿using System;
using System.Configuration;



namespace Berger.MSCRM.DataMigration
{

    class DataMigration
    {
       // public static PragmasysLogger bergerlogger = null;
        static void Main(string[] args)
        {
          
            PragmasysLogger bergerloggerM = PragmasysLogger.Instance;         
            string DebugMode      = ConfigurationManager.AppSettings["DebugMode"].ToString();
            string Filepath       = ConfigurationManager.AppSettings["SaveCSVTo"].ToString();
            string IsReadFromCSV = ConfigurationManager.AppSettings["IsReadFromCSV"].ToString();
            string guid = string.Empty;
            string DBConnectionString = string.Empty;
           
            bergerloggerM.Log("MSCRM.BERGER Data Migration", "Main Start", "---: DataMigration JOB Started :---", System.DateTime.Now.ToString());
            Guid CRM_REQUEST_ID = Guid.NewGuid();
            //Guid CRM_REQUEST_ID = new Guid("6772cdc0-2dc7-4728-a9f3-1363f2953bf3");

            string tablename      = "account";
            if (IsReadFromCSV.ToUpper() == "YES")
            {
                //Tested ................
                DMWrapper.CreateCSVFile("MASTER_DATAxxssss.csv");
                //Tested ................
                CSVToTable.CSV2Table(Filepath);
            }
            else
            {
                // Oracle To CRM direct Table to Table  
                CSVToTable.Oracle2CRMStagging();
            }

            //Inserting data in MS CRM
            DMWrapper.accountsitetblInsert(CRM_REQUEST_ID, tablename);  // its calling ExecuteDM thats is main  

            bergerloggerM.Log("MSCRM.BERGER Data Migration", "Main End", "---: DataMigration JOB Ended :---", System.DateTime.Now.ToString());
        }
    }
}