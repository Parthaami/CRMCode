﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data.SqlClient;
using System.Threading;
using System.Configuration;

namespace Berger.MSCRM.DataMigration
{
    public class PragmasysLogger
    {
        private static PragmasysLogger _instance = new PragmasysLogger();
        private static string filecreatedDatetime = String.Empty;
        static string _filePath = ConfigurationManager.AppSettings["loggerpath"] + "Log_DataMigration_" + "Berger" + DateTime.Now.ToString("yyyyMMdd") + ".txt";
        private static Object _Lock = new object();

        private PragmasysLogger()
        {

        }

        public void Log(string SourceName, string MethodName, string description, string ErrorMessage)
        {
            try
            {
                //lock (_Lock)
                //{

                string fullpath = Path.GetFullPath(_filePath);
                string directory = Path.GetDirectoryName(fullpath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }
                string[] ErrorLogs = { SourceName, MethodName, description, ErrorMessage };

                if (!File.Exists(_filePath))
                {
                    FileStream aFile = null;
                    if (String.IsNullOrEmpty(filecreatedDatetime))
                    {
                        aFile = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                    }
                    else if (!String.IsNullOrEmpty(filecreatedDatetime) && filecreatedDatetime != DateTime.Now.ToString("yyyyMMdd"))
                    {
                        aFile = new FileStream(_filePath, FileMode.Create, FileAccess.Write);
                    }
                    else
                    {
                        aFile = new FileStream(_filePath, FileMode.Append, FileAccess.Write);
                    }
                    aFile.Close();

                    FileInfo fileinfo = new FileInfo(_filePath);
                    filecreatedDatetime = fileinfo.CreationTime.ToString("yyyyMMdd");

                    StreamWriter file = new StreamWriter(_filePath);
                    file.WriteLine("--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.WriteLine(" S.No.       CreatedOn                  Source Name                         Method Name                         Description                         Error Message");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Write("*.");
                    file.Write("\t");
                    file.Write(System.DateTime.Now);
                    file.Write("\t\t");
                    foreach (string log in ErrorLogs)
                    {
                        file.Write(log);
                        file.Write("\t\t");
                    }
                    file.WriteLine("");
                    file.WriteLine("---------------------------------------------------------------------------------------------------------------------------------------------------------------");
                    file.Close();
                }
                else
                {

                    File.AppendAllText(_filePath, System.Environment.NewLine);
                    File.AppendAllText(_filePath, "*.");
                    File.AppendAllText(_filePath, "\t");
                    File.AppendAllText(_filePath, System.DateTime.Now.ToString());
                    File.AppendAllText(_filePath, "\t\t");
                    foreach (string log in ErrorLogs)
                    {
                        File.AppendAllText(_filePath, log);
                        File.AppendAllText(_filePath, "\t\t");
                    }
                    File.AppendAllText(_filePath, System.Environment.NewLine);
                    File.AppendAllText(_filePath, "--------------------------------------------------------------------------------------------------------------------------------------------------------------");
                }
                //}

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static PragmasysLogger Instance
        {
            get
            {
                return _instance;
            }
        }
    }


}
