﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;
using Oracle.DataAccess.Client;
using System.IO;
using System.Net;
using System.Data.SqlClient;

namespace Berger.MSCRM.DataMigration
{
   public static class DMWrapper
    {
       
        #region Call level Variables
        public static string SQLProvider = ConfigurationManager.ConnectionStrings["StaggingDBConnectionString"].ConnectionString;
        public static string ORAProvider = ConfigurationManager.ConnectionStrings["OracleDBConnection"].ConnectionString;

        public static string OrganisationName = ConfigurationManager.AppSettings["OrgName"];
        public static string LoggerFilePath = ConfigurationManager.AppSettings["LoggerPath"];

        public static string IsConfigId = ConfigurationManager.AppSettings["IDFromConfig"];
        public static string PId = ConfigurationManager.AppSettings["ProcessId"];
        public static string TimeOut = ConfigurationManager.AppSettings["TimeOut"];
        public static int    loglevel = Convert.ToInt32(ConfigurationManager.AppSettings["loglevel"].ToString());

        //public static Logger oLogger;
        //public static PragmasysLogger oLogger = null;
        public static PragmasysLogger oLogger = PragmasysLogger.Instance;
        public static Guid ProcessId;
        public static int RecordsUpdated = 0;
        public static DataSet DSCreatedRecordInDM = new DataSet();
        #endregion

        #region Create CSV File
        public static void CreateCSVFile(string inputstring)
        {
            if (inputstring.EndsWith(".csv") || inputstring.EndsWith(".CSV"))
            {
                OracleConnection connection = new OracleConnection(ORAProvider);
                connection.Open();
                OracleCommand command = new OracleCommand();
                command.Connection = connection;
                try
                {
                    command.CommandText = "dump_table_to_csv";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new OracleParameter("p_tname", "xxcrm_accounts_interface"));
                    command.Parameters.Add(new OracleParameter("p_dir", ConfigurationManager.AppSettings["CSVPath"]));
                    command.Parameters.Add(new OracleParameter("p_filename", inputstring));

                    command.ExecuteNonQuery();

                    //if (loglevel >= 1)
                    //    oLogger.Log("WrapperExecutorforDMUtility", "Main", "File Successfuly Created.", inputstring);

                    //Call FTP function to get File from ERP server to local server.
                    Download(ConfigurationManager.AppSettings["SaveCSVTo"], inputstring);
                }
                catch (Exception ex)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "Main", "Unable to create CSV file", "Error:" + ex.Message);
                }
                finally
                {
                    command.Dispose();
                    connection.Dispose();
                }
            }
        }
        #endregion

        #region Function to Download File from ERP server
        public static void Download(string filePath, string fileName)
        {
            FtpWebRequest reqFTP;
            try
            {
                //filePath = <<The full path where the 
                //file is to be created. the>>, 
                //fileName = <<Name of the file to be createdNeed not 
                //name on FTP server. name name()>>



                FileStream outputStream = new FileStream(filePath + "\\" + fileName, FileMode.Create);
                reqFTP = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + ConfigurationManager.AppSettings["FTPServerIP"] + "/" + fileName));
                reqFTP.Method = WebRequestMethods.Ftp.DownloadFile;
                reqFTP.UseBinary = true;
                reqFTP.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["FTPUserName"], ConfigurationManager.AppSettings["FTPPassword"]);

                //if (ConfigurationManager.AppSettings["ProxyRequired"].ToLower().ToString() == "yes")
                //{
                //    reqFTP.Proxy = new WebProxy(ConfigurationManager.AppSettings["ProxyServer"], Convert.ToInt32(ConfigurationManager.AppSettings["ProxyPort"]));
                //    if (ConfigurationManager.AppSettings["ProxyDomain"] != null && ConfigurationManager.AppSettings["ProxyDomain"] != "" && ConfigurationManager.AppSettings["ProxyDomain"] != "null")
                //        reqFTP.Proxy.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["ProxyUserName"], ConfigurationManager.AppSettings["ProxyPassword"], ConfigurationManager.AppSettings["ProxyDomain"]);
                //    else
                //        reqFTP.Proxy.Credentials = new NetworkCredential(ConfigurationManager.AppSettings["ProxyUserName"], ConfigurationManager.AppSettings["ProxyPassword"]);
                //}


                FtpWebResponse response = (FtpWebResponse)reqFTP.GetResponse();
                Stream ftpStream = response.GetResponseStream();
                long cl = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[bufferSize];

                readCount = ftpStream.Read(buffer, 0, bufferSize);
                while (readCount > 0)
                {
                    outputStream.Write(buffer, 0, readCount);
                    readCount = ftpStream.Read(buffer, 0, bufferSize);
                }
                 
                ftpStream.Close();
                outputStream.Close();
                response.Close();
            }
            catch (Exception ex)
            {
                oLogger.Log("WeapperExecutorfroDMUtility", "Download", "ERROR DOWNLOADING FILE", ex.Message.ToString());
            }

            //catch (WebException e)
            //{
            //    String status = ((FtpWebResponse)e.Response).StatusDescription;
            //}
        }
        #endregion      

        #region Code for xxcrm_accounts_interface table for account/site tbl in DM
        public static void accountsitetblInsert(Guid ProcessId,string inputstring)
        {
            try
            {
                if (ProcessId != Guid.Empty && inputstring == "account")
                {
                    //if (loglevel >= 1)
                        oLogger.Log("WrapperExecutorforDMUtility", "Processing Table :", "ACCOUNT", "START");

                    string accountQry = "update xxcrm_accounts_interface SET STATUS = 'COMPLETED',CRM_REQUEST_ID =  '" + ProcessId + "' " +
                                        "where STATUS = 'NEW' AND Isnull(CRM_REQUEST_ID,'') = '' ";

                    RecordsUpdated = SetProcessId(accountQry);
                    if (RecordsUpdated > 0)
                    {
                        DSCreatedRecordInDM.Clear();
                        //Call Function to Retrive Data from oracle replica table for inserting in DM Database
                        DSCreatedRecordInDM = GetRecordsFromReplicaTable(ProcessId, "xxcrm_accounts_interface", false);
                        //Call Function to Create record in Data Migration DB
                        if (DSCreatedRecordInDM.Tables.Count > 0)
                        {
                            CreateRecordInDMForAccount(DSCreatedRecordInDM, "account");
                            //Code Is Added.......
                            //ExecuteDM(ProcessId.ToString(), "account");
                            ClsExecuteDM.tablename = "account";
                            ClsExecuteDM.ExecuteDM(ProcessId.ToString());
                            
                            //if (loglevel >= 2)
                              oLogger.Log("WrapperExecutorforDMUtility", "Processing Table :", "ACCOUNT", "END");


                            //if (loglevel >= 2)
                              oLogger.Log("WrapperExecutorforDMUtility", "Processing Table :", "SITE", "START");

                            string SiteQry = "update xxcrm_accounts_interface SET STATUS = 'WIP' where STATUS = 'COMPLETED' " +
                                "AND SUBSTRING(ORDER_TYPE,5,DATALENGTH(ORDER_TYPE)) IN ('MRP_ORDER','ORDER') AND CRM_REQUEST_ID =  '" + ProcessId + "'";

                            RecordsUpdated = SetProcessId(SiteQry);

                            DSCreatedRecordInDM.Clear();
                            //Call Function to Retrive Data from oracle replica table for inserting in DM Database
                            DSCreatedRecordInDM = GetRecordsFromReplicaTable(ProcessId, "xxcrm_accounts_interface", true);
                            //Call Function to Create record in Data Migration DB
                            if (DSCreatedRecordInDM.Tables.Count > 0)
                            {
                                CreateRecordInDMForSite(DSCreatedRecordInDM, "site");
                                //Code Is Added.......
                                //ExecuteDM(ProcessId.ToString(), "site");
                                ClsExecuteDM.tablename = "site";
                                ClsExecuteDM.ExecuteDM(ProcessId.ToString());

                                string CompleteSiteQry = "update xxcrm_accounts_interface SET STATUS = 'COMPLETED' where STATUS = 'WIP' " +
                                "AND SUBSTRING(ORDER_TYPE,5,DATALENGTH(ORDER_TYPE)) IN ('MRP_ORDER','ORDER') AND CRM_REQUEST_ID =  '" + ProcessId + "'";
                                
                                SetProcessId(CompleteSiteQry);
                            }
                            //if (loglevel >= 2)
                              oLogger.Log("WrapperExecutorforDMUtility", "Processing Table :", "SITE", "END");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "Main", "Error while Processing Account staging tbl", ex.Message.ToString());
            }
           
        }
        #endregion

        #region Function to set Process Id in Oracle Replica Table
        public static int SetProcessId(string query)
        {
            int nowofRecordsUpdated = 0;
            //if (loglevel >= 3)
            //    oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Update Query: ", query);

            SqlConnection connection = new SqlConnection(SQLProvider);
            connection.Open();
            try
            {
                SqlCommand UpdateCmd = new SqlCommand(query, connection);
                nowofRecordsUpdated = UpdateCmd.ExecuteNonQuery();
                //if (loglevel >= 2)
                //oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Records updated in Oracle Replica table: ", nowofRecordsUpdated.ToString());

                return nowofRecordsUpdated;
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "SetProcessId", "Query : " + query, " Exception: " + ex.Message.ToString());
            }
            finally
            {
                // command.Dispose();
                connection.Close();
                connection.Dispose();
            }
            return nowofRecordsUpdated;
        }
        #endregion

        #region Function to retrive records from oracle replica table and insert into DM Table
        public static DataSet GetRecordsFromReplicaTable(Guid PId, string TableName, bool IsSite)
        {
            string query = string.Empty;

            if (TableName.ToLower() == "xxcrm_accounts_interface" && (!IsSite))
            {
                query = "select ROWID,ACCOUNT_NUMBER,PARTY_NAME as ACCOUNT_NAME,TAX_CATEGORY_LIST,TER_NAME as TERRITORY_ID,SALESREP_ID,ALTERNATE_CONTACT_NUMBER_1,ORGANIZATION_CODE as DEPOT," +
                        "ALTERNATE_CONTACT_NUMBER_2,ALTERNATE_CONTACT_NUMBER_3,SECD_PERSON_NAME,THRD_PERSON_NAME,case BILLING_SYSTEM when 'Computerised' then '1' else '0' end as BILLING_SYSTEM," +
                        "case COLORBANK when 'Yes' then '1' else '0' end as COLORBANK,COMPETITION_CLUB,CR_LMT,case CST_BILLING_AVAILABLE when 'Yes' then '1' else '0' end as  CST_BILLING_AVAILABLE,CST_REG_NO," +
                        "isnull(CUSTOMER_CATEGORY,'Others') as CUST_CAT,isnull(MAX_DAILY_TRANSACTION_LIMIT,CR_LMT) as MAX_DAILY_TRANSACTION_LIMIT,EMAIL_ADDRESS," +
                        "EXCLUSIVITY,case INTERNET_ACCESS_AT_SHOP when 'Yes'then '1' else '0' end as INTERNET_ACCESS_AT_SHOP,LOCATION,MAX_CHEQUE_VALUE_LIMIT,case OLD_MRP_MTRL_ACCEPTABLE when 'Yes' then '1' else '0' end as OLD_MRP_MTRL_ACCEPTABLE," +
                        "PAN_NO,LANGUAGEL_PREFERENCE_1,LANGUAGEL_PREFERENCE_2,isnull(PREFERED_TIME,'NA') as PREFERED_TIME,PRIMARY_CONTACT_NUMBER,PRIM_PERSON_NAME,REGION," +
                        "SBL_TYPE as SALES_CHANNEL,SECURITY_ANSWER,SECRUITY_QUESTION,TIN_NO,VAT_REG_NO,ZONE,'R'IMPORT_STATUS,CRM_REQUEST_ID as CRM_REQUEST_ID " +
                        "from xxcrm_accounts_interface where CRM_REQUEST_ID = '" + PId + "' AND prim = 'PRIMARY' ";

                        // Filteration should be there ........
            }
            else if (TableName.ToLower() == "xxcrm_accounts_interface" && IsSite)
            {
                query = "select ROWID,BILL_TO,LEG_NAME as ACCOUNT_NAME,ACCOUNT_NUMBER as PARENT_ACCOUNT,CUST_TYPE,DUE_DAYS,case prim when 'PRIMARY' then 0 else 1 end as PRIM,TAX_CATEGORY_LIST,ORGANIZATION_CODE as DEPOT,TER_NAME as TERRITORY_ID," +
                        "SALESREP_ID,CITY,'India' as COUNTRY,STATE,ADDRESS1,ADDRESS2,ADDRESS3,POSTAL_CODE,ALTERNATE_CONTACT_NUMBER_1,ALTERNATE_CONTACT_NUMBER_2,ALTERNATE_CONTACT_NUMBER_3,SECD_PERSON_NAME,THRD_PERSON_NAME,'0000000000' as BANK_ACCOUNT_NUMBER," +
                        "CUST_BRANCH_NAME,CUST_BANK_NAME,case BILLING_SYSTEM when 'Computerised' then '1' else '0' end as BILLING_SYSTEM,case COLORBANK when 'Yes' then '1' else '0' end as COLORBANK,COMPETITION_CLUB,case CST_BILLING_AVAILABLE when 'Yes' then '1' else '0' end as CST_BILLING_AVAILABLE," +
                        "CST_REG_NO,isnull(CUSTOMER_CATEGORY,'Others') as CUST_CAT,ADDRESS4 as DISTRICT,EMAIL_ADDRESS,EXCLUSIVITY,case INTERNET_ACCESS_AT_SHOP when 'Yes' then '1' else '0' end as INTERNET_ACCESS_AT_SHOP,LOCATION,case OLD_MRP_MTRL_ACCEPTABLE when 'Yes' then '1' else '0' end as OLD_MRP_MTRL_ACCEPTABLE," +
                        "SUBSTRING(ORDER_TYPE,5,LEN(ORDER_TYPE)) ORDER_TYPE,PAN_NO,SUBSTRING(CUST_TYPE_AP,5,CHARINDEX('_',substring(CUST_TYPE_AP,5,Datalength(CUST_TYPE_AP)))-1) PAYMENT_TERMS,isnull(PREFERED_TIME,'NA') as PREFERED_TIME,PRIMARY_CONTACT_NUMBER,PRIM_PERSON_NAME,REGION,SBL_TYPE,SITE_USE_CODE,TIN_NO," +
                        "VAT_REG_NO,ZONE,'R' IMPORT_STATUS,CRM_REQUEST_ID as CRM_REQUEST_ID from xxcrm_accounts_interface where SUBSTRING(ORDER_TYPE,5,LEN(ORDER_TYPE)) IN ('MRP_ORDER','ORDER') AND CRM_REQUEST_ID = '" + PId + "'";

            }
            DataSet sds = new DataSet();
            //if (loglevel >= 3)
             oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Select Query: " + query);

            SqlConnection connection = new SqlConnection(SQLProvider);
            SqlCommand command = new SqlCommand();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
            try
            {
                //if (loglevel >= 4)
                //    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Open Connection");
                connection.Open();
                //if (loglevel >= 4)
                //    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Connection Open Successfuly.");
                command.Connection = connection;
                command.CommandText = query;
                command.CommandType = CommandType.Text;
                //if (loglevel >= 4)
                //    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Fill data in Datatable");

                dataAdapter.Fill(sds);

                //if (loglevel >= 4)
                //    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", "Records Filled into DataTable", "Row Count : " + sds.Tables[0].Rows.Count.ToString());


                try
                {
                    //if (loglevel >= 2)
                    //    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Count for Records selected: " + sds.Tables[0].Rows.Count.ToString());
                }
                catch (Exception exp)
                {
                    oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", TableName, "Count of Tables in DataSet: " + sds.Tables.Count.ToString() + "Exception : " + exp.ToString());
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "GetRecordsFromReplicaTable", "Query : " + query, " Exception: " + ex.Message.ToString());
            }
            finally
            {
                connection.Close();
                dataAdapter.Dispose();
                command.Dispose();
                connection.Dispose();
            }
            return sds;
        }
        #endregion

        #region Function to Create record in Data Migration DB in SITE Table
        public static void CreateRecordInDMForSite(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy copy = null;
            try
            {
                //if (loglevel >= 3)
                //    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForSite", "Destination Table Name", DestinationTable);
                using (copy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    copy.BulkCopyTimeout = Convert.ToInt32(TimeOut);
                    copy.ColumnMappings.Add("IMPORT_STATUS", "Import_Status");
                    copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");
                    copy.ColumnMappings.Add("ROWID", "oracle_row_id");

                    copy.ColumnMappings.Add("PARENT_ACCOUNT", "parentaccountid");
                    copy.ColumnMappings.Add("ADDRESS1", "address1_line1");
                    copy.ColumnMappings.Add("ADDRESS2", "address1_line2");
                    copy.ColumnMappings.Add("ADDRESS3", "address1_line3");
                    copy.ColumnMappings.Add("CITY", "address1_city");
                    copy.ColumnMappings.Add("BILL_TO", "accountnumber");
                    copy.ColumnMappings.Add("ACCOUNT_NAME", "name");
                    copy.ColumnMappings.Add("STATE", "address1_stateorprovince");
                    copy.ColumnMappings.Add("POSTAL_CODE", "address1_postalcode");
                    copy.ColumnMappings.Add("CUST_TYPE", "customertypecode");
                    copy.ColumnMappings.Add("SBL_TYPE", "accountclassificationcode");
                    copy.ColumnMappings.Add("SITE_USE_CODE", "address1_addresstypecode");
                    copy.ColumnMappings.Add("ORDER_TYPE", "businesstypecode");
                    copy.ColumnMappings.Add("ZONE", "ber_zone");
                    copy.ColumnMappings.Add("REGION", "ber_region");
                    copy.ColumnMappings.Add("DEPOT", "ber_depotid");
                    copy.ColumnMappings.Add("TERRITORY_ID", "territoryid");
                    copy.ColumnMappings.Add("PAYMENT_TERMS", "paymenttermscode");
                    copy.ColumnMappings.Add("TAX_CATEGORY_LIST", "ber_taxcategory");
                    copy.ColumnMappings.Add("DUE_DAYS", "ber_creditdays");//
                    copy.ColumnMappings.Add("CUST_CAT", "accountcategorycode");
                    copy.ColumnMappings.Add("PRIM", "donotfax");
                    copy.ColumnMappings.Add("SALESREP_ID", "ber_associatedtsiid");

                    copy.ColumnMappings.Add("COUNTRY", "address1_country");
                    copy.ColumnMappings.Add("DISTRICT", "address1_postofficebox");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_1", "telephone2");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_2", "address1_telephone1");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_3", "telephone3");
                    copy.ColumnMappings.Add("SECD_PERSON_NAME", "address2_name");
                    copy.ColumnMappings.Add("THRD_PERSON_NAME", "ber_contactperson3");
                    copy.ColumnMappings.Add("BANK_ACCOUNT_NUMBER", "ber_bankaccountnumber");
                    copy.ColumnMappings.Add("CUST_BRANCH_NAME", "ber_bankbranchaddress");
                    copy.ColumnMappings.Add("CUST_BANK_NAME", "ber_bankname");
                    copy.ColumnMappings.Add("BILLING_SYSTEM", "ber_billingsystem");
                    copy.ColumnMappings.Add("COLORBANK", "ber_colorbank");
                    copy.ColumnMappings.Add("COMPETITION_CLUB", "ber_competitionclub");
                    copy.ColumnMappings.Add("CST_BILLING_AVAILABLE", "ber_cstbillingavailable");
                    copy.ColumnMappings.Add("CST_REG_NO", "ber_cstno");
                    copy.ColumnMappings.Add("EMAIL_ADDRESS", "emailaddress1");
                    copy.ColumnMappings.Add("EXCLUSIVITY", "ber_exclusivity");
                    copy.ColumnMappings.Add("INTERNET_ACCESS_AT_SHOP", "ber_internetaccessatshop");
                    copy.ColumnMappings.Add("LOCATION", "accountratingcode");
                    copy.ColumnMappings.Add("OLD_MRP_MTRL_ACCEPTABLE", "ber_oldmrpmat");
                    copy.ColumnMappings.Add("VAT_REG_NO", "ber_vatno");
                    copy.ColumnMappings.Add("PAN_NO", "ber_panno");
                    copy.ColumnMappings.Add("TIN_NO", "ber_tinno");
                    copy.ColumnMappings.Add("PREFERED_TIME", "preferredappointmenttimecode");
                    copy.ColumnMappings.Add("PRIMARY_CONTACT_NUMBER", "telephone1");
                    copy.ColumnMappings.Add("PRIM_PERSON_NAME", "address1_name");

                    copy.DestinationTableName = DestinationTable;
                    copy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForSite", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                copy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion

        #region Function to execute DM exe and wait until process gets completed
        public static void ExecuteDM(string ProcessID, string DestinationTblName)
        {
            //throw new NotImplementedException();
            string xx = "";
        } 
       //public static void ExecuteDM(string ProcessID, string DestinationTblName)
        //{


        //    try
        //    {
        //        if (loglevel >= 1)
        //            oLogger.Log("WrapperExecutorforDMUtility", "ExecuteDM", "Process Id: " + ProcessID, "Destination Table Name: " + DestinationTblName);

        //        ProcessStartInfo p = new System.Diagnostics.ProcessStartInfo();
        //        p.CreateNoWindow = true;
        //        p.UseShellExecute = false;
        //        p.WindowStyle = ProcessWindowStyle.Hidden;
        //        //p.FileName = @"\\" + ConfigurationManager.AppSettings["ServerIP"].ToString() + "\\" + ConfigurationManager.AppSettings["DMExecutablePath"].ToString();
        //        p.FileName = ConfigurationManager.AppSettings["DMExecutablePath"].ToString();
        //        p.Arguments = ProcessID + "|" + DestinationTblName;
        //        p.Domain = ConfigurationManager.AppSettings["Domain"].ToString();
        //        p.UserName = ConfigurationManager.AppSettings["UserName"].ToString();

        //        char[] psw = ConfigurationManager.AppSettings["Password"].ToString().ToCharArray();
        //        SecureString ss = new SecureString();
        //        for (int x = 0; x < psw.Length; x++)
        //        {
        //            ss.AppendChar(psw[x]);
        //        }
        //        p.Password = ss;

        //        Process proc = new System.Diagnostics.Process();

        //        proc.StartInfo = p;
        //        proc.Start();
        //        proc.WaitForExit();

        //    }
        //    catch (Exception ex)
        //    {
        //        oLogger.Log("WrapperExecutorforDMUtility", "ExecuteDM", "Process Id : " + ProcessID + "Destination Tbl :" + DestinationTblName, " Exception: " + ex.Message.ToString());
        //    }
        //}
        #endregion
       
        #region Function to Create record in Data Migration DB in Account Table
        public static void CreateRecordInDMForAccount(DataSet DS, string DestinationTable)
        {
            DataTable DT = DS.Tables[0];
            SqlConnection cn = new SqlConnection(SQLProvider);
            SqlBulkCopy copy = null;
            try
            {
                //if (loglevel >= 3)
                //    oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForAccount", "Destination Table Name", DestinationTable);

                using (copy = new SqlBulkCopy(cn))
                {
                    cn.Open();

                    copy.BulkCopyTimeout = Convert.ToInt32(TimeOut);

                    copy.ColumnMappings.Add("IMPORT_STATUS", "Import_Status");
                    copy.ColumnMappings.Add("CRM_REQUEST_ID", "crm_request_id");

                    copy.ColumnMappings.Add("ROWID", "oracle_row_id");
                    copy.ColumnMappings.Add("ACCOUNT_NUMBER", "accountnumber");
                    copy.ColumnMappings.Add("ACCOUNT_NAME", "name");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_1", "telephone2");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_2", "address1_telephone1");
                    copy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_3", "telephone3");
                    copy.ColumnMappings.Add("SECD_PERSON_NAME", "address2_name");
                    copy.ColumnMappings.Add("THRD_PERSON_NAME", "ber_contactperson3");
                    copy.ColumnMappings.Add("BILLING_SYSTEM", "ber_billingsystem");
                    copy.ColumnMappings.Add("COLORBANK", "ber_colorbank");
                    copy.ColumnMappings.Add("COMPETITION_CLUB", "ber_competitionclub");
                    copy.ColumnMappings.Add("MAX_DAILY_TRANSACTION_LIMIT", "ber_availablecreditlimit");
                    copy.ColumnMappings.Add("CST_BILLING_AVAILABLE", "ber_cstbillingavailable");
                    copy.ColumnMappings.Add("EMAIL_ADDRESS", "emailaddress1");
                    copy.ColumnMappings.Add("EXCLUSIVITY", "ber_exclusivity");
                    copy.ColumnMappings.Add("INTERNET_ACCESS_AT_SHOP", "ber_internetaccessatshop");
                    copy.ColumnMappings.Add("LOCATION", "accountratingcode");
                    copy.ColumnMappings.Add("MAX_CHEQUE_VALUE_LIMIT", "marketcap");
                    copy.ColumnMappings.Add("OLD_MRP_MTRL_ACCEPTABLE", "ber_oldmrpmat");
                    copy.ColumnMappings.Add("LANGUAGEL_PREFERENCE_1", "ber_preferredlanguage1");
                    copy.ColumnMappings.Add("LANGUAGEL_PREFERENCE_2", "ber_preferredlanguage2");
                    copy.ColumnMappings.Add("PREFERED_TIME", "preferredappointmenttimecode");
                    copy.ColumnMappings.Add("PRIMARY_CONTACT_NUMBER", "telephone1");
                    copy.ColumnMappings.Add("PRIM_PERSON_NAME", "address1_name");
                    copy.ColumnMappings.Add("SECURITY_ANSWER", "stockexchange");
                    copy.ColumnMappings.Add("SECRUITY_QUESTION", "sic");
                    copy.ColumnMappings.Add("TIN_NO", "ber_tinno");
                    copy.ColumnMappings.Add("SALES_CHANNEL", "accountclassificationcode");
                    copy.ColumnMappings.Add("CR_LMT", "creditlimit");
                    copy.ColumnMappings.Add("CST_REG_NO", "ber_cstno");
                    copy.ColumnMappings.Add("VAT_REG_NO", "ber_vatno");
                    copy.ColumnMappings.Add("PAN_NO", "ber_panno");
                    copy.ColumnMappings.Add("TAX_CATEGORY_LIST", "ber_taxcategory");
                    copy.ColumnMappings.Add("SALESREP_ID", "ber_associatedtsiid");
                    copy.ColumnMappings.Add("ZONE", "ber_zone");
                    copy.ColumnMappings.Add("REGION", "ber_region");
                    copy.ColumnMappings.Add("DEPOT", "ber_depotid");
                    copy.ColumnMappings.Add("TERRITORY_ID", "territoryid");
                    copy.ColumnMappings.Add("CUST_CAT", "accountcategorycode");

                    copy.DestinationTableName = DestinationTable;
                    copy.WriteToServer(DT);
                }
            }
            catch (Exception ex)
            {
                oLogger.Log("WrapperExecutorforDMUtility", "CreateRecordInDMForAccount", "Unable to create record in Data Migration DB", ex.Message.ToString());
            }
            finally
            {
                copy.Close();
                cn.Close();
                cn.Dispose();
                DT.Clear();
            }
        }
        #endregion
       
    }
}
