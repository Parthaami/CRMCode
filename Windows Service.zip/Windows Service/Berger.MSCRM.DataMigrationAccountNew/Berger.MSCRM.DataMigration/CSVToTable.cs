﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;
using Oracle.DataAccess.Client;

namespace Berger.MSCRM.DataMigration
{
    public static class CSVToTable
    {
        public static PragmasysLogger bergerlogger = PragmasysLogger.Instance;
        public static SqlConnection con;
        public static string sqlconn;

        /// <summary>
        /// 
        /// </summary>
        public static void connection()
        {
            sqlconn = ConfigurationManager.ConnectionStrings["StaggingDBConnectionString"].ConnectionString;
            con = new SqlConnection(sqlconn);
        }

        //Reading CSV File 
        public static void CSV2Table(string FileName)
        {

            //berglogger = new PragmasysLogger("Berger", ConfigurationManager.AppSettings["loggerpath"]);
            //Creating object of datatable  
            DataTable tblcsv = new DataTable();

            ////creating columns     
            tblcsv.Columns.Add("ROWID"); // map ROWID to ROWID
            tblcsv.Columns.Add("ORGANIZATION_CODE");                                        // map ORGANIZATION_CODE to ORGANIZATION_CODE
            tblcsv.Columns.Add("ORGANIZATION_ID");                                          // map ORGANIZATION_ID to ORGANIZATION_ID
            tblcsv.Columns.Add("ACCOUNT_NUMBER");                                           // map ACCOUNT_NUMBER to ACCOUNT_NUMBER
            tblcsv.Columns.Add("PARTY_NUMBER");                                             // map PARTY_NUMBER to PARTY_NUMBER
            tblcsv.Columns.Add("CUST_ACCOUNT_ID");                                          // map CUST_ACCOUNT_ID to CUST_ACCOUNT_ID
            tblcsv.Columns.Add("PARTY_NAME");                                               // map PARTY_NAME to PARTY_NAME
            tblcsv.Columns.Add("PARTY_ID");                                                 // map PARTY_ID to PARTY_ID
            tblcsv.Columns.Add("ADDRESS1");                                                 // map ADDRESS1 to ADDRESS1
            tblcsv.Columns.Add("ADDRESS2");                                                 // map ADDRESS2 to ADDRESS2
            tblcsv.Columns.Add("ADDRESS3");                                                 // map ADDRESS3 to ADDRESS3
            tblcsv.Columns.Add("ADDRESS4");                                                 // map ADDRESS4 to ADDRESS4
            tblcsv.Columns.Add("CITY");                                                     // map CITY  to CITY
            tblcsv.Columns.Add("POSTAL_CODE");                                              // map POSTAL_CODE to POSTAL_CODE
            tblcsv.Columns.Add("STATE");                                                    // map STATE to STATE
            tblcsv.Columns.Add("COUNTRY");                                                  // map COUNTRY to COUNTRY
            tblcsv.Columns.Add("PHONE_NUM");                                                // map PHONE_NUM to PHONE_NUM
            tblcsv.Columns.Add("CUST_TYPE");                                                // map CUST_TYPE to CUST_TYPE
            tblcsv.Columns.Add("SBL_TYPE");                                                 // map SBL_TYPE to SBL_TYPE
            tblcsv.Columns.Add("SITE_USE_CODE");                                            // map SITE_USE_CODE to SITE_USE_CODE
            tblcsv.Columns.Add("CUST_ACCT_SITE_ID");                                        // map CUST_ACCT_SITE_ID to CUST_ACCT_SITE_ID
            tblcsv.Columns.Add("PARTY_SITE_ID");                                            // map PARTY_SITE_ID to PARTY_SITE_ID
            tblcsv.Columns.Add("PRIM");                                                     // map PRIM to PRIM             
            tblcsv.Columns.Add("BILL_TO");                                                  // map BILL_TO to BILL_TO     
            tblcsv.Columns.Add("ORDER_TYPE");                                               // map ORDER_TYPE to ORDER_TYPE
            tblcsv.Columns.Add("TERR");                                                     // map TERR to TERR           
            tblcsv.Columns.Add("TERRITORY_ID");                                             // map TERRITORY_ID to TERRITORY_ID
            tblcsv.Columns.Add("LEG_NAME");                                                 // map LEG_NAME to LEG_NAME   
            tblcsv.Columns.Add("PR_PIS");                                                   // map PR_PIS to PR_PIS      
            tblcsv.Columns.Add("CN42");                                                     // map CN42  to  CN42         
            tblcsv.Columns.Add("BIRTH_DATE");                                               // map BIRTH_DATE to BIRTH_DATE
            tblcsv.Columns.Add("TER_NAME");                                                 // map TER_NAME to TER_NAME  
            tblcsv.Columns.Add("SALESREP_ID");                                              // map SALESREP_ID to SALESREP_ID
            tblcsv.Columns.Add("SAL_REP");                                                  // map SAL_REP to SAL_REP     
            tblcsv.Columns.Add("CUST_TYPE_AP");                                             // map CUST_TYPE_AP to CUST_TYPE_AP
            tblcsv.Columns.Add("LEGACY_CODE");                                              // map LEGACY_CODE to LEGACY_CODE
            tblcsv.Columns.Add("EXCISE_DUTY_REGION");                                       // map EXCISE_DUTY_REGION to EXCISE_DUTY_REGION
            tblcsv.Columns.Add("EXCISE_DUTY_ZONE");                                         // map EXCISE_DUTY_ZONE to EXCISE_DUTY_ZONE
            tblcsv.Columns.Add("EXCISE_DUTY_REG_NO");                                       // map EXCISE_DUTY_REG_NO to EXCISE_DUTY_REG_NO
            tblcsv.Columns.Add("EXCISE_DUTY_RANGE");                                        // map EXCISE_DUTY_RANGE to EXCISE_DUTY_RANGE
            tblcsv.Columns.Add("EXCISE_DUTY_DIVISION");                                     // map EXCISE_DUTY_DIVISION to EXCISE_DUTY_DIVISION
            tblcsv.Columns.Add("EXCISE_DUTY_COMM");                                         // map EXCISE_DUTY_COMM to EXCISE_DUTY_COMM
            tblcsv.Columns.Add("TAX_CATEGORY_LIST");                                        // map EXCISE_DUTY_COMM to EXCISE_DUTY_COMM
            tblcsv.Columns.Add("ST_REG_NO");                                                // map TAX_CATEGORY_LIST to TAX_CATEGORY_LIST
            tblcsv.Columns.Add("CST_REG_NO");                                               // map ST_REG_NO to ST_REG_NO
            tblcsv.Columns.Add("EC_CODE");                                                  // map EC_CODE to EC_CODE
            tblcsv.Columns.Add("EXEMPT");                                                   // map EXEMPT to EXEMPT
            tblcsv.Columns.Add("VAT_REG_NO");                                               // map VAT_REG_NO to VAT_REG_NO
            tblcsv.Columns.Add("SERVICE_TAX_REGNO");                                        // map SERVICE_TAX_REGNO to SERVICE_TAX_REGNO
            tblcsv.Columns.Add("PAN_NO");                                                   // map PAN_NO to PAN_NO
            tblcsv.Columns.Add("TAN_NO");                                                   // map DUE_DAYS to DUE_DAYS
            tblcsv.Columns.Add("DUE_DAYS");                                                 // map CR_LMT to CR_LMT
            tblcsv.Columns.Add("CR_LMT");                                                   // map CR_LMT to CR_LMT
            tblcsv.Columns.Add("HCA_STATUS");                                               // map HCA_STATUS to HCA_STATUS
            tblcsv.Columns.Add("HCSUA_STATUS");                                             // map HCSUA_STATUS to HCSUA_STATUS
            tblcsv.Columns.Add("STATUS");                                                   // map STATUS to STATUS
            tblcsv.Columns.Add("REQUEST_ID");                                               // map REQUEST_ID to REQUEST_ID
            tblcsv.Columns.Add("REMARKS");                                                  // map REMARKS to REMARKS
            tblcsv.Columns.Add("CUSTOMER_CATEGORY");                                        // map CUSTOMER_CATEGORY to CUSTOMER_CATEGORY
            tblcsv.Columns.Add("CST_BILLING_AVAILABLE");                                    // map CST_BILLING_AVAILABLE to CST_BILLING_AVAILABLE
            tblcsv.Columns.Add("OLD_MRP_MTRL_ACCEPTABLE");                                  // map OLD_MRP_MTRL_ACCEPTABLE to OLD_MRP_MTRL_ACCEPTABLE
            tblcsv.Columns.Add("COLORBANK");                                                // map COLORBANK to COLORBANK
            tblcsv.Columns.Add("EXCLUSIVITY");                                              // map EXCLUSIVITY to EXCLUSIVITY
            tblcsv.Columns.Add("COMPETITION_CLUB");                                         // map EXCLUSIVITY to EXCLUSIVITY
            tblcsv.Columns.Add("LANGUAGEL_PREFERENCE_1");                                   // map LANGUAGEL_PREFERENCE_1 to LANGUAGEL_PREFERENCE_1
            tblcsv.Columns.Add("LANGUAGEL_PREFERENCE_2");                                   // map LANGUAGEL_PREFERENCE_2 to LANGUAGEL_PREFERENCE_2
            tblcsv.Columns.Add("SECRUITY_QUESTION");                                        // map SECRUITY_QUESTION to SECRUITY_QUESTION
            tblcsv.Columns.Add("SECURITY_ANSWER");                                          // map MAX_CHEQUE_VALUE_LIMIT to MAX_CHEQUE_VALUE_LIMIT
            tblcsv.Columns.Add("MAX_CHEQUE_VALUE_LIMIT");                                   // map MAX_CHEQUE_VALUE_LIMIT to MAX_CHEQUE_VALUE_LIMIT
            tblcsv.Columns.Add("MAX_DAILY_TRANSACTION_LIMIT");                              // map MAX_DAILY_TRANSACTION_LIMIT to MAX_DAILY_TRANSACTION_LIMIT
            tblcsv.Columns.Add("BILLING_SYSTEM");                                           // map BILLING_SYSTEM to BILLING_SYSTEM
            tblcsv.Columns.Add("INTERNET_ACCESS_AT_SHOP");                                  // map INTERNET_ACCESS_AT_SHOP to INTERNET_ACCESS_AT_SHOP
            tblcsv.Columns.Add("CUST_BANK_NAME");                                           // map CUST_BRANCH_NAME to CUST_BRANCH_NAME
            tblcsv.Columns.Add("CUST_BRANCH_NAME");                                         // map CUST_BRANCH_NAME to CUST_BRANCH_NAME
            tblcsv.Columns.Add("REGION");                                                   // map REGION to REGION
            tblcsv.Columns.Add("ZONE");                                                     // map ZONE to ZONE
            tblcsv.Columns.Add("TIN_NO");                                                   // map TIN_NO to TIN_NO
            tblcsv.Columns.Add("PREFERED_TIME");                                            // map PREFERED_TIME to PREFERED_TIME
            tblcsv.Columns.Add("LOCATION");                                                 // map LOCATION to LOCATION
            tblcsv.Columns.Add("PRIMARY_CONTACT_NUMBER");                                   // map PRIMARY_CONTACT_NUMBER to PRIMARY_CONTACT_NUMBER
            tblcsv.Columns.Add("ALTERNATE_CONTACT_NUMBER_1");                               // map ALTERNATE_CONTACT_NUMBER_1 to ALTERNATE_CONTACT_NUMBER_1
            tblcsv.Columns.Add("ALTERNATE_CONTACT_NUMBER_2");                               // map ALTERNATE_CONTACT_NUMBER_2 to ALTERNATE_CONTACT_NUMBER_2
            tblcsv.Columns.Add("ALTERNATE_CONTACT_NUMBER_3");                               // map ALTERNATE_CONTACT_NUMBER_3 to ALTERNATE_CONTACT_NUMBER_3
            tblcsv.Columns.Add("EMAIL_ADDRESS");                                            // map EMAIL_ADDRESS to EMAIL_ADDRESS
            tblcsv.Columns.Add("PRIM_PERSON_NAME");                                         // map PRIM_PERSON_NAME to PRIM_PERSON_NAME
            tblcsv.Columns.Add("SECD_PERSON_NAME");                                         // map SECD_PERSON_NAME to SECD_PERSON_NAME
            tblcsv.Columns.Add("THRD_PERSON_NAME");                                         // map THRD_PERSON_NAME to THRD_PERSON_NAME
            tblcsv.Columns.Add("CREATION_DATE");                                            // map CREATION_DATE to CREATION_DATE
            tblcsv.Columns.Add("CRM_REQUEST_ID");                                           // map CRM_REQUEST_ID to CRM_REQUEST_ID  
                        

            //getting full file path of Uploaded file  
            string CSVFilePath = Path.GetFullPath(FileName);
            //Reading All text  
            //Skip(1).ToList()
            string ReadCSV = "";
            foreach (string file in Directory.EnumerateFiles(CSVFilePath, "*.csv"))
            {
                //string contents = File.ReadAllText(file);
                ReadCSV = File.ReadAllText(file);
            }
            
            //spliting row after new line 
            int rowsCount = 0; 
            foreach (string csvRow in ReadCSV.Split('\n'))
            { 
               
                if (rowsCount > 0) // Skip first row a header
                {
                    if (!string.IsNullOrEmpty(csvRow))
                    {
                        //Adding each row into datatable  
                        tblcsv.Rows.Add();
                        int count = 0;
                        foreach (string FileRec in csvRow.Split('|'))
                        {

                            tblcsv.Rows[tblcsv.Rows.Count - 1][count] = FileRec;
                            count++;
                        }

                    }
                }
                rowsCount++;
            }
            //Calling insert Functions  
            InsertBulkRecords(tblcsv);
        }
        
        
        /// <summary>
        /// Function to Insert Bulk Records  
        /// </summary>
        /// <param name="csvdt"> DataTable for Bulk </param>
        public static void InsertBulkRecords(DataTable csvdt)
        {
            try
            {
                connection();
                // Put the operation into a transaction, means that can commit at the end.
                //SqlTransaction tx = con.BeginTransaction();

                //creating object of SqlBulkCopy    
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(con))
                {

                    try
                    {
                        //assigning Destination table name    
                        bulkCopy.DestinationTableName = "XXCRM_ACCOUNTS_INTERFACE";
                        //Mapping Table column    
                        bulkCopy.ColumnMappings.Add("ROWID", "ROWID"); // map ROWID to ROWID
                        bulkCopy.ColumnMappings.Add("ORGANIZATION_CODE", "ORGANIZATION_CODE");                              // map ORGANIZATION_CODE to ORGANIZATION_CODE
                        bulkCopy.ColumnMappings.Add("ORGANIZATION_ID", "ORGANIZATION_ID");                                  // map ORGANIZATION_ID to ORGANIZATION_ID
                        bulkCopy.ColumnMappings.Add("ACCOUNT_NUMBER", "ACCOUNT_NUMBER");                                    // map ACCOUNT_NUMBER to ACCOUNT_NUMBER
                        bulkCopy.ColumnMappings.Add("PARTY_NUMBER", "PARTY_NUMBER");                                        // map PARTY_NUMBER to PARTY_NUMBER
                        bulkCopy.ColumnMappings.Add("CUST_ACCOUNT_ID", "CUST_ACCOUNT_ID");                                  // map CUST_ACCOUNT_ID to CUST_ACCOUNT_ID
                        bulkCopy.ColumnMappings.Add("PARTY_NAME", "PARTY_NAME");                                            // map PARTY_NAME to PARTY_NAME
                        bulkCopy.ColumnMappings.Add("PARTY_ID", "PARTY_ID");                                                // map PARTY_ID to PARTY_ID
                        bulkCopy.ColumnMappings.Add("ADDRESS1", "ADDRESS1");                                                // map ADDRESS1 to ADDRESS1
                        bulkCopy.ColumnMappings.Add("ADDRESS2", "ADDRESS2");                                                // map ADDRESS2 to ADDRESS2
                        bulkCopy.ColumnMappings.Add("ADDRESS3", "ADDRESS3");                                                // map ADDRESS3 to ADDRESS3
                        bulkCopy.ColumnMappings.Add("ADDRESS4", "ADDRESS4");                                                // map ADDRESS4 to ADDRESS4
                        bulkCopy.ColumnMappings.Add("CITY", "CITY");                                                        // map CITY  to CITY
                        bulkCopy.ColumnMappings.Add("POSTAL_CODE", "POSTAL_CODE");                                          // map POSTAL_CODE to POSTAL_CODE
                        bulkCopy.ColumnMappings.Add("STATE", "STATE");                                                      // map STATE to STATE
                        bulkCopy.ColumnMappings.Add("COUNTRY", "COUNTRY");                                                  // map COUNTRY to COUNTRY
                        bulkCopy.ColumnMappings.Add("PHONE_NUM", "PHONE_NUM");                                              // map PHONE_NUM to PHONE_NUM
                        bulkCopy.ColumnMappings.Add("CUST_TYPE", "CUST_TYPE");                                              // map CUST_TYPE to CUST_TYPE
                        bulkCopy.ColumnMappings.Add("SBL_TYPE", "SBL_TYPE");                                                // map SBL_TYPE to SBL_TYPE
                        bulkCopy.ColumnMappings.Add("SITE_USE_CODE", "SITE_USE_CODE");                                      // map SITE_USE_CODE to SITE_USE_CODE
                        bulkCopy.ColumnMappings.Add("CUST_ACCT_SITE_ID", "CUST_ACCT_SITE_ID");                              // map CUST_ACCT_SITE_ID to CUST_ACCT_SITE_ID
                        bulkCopy.ColumnMappings.Add("PARTY_SITE_ID", "PARTY_SITE_ID");                                      // map PARTY_SITE_ID to PARTY_SITE_ID
                        bulkCopy.ColumnMappings.Add("PRIM", "PRIM");                                                        // map PRIM to PRIM             
                        bulkCopy.ColumnMappings.Add("BILL_TO", "BILL_TO");                                                  // map BILL_TO to BILL_TO     
                        bulkCopy.ColumnMappings.Add("ORDER_TYPE", "ORDER_TYPE");                                            // map ORDER_TYPE to ORDER_TYPE
                        bulkCopy.ColumnMappings.Add("TERR", "TERR");                                                        // map TERR to TERR           
                        bulkCopy.ColumnMappings.Add("TERRITORY_ID", "TERRITORY_ID");                                        // map TERRITORY_ID to TERRITORY_ID
                        bulkCopy.ColumnMappings.Add("LEG_NAME", "LEG_NAME");                                                // map LEG_NAME to LEG_NAME   
                        bulkCopy.ColumnMappings.Add("PR_PIS", "PR_PIS");                                                    // map PR_PIS to PR_PIS      
                        bulkCopy.ColumnMappings.Add("CN42", "CN42");                                                        // map CN42  to  CN42         
                        bulkCopy.ColumnMappings.Add("BIRTH_DATE", "BIRTH_DATE");                                            // map BIRTH_DATE to BIRTH_DATE
                        bulkCopy.ColumnMappings.Add("TER_NAME", "TER_NAME");                                                // map TER_NAME to TER_NAME  
                        bulkCopy.ColumnMappings.Add("SALESREP_ID", "SALESREP_ID");                                          // map SALESREP_ID to SALESREP_ID
                        bulkCopy.ColumnMappings.Add("SAL_REP", "SAL_REP");                                                  // map SAL_REP to SAL_REP     
                        bulkCopy.ColumnMappings.Add("CUST_TYPE_AP", "CUST_TYPE_AP");                                        // map CUST_TYPE_AP to CUST_TYPE_AP
                        bulkCopy.ColumnMappings.Add("LEGACY_CODE", "LEGACY_CODE");                                          // map LEGACY_CODE to LEGACY_CODE
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_REGION", "EXCISE_DUTY_REGION");                            // map EXCISE_DUTY_REGION to EXCISE_DUTY_REGION
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_ZONE", "EXCISE_DUTY_ZONE");                                // map EXCISE_DUTY_ZONE to EXCISE_DUTY_ZONE
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_REG_NO", "EXCISE_DUTY_REG_NO");                            // map EXCISE_DUTY_REG_NO to EXCISE_DUTY_REG_NO
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_RANGE", "EXCISE_DUTY_RANGE");                              // map EXCISE_DUTY_RANGE to EXCISE_DUTY_RANGE
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_DIVISION", "EXCISE_DUTY_DIVISION");                        // map EXCISE_DUTY_DIVISION to EXCISE_DUTY_DIVISION
                        bulkCopy.ColumnMappings.Add("EXCISE_DUTY_COMM", "EXCISE_DUTY_COMM");                                // map EXCISE_DUTY_COMM to EXCISE_DUTY_COMM
                        bulkCopy.ColumnMappings.Add("TAX_CATEGORY_LIST", "TAX_CATEGORY_LIST");                              // map EXCISE_DUTY_COMM to EXCISE_DUTY_COMM
                        bulkCopy.ColumnMappings.Add("ST_REG_NO", "ST_REG_NO");                                              // map TAX_CATEGORY_LIST to TAX_CATEGORY_LIST
                        bulkCopy.ColumnMappings.Add("CST_REG_NO", "CST_REG_NO");                                            // map ST_REG_NO to ST_REG_NO
                        bulkCopy.ColumnMappings.Add("EC_CODE", "EC_CODE");                                                  // map EC_CODE to EC_CODE
                        bulkCopy.ColumnMappings.Add("EXEMPT", "EXEMPT");                                                    // map EXEMPT to EXEMPT
                        bulkCopy.ColumnMappings.Add("VAT_REG_NO", "VAT_REG_NO");                                            // map VAT_REG_NO to VAT_REG_NO
                        bulkCopy.ColumnMappings.Add("SERVICE_TAX_REGNO", "SERVICE_TAX_REGNO");                              // map SERVICE_TAX_REGNO to SERVICE_TAX_REGNO
                        bulkCopy.ColumnMappings.Add("PAN_NO", "PAN_NO");                                                    // map PAN_NO to PAN_NO
                        bulkCopy.ColumnMappings.Add("TAN_NO", "TAN_NO");                                                    // map DUE_DAYS to DUE_DAYS
                        bulkCopy.ColumnMappings.Add("DUE_DAYS", "DUE_DAYS");                                                // map CR_LMT to CR_LMT
                        bulkCopy.ColumnMappings.Add("CR_LMT", "CR_LMT");                                                    // map CR_LMT to CR_LMT
                        bulkCopy.ColumnMappings.Add("HCA_STATUS", "HCA_STATUS");                                            // map First to first_name
                        bulkCopy.ColumnMappings.Add("HCSUA_STATUS", "HCSUA_STATUS");                                        // map Last to last_name
                        bulkCopy.ColumnMappings.Add("STATUS", "STATUS");                                                    // map Date to first_sale
                        bulkCopy.ColumnMappings.Add("REQUEST_ID", "REQUEST_ID");                                            // map Amount to sale_amount
                        bulkCopy.ColumnMappings.Add("REMARKS", "REMARKS");                                                  // map First to first_name
                        bulkCopy.ColumnMappings.Add("CUSTOMER_CATEGORY", "CUSTOMER_CATEGORY");                              // map Last to last_name
                        bulkCopy.ColumnMappings.Add("CST_BILLING_AVAILABLE", "CST_BILLING_AVAILABLE");                      // map Date to first_sale
                        bulkCopy.ColumnMappings.Add("OLD_MRP_MTRL_ACCEPTABLE", "OLD_MRP_MTRL_ACCEPTABLE");                  // map Amount to sale_amount
                        bulkCopy.ColumnMappings.Add("COLORBANK", "COLORBANK");                                              // map First to first_name
                        bulkCopy.ColumnMappings.Add("EXCLUSIVITY", "EXCLUSIVITY");                                          // map Last to last_name
                        bulkCopy.ColumnMappings.Add("COMPETITION_CLUB", "COMPETITION_CLUB");                                // map Date to first_sale
                        bulkCopy.ColumnMappings.Add("LANGUAGEL_PREFERENCE_1", "LANGUAGEL_PREFERENCE_1");                    // map First to first_name
                        bulkCopy.ColumnMappings.Add("LANGUAGEL_PREFERENCE_2", "LANGUAGEL_PREFERENCE_2");                    // map Last to last_name
                        bulkCopy.ColumnMappings.Add("SECRUITY_QUESTION", "SECRUITY_QUESTION");                              // map Date to first_sale
                        bulkCopy.ColumnMappings.Add("SECURITY_ANSWER", "SECURITY_ANSWER");                                  // map Amount to sale_amount
                        bulkCopy.ColumnMappings.Add("MAX_CHEQUE_VALUE_LIMIT", "MAX_CHEQUE_VALUE_LIMIT");                    // map First to first_name
                        bulkCopy.ColumnMappings.Add("MAX_DAILY_TRANSACTION_LIMIT", "MAX_DAILY_TRANSACTION_LIMIT");          // map MAX_DAILY_TRANSACTION_LIMIT to MAX_DAILY_TRANSACTION_LIMIT
                        bulkCopy.ColumnMappings.Add("BILLING_SYSTEM", "BILLING_SYSTEM");                                    // map BILLING_SYSTEM to BILLING_SYSTEM
                        bulkCopy.ColumnMappings.Add("INTERNET_ACCESS_AT_SHOP", "INTERNET_ACCESS_AT_SHOP");                  // map INTERNET_ACCESS_AT_SHOP to INTERNET_ACCESS_AT_SHOP
                        bulkCopy.ColumnMappings.Add("CUST_BANK_NAME", "CUST_BANK_NAME");                                    // map CUST_BRANCH_NAME to CUST_BRANCH_NAME
                        bulkCopy.ColumnMappings.Add("CUST_BRANCH_NAME", "CUST_BRANCH_NAME");                                // map CUST_BRANCH_NAME to CUST_BRANCH_NAME
                        bulkCopy.ColumnMappings.Add("REGION", "REGION");                                                    // map REGION to REGION
                        bulkCopy.ColumnMappings.Add("ZONE", "ZONE");                                                        // map ZONE to ZONE
                        bulkCopy.ColumnMappings.Add("TIN_NO", "TIN_NO");                                                    // map TIN_NO to TIN_NO
                        bulkCopy.ColumnMappings.Add("PREFERED_TIME", "PREFERED_TIME");                                      // map PREFERED_TIME to PREFERED_TIME
                        bulkCopy.ColumnMappings.Add("LOCATION", "LOCATION");                                                // map LOCATION to LOCATION
                        bulkCopy.ColumnMappings.Add("PRIMARY_CONTACT_NUMBER", "PRIMARY_CONTACT_NUMBER");                    // map PRIMARY_CONTACT_NUMBER to PRIMARY_CONTACT_NUMBER
                        bulkCopy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_1", "ALTERNATE_CONTACT_NUMBER_1");            // map ALTERNATE_CONTACT_NUMBER_1 to ALTERNATE_CONTACT_NUMBER_1
                        bulkCopy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_2", "ALTERNATE_CONTACT_NUMBER_2");            // map ALTERNATE_CONTACT_NUMBER_2 to ALTERNATE_CONTACT_NUMBER_2
                        bulkCopy.ColumnMappings.Add("ALTERNATE_CONTACT_NUMBER_3", "ALTERNATE_CONTACT_NUMBER_3");            // map ALTERNATE_CONTACT_NUMBER_3 to ALTERNATE_CONTACT_NUMBER_3
                        bulkCopy.ColumnMappings.Add("EMAIL_ADDRESS", "EMAIL_ADDRESS");                                      // map EMAIL_ADDRESS to EMAIL_ADDRESS
                        bulkCopy.ColumnMappings.Add("PRIM_PERSON_NAME", "PRIM_PERSON_NAME");                                // map PRIM_PERSON_NAME to PRIM_PERSON_NAME
                        bulkCopy.ColumnMappings.Add("SECD_PERSON_NAME", "SECD_PERSON_NAME");                                // map SECD_PERSON_NAME to SECD_PERSON_NAME
                        bulkCopy.ColumnMappings.Add("THRD_PERSON_NAME", "THRD_PERSON_NAME");                                // map THRD_PERSON_NAME to THRD_PERSON_NAME
                        bulkCopy.ColumnMappings.Add("CREATION_DATE", "CREATION_DATE");                                      // map CREATION_DATE to CREATION_DATE
                        bulkCopy.ColumnMappings.Add("CRM_REQUEST_ID", "CRM_REQUEST_ID");                                    // map CRM_REQUEST_ID to CRM_REQUEST_ID  

                        //inserting Datatable Records to DataBase    
                        con.Open();
                        bulkCopy.WriteToServer(csvdt);
                        //tx.Commit();
                        con.Close();
                        //bulkCopy.Close();
                    }
                    catch (Exception ex)
                    {
                        //tx.Rollback();
                    }
                }
            }
            catch (Exception ex)
            {
                
                bergerlogger.Log("MSCRM.BERGER Data Migration1", "OracleStaggingTable", "Exception occured while Inserting data from Oracle to CRM staging table", ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        #region   [DataFrom Oracle Statgging Table To CRM]
        
        /// <summary>
        ///  Fetching Oracle Account Data
        /// </summary>
        /// <returns></returns>
        public static DataTable fetchOracleAccountdata()
        {
            string ORAProvider = ConfigurationManager.ConnectionStrings["OracleDBConnection"].ConnectionString;
            DataTable dt = new DataTable();
            OracleConnection connection = new OracleConnection(ORAProvider);
            OracleCommand command = new OracleCommand();
            OracleDataAdapter dataAdapter = new OracleDataAdapter(command);
            string OracleQueryFetchStaggingData = ConfigurationManager.AppSettings["OracleQueryFetchStaggingData"];

            try
            {
                connection.Open();
                command.Connection = connection;
                //command.CommandText = OracleQuery;
                command.CommandText = OracleQueryFetchStaggingData;
                command.CommandType = CommandType.Text;
                //command.FetchSize = oracleFetchSize;
                dataAdapter.Fill(dt);

                //if (filewrite == "yes")
                //{
                //    oLogger.Log("OracleServiceAccount", "fetchdata", "Query : " + query, "Row Size: " + command.RowSize + "Fetch Size: " + command.FetchSize);
                //    if (sds.Tables.Count > 0)
                //    {
                //        oLogger.Log("OracleServiceAccount", "fetchdata", "Query : " + query, "No. of tables retrieved : " + sds.Tables.Count.ToString() + "No. of Rows retrieved : " + sds.Tables[0].Rows.Count.ToString());

                //    }
                //}
            }
            catch (Exception exp)
            {
                //oLogger.Log("OracleServiceAccount", "fetchdata", "Query : " + query + "Row Size: " + command.RowSize + "Fetch Size: " + command.FetchSize, " Exception: " + exp.ToString() + exp.StackTrace.ToString());
                bergerlogger.Log("OracleServiceAccount", "CSVToStaggingTable", "Exception occured while Fetching Oracle Data", exp.ToString());
            }
            finally
            {
                dataAdapter.Dispose();
                command.Dispose();
                connection.Close();
                connection.Dispose();
            }
            return dt;
        }        
       

        /// <summary>
        ///  Insert Oracle stagging Data to CRM
        /// </summary>
        public static void Oracle2CRMStagging()
        {
            InsertBulkRecords(fetchOracleAccountdata());          
        }
       #endregion 

       #region [DT to CSV Helper Method]
        /// <summary>
        /// 
        /// </summary>
        /// <param name="datatable"></param>
        /// <param name="seperator"></param>
        /// <returns></returns>
       public static string DataTableToCSV(this DataTable datatable, char seperator)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < datatable.Columns.Count; i++)
            {
                sb.Append(datatable.Columns[i]);
                if (i < datatable.Columns.Count - 1)
                    sb.Append(seperator);
            }
            sb.AppendLine();
            foreach (DataRow dr in datatable.Rows)
            {
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    sb.Append(dr[i].ToString());

                    if (i < datatable.Columns.Count - 1)
                        sb.Append(seperator);
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }
       #endregion
    }
}
