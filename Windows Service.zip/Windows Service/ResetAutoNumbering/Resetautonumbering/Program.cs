﻿//========================================================================
//  This windows service executes on monthly basis.
//  It resets the numbering scheme record for specified entity.
//  In Numbering Scheme Entity based on  reset frequency value it resets the
//  current number to 0.
//
//  Copyright @ Pragmasys Consulting LLP (www.pragmasys.in)
//========================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Microsoft.Xrm.Sdk;
using Microsoft.Win32;
using System.IO;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;

namespace ResetAutonumbering
{
    class Program
    {
        #region Class Level Members

        private static IOrganizationService _service;
        static Logger oLogger;
        static string _loggerPath = string.Empty;
        static string _crmServerUrl = string.Empty;
        static Configuration config;
        static string _orgName = ConfigurationManager.AppSettings["OrgName"];
        public static int Today = DateTime.Now.Day;

        #endregion
        static void Main(string[] args)
        {
            try
            {

                #region Read Registry Key & get Pragmasys.config Path
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }
                #endregion

                /// <summary>
                /// Registry entry not required
                /// If in code want to use configration file 
                /// Add configration file in CRMWeb\ISV folder Pragmasys.config
                /// if Configration file is not used comment the code.      
                /// </summary>
                /// 
                string configpath = DB_path + "\\CRMWeb\\ISV\\" + "\\Berger.config";

                ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
                if (File.Exists(configpath))
                {
                    //  Get configration data     
                    fileMap.ExeConfigFilename = configpath;
                    config = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
                    if (config.AppSettings.Settings.Count > 0)
                    {
                        _loggerPath = config.AppSettings.Settings["loggerfilepath"].Value.ToString();
                        oLogger = new Logger(_orgName, _loggerPath);
                        _crmServerUrl = config.AppSettings.Settings["CRMUrl"].Value.ToString();
                    }
                }

                //get CRM service
                _service = GetService();
                ResetRecordNumber();

            }
            catch (Exception ex)
            {
                oLogger.Log("ResetAutonumbering", "Main", ex.Message, ex.StackTrace.ToString());
            }
        }

        #region Function to Retrive Service
        public static IOrganizationService GetService()
        {
            IOrganizationService _service = null;
            try
            {
                string orgUrl = _crmServerUrl + "/" + "/XRMServices/2011/Organization.svc";
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(orgUrl));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy organizationServiceProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                organizationServiceProxy.EnableProxyTypes();

                _service = (IOrganizationService)organizationServiceProxy;

            }
            catch (Exception ex)
            {
                oLogger.Log("ResetAutonumbering", "GetService", ex.Message, ex.StackTrace.ToString());
            }
            return _service;
        }

        private static TProxy GetProxy<TService, TProxy>(
        IServiceManagement<TService> serviceManagement,
        AuthenticationCredentials authCredentials)
        where TService : class
        where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Function to Restrive Data from Fetch XMl
        private static EntityCollection Retrieve(string strFetchXML)
        {
            RetrieveMultipleResponse oResponse = null;
            try
            {
                FetchXmlToQueryExpressionRequest fetch = new FetchXmlToQueryExpressionRequest();
                fetch.FetchXml = strFetchXML;

                FetchXmlToQueryExpressionResponse qe = (FetchXmlToQueryExpressionResponse)_service.Execute(fetch);

                RetrieveMultipleRequest oRequest = new RetrieveMultipleRequest();
                oRequest.Query = qe.Query;

                oResponse = (RetrieveMultipleResponse)_service.Execute(oRequest);
            }
            catch (Exception ex)
            {
                oLogger.Log("ResetAutonumbering", "Retrieve", ex.Message, ex.StackTrace.ToString());
            }
            return oResponse.EntityCollection;
        }
        #endregion

        #region Function to get NumberingSchema Active Records
        public static EntityCollection getNumberingSchemaRecord()
        {
            EntityCollection Result = null;
            try
            {
                StringBuilder query = new StringBuilder();
                query.Append("<fetch mapping='logical'>");
                query.Append("<entity name='pcl_numberingscheme'>");
                query.Append("<attribute name='pcl_numberingschemeid' />");
                query.Append("<attribute name='pcl_name' />");
                query.Append("<filter type='and'>");
                query.Append("<condition attribute='statecode' operator='eq' value='0' />");
                query.Append("<condition attribute='ber_resetfrequency' operator='eq' value='278290000' />");
                query.Append("</filter>");              
                query.Append("</entity>");
                query.Append("</fetch>");
               
                Result = Retrieve(query.ToString());
            }
            catch (Exception ex)
            {
                oLogger.Log("ResetAutonumbering", "getNumberingSchemaRecord", ex.Message, ex.StackTrace.ToString());
            }
            return Result;
        }
        #endregion

        #region Function to reset record number
        public static void ResetRecordNumber()
        {
            try
            {
                EntityCollection NumberingSchemeColl = getNumberingSchemaRecord();
                foreach (Entity NumberingScheme in NumberingSchemeColl.Entities)
                {
                    Entity newNumberingScheme = new Entity();
                    newNumberingScheme.LogicalName = NumberingScheme.LogicalName;
                    newNumberingScheme.Id = NumberingScheme.Id;
                    newNumberingScheme["pcl_currentnumber"] = 0;
                    _service.Update(newNumberingScheme);
                }

            }
            catch (Exception ex)
            {
                oLogger.Log("ResetAutonumbering", "ResetRecordNumber", ex.Message, ex.StackTrace.ToString());
            }
        }
        #endregion
    }
}
