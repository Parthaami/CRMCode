﻿////********************************** OVERT TRADE LIMIT CHECK*********************************************************//
////vw_OTLimitConfig = Active Meet having sales consideration date less than equal to today
////vw_PrimarySellsIn = Primary Sales data group by Dealer, Product
////******************************************************************************************************************//
//// 1. Meet records having final calculation date earlier than today
//// 2. Primary Sales data having sales in consideration date between sales in consideration date of meet and Today
//// ******************************************************************************************************************//

namespace PainterMeetOTCheck
{
    using System;
    using System.Configuration;
    using System.Data;
    using System.Data.SqlClient;
    using System.Net;
    using System.ServiceModel.Description;
    using Microsoft.Crm.Sdk.Messages;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;

    /// <summary>
    /// Class Program
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Pragmasys logger class object
        /// </summary>
        private static PragmasysLogger bergerlogger = null;

        /// <summary>
        /// Print log variable definition
        /// </summary>
        private static string printLog = string.Empty;
        
        /// <summary>
        /// Retrieve OT Configuration Data
        /// </summary>
        /// <param name="connString">SQL staging database connection string</param>
        /// <returns>OT config view records</returns>        
        public static DataTable RetrieveOTConfigData(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select T1.OT_LIMIT,T1.MEET_ID,T1.PRODUCT_NUM,T1.SELL_IN_DATE,T1.PAINTER_MEET_ID,START_DATE,END_DATE from vw_OTLimitConfig as T1 ";                               
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrieveOTConfigData", ex.Message.ToString(), ex.StackTrace.ToString());
            }

            return dt;
        }
       
        /// <summary>
        /// Method to retrieve data from view PendingLiftingDetails
        /// </summary>
        /// <param name="connString">SQL staging database connection string</param>
        /// <returns>Data table of records</returns>
        public static DataTable RetrievePendingLiftingDetails(string connString)
        {
            DataTable dt = new DataTable();
            try
            {
                string query = "select * from vw_PendingLiftingDetails";
                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrievePendingLiftingDetails", ex.Message.ToString(), ex.StackTrace.ToString());
            }

            return dt;
        }

        /// <summary>
        /// Method to retrieve Sum of verified quantity of lifting details
        /// </summary>
        /// <param name="connString">SQL staging database connection string</param>
        /// <param name="productNum">CRM product, product code</param>
        /// <param name="dealerNum">Dealer code</param>
        /// <param name="startDate">Painter meet start date</param>
        /// <param name="endDate">Painter meet end date</param>
        /// <returns>Sum of verified quantity</returns>
        public static int GetSellsTotal(string connString, string productNum, string dealerNum, DateTime startDate, DateTime endDate)
        {
            DataTable dt = new DataTable();
            int sellsTotal = 0;
            try
            {
                string strStartDate = startDate.Year.ToString() + "-" + startDate.Month.ToString() + "-" + startDate.Day.ToString();
                string strEndDate = endDate.Year.ToString() + "-" + endDate.Month.ToString() + "-" + endDate.Day.ToString();
                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("PainterMeetOTCheck", "GetSellsTotal", "Parameters : ", "productNum : " + productNum + ",dealerNum :" + dealerNum + ",startDate: " + startDate + ",endDate" + endDate);
                }

                string query = "SELECT SUM(VERIFIED_QTY) AS SELLS_TOTAL FROM dbo.vw_OTLiftingDetails " +
                               "WHERE PRODUCT_NUM ='" + productNum + "' AND ACCOUNT_NUM ='" + dealerNum + "' " +
                               "AND (CAST(LD_CREATED_DATE as Date) BETWEEN CAST('" + strStartDate + "' as Date) AND CAST('" + strEndDate + "' as Date))";

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("PainterMeetOTCheck", "GetSellsTotal", "SellsTotal Query : ", query);
                }

                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
                if (dt.Rows.Count > 0 && dt.Rows[0]["SELLS_TOTAL"] != DBNull.Value)
                {
                    sellsTotal = (int)dt.Rows[0]["SELLS_TOTAL"];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return sellsTotal;
        }
   
        /// <summary>
        /// Retrieve Primary Sales data with Sales In Date and Current Date group by Dealer and Product. 
        /// </summary>
        /// <param name="connString">SQL staging database connection string</param>
        /// <param name="salesInDate">Painter meet saleIn consideration date</param>
        /// <param name="strProduct">Product number</param>
        /// <param name="strDealer">Dealer code</param>
        /// <returns>Primary sales total</returns>
        public static decimal RetrievePrimarySalesData(string connString, DateTime salesInDate, string strProduct, string strDealer)
        {
            decimal sellInTotal = 0;
            DataTable dt = new DataTable();
            try
            {
                string strSalesInDate = salesInDate.Year.ToString() + "-" + salesInDate.Month.ToString() + "-" + salesInDate.Day.ToString();
                string strToday = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
                string query = "select DLR_CODE, PRODUCT, SUM(TOTAL_SELL_IN) TOTAL from dbo.vw_PrimarySellsIn " +
                                "where TRX_DATE between '" + strSalesInDate + "' and '" + strToday + "' " +
                                "group by DLR_CODE, PRODUCT " +
                                "having DLR_CODE = '" + strDealer + "' AND PRODUCT = '" + strProduct + "' " +
                                "order by DLR_CODE, PRODUCT";              

                SqlDataAdapter da = new SqlDataAdapter(query, connString);
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    sellInTotal = (decimal)dt.Rows[0]["TOTAL"];
                }

                if (printLog.ToLower() == "yes")
                {
                    bergerlogger.Log("PainterMeetOTCheck", "RetrievePrimarySalesData", "Primary Sales Query", query);
                }
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrievePrimarySalesData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
            finally
            {
                dt.Dispose();
            }

            return sellInTotal;
        }

        /// <summary>
        /// Method to update lifting details status
        /// </summary>
        /// <param name="orgService">CRM service object</param>
        /// <param name="LiftingDetialsId">Lifting details record unique id</param>
        /// <param name="OTStatus">Lifting details updated status</param>
        public static void UpdateLiftingDetailStatus(OrganizationServiceProxy orgService, string LiftingDetialsId, int OTStatus)
        {
            try
            {   
                SetStateRequest request = new SetStateRequest();

                request.State = new OptionSetValue()
                {
                    Value = 0
                };
                request.Status = new OptionSetValue()
                {
                    Value = OTStatus
                };

                request.EntityMoniker = new EntityReference()
                {
                    Id = new Guid(LiftingDetialsId),
                    LogicalName = "ber_liftingdetails"
                };

                SetStateResponse response = (SetStateResponse)orgService.Execute(request);
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "RetrievePrimarySalesData", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

        /// <summary>
        /// Class Program main method
        /// </summary>
        /// <param name="args">Command line arguments</param>
        public static void Main(string[] args)
        {
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["StaggingDBConnectionString"].ConnectionString;
                string org = ConfigurationManager.AppSettings["Org"].ToString();
                string logfilepath = ConfigurationManager.AppSettings["loggerpath"].ToString();
                printLog = ConfigurationManager.AppSettings["PrintLog"].ToString();
                string serverurl = ConfigurationManager.AppSettings["ServerUrl"].ToString();
                int OTHold = Convert.ToInt32(ConfigurationManager.AppSettings["OTHold"].ToString());
                int OTPass = Convert.ToInt32(ConfigurationManager.AppSettings["OTPass"].ToString());
                string verified = ConfigurationManager.AppSettings["Verified"].ToString();
                bergerlogger = new PragmasysLogger(org, logfilepath);

                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["ServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy orgService = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                orgService.EnableProxyTypes();

                DataTable dtOTConfigData = RetrieveOTConfigData(connString);
                DataTable dtPendingLiftingDetailsData = RetrievePendingLiftingDetails(connString);

                decimal maxOTLimit = 0;
                DateTime salesInDate = new DateTime();
                DateTime painterMeetStartDate = new DateTime();
                DateTime painterMeetEndDate = new DateTime();
                string strProduct = string.Empty;
                decimal nPrimarySalesTotal = 0;
                decimal calculatedOTLimit = 0;
                DataTable dtPainterMeetToProcess = null;
                DataRow[] drSelectedConfigDtls = null;
                DataRow[] drToProcessLiftingDetails = null;
                int nSecondarySalesTotal = 0;
                string strDealer = string.Empty;

                if (dtPendingLiftingDetailsData.Rows.Count > 0)
                {
                    dtPainterMeetToProcess = dtPendingLiftingDetailsData.DefaultView.ToTable(true, "PAINTER_MEET_ID");

                    foreach (DataRow dr in dtPainterMeetToProcess.Rows)
                    {
                        drSelectedConfigDtls = dtOTConfigData.Select("PAINTER_MEET_ID ='" + dr["PAINTER_MEET_ID"].ToString() + "'");

                        foreach (DataRow drOTConfigData in drSelectedConfigDtls)
                        {
                            bergerlogger.Log("PainterMeetOTCheck", "Main", "OT_LIMIT: " + drOTConfigData["OT_LIMIT"].ToString() + " SELL_IN_DATE: " + drOTConfigData["SELL_IN_DATE"].ToString() + " PRODUCT_NUM: " + drOTConfigData["PRODUCT_NUM"].ToString(), "START_DATE: " + drOTConfigData["START_DATE"].ToString() + " END_DATE: " + drOTConfigData["END_DATE"].ToString());

                            maxOTLimit = Convert.ToDecimal(drOTConfigData["OT_LIMIT"].ToString());
                            salesInDate = (DateTime)drOTConfigData["SELL_IN_DATE"];
                            strProduct = (string)drOTConfigData["PRODUCT_NUM"];
                            painterMeetStartDate = (DateTime)drOTConfigData["START_DATE"];
                            painterMeetEndDate = (DateTime)drOTConfigData["END_DATE"];

                            drToProcessLiftingDetails = dtPendingLiftingDetailsData.Select("PAINTER_MEET_ID ='" + drOTConfigData["PAINTER_MEET_ID"].ToString() + "' AND PRODUCT_NUM ='" + strProduct + "'");

                            foreach (DataRow drToProcess in drToProcessLiftingDetails)
                            {
                                strDealer = (string)drToProcess["ACCOUNT_NUM"];

                                nSecondarySalesTotal = GetSellsTotal(connString, strProduct, strDealer, painterMeetStartDate.ToLocalTime(), painterMeetEndDate.ToLocalTime());

                                if (printLog.ToLower() == "yes")
                                {
                                    bergerlogger.Log("PainterMeetOTCheck", "Main", "Sales Total: ", nSecondarySalesTotal.ToString());
                                }
                                
                                if (nSecondarySalesTotal > 0)
                                {
                                    nPrimarySalesTotal = RetrievePrimarySalesData(connString, salesInDate.ToLocalTime(), strProduct, strDealer);

                                    if (printLog.ToLower() == "yes")
                                    {
                                        bergerlogger.Log("PainterMeetOTCheck", "Main", "Primary Sales Total: ", nPrimarySalesTotal.ToString());
                                    }

                                    if (nPrimarySalesTotal != 0)
                                    {
                                        calculatedOTLimit = (Convert.ToDecimal(nSecondarySalesTotal) / nPrimarySalesTotal) * 100;
                                        calculatedOTLimit = decimal.Round(calculatedOTLimit, 2);
                                    }
                                    else
                                    {
                                        calculatedOTLimit = maxOTLimit + 1;
                                    }

                                    ////Update Status to OTHold/OTPass
                                    if (calculatedOTLimit > maxOTLimit)
                                    {
                                        UpdateLiftingDetailStatus(orgService, drToProcess["LIFTING_DETAILS_ID"].ToString(), OTHold);
                                        if (printLog.ToLower() == "yes")
                                        {
                                            bergerlogger.Log("PainterMeetOTCheck", "Main", "Lifting Details Id: " + drToProcess["LIFTING_DETAILS_ID"].ToString(), "Status: OTHold" );
                                        }
                                    }
                                    else
                                    {   ////staus is OTPass                             
                                        UpdateLiftingDetailStatus(orgService, drToProcess["LIFTING_DETAILS_ID"].ToString(), OTPass);
                                        if (printLog.ToLower() == "yes")
                                        {
                                            bergerlogger.Log("PainterMeetOTCheck", "Main", "Lifting Details Id: " + drToProcess["LIFTING_DETAILS_ID"].ToString(), "Status: OTPass");
                                        }
                                    }
                                }

                                strDealer = string.Empty;
                                nPrimarySalesTotal = 0;
                                calculatedOTLimit = 0;
                            }

                            maxOTLimit = 0;
                            salesInDate = new DateTime();
                            strProduct = string.Empty;
                            drToProcessLiftingDetails = null;
                        }

                        drSelectedConfigDtls = null;
                    }

                    dtPainterMeetToProcess = null;
                }
            }
            catch (Exception ex)
            {
                bergerlogger.Log("PainterMeetOTCheck", "Main", ex.Message.ToString(), ex.StackTrace.ToString());
            }
        }

       private static TProxy GetProxy<TService, TProxy>(
       IServiceManagement<TService> serviceManagement,
       AuthenticationCredentials authCredentials)
       where TService : class
       where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
    }
}
