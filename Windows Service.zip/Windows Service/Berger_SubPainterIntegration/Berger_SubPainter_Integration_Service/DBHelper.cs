using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Text;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data;
using System.Collections;
using System.Configuration;



namespace Berger_TokenMaster_Integration_Service
{
    class DBHelper
    {
        #region declare all the local Variables

        string _sqlConnectionString = Program.DBConnectionString;
        string _OracleConnectionString = string.Empty;
        
        #endregion

        #region Opend DB Connection
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlConnectionString"></param>
        /// <returns>SqlConnection</returns>
        private SqlConnection OpenDBConnection(string sqlConnectionString)
        {
            SqlConnection _sqlConnection = null;
            try
            {

                _sqlConnection = new SqlConnection();
                _sqlConnection.ConnectionString = sqlConnectionString;
                _sqlConnection.Open();

            }
            catch (Exception ex)
            {
                //  string x= ex.ToString();
            }
            return _sqlConnection;
        }
        #endregion

        #region Close DB Connection
        private void CloseDBConnection(SqlConnection sqlConnection)
        {
            try
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                string x = ex.ToString();
                throw;
            }
        }
        #endregion

        #region Getting the record as DataTable from the Database
        public DataTable GetDataTable(string _sqlConnectionString)
        {
            DataTable _datatable = null;
            SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();
            StringBuilder _sqlQuery = new StringBuilder();             
            try
            {
                
                SqlDataAdapter _sqlAdapter = new SqlDataAdapter();
                StringBuilder _sqlQry = new StringBuilder();
                // Framing the Query string for fetching the data from the corresponding entity staging table. 
                _sqlQuery.Append("SELECT * FROM SubPainter_Integration where status='R'");                
                // Query the database for all of the data in the corresponding entity staging table.
                _sqlDbAdapter = new SqlDataAdapter(_sqlQuery.ToString(), _sqlConnectionString);
                // Create a data set containing the data from the corresponding entity staging table.
                DataSet _dataSet = new DataSet("SubPainter");
                _dataSet.Locale = CultureInfo.InvariantCulture;
                //Fill the DataSet
                _sqlDbAdapter.Fill(_dataSet, "SubPainter");
                // Return the file data as an ADO.NET DataTable.
                _datatable = _dataSet.Tables[0];
                Console.WriteLine("Total data retrieved" +_datatable.Rows.Count.ToString());
            }
            catch (Exception ex)
            {
                throw new Exception("Exception occured while fetching data from staging table");
            }
            finally
            {
                _sqlDbAdapter.Dispose();
            }

            return _datatable;
        }
        #endregion               
              
        #region Updateing the RecordStatus
        public void UpdateRecordStatus(string status, string recordId, string errorMessage)
        {
            SqlConnection _sqlConnection = new SqlConnection();
            try
            {
                string currentDate = DateTime.Now.ToString();
                _sqlConnection = OpenDBConnection(Program.DBConnectionString);
                StringBuilder _sqlQuery = new StringBuilder();

                _sqlQuery.Append("update ");
                _sqlQuery.Append("SubPainter_Integration");
                _sqlQuery.Append(" set Status='");
                _sqlQuery.Append(status);
                _sqlQuery.Append("',");
                _sqlQuery.Append(" ModifiedOn=getdate() ,");
                _sqlQuery.Append("ErrorMsg ='");
                _sqlQuery.Append(errorMessage.Replace("'", ""));
                _sqlQuery.Append("' where SequenceNo='");
                _sqlQuery.Append(recordId+"'");


                SqlCommand _sqlCmd = new SqlCommand(_sqlQuery.ToString(), _sqlConnection);
                int i = _sqlCmd.ExecuteNonQuery();

            }
            catch
            {
                throw;
            }
            finally
            {
                CloseDBConnection(_sqlConnection);
            }

        }
        #endregion
    }
}
