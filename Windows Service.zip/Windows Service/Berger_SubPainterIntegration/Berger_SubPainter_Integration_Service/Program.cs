﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;


namespace Berger_TokenMaster_Integration_Service
{
    class Program
    {
        public static string DBConnectionString = string.Empty;
        public static IOrganizationService _crmService = null;
    
        static void Main(string[] args)
        {             
            try
            {
                #region Private Variable
                string ServerURL = ConfigurationManager.AppSettings["ServerURL"];
                string _userName = "";
                string _password = "";
                string _domain = "";
                string Orgname = ConfigurationManager.AppSettings["Orgname"];                               
                DataTable _SubPainterTable = null; 
                CrmHelper _crmHelper = new CrmHelper();
                DBHelper _dbHelper = new DBHelper();
                #endregion

                DBConnectionString = "Data Source=" + ConfigurationManager.AppSettings["TransactionDataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["TransactionInitialCatalog"] + ";User ID="+ ConfigurationManager.AppSettings["UserName"] + "; Password="+ ConfigurationManager.AppSettings["Password"] + ";";
                  
                #region [Connect with CRM]

                Console.WriteLine("Starting process for migrating");
                if (_crmHelper.ConnectToCRM(ServerURL, Orgname, _userName, _password, _domain))
                {
                    _crmService = _crmHelper.GetCRMService();
                }

                #endregion

                #region [Get Data and Create sub painter]
               
                Console.WriteLine("Retrieving data from Transaction Table");
                _SubPainterTable = _dbHelper.GetDataTable(DBConnectionString);

                if (_SubPainterTable != null && _SubPainterTable.Rows.Count > 0)
                {                                
                    Entity _subPainter=null;
                    foreach (DataRow r in _SubPainterTable.Rows)
                    {                         
                        try
                        {
                            Console.WriteLine("Creating Token Master for " + r["SequenceNo"].ToString() + " record");

                            #region [Create Token Master]

                           #region [Check Painter]
                           DataTable PainterTable = null;
                            string dbConnectionString = "Data Source=" + ConfigurationManager.AppSettings["DataSource"] + ";Initial Catalog=" + ConfigurationManager.AppSettings["Database"] + ";User ID=" + ConfigurationManager.AppSettings["UserName"] + "; Password=" + ConfigurationManager.AppSettings["Password"] + ";";
                           SqlConnection con = new SqlConnection(dbConnectionString);
                           con.Open();
                           string command = "select contactid,ber_DealerId,ber_DepotId,OwnerId,ber_preferredlanguage1,ber_PreferredLanguage2 from Contact where StateCode=0 and mobilephone='" + r["ParentPainterMobile"].ToString() + "' and ber_customertype=278290001";
                           SqlCommand cm = new SqlCommand(command, con);
                           SqlDataAdapter da = new SqlDataAdapter(cm);
                           PainterTable = new DataTable();
                           da.Fill(PainterTable);
                           #endregion
                           if (PainterTable.Rows.Count <= 0)
                           {
                               _dbHelper.UpdateRecordStatus("F", r["SequenceNo"].ToString(), "Parent Painter Not Found");
                               con.Close();                               
                           }
                           else
                           {

                               _subPainter = new Entity("contact");
                               _subPainter.Attributes["ber_parentpainter"] = new EntityReference("contact", new Guid(PainterTable.Rows[0][0].ToString()));
                               _subPainter.Attributes["firstname"] = r["FirstName"].ToString();
                               _subPainter.Attributes["lastname"] = r["LastName"].ToString();
                               _subPainter.Attributes["mobilephone"] = r["SubPainterMobile"].ToString();
                               _subPainter.Attributes["ber_customertype"] = new OptionSetValue(278290001);
                               _subPainter.Attributes["ber_dealerid"] = new EntityReference("account", new Guid(PainterTable.Rows[0]["ber_DealerId"].ToString()));
                               _subPainter.Attributes["ber_depotid"] = new EntityReference("ber_depot", new Guid(PainterTable.Rows[0]["ber_DepotId"].ToString()));
                               _subPainter.Attributes["ownerid"] = new EntityReference("systemuser", new Guid(PainterTable.Rows[0]["OwnerId"].ToString()));
                               if(!string.IsNullOrEmpty( PainterTable.Rows[0]["ber_preferredlanguage1"].ToString()))
                                 _subPainter.Attributes["ber_preferredlanguage1"] = new EntityReference("ber_language", new Guid(PainterTable.Rows[0]["ber_preferredlanguage1"].ToString()));
                               if (!string.IsNullOrEmpty(PainterTable.Rows[0]["ber_PreferredLanguage2"].ToString()))
                                 _subPainter.Attributes["ber_preferredlanguage2"] = new EntityReference("ber_language", new Guid(PainterTable.Rows[0]["ber_PreferredLanguage2"].ToString()));
                               try
                               {
                                   _crmService.Create(_subPainter);
                                   _dbHelper.UpdateRecordStatus("p", r["SequenceNo"].ToString(), "");
                                   _subPainter = null;

                               }
                               catch (Exception ex)
                               {
                                   _dbHelper.UpdateRecordStatus("F", r["SequenceNo"].ToString(), ex.Message);
                               }
                           } 
                          #endregion                    
                            
                            Console.WriteLine("Record migrated successfully");
                        }
                        catch (Exception ex)
                        {
                            _dbHelper.UpdateRecordStatus("F", r["SequenceNo"].ToString(), ex.Message);
                        }
                    }
                   
                }
                #endregion
            }
            catch (Exception ex)
            { }
            
        }         
    }
}
