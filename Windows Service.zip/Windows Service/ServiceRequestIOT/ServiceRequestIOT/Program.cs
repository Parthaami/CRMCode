﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Data.OleDb;
using System.Data;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Crm.Sdk.Messages;
using System.Data.SqlClient;
using System.Globalization;
using System.ServiceModel;
using System.Threading.Tasks;


namespace ServiceRequestIOT
{
    class Program
    {
        #region declare all the local/Global Variables
        public static IOrganizationService _service;
        public static IOTLogger bergerlogger = IOTLogger.Instance;
        public static string _sqlConnectionString = ConfigurationManager.ConnectionStrings["db_connection"].ConnectionString;

        public static string SrType          = ConfigurationManager.AppSettings["SrType"].ToString();
        public static string subSrtype       = ConfigurationManager.AppSettings["subSrtype"].ToString();
        public static string CustomerID      = ConfigurationManager.AppSettings["CustomerID"].ToString();
        public static string createdby       = ConfigurationManager.AppSettings["createdby"].ToString();
        public static string resolutionType  = ConfigurationManager.AppSettings["ResolutionType"].ToString();
        public static string priority        = ConfigurationManager.AppSettings["Priority"].ToString();
        public static string organizationURL = ConfigurationManager.AppSettings["CRMOrgServiceUrl"].ToString();
        #endregion

        static void Main(string[] args)
        {
            bergerlogger.Log("IOT Console for MCC SR data ", "Main Start", "---:  IOT Job Started :---", System.DateTime.Now.ToString());
            try
            {
                ConnectToMSCRM(organizationURL);

                OpenDBConnection(_sqlConnectionString);
                DataTable dt = GetDataTable(_sqlConnectionString);

                string leadId = "";
                string iotserial = "";
                string SrInfoLead = "";

                //Parallel.ForEach(dt.AsEnumerable(), drow =>
                foreach(DataRow drow in dt.Rows)
                {
                    leadId = drow["MCC_LEAD_ID"].ToString();
                    iotserial = drow["MCC_IOTSERIALKEY"].ToString();
                    SrInfoLead = GetLeadInfonNSRinCRM(leadId, iotserial, SrType, subSrtype, CustomerID, createdby, resolutionType, priority, _service);
                    
                    if (SrInfoLead != "")
                    {
                        UpdateRecordStatus("P", SrInfoLead, iotserial, "", _sqlConnectionString);
                    }
                    else
                    {
                        UpdateRecordStatus("F", "", iotserial, "Lead Id Not found", _sqlConnectionString);
                    }

                }
                //);

            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestIOT", "Main", "---: IOT JOB STATUS Error :---", ex.Message.ToString());
            }


            bergerlogger.Log("IOT Console for MCC SR data", "Main End", "---: IOT JOB End :---", System.DateTime.Now.ToString());

        }

        #region Opend DB Connection
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sqlConnectionString"></param>
        /// <returns>SqlConnection</returns>
        static private SqlConnection OpenDBConnection(string sqlConnectionString)
        {
            SqlConnection _sqlConnection = null;
            try
            {
                _sqlConnection = new SqlConnection();
                _sqlConnection.ConnectionString = sqlConnectionString;
                _sqlConnection.Open();

            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestIOT", "OpenDBConnection", "---: IOT JOB STATUS Error Open connection:---", ex.Message.ToString());
            }
            return _sqlConnection;
        }
        #endregion

        #region Close DB Connection
        private static void CloseDBConnection(SqlConnection sqlConnection)
        {
            try
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            catch (Exception ex)
            {
                //string x = ex.ToString();
                bergerlogger.Log("ServiceRequestIOT", "CloseDBConnection", "---: IOT JOB STATUS Error Colse connection:---", ex.Message.ToString());
                //throw;
            }
        }
        #endregion

        #region Getting the record as DataTable from the Database
        public static DataTable GetDataTable(string _sqlConnectionString)
        {
            DataTable _datatable = null;
            SqlDataAdapter _sqlDbAdapter = new SqlDataAdapter();
            StringBuilder _sqlQuery = new StringBuilder();
            try
            {

                SqlDataAdapter _sqlAdapter = new SqlDataAdapter();
                StringBuilder _sqlQry = new StringBuilder();
                // Framing the Query string for fetching the data from the corresponding entity staging table. 
                _sqlQuery.Append("select * from MCC_IOT_LEAD_ServReq where MCC_LRED_STATUS='R'");
                // Query the database for all of the data in the corresponding entity staging table.
                _sqlDbAdapter = new SqlDataAdapter(_sqlQuery.ToString(), _sqlConnectionString);
                // Create a data set containing the data from the corresponding entity staging table.
                DataSet _dataSet = new DataSet("MCC_IOT_Lead");
                _dataSet.Locale = CultureInfo.InvariantCulture;
                //Fill the DataSet
                _sqlDbAdapter.Fill(_dataSet, "MCC_IOT_Lead");
                // Return the file data as an ADO.NET DataTable.
                _datatable = _dataSet.Tables[0];
                Console.WriteLine("Total data retrieved" + _datatable.Rows.Count.ToString());
            }
            catch (Exception ex)
            {

                bergerlogger.Log("ServiceRequestIOT", "GetDataTable", "Error while fatching data from Stagging Table", ex.Message.ToString());
            }
            finally
            {
                _sqlDbAdapter.Dispose();
            }
            return _datatable;
        }
        #endregion

        #region Updateing the RecordStatus
        public static void UpdateRecordStatus(string status, string recordId, string MCC_IOTSERIALKEY,string errorMessage, string _sqlConnectionString)
        {
            SqlConnection _sqlConnection = new SqlConnection();
            try
            {
                string currentDate = DateTime.Now.ToString();
                _sqlConnection = OpenDBConnection(_sqlConnectionString);
                StringBuilder _sqlQuery = new StringBuilder();

                _sqlQuery.Append("update ");
                _sqlQuery.Append("MCC_IOT_LEAD_ServReq");
                _sqlQuery.Append(" set MCC_LRED_STATUS='");
                _sqlQuery.Append(status);
                _sqlQuery.Append("',");
                _sqlQuery.Append("MCC_LEAD_GUID='");
                _sqlQuery.Append(recordId.Trim());
                _sqlQuery.Append("',");
                _sqlQuery.Append("MCC_LEAD_MODIFIEDON=getdate() ,");
                _sqlQuery.Append("MCC_LEAD_ERRORMSG ='");
                _sqlQuery.Append(errorMessage.Replace("'", ""));
                _sqlQuery.Append("' where MCC_IOTSERIALKEY='");
                _sqlQuery.Append(MCC_IOTSERIALKEY.Trim());
                _sqlQuery.Append("'");   //adddddd

                SqlCommand _sqlCmd = new SqlCommand(_sqlQuery.ToString(), _sqlConnection);
                int i = _sqlCmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                //throw;
                bergerlogger.Log("ServiceRequestIOT", "UpdateRecordStatus", "Error while Updating status in Stagging Table", ex.Message.ToString());
            }
            finally
            {
                CloseDBConnection(_sqlConnection);
            }

        }
        #endregion

        #region CRM Connection 
        public static void ConnectToMSCRM(string SoapOrgServiceUri)
        {
            try
            {
                IServiceManagement<IOrganizationService> orgServiceManagement =
                ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                new Uri(ConfigurationManager.AppSettings["ServerUrl"].ToString()));

                AuthenticationCredentials authCredentials = new AuthenticationCredentials();

                authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["username"].ToString();
                authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["password"].ToString();

                OrganizationServiceProxy organizationServiceProxy = GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, authCredentials);
                organizationServiceProxy.EnableProxyTypes();

                _service = (IOrganizationService)organizationServiceProxy;
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestIOT", "ConnectToMSCRM", "---: IOT JOB STATUS Error Oranization service :---", ex.Message.ToString());
            }

        }

        private static TProxy GetProxy<TService, TProxy>(
         IServiceManagement<TService> serviceManagement,
         AuthenticationCredentials authCredentials)
         where TService : class
         where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }
        #endregion

        #region Get Lead Info from CRM Application
        public static string GetLeadInfonNSRinCRM(string LeadID, string srmcckey, string SrType, string subSrtype, string CustomerID, string createdby, string resolutionType, string priority,IOrganizationService orgService)
        {
            string result = string.Empty;
            try
            {
                string resultleadid = String.Empty;
                string resultdepotid = String.Empty;
                string resultownerid = String.Empty;


                //Retrive Data from Lead ID ........
                QueryExpression query = new QueryExpression
                {
                    EntityName = "lead",
                    ColumnSet = new ColumnSet(new string[]
                {
                    "ber_depotid",
                    "leadid",
                    "ownerid"
                    
                }),
                    Criteria =
                    {
                        Conditions = 
                                {
                                    new ConditionExpression("subject", ConditionOperator.Equal, LeadID)
                                }
                    }
                };

                Entity GettingLeadEntity = orgService.RetrieveMultiple(query).Entities[0];

                if (!string.IsNullOrEmpty(GettingLeadEntity["leadid"].ToString()))
                {
                    resultleadid = GettingLeadEntity["leadid"].ToString();
                    resultdepotid = GettingLeadEntity.GetAttributeValue<EntityReference>("ber_depotid").Id.ToString();
                    resultownerid = GettingLeadEntity.GetAttributeValue<EntityReference>("ownerid").Id.ToString();
                    result = resultleadid;
                }
                else
                {
                    result = string.Empty;
                }

                //Create SR Data in  in CRM .........
                Entity _incident = new Entity("incident");
                _incident.Attributes["ber_leadid"] = new EntityReference("lead", new Guid(resultleadid));
                _incident.Attributes["ber_depot"] = new EntityReference("ber_depot", new Guid(resultdepotid));
                // _incident.Attributes["ownerid"] = new Guid(createdby);
                _incident.Attributes["ber_iotserialkey"] = srmcckey;//ADDED BY SOUMEN
                _incident.Attributes["customerid"] = new EntityReference("account", new Guid(CustomerID));

                _incident.Attributes["pcl_srtypeid"] = new EntityReference("pcl_srtype", new Guid(SrType));
                _incident.Attributes["pcl_subsrtypeid"] = new EntityReference("pcl_subsrtype", new Guid(subSrtype));
                _incident.Attributes["pcl_resolutiontype"] = new OptionSetValue(Convert.ToInt32(resolutionType));
                _incident.Attributes["prioritycode"] = new OptionSetValue(Convert.ToInt32(priority));

                orgService.Create(_incident);

            }
            catch (FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                bergerlogger.Log("ServiceRequestIOT", "GetLeadInfoCRM", "---: IOT JOB End :---", ex.Message.ToString());
                result = "";
            }
            catch (Exception ex)
            {
                bergerlogger.Log("ServiceRequestIOT", "GetLeadInfoCRM", "---: IOT JOB End :---", ex.Message.ToString());
                result = "";
            }
            finally
            {

            }

            return result;
        }
        #endregion
    }      
}
