﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using Microsoft.Xrm.Sdk.Client;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.Net.Mail;



namespace SubmitOrderToERP
{
    class Program
    {
        static void Main(string[] args)
        {

            try
            {

                #region Read Registry Key & get Pragmasys.config Path
                string CRMpath = @"SOFTWARE\Microsoft\MSCRM";
                string keyValue = "CRM_Server_InstallDir";
                string value64 = string.Empty;
                string value32 = string.Empty;
                string DB_path = string.Empty;

                RegistryKey localKey = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry64);
                localKey = localKey.OpenSubKey(CRMpath);
                if (localKey != null)
                {
                    if (localKey.GetValue(keyValue) != null)
                    {
                        value64 = localKey.GetValue(keyValue).ToString();
                        DB_path = value64;
                    }
                }
                RegistryKey localKey32 = RegistryKey.OpenBaseKey(Microsoft.Win32.RegistryHive.LocalMachine, RegistryView.Registry32);
                localKey32 = localKey32.OpenSubKey(CRMpath);
                if (localKey32 != null)
                {
                    if (localKey32.GetValue(keyValue) != null)
                    {
                        value32 = localKey32.GetValue(keyValue).ToString();
                        DB_path = value32;
                    }
                }
                #endregion


            }

            catch (Exception ex)
            {

            }


        }
    }
}
