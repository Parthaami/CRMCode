function DisableFormOnLaunched()
{
//debugger;
	if(Xrm.Page.getAttribute("ber_paintermeet").getValue() != null && Xrm.Page.getAttribute("ber_paintermeet").getValue() != undefined)
	{
		var PainterMeetId = Xrm.Page.getAttribute("ber_paintermeet").getValue()[0].id;
		var columns = ['ber_ApprovalStatus'];
        var filter = "ber_paintermeetId eq (Guid'" + PainterMeetId + "')";
        var collection = CrmRestKit.RetrieveMultiple('ber_paintermeet', columns, filter);
		if (collection != null && collection.results != null && collection.results.length > 0) 
	    {
			if (collection.results[0].ber_ApprovalStatus != null) 
			{
				if(collection.results[0].ber_ApprovalStatus.Value == 278290002 || collection.results[0].ber_ApprovalStatus.Value == 278290005 || collection.results[0].ber_ApprovalStatus.Value == 278290006||collection.results[0].ber_ApprovalStatus.Value == 278290000 )
				{
					Xrm.Page.getControl("ber_paintermeet").setDisabled(true);
					Xrm.Page.getControl("ber_product").setDisabled(true);
					Xrm.Page.getControl("ber_loadinginpoints").setDisabled(true);
					Xrm.Page.getControl("ber_otlimit").setDisabled(true);
					if(collection.results[0].ber_ApprovalStatus.Value == 278290000)
                                                                                                       {
					alert('Scheme is already approved ! No products can be added!');
					}
                                                                                                    else    if(collection.results[0].ber_ApprovalStatus.Value == 278290002)
                                                                                                       {
					alert('Scheme is already launched ! No products can be added!');
					}
                                                                                                     else
                                                                                                        {
                                                                                                          alert(' No products can be added!');
                                                                                                        }
					Xrm.Page.ui.close();
				}
			}
	    }
	}
}


function ApplyProductLookupFilter() 
 {
 // debugger;
    if (Xrm.Page.getAttribute("ber_paintermeet").getValue() != null && Xrm.Page.getAttribute("ber_paintermeet").getValue() != undefined)
       {
        
         var painterMeetName = null;
         var painterMeetId=null;
                 painterMeetName =Xrm.Page.getAttribute("ber_paintermeet").getValue()[0].name;
                 painterMeetId=Xrm.Page.getAttribute("ber_paintermeet").getValue()[0].id;
		//    painterMeet=Xrm.Page.getAttribute("ber_paintermeet").getValue();
		//    if(painterMeetId!=null)
		    {
			   
            var    isDefaultView = 'true';
        var       layoutxml = '<grid name="resultset" object="1024" jump="name" select="1" icon="1" preview="1">'
                                    + '<row name="result" id="ber_product">'
                                    + '<cell name="ber_name" width="300" />'
                               //     + '<cell name="createdon" width="125" />'
                                    + '</row>'
                                    + '</grid>';

      var  fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">'
					+'<entity name="product">'
					+' <attribute name="name" />'
					+'    <attribute name="productnumber" />'
					//+'    <attribute name="productid" />'
					//+'    <attribute name="defaultuomid" />'
					//+'    <attribute name="ber_shadeid" />'
					+ '   <order attribute="name" descending="false" />'
					+'    <link-entity name="ber_meetproduct" from="ber_product" to="productid" alias="aa">'
					+'      <filter type="and">'
					+'        <condition attribute="ber_paintermeet" operator="eq" uiname="'+painterMeetName +'" uitype="ber_paintermeet" value="'+painterMeetId+'" />'
					+'      </filter>'
					+'    </link-entity>'
					+'  </entity>'
					+'</fetch>';
					
			viewDisplayName = 'Related Products';
            viewId = GetuniqueGuid();

           Xrm.Page.getControl('ber_product').addCustomView(viewId, 'product', viewDisplayName, fetchxml, layoutxml,1);
           Xrm.Page.getControl('ber_product').setDefaultView(viewId);
            }
       }
}
function GetuniqueGuid() {

    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };

    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';

};
 