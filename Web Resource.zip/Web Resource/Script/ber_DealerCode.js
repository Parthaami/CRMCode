function retriveFax() {
    var collection;
    if (Xrm.Page.getAttribute("ber_dealerid") != null && Xrm.Page.getAttribute("ber_dealerid").getValue() != null && Xrm.Page.getAttribute("ber_dealerid").getValue() != "") {
        var lookupValue = Xrm.Page.getAttribute("ber_dealerid").getValue();
        var BillToId = lookupValue[0].id;
        BillToId = BillToId.replace("{", "").replace("}", "");

        $.ajax({
            type: "GET",
            async: false,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + BillToId + ")?$select=accountnumber",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processdata: false,
            crossDomain: true,
            success: function (msg) {
                collection = msg;
            },
            error: function (msg) {
                alert('error fetching the accounts information from crm organization');
            },
        });

        if (collection != null) {
            if (collection["AccountNumber"] != null) {
                var mobno = collection["AccountNumber"];
                Xrm.Page.getAttribute("ber_dealeroraclecode").setValue(mobno);
            }
        }

    }
}