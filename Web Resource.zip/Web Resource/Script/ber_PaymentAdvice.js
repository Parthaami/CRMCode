function Confirm() {
    
	var workflowId = '681AD9D7-28BF-4CF8-88A7-39AF0CC7E6C7'; //workflow: Confirm Payment Advice
    RunWorkflow(workflowId);
	
	Xrm.Page.getAttribute('ber_disableworkflow').setValue(true);
    Xrm.Page.data.entity.save();
}

function Cancel() 
{
    var workflowId = '2A4D2BD8-5D5C-4A71-AEC4-9C53314BCDE5'; //workflow: Cancel Payment Advice
    RunWorkflow(workflowId);

    Xrm.Page.getAttribute('ber_disableworkflow').setValue(true);
    Xrm.Page.data.entity.save();
}

function RunWorkflow(workflowId) {
    var url = Xrm.Page.context.getServerUrl();
    var entityId = Xrm.Page.data.entity.getId();    
    var OrgServicePath = "/XRMServices/2011/Organization.svc/web";
    url = url + OrgServicePath;
    var request;
    request = "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
                      "<s:Body>" +
                        "<Execute xmlns=\"http://schemas.microsoft.com/xrm/2011/Contracts/Services\" xmlns:i=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                          "<request i:type=\"b:ExecuteWorkflowRequest\" xmlns:a=\"http://schemas.microsoft.com/xrm/2011/Contracts\" xmlns:b=\"http://schemas.microsoft.com/crm/2011/Contracts\">" +
                            "<a:Parameters xmlns:c=\"http://schemas.datacontract.org/2004/07/System.Collections.Generic\">" +
                              "<a:KeyValuePairOfstringanyType>" +
                                "<c:key>EntityId</c:key>" +
                                "<c:value i:type=\"d:guid\" xmlns:d=\"http://schemas.microsoft.com/2003/10/Serialization/\">" + entityId + "</c:value>" +
                              "</a:KeyValuePairOfstringanyType>" +
                              "<a:KeyValuePairOfstringanyType>" +
                                "<c:key>WorkflowId</c:key>" +
                                "<c:value i:type=\"d:guid\" xmlns:d=\"http://schemas.microsoft.com/2003/10/Serialization/\">" + workflowId + "</c:value>" +
                              "</a:KeyValuePairOfstringanyType>" +
                            "</a:Parameters>" +
                            "<a:RequestId i:nil=\"true\" />" +
                            "<a:RequestName>ExecuteWorkflow</a:RequestName>" +
                          "</request>" +
                        "</Execute>" +
                      "</s:Body>" +
                    "</s:Envelope>";

    var req = new XMLHttpRequest();
    req.open("POST", url, true)
    // Responses will return XML. It isn't possible to return JSON.
    req.setRequestHeader("Accept", "application/xml, text/xml, */*");
    req.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
    req.setRequestHeader("SOAPAction", "http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute");
    req.onreadystatechange = function () { assignResponse(req); };
    req.send(request);
}

function assignResponse(req) {
    if (req.readyState == 4) {
        if (req.status == 200) {
            //alert('successfully executed the workflow');
        }
    }
}