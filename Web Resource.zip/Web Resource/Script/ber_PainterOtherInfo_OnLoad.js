/**************
Developer : Madhumita
Date : 06/08/2018
Ticket: =#233(Key contractor functionality)
Method: change fields behavior based on form type
***************/


// Note: Form type codes: Create (1), Update (2), Read Only (3), Disabled (4), Bulk Edit (6)

function AlertFormType() {
    var FormType = Xrm.Page.ui.getFormType();
    if (FormType != null) {
        // If create form then
        if (FormType == 1) {
            // Do Nothing
        }

        // If update form then make depot,mobile & type fields disabled
        else if (FormType == 2) {
            if ((UserHasRole("Depot User")) || (UserHasRole("Call Center User"))) {
                Xrm.Page.getControl("ber_depot").setDisabled(true);
                Xrm.Page.getControl("ber_mobilenumber").setDisabled(true);
                Xrm.Page.getControl("ber_type").setDisabled(true);
            }
            else if ((UserHasRole("System Administrator"))) {
                Xrm.Page.getControl("ber_depot").setDisabled(false);
                Xrm.Page.getControl("ber_mobilenumber").setDisabled(false);
                Xrm.Page.getControl("ber_type").setDisabled(false);
            }
        }

        else {

        }
    }

}