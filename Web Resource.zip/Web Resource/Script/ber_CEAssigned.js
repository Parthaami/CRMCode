// JavaScript source code
function CEAssigned() {
    if (Xrm.Page.getAttribute("ber_whowill") != undefined && Xrm.Page.getAttribute("ber_whowill") !== null) {
        if (UserHasRole("System Administrator") || UserHasRole("Depot User") || UserHasRole("Depot Home Decor User")) {
            //var today = new Date();
            //   var localTime = new Date()
            var today = getServerTime();


            //  alert('Server Date :' + today);
            //  alert('Locale Date :' + localTime);

            var HDEmployee = Xrm.Page.data.entity.attributes.get("ber_whowill").getValue();
            if (Xrm.Page.getAttribute("ber_dgcontact").getValue() != null && Xrm.Page.getAttribute("ber_dgcontact") != undefined) {
                var DGCSM = Xrm.Page.getAttribute("ber_dgcontact").getValue();
            }

            if (Xrm.Page.getAttribute("ber_leadtype") !== undefined && Xrm.Page.getAttribute("ber_leadtype") !== null) {
                var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();

            }

            //var StatusReason = Xrm.Page.getAttribute("statuscode");

            var StatusReasonValue = Xrm.Page.getAttribute("statuscode").getValue();

            if (HDEmployee != null && StatusReasonValue == 1 && leadtype == 278290002) {

                if (Xrm.Page.getAttribute("ber_capturece") != undefined && Xrm.Page.getAttribute("ber_capturece").getValue() == null) {

                    var CaptureDate = Xrm.Page.getAttribute("ber_capturece").setValue(today);

                    Xrm.Page.getAttribute("ber_capturece").setSubmitMode("always");
                    Xrm.Page.getAttribute("statuscode").setValue(278290032);
                    Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
                    Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
                }

            }

            else if (leadtype == 278290001 && DGCSM != null && StatusReasonValue == 1) {

                if (Xrm.Page.getAttribute("ber_capturece") != undefined && Xrm.Page.getAttribute("ber_capturece").getValue() == null) {

                    var CaptureDate = Xrm.Page.getAttribute("ber_capturece").setValue(today);
                    Xrm.Page.getAttribute("ber_capturece").setSubmitMode("always");
                    Xrm.Page.getAttribute("statuscode").setValue(278290032);
                    Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
                    Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
                }
            }

            else if (leadtype == 278290001 && DGCSM == null) {
                Xrm.Page.getAttribute("ber_capturece").setValue(null);
                Xrm.Page.getAttribute("ber_capturece").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_daysexceededoverceassigned").setValue(null);
                // Xrm.Page.getAttribute("ber_daysexceededoverceassigned").setSubmitMode("always");                
            }
            else {
            }
        }
    }
    else {
        Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);
    }
}







function Noofdays() {
    if (Xrm.Page.data.entity.attributes.get("statuscode").getValue() == 278290032 && Xrm.Page.data.entity.attributes.get("statuscode").getValue() != undefined) {
        var Status = Xrm.Page.data.entity.attributes.get("statuscode").getValue();


        if (Xrm.Page.data.entity.attributes.get("ber_capturece") != undefined && Xrm.Page.data.entity.attributes.get("ber_capturece").getValue() != null) {
            var DateCapture = Xrm.Page.data.entity.attributes.get("ber_capturece").getValue();

        }
        var today = new Date();

        if (today != null && DateCapture != null) {

            var Days = calculateDays(today, DateCapture);

        }

        if (Xrm.Page.data.entity.attributes.get("ber_daysexceededoverceassigned") != null && Xrm.Page.data.entity.attributes.get("ber_daysexceededoverceassigned") != undefined) {
            var DaysExceeded = Xrm.Page.data.entity.attributes.get("ber_daysexceededoverceassigned");

        }

        if ((DateCapture != null) || (DateCapture != undefined)) {

            if (Days != null && Days != undefined) {
                DaysExceeded.setValue(Days);
                Xrm.Page.getAttribute("ber_daysexceededoverceassigned").setSubmitMode("always");

            }

        }
    }

}


function calculateDays(datetime1, datetime2) {
    var oneDay = 1000 * 60 * 60 * 24;        // The number of milliseconds in a day
    //Convert the datetime1 and datetime2 to Date object and get Time in milliseconds

    var dt1 = new Date(datetime1).getTime();
    var dt2 = new Date(datetime2).getTime();

    // Calculate the difference in milliseconds
    var diff = Math.abs(dt1 - dt2); // Difference of Days

    return Math.round(diff / oneDay);
}









function CE() {

    if (Xrm.Page.getAttribute("ber_whowill") !== undefined && Xrm.Page.getAttribute("ber_whowill") !== null) {
        if (Xrm.Page.getAttribute("statuscode") !== undefined && Xrm.Page.getAttribute("statuscode") !== null) {
            var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");

            var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

            if (StatusReasonValue == 278290032)
                StatusReason.setValue(278290032);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
            Xrm.Page.ui.controls.get("statuscode").setDisabled(true);

        }

    }

}


function SetHDEmployee() {
    if (Xrm.Page.getAttribute("ber_whowill") !== undefined && Xrm.Page.getAttribute("ber_whowill").getValue() !== null) {

        Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");
        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

        if (Xrm.Page.getAttribute("ber_dgcontact") !== undefined && Xrm.Page.getAttribute("ber_dgcontact").getValue() !== null) {
            var DGContact = Xrm.Page.data.entity.attributes.get("ber_dgcontact");
            // var DGContactId = DGContact[0].id;

        }

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }


        if (leadtype == 278290001 && StatusReasonValue == 278290032 && DGContact != null) {


            if (Xrm.Page.getAttribute("ber_dgcontact") !== undefined && Xrm.Page.getAttribute("ber_dgcontact") !== null) {
                var HDEmp = new Array();
                HDEmp[0] = new Object();
                HDEmp[0].id = DGContact.getValue()[0].id;
                HDEmp[0].name = DGContact.getValue()[0].name;
                HDEmp[0].entityType = "contact";
                Xrm.Page.getAttribute("ber_hdemployeeid").setValue(HDEmp);
                Xrm.Page.getAttribute("ber_hdemployeeid").setSubmitMode("always");

            }

        }
    }

}



function SetStatusQuotation() {

    if (Xrm.Page.getAttribute("ber_quotationvalue") !== undefined && Xrm.Page.getAttribute("ber_quotationvalue") !== null) {

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        var QuotationValue = Xrm.Page.getAttribute("ber_quotationvalue").getValue();
        if (leadtype == 278290002 && StatusReasonValue == 278290009 && QuotationValue != null) {

            Xrm.Page.data.entity.attributes.get("statuscode").setValue(278290026);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");

        }

       

        else {


        }

    }
}



function NextVisitCount() {
    if (Xrm.Page.getAttribute("ber_nextvisitdate") !== undefined && Xrm.Page.getAttribute("ber_nextvisitdate").getValue() !== null) {

        if (Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged") !== undefined && Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged") !== null) {

            var Count = Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged").getValue();

        }

        if (Count == null) {
            Count = 1;
            Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged").setValue(Count);
            Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged").setSubmitMode("always");
            alert(Count);
        }

        else if (Count != null) {

            Count = Count + 1;
            Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged").setValue(Count);
            Xrm.Page.getAttribute("ber_nooftimesnextvisitchanged").setSubmitMode("always");
            alert(Count);


        }


        else {

            

        }
      

    }

}



function SetStatusQuotationLBHP() {

    if (Xrm.Page.getAttribute("ber_lbhpquotationvalue") !== undefined && Xrm.Page.getAttribute("ber_lbhpquotationvalue") !== null) {

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }



        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        var QuotationValue = Xrm.Page.getAttribute("ber_lbhpquotationvalue").getValue();
        if (leadtype == 278290001 && StatusReasonValue == 278290032 && QuotationValue != null) {

            Xrm.Page.data.entity.attributes.get("statuscode").setValue(278290026);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");

        }



        else {


        }

    }
}








function SetStatusQuotationLBHPonload() {

    if (Xrm.Page.getAttribute("ber_lbhpquotationvalue") !== undefined && Xrm.Page.getAttribute("ber_lbhpquotationvalue") !== null) {

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

    

        if (Xrm.Page.getAttribute("ber_wondate").getValue() != null && Xrm.Page.getAttribute("ber_wondate") != undefined) {

            var wondate = Xrm.Page.getAttribute("ber_wondate").getValue();
        }


        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        var QuotationValue = Xrm.Page.getAttribute("ber_lbhpquotationvalue").getValue();
        if (QuotationValue != null && wondate != null) {

            Xrm.Page.data.entity.attributes.get("statuscode").setValue(278290026);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");

        }



        else {


        }

    }
}

//function getServerTime() {
//    return $.ajax({ async: false }).getResponseHeader('Date');
//}

var xmlHttp;
function getServerTime() {
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD', window.location.href.toString(), false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    // addMinutes(xmlHttp.getResponseHeader("Date"), 330)
    var addmin = addMinutes(xmlHttp.getResponseHeader("Date"));

    return addmin
}

function addMinutes(date) {
    var d = new Date(date);
    // alert(typeof (d));
    //return new Date(d.getTime() + 330 * 60000);
    //d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000);
    return d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000)

}






/*********************

Developed By: Madhumita
Method Name: RetrieveUrbanRural
Purpose: to retrieve the territory type
Date: 12/10/2018
Ticket : 


**********************/

var Terrcode;
function RetrieveUrbanRural() {

    if (Xrm.Page.getAttribute("statuscode").getValue() != null && Xrm.Page.getAttribute("statuscode") != undefined) {
        var statusReason = Xrm.Page.getAttribute("statuscode").getValue();
        if (statusReason == 278290032) {
            if (Xrm.Page.getAttribute("ber_tsiid2").getValue() != null && Xrm.Page.getAttribute("ber_tsiid2") != undefined) {
                var TSI = Xrm.Page.getAttribute("ber_tsiid2").getValue();
                var TSIId = TSI[0].id;
                var modifiedTSIId = TSIId.replace("{", "").replace("}", "");
                //req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis?$select=_ber_depotid_value,ber_mobilenumber,ber_name,ber_tsiid&$expand=ber_terr_code($select=ber_territorytype)&$filter=ber_tsiid eq '" + modifiedTSIId + "' and  statecode eq 0", false);

                var url = "$select=ber_name,_ber_terr_code_value,ber_tsiid&$filter=ber_tsiid eq " + modifiedTSIId + " and  statecode eq 0";
                // var url = "$select=_ber_depotid_value,ber_mobilenumber,ber_name,ber_tsiid&$expand=ber_terr_code($select=ber_territorytype)&$filter=ber_tsiid eq " + modifiedTSIId + " and  statecode eq 0
                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis?" + url, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

                req.send();
                if (req.response != null && req.response != "") {
                    var results = JSON.parse(req.response);
                    if (results != null) {
                        //no duplicate record should be allowed
                        if (results.value.length > 0) {

                            var ber_name = results.value[0]["ber_name"];
                            var _ber_terr_code_value = results.value[0]["_ber_terr_code_value"];
                            var _ber_terr_code_value_formatted = results.value[0]["_ber_terr_code_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_terr_code_value_lookuplogicalname = results.value[0]["_ber_terr_code_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var ber_tsiid = results.value[0]["ber_tsiid"];
                            Terrcode = _ber_terr_code_value;
                            // alert(Terrcode);
                        }

                    }
                }
                //  alert(Terrcode);
                var url1 = "$select=ber_territory,ber_territorytype,territoryid&$filter=territoryid eq " + Terrcode;
                var req1 = new XMLHttpRequest();
                req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/territories?" + url1, false);
                req1.setRequestHeader("OData-MaxVersion", "4.0");
                req1.setRequestHeader("OData-Version", "4.0");
                req1.setRequestHeader("Accept", "application/json");
                req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

                req1.send();
                if (req1.response != null && req1.response != "") {
                    var results1 = JSON.parse(req1.response);
                    //for (var i = 0; i < results.value.length; i++) {
                    if (results1 != null) {
                        //no duplicate record should be allowed
                        if (results1.value.length > 0) {
                            var ber_territory = results1.value[0]["ber_territory"];
                            var ber_territorytype = results1.value[0]["ber_territorytype"];
                            var ber_territorytype_formatted = results1.value[0]["ber_territorytype@OData.Community.Display.V1.FormattedValue"];
                            var territoryid = results1.value[0]["territoryid"];
                            //  alert(ber_territorytype_formatted);

                            Xrm.Page.getAttribute("ber_territorytype").setValue(ber_territorytype_formatted);
                            Xrm.Page.getAttribute("ber_territorytype").setSubmitMode("always");
                        }
                    }
                }

            }
        }
    }

}


/*********************

Developed By: Madhumita
Method Name: retrieveLeadsourceAD
Purpose: to retrieve the territory type
Date: 12/10/2018
Ticket : 
**********************/
function retrieveLeadsourceAD1() {
    if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode") != undefined) {
        var leadsourcecode = Xrm.Page.getAttribute("leadsourcecode").getValue();

        var req = new XMLHttpRequest();
        url = "$select=ber_ad_leadsourcemappingid,ber_leadsourcecode,ber_lockedforad,ber_name&$filter=ber_leadsourcecode eq " + leadsourcecode + " and  statecode eq 0";
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_ad_leadsourcemappings?" + url, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        //ber_lockedforad
        req.send();
        if (req.response != null && req.response != "") {
            var results = JSON.parse(req.response);
            //for (var i = 0; i < results.value.length; i++) {
            if (results != null) {
                //no duplicate record should be allowed
                if (results.value.length > 0) {
                    var ber_ad_leadsourcemappingid = results.value[0]["ber_ad_leadsourcemappingid"];
                    var ber_leadsourcecode = results.value[0]["ber_leadsourcecode"];
                    var ber_leadsourcecode_formatted = results.value[0]["ber_leadsourcecode@OData.Community.Display.V1.FormattedValue"];
                    var ber_lockedforad = results.value[0]["ber_lockedforad"];
                    var ber_lockedforad_formatted = results.value[0]["ber_lockedforad@OData.Community.Display.V1.FormattedValue"];
                    var ber_name = results.value[0]["ber_name"];

                    if (ber_lockedforad_formatted != null) {
                        Xrm.Page.getAttribute("ber_lockedforad").setValue(ber_lockedforad_formatted);
                        Xrm.Page.getAttribute("ber_lockedforad").setSubmitMode("always");
                    }
                    else if (ber_lockedforad_formatted == null) {
                        Xrm.Page.getAttribute("ber_lockedforad").setValue(null);
                        Xrm.Page.getAttribute("ber_lockedforad").setSubmitMode("always");
                    }

                }
            }

        }



    }
}
