function populateNameField()
{

Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_amount").getValue().toString() +'\\' + Xrm.Page.getAttribute("ber_chequenumber").getValue().toString() + '\\'+ Xrm.Page.getAttribute("ber_bank").getValue().toString()) ;
Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 

}