function Setpincode() {
    // debugger;
   // alert("0");
//window.parent.location.reload();
    if (Xrm.Page.getAttribute("address1_postalcode") != null && Xrm.Page.getAttribute("address1_postalcode") != 'undefined') {
    //    alert("1");
        var pincode = Xrm.Page.getAttribute("address1_postalcode").getValue();
        if (pincode != null && pincode != undefined) {
       //     alert("2");
            // var pincodevalue = pincode[0].id;
            var PincodeColumns = ['ber_name', 'ber_pincodeId'];
            //var PincodeColumns1 = ['ber_pincodeid']
          //  alert(pincode);
            var PincodeFilter = "ber_name eq '" + pincode + "'";
        //    alert(PincodeFilter);
            var PincodeCollection = CrmRestKit.RetrieveMultiple('ber_pincode', PincodeColumns, PincodeFilter);
            if (PincodeCollection != null && PincodeCollection != undefined) {
           //     alert("3");
                if (PincodeCollection.results != null) {
              //      alert("4");
                    if (PincodeCollection.results.length > 0) {

                   //     alert("5");
                        var collection = PincodeCollection.results[0];
                        var PinArray = new Array();
                        PinArray[0] = new Object();

                        PinArray[0].name = collection.ber_name;
                        PinArray[0].id = collection.ber_pincodeId;
                        PinArray[0].entityType = "ber_pincode";                                            //collection.ber_postalcode.LogicalName;
                        Xrm.Page.getAttribute("ber_postalcode").setValue(PinArray);
                  //      alert("6");
						Xrm.Page.getAttribute("ber_postalcode").setSubmitMode("always");



                    }
					
					
                }
				
				var pinCodeId = Xrm.Page.getAttribute("ber_postalcode").getValue();
			//	alert(pinCodeId);
				if (pinCodeId != null) {
        var _pinCode = pinCodeId[0].id;
        if (_pinCode != null) {

         //   alert("b");
            var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                '<entity name="ber_pincode">' +
                '<attribute name="ber_pincodeid" />' +
                '<attribute name="ber_cityid" />' +
                '<filter type="and">' +
                '<condition attribute="ber_pincodeid" operator="eq" value="' + _pinCode + '" />' +
                '</filter>' +
                '</entity>' +
                '</fetch>';
            var retrievedCity = XrmServiceToolkit.Soap.Fetch(fetchxml);
            if (retrievedCity.length > 0) {
                var CityArray = new Array();
                CityArray[0] = new Object();
                CityArray[0].id = retrievedCity[0].attributes.ber_cityid.id;
                CityArray[0].name = retrievedCity[0].attributes.ber_cityid.name;
                CityArray[0].entityType = retrievedCity[0].attributes.ber_cityid.logicalName;
                Xrm.Page.getAttribute("ber_city").setValue(CityArray);
                Xrm.Page.getAttribute("ber_city").setSubmitMode("always");




            }

            if (retrievedCity[0].attributes.ber_cityid != null) {
                var CityId = retrievedCity[0].attributes.ber_cityid.id;
                var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="ber_city">' +
                    '<attribute name="ber_cityid" />' +
                    '<attribute name="ber_stateid" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_cityid" operator="eq" value="' + CityId + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                var retrieveState = XrmServiceToolkit.Soap.Fetch(fetchxml);
                if (retrieveState.length > 0) {
                    var StateArray = new Array();
                    StateArray[0] = new Object();
                    StateArray[0].id = retrieveState[0].attributes.ber_stateid.id;
                    StateArray[0].name = retrieveState[0].attributes.ber_stateid.name
                    StateArray[0].entityType = retrieveState[0].attributes.ber_stateid.logicalName
                    Xrm.Page.getAttribute("ber_state").setValue(StateArray);
                    Xrm.Page.getAttribute("ber_state").setSubmitMode("always");

                   // OnCityChange();

                }
            }

        }
    }
	else {
        Xrm.Page.getAttribute("ber_city").setValue(null);
        Xrm.Page.getAttribute("ber_city").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_state").setValue(null);
        Xrm.Page.getAttribute("ber_state").setSubmitMode("always");
    }
				

            }
        }

    }
}