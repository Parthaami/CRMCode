function RetrieveRecord(fetchXml) {

    try {

        return XrmServiceToolkit.Soap.Fetch(fetchXml);
    }
    catch (e) {
        alert(e.message);
    }
}

function getCity(){
 var varlead = Xrm.Page.getAttribute("ber_lead").getValue();
 if (varlead != null && varlead != undefined) {
 var fetchxml="<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>"+
  "<entity name='lead'>"+
    "<attribute name='fullname' />"+
    "<attribute name='leadid' />"+
    "<attribute name='ber_cityid' />"+
    "<order attribute='fullname' descending='false' />"+
    "<filter type='and'>"+
      "<condition attribute='leadid' operator='eq' value='"+varlead[0].id+"' />"+
    "</filter>"+
  "</entity>"+
"</fetch>";
  var Response = RetrieveRecord(fetchxml);
  if(Response !=null){
  if(Response[0].attributes.ber_cityid !=null){
   var city=new Array();
   city[0]=new Object();
   city[0].id=Response[0].attributes.ber_cityid.id;
   city[0].name=Response[0].attributes.ber_cityid.name;
   city[0].entityType=Response[0].attributes.ber_cityid.logicalName;
  Xrm.Page.getAttribute("ber_city").setValue(city);
            Xrm.Page.getAttribute("ber_city").setSubmitMode("always");
  }
  }
 } 
 	else
	{
			Xrm.Page.getAttribute("ber_city").setValue(null);
                                                                Xrm.Page.getAttribute("ber_city").setSubmitMode("always");
			//Xrm.Page.getControl("ber_depot").setDisabled(true);
	}
}