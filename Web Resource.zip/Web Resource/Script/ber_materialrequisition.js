

function Form_OnLoad() {  

//var formType = Xrm.Page.ui.getFormType();
//    if (formType == '2') {
//        //set IFrame URL
//        //IFRAME_control is Iframe which displays CRM form
//        var iFrame = Xrm.Page.ui.controls.get("IFRAME_reqdetail");

//        //Get material req ID

//        var matreqId = Xrm.Page.data.entity.getId();
//        if (matreqId == null) {
//            Xrm.Page.getControl(iFrame).setVisible(false);
//        }
//        else {

//            var serverUrl = Xrm.Page.context.getServerUrl();

//            Xrm.Page.ui.controls.get("IFRAME_reqdetail").setSrc("/main.aspx?etn=ber_dealerrequistiondetails&extraqs=ber_materialrequisitionid%3d" + matreqId + "&pagetype=entityrecord");

//        }




//    }





Xrm.Page.getControl("ber_customerid").setDisabled(true);
Xrm.Page.getControl("ber_estimatedetailsid").setDisabled(true);
}

function FormRefresh() {
    window.location.reload(true);
}

function saveForm() {
    Xrm.Page.data.entity.save();
}


function updateSubGrid() {
    //This will get the related Quotation Detail grid details and store in a variable.
    var relatedQuoDet = document.getElementById("QuotationDetails");

    //Initializing the lookup field to store in an array.
    var lookupfield = new Array;

    //Get the lookup field
    lookupfield = Xrm.Page.getAttribute("ber_estimatedetailsid").getValue();


    //This will get the lookup field guid if there is value present in the lookup
    if (lookupfield != null) {
        var lookupid = lookupfield[0].id;
    }
    //Else the function will return and no code will be executed.
    else {
        return;
    }



    //This method is to ensure that grid is loaded before processing.
    if (relatedQuoDet == null || relatedQuoDet.readyState != "complete") {
        //This statement is used to wait for 2 seconds and recall the function until the grid is loaded.
        setTimeout('updateSubGrid()', 2500);
        return;
    }

       
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>";
    fetchXml += "<entity name='ber_quotationitem'>";
    fetchXml += "<attribute name='ber_name' />";
    fetchXml += "<attribute name='ber_paintingarea' />";
    fetchXml += "<attribute name='ber_homepaintingproductid' />";
    fetchXml += "<attribute name='ber_primer' />";
    fetchXml += "<attribute name='ber_shade' />";
    fetchXml += "<attribute name='ber_paintingsystemid' />";
    fetchXml += "<attribute name='ber_ratepersqft' />";
    fetchXml += "<attribute name='ber_areainsqft' />";
    fetchXml += "<attribute name='ber_amount' />";    
    fetchXml += "<attribute name='ber_puttyid' />";
    fetchXml += "<attribute name='ber_puttyrate' />";
    fetchXml += "<attribute name='ber_puttyarea' />";
    fetchXml += "<attribute name='ber_puttyamount' />";
    fetchXml += "<attribute name='ber_totalamount' />";
    fetchXml += "<link-entity name='ber_estimatedetails' from='ber_estimatedetailsid' to='ber_estimateid' alias='aa'>";
    fetchXml += "<filter type='and'>";
    fetchXml += "<condition attribute='ber_estimatedetailsid' operator='eq'  value='" + lookupid + "' />";
    fetchXml += "</filter>";
    fetchXml += "</link-entity>";
    fetchXml += "</entity>";
    fetchXml += "</fetch>";

    //Setting the fetch xml to the sub grid.
    relatedQuoDet.control.setParameter("fetchXml", fetchXml);
    
    try {
        relatedQuoDet.control.refresh();
    }
    catch (Err) {        
    } 

}


function populateNameField() {
    Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_customerid").getValue()[0].name + '\\' + Xrm.Page.getAttribute("ber_estimatedetailsid").getValue()[0].name + '\\' + Xrm.Page.getAttribute("ber_dealerid").getValue()[0].name);

    //Always submit readonly field ber_name
    Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
}