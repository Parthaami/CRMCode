// JScript source code
//setVisibleTab function use to hide/show the particular Tab..
//setVisibleSection function use to hide/show the particular section..
//tabname:Pass Name Of Tab which tab we have to hide or show..
//Show:is a visibilty Parameter need pass i.e true or false..
//sectionname:Pass Name Of Section which Section we have to hide or show..

function setVisibleTab(tabname, show) 
{
     var oTabName = Xrm.Page.ui.tabs.get(tabname);

     if (oTabName != null) 
     {
         oTabName.setVisible(show);
     }
}

function setVisibleSectionshipto(tabname, sectionname, show) 
{
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) 
    {
        if (sectionname == null ) 
        {
        }
        else 
        {
            var oSection = oTabName.sections.get(sectionname);
                 var button=Xrm.Page.getAttribute("ber_shiptotype").getValue();
             if(button == true)
{

                         if (oSection != null) 
            {
                oSection.setVisible(show);
                 Xrm.Page.ui.controls.get("ber_shipto").setVisible(false);
               
            }
}
else
{
                oSection.setVisible(false);
                 Xrm.Page.ui.controls.get("ber_shipto").setVisible(true);
}
        }

    }
}