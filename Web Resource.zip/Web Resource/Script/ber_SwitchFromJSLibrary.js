/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: switchFormOnLoad
functionality: To switch between multiple forms based on certain parameter
***************/


function switchFormOnLoad() {

    DisablePhone();
    //var FormSubDealer = '4C3DB2D2-50FC-4F3D-96B3-BF87950F9360';
    //var FormInfo = '894CC46A-B0CB-4AB0-8BF6-200544E46A2D';
    //var FormPainter = '43F9EA0B-195A-4112-B652-2331E38E64C9';    
    var isSubDealer = Xrm.Page.getAttribute("ber_subdealer").getValue();
    var customerType = Xrm.Page.getAttribute("ber_customertype").getValue();
    var ParentPainter = null;

    // Code Added for Creation Sub Painter..
    var FormType = Xrm.Page.ui.getFormType();
    if (FormType != null) {
        if (Xrm.Page.data.entity.getId() == null || Xrm.Page.data.entity.getId() == 'undefined' || Xrm.Page.data.entity.getId() == '') {
            if (UserHasRole("Depot User")) {
                if (Xrm.Page.ui.formSelector.getCurrentItem().getLabel() != "Sub Painter Form") {
                    ShowForm("Sub Painter Form");
                }

                if (Xrm.Page.ui.formSelector.getCurrentItem().getLabel() == "Sub Painter Form") {
                    //  ShowForm("Sub Painter Form");
                    //if (Xrm.Page.ui.formSelector.getCurrentItem().getLabel() == "Sub Painter Form") {
                    EnableFiled();

                    // to remove all the customer type except painter

                    var a = Xrm.Page.ui.controls.get("ber_customertype");
                    a.removeOption("278290000");
                    a.removeOption("278290002");
                    a.removeOption("278290003");
                    a.removeOption("278290004");
                    a.removeOption("278290005");
                    a.removeOption("278290008");
                    a.removeOption("278290010");
                    a.removeOption("278290006");
                    a.removeOption("278290007");
                    a.removeOption("278290009");
                    a.removeOption("278290011");
                    a.removeOption("278290012");


                }

            }
        }

        // else if (FormType == 2) {
        else if (Xrm.Page.data.entity.getId() != null && Xrm.Page.data.entity.getId() != 'undefined' && Xrm.Page.data.entity.getId() != '' && FormType == 2) {
            if (UserHasRole("Depot User")) {
                if (Xrm.Page.ui.formSelector.getCurrentItem().getLabel() == "Sub Painter Form") {
                    var Enableparentpainter = Xrm.Page.ui.controls.get("ber_parentpainter");
                    var Enablechangetomasterpainter = Xrm.Page.ui.controls.get("ber_changetomasterpainter");
                    var Enableconverttomasterpainter = Xrm.Page.ui.controls.get("ber_converttomasterpainter");

                    Enablechangetomasterpainter.setDisabled(false);
                    Enableconverttomasterpainter.setDisabled(false);
                    Enableparentpainter.setDisabled(true);
                }
            }
        }
    }

    if (Xrm.Page.getAttribute("ber_parentpainter"))
        ParentPainter = Xrm.Page.getAttribute("ber_parentpainter").getValue();

    if (customerType != 278290001 && !((FormType == 1) && (UserHasRole("Depot User")))) //Contact Type is Painter
    {
        ShowForm("Information");
    }
    else if (customerType == 278290001 && (isSubDealer == false || isSubDealer == null) && ParentPainter == null) //Contact Type is Painter and Subdealer is false
    {
        ShowForm("Painter Form");
    }
    else if (customerType == 278290001 && (isSubDealer == false || isSubDealer == null) && ParentPainter != null) {
        ShowForm("Sub Painter Form");
    }
    else if (isSubDealer) {
        ShowForm("SubDealer Form");
    }
    else if (isSubDealer)
        ShowForm("subdealer form");

}

function ShowForm(formName) {
    var name = Xrm.Page.ui.formSelector.getCurrentItem().getLabel();
    var forms = Xrm.Page.ui.formSelector.items.get();
    if (name.toLowerCase() != formName.toLowerCase()) {
        for (i = 0; i < forms.length; i++) {
            if (forms[i].getLabel().toLowerCase() == formName.toLowerCase()) {
                forms[i].navigate();
                //   alert("A");
                break;
                //  EnableFiled();
            }
        }
    }
}


/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: EnableFiled
functionality: To enable list of fields based the form type for sub painter form
***************/

function EnableFiled() {
    //Enable all Required Filed
    // if (Xrm.Page.ui.formSelector.getCurrentItem().getLabel() == "Sub Painter Form") {
    var Enablefirstname = Xrm.Page.ui.controls.get("firstname");
    var Enablelastname = Xrm.Page.ui.controls.get("lastname");
    var Enablemobilephone = Xrm.Page.ui.controls.get("mobilephone");
    var Enablecustomertype = Xrm.Page.ui.controls.get("ber_customertype");

    var Enablepreferredlanguage1 = Xrm.Page.ui.controls.get("ber_preferredlanguage1");
    var Enablepreferredlanguage2 = Xrm.Page.ui.controls.get("ber_preferredlanguage2");
    var Enablechangetomasterpainter = Xrm.Page.ui.controls.get("ber_changetomasterpainter");
    var Enableconverttomasterpainter = Xrm.Page.ui.controls.get("ber_converttomasterpainter");

    try {
        Enablefirstname.setDisabled(false);
        Enablelastname.setDisabled(false);
        Enablemobilephone.setDisabled(false);
        Enablecustomertype.setDisabled(false);
        Enablepreferredlanguage1.setDisabled(false);
        Enablepreferredlanguage2.setDisabled(false);
        Enablechangetomasterpainter.setDisabled(true);
        Enableconverttomasterpainter.setDisabled(true);
    }
    catch (ex) {
        alert(ex);
    }
    //  }

}


/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: DisablePhone
functionality: to disable phone number
***************/

// JavaScript source code
function DisablePhone() {
    if (Xrm.Page.ui.getFormType() != 1) {
        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = GetRoleName(userRoleId);
            if (userRoleName == "System Administrator") {
                Xrm.Page.getControl("mobilephone").setDisabled(false);
                return true;
            }
        }
    }
    else if ((Xrm.Page.ui.getFormType() == 1) && (UserHasRole("Depot User"))) {
        Xrm.Page.getControl("mobilephone").setDisabled(false);
    }
    else {
        Xrm.Page.getControl("mobilephone").setDisabled(true);
    }

}

//Get Rolename based on RoleId
function GetRoleName(roleId) {
    var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
    var roleName = null;
    $.ajax(
        {
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                roleName = data.d.results[0].Name;
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
        }
    );
    return roleName;
}


/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: DisablePhone
functionality: to disable phone number
***************/


function ForceRefresh() {

    if (Xrm.Page.data.entity.getId() != null && Xrm.Page.data.entity.getId() != 'undefined' && Xrm.Page.data.entity.getId() != '') {
        if (Xrm.Page.getAttribute("ber_parentpainter").getValue() == null && Xrm.Page.ui.formSelector.getCurrentItem().getLabel() == "Sub Painter Form") {
            contactid = Xrm.Page.data.entity.getId();
            var parameters = {};
            parameters["navbar"] = "on";
            Xrm.Utility.openEntityForm("contact", contactid, parameters)


        }
    }

}







/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: filteredview_Painter
functionality: to get the filtered view based on master painter
***************/


function filteredview_Painter() {
    if (UserHasRole("Depot User")) {

        $("#ber_parentpainter").find("img").attr("disableviewpicker", "0");
        if (Xrm.Page.context.getUserId() != null && Xrm.Page.context.getUserId() != undefined) {
            var currentUser = Xrm.Page.context.getUserId();
            if (currentUser != null) {
                if (currentUser != null) {
                    currentUser = currentUser.replace("{", "");
                    currentUser = currentUser.replace("}", "");
                    var viewDisplayName2 = 'Filtered Master Painter View based on Depot Owner';

                    var viewId2 = "{00000000-0000-0000-00AA-000010001009}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="fullname" width="200" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="ber_customertype" width="100" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                                 '<entity name="contact">' +
                                 '<attribute name="fullname" />' +
                                 '<attribute name="mobilephone" />' +
                                  '<attribute name="ber_depotid" />' +
                                  '<attribute name="ber_customertype" />' +
                                  '<attribute name="contactid" />' +
                                  '<order attribute="fullname" descending="false" />' +
                                   '<filter type="and">' +
                                  '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                                  '<condition attribute="statecode" operator="eq" value="0" />' +
                                  '<condition attribute="ownerid" operator="eq" value="' + currentUser + '" />' +
                                   '<filter type="or">' +
                                   '<condition attribute="ber_subdealer" operator="eq" value="0" />' +
                                    '<condition attribute="ber_subdealer" operator="null" />' +
                                    '</filter>' +
                                    '<condition attribute="ber_parentpainter" operator="null" />' +
                                     '</filter>' +
                                     '</entity>' +
                                      '</fetch>';
                    Xrm.Page.getControl("ber_parentpainter").addCustomView(viewId2, "contact", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_parentpainter').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_parentpainter").find("img").attr("disableviewpicker", "1");
                }
            }
        }
        // }


    }
}
