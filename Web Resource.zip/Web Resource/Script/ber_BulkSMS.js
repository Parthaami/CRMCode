function SendSMS(selectedRecordIDs, entityTypeCode) {

    //Attach JQuery WebResource File
    var jqueryWebResourceUrl = "../WebResources/pcl_jquery_v1.4.2";
    var xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
    xmlHttp.open("GET", jqueryWebResourceUrl, false);
    xmlHttp.send();
    eval(xmlHttp.responseText);

    //Load json WebResource File
    var jsonWebResoureUrl = "../WebResources/pcl_json2";
    var xmlHttp1 = new ActiveXObject("Microsoft.XMLHTTP");
    xmlHttp1.open("GET", jsonWebResoureUrl, false);
    xmlHttp1.send();
    eval(xmlHttp1.responseText);

    //Attach CRMRestKit WebResource File
    var crmRestKitWebResourceUrl = "../WebResources/pcl_crmrestkit";
    var xmlHttp2 = new ActiveXObject("Microsoft.XMLHTTP");
    xmlHttp2.open("GET", crmRestKitWebResourceUrl, false);
    xmlHttp2.send();
    eval(xmlHttp2.responseText);

    var SMSText = prompt("Please enter SMS text", "");

    if (SMSText != null && SMSText != "") {
        for (var count = 0; count < selectedRecordIDs.length; count++) {
            var objectId = selectedRecordIDs[count].replace('{', '').replace('}', '');

            if (entityTypeCode == '1') {
                var bulkSMS = CrmRestKit.Create('ber_bulksms',
                {
                    ber_SMSText: SMSText,
                    ber_Account: {
                        __metadata: { type: "Microsoft.Crm.Sdk.Data.Services.EntityReference" },
                        Id: objectId,
                        LogicalName: 'account'
                    }
                });
            }
            else if (entityTypeCode == '2') {
                var bulkSMS = CrmRestKit.Create('ber_bulksms',
                {
                    ber_SMSText: SMSText,
                    ber_contact: {
                        __metadata: { type: "Microsoft.Crm.Sdk.Data.Services.EntityReference" },
                        Id: objectId,
                        LogicalName: 'contact'
                    }
                });
            }
            else if (entityTypeCode == '10012') {
                var bulkSMS = CrmRestKit.Create('ber_bulksms',
                {
                    ber_SMSText: SMSText,
                    ber_tsi: {
                        __metadata: { type: "Microsoft.Crm.Sdk.Data.Services.EntityReference" },
                        Id: objectId,
                        LogicalName: 'ber_tsi'
                    }
                });
            }
            else if (entityTypeCode == '10003') {
                var bulkSMS = CrmRestKit.Create('ber_bulksms',
                {
                    ber_SMSText: SMSText,
                    ber_depot: {
                        __metadata: { type: "Microsoft.Crm.Sdk.Data.Services.EntityReference" },
                        Id: objectId,
                        LogicalName: 'ber_depot'
                    }
                });
            }
            else if (entityTypeCode == '10007') {
                var bulkSMS = CrmRestKit.Create('ber_bulksms',
                {
                    ber_SMSText: SMSText,
                    ber_RSM: {
                        __metadata: { type: "Microsoft.Crm.Sdk.Data.Services.EntityReference" },
                        Id: objectId,
                        LogicalName: 'ber_region'
                    }
                });
            }
        }
    }
}