function contactUpdate(id, entityObject, odataSetName, successCallback, errorCallback) {
    var context = Xrm.Page.context;
    // var serverUrl = context.getServerUrl();
    var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    // var serverUrl = "http://10.62.163.60:6505/BergerQA";

    //The XRM OData end-point
    var ODATA_ENDPOINT = "/XRMServices/2011/OrganizationData.svc";

    //id is required
    if (!id) {
        alert("record id is required.");
        return;
    }
    //odataSetName is required, i.e. "AccountSet"
    if (!odataSetName) {
        alert("odataSetName is required.");
        return;
    }

    //Parse the entity object into JSON
    var jsonEntity = window.JSON.stringify(entityObject);

    //Asynchronous AJAX function to Update a CRM record using OData
    $.ajax({
        type: "POST",
        async: false,
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        data: jsonEntity,
        url: serverUrl + ODATA_ENDPOINT + "/" + odataSetName + "(guid'" + id + "')",
        beforeSend: function (XMLHttpRequest) {
            //Specifying this header ensures that the results will be returned as JSON.             
            XMLHttpRequest.setRequestHeader("Accept", "application/json");

            //Specify the HTTP method MERGE to update just the changes you are submitting.             
            XMLHttpRequest.setRequestHeader("X-HTTP-Method", "MERGE");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            //The MERGE does not return any data at all, so we'll add the id 
            //onto the data object so it can be leveraged in a Callback. When data 
            //is used in the callback function, the field will be named generically, "id"
            data = new Object();
            data.id = id;
            if (successCallback) {
                successCallback(data, textStatus, XmlHttpRequest);
            }
        },
        error: function (XmlHttpRequest, textStatus, errorThrown) {
            if (errorCallback)
                errorCallback(XmlHttpRequest, textStatus, errorThrown);
            else
                errorHandler(XmlHttpRequest, textStatus, errorThrown);
        }
    });
}


function errorHandler(xmlHttpRequest, textStatus, errorThrow) {
    alert("Error : " + textStatus + ": " + xmlHttpRequest.statusText);
}

//Called upon successful Account update.
function updatecontactCompleted(data, textStatus, XmlHttpRequest) {

}



function TokenCode() {
    var VoucherCollection;
    if (Xrm.Page.getAttribute("ber_vouchertext") != null && Xrm.Page.getAttribute("ber_vouchertext") != 'undefined') {
        var VoucherTxt = Xrm.Page.getAttribute("ber_vouchertext").getValue();
        if (VoucherTxt != null && VoucherTxt != undefined) {

            $.ajax({
                type: "GET",
                async: false,
                url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_voucherdetails?$select=ber_count,ber_name,ber_voucherconfirmationyn,ber_voucherdetailid&$filter=ber_name eq '" + VoucherTxt + "'",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                processdata: false,
                crossDomain: true,
                success: function (msg) {
                    VoucherCollection = msg;

                },
                error: function (msg) {
                    alert('error fetching the price level from crm organization');
                },
            });
            var VoucherCollection = CrmRestKit.RetrieveMultiple('ber_voucherdetail', VoucherTxtColumns, VoucherTxtFilter);

            if (VoucherCollection != null && VoucherCollection != undefined) {

                if (VoucherCollection.value != null) {
                    if (VoucherCollection.value.length > 0) {
                        var voucherid = VoucherCollection.value[0]["ber_voucherdetailid"];
                        var count = VoucherCollection.value[0]["ber_count"];
                        if (count <= 199) {
                            var VoucherArray = new Array();
                            VoucherArray[0] = new Object();
                            VoucherArray[0].name = VoucherCollection.value[0]["ber_name"];
                            VoucherArray[0].id = VoucherCollection.value[0]["ber_voucherdetailid"];
                            VoucherArray[0].entityType = "ber_voucherdetail";
                            Xrm.Page.getAttribute("ber_vouchercode").setValue(VoucherArray);
                            Xrm.Page.getAttribute("ber_vouchercode").setSubmitMode("always");
                        }
                        else if (count >= 200) {
                            alert("This Voucher code is not applicable anymore");
                            Xrm.Page.getAttribute("ber_vouchercode").setValue(null);
                            Xrm.Page.getAttribute("ber_vouchercode").setSubmitMode("always");
                        }

                        else {


                        }

                    }
                }

            }

        }

            else if (count == 1) {
            var count1 = count + 1;
            var lead2 = {
            // EP Status = XP
            ber_VoucherConfirmationYN: { Value: true }
            };

    }

}