function SetCityAndState() {
    if (Xrm.Page.getAttribute("ber_pincode").getValue() != undefined || Xrm.Page.getAttribute("ber_pincode").getValue() != null) {
        var pinCodeId = Xrm.Page.getAttribute("ber_pincode").getValue();
        if (pinCodeId != null) {
            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {

                // alert(_pinCode);
                var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                '<entity name="ber_pincode">' +
                '<attribute name="ber_pincodeid" />' +
                '<attribute name="ber_cityid" />' +
                '<filter type="and">' +
                '<condition attribute="ber_pincodeid" operator="eq" value="' + _pinCode + '" />' +
                '</filter>' +
                '</entity>' +
                '</fetch>';
                //   alert("1");
                var retrievedCity = XrmServiceToolkit.Soap.Fetch(fetchxml);
                if (retrievedCity.length > 0) {
                    var CityArray = new Array();
                    CityArray[0] = new Object();
                    CityArray[0].id = retrievedCity[0].attributes.ber_cityid.id;
                    //    alert(CityArray[0].id);
                    CityArray[0].name = retrievedCity[0].attributes.ber_cityid.name;
                    //     alert(CityArray[0].name);
                    CityArray[0].entityType = retrievedCity[0].attributes.ber_cityid.logicalName;
                    Xrm.Page.getAttribute("ber_city").setValue(CityArray);
                    Xrm.Page.getAttribute("ber_city").setSubmitMode("always");

                }

                if (retrievedCity[0].attributes.ber_cityid != null) {
                    var CityId = retrievedCity[0].attributes.ber_cityid.id;
                    var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="ber_city">' +
                    '<attribute name="ber_cityid" />' +
                     '<attribute name="ber_citytype" />' +
                    '<attribute name="ber_stateid" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_cityid" operator="eq" value="' + CityId + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                    var retrieveState = XrmServiceToolkit.Soap.Fetch(fetchxml);
                    if (retrieveState.length > 0) {
                        var StateArray = new Array();
                        StateArray[0] = new Object();
                        StateArray[0].id = retrieveState[0].attributes.ber_stateid.id;
                        StateArray[0].name = retrieveState[0].attributes.ber_stateid.name
                        StateArray[0].entityType = retrieveState[0].attributes.ber_stateid.logicalName
                        Xrm.Page.getAttribute("ber_state").setValue(StateArray);
                        Xrm.Page.getAttribute("ber_state").setSubmitMode("always");


                    }
                }
            }



        }
    }
    else {
        Xrm.Page.getAttribute("ber_city").setValue(null);
        Xrm.Page.getAttribute("ber_city").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_state").setValue(null);
        Xrm.Page.getAttribute("ber_state").setSubmitMode("always");
    }

}
