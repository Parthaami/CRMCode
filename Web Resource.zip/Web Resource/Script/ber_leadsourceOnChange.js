function leadsourceOnChange()
{
	if(Xrm.Page.getAttribute("leadsourcecode").getValue() == 278290002)
	{
		Xrm.Page.getControl("ber_leadcontactid").setVisible(true);
	}
	else
	{
		Xrm.Page.getControl("ber_leadcontactid").setVisible(false);
	}
}