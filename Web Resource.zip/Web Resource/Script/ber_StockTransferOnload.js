function StockTransferOnload() {

    if (!UserHasRole('HO Color Bank')) {
        var TransferType = Xrm.Page.getControl("ber_type");
        TransferType.removeOption(278290002);
    }

    var status = Xrm.Page.getAttribute("ber_status").getValue();


    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    if (Xrm.Page.ui.getFormType() != 1) {

        var context;
        var objectId;
        var orgName;
        //var userId;
        var hostName;
        var IsAdjustment;
        var HOTransfer;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        var instReq = Xrm.Page.getAttribute("ber_installationrequestid").getValue();
        var scheme = Xrm.Page.getAttribute("ber_schemeid").getValue();
        var IsIDTP = Xrm.Page.getAttribute("ber_idtp").getValue();
        var TType = Xrm.Page.getAttribute("ber_type").getValue();

        if (TType == 278290000) {
            IsAdjustment = true;
            HOTransfer = false;
        }
        else if (TType == 278290002) {
            IsAdjustment = false;
            HOTransfer = true;
        }
        else {
            IsAdjustment = false;
            HOTransfer = false;
        }

        if (instReq != null) {
            var instReqId = instReq[0].id;
            instReqId = instReqId.replace("{", "");
            instReqId = instReqId.replace("}", "");

            var from = Xrm.Page.getAttribute("ber_from").getValue();
            var to = Xrm.Page.getAttribute("ber_to").getValue();
            if (from != null && to != null) {
                var fromId = from[0].id;
                fromId = fromId.replace("{", "");
                fromId = fromId.replace("}", "");

                var toId = to[0].id;
                toId = toId.replace("{", "");
                toId = toId.replace("}", "");

                var ShipMent = serverURL + "/ISV/" + _orgName + "/ColorBank/Default.aspx?Id=" + objectId + "&BRId=" + instReqId + "&FRMId=" + fromId + "&TOId=" + toId;
                if (document.all.IFRAME_shipmentGrid != null) {
                    document.all.IFRAME_shipmentGrid.src = ShipMent;
                }
            }
        }
        else {
            ///////////Status is Draft////////////////////////////////////
            if (status == "278290000") {
                if (scheme != null || IsAdjustment || HOTransfer) {
                    var ShipMent = "http://10.150.80.11:7045/Shipment.aspx?Id=" + objectId + "&Adjustment=" + IsAdjustment + "&HOTransfer=" + HOTransfer + "&IDTP=" + IsIDTP;
                    if (document.all.IFRAME_shipmentGrid != null) {
                        document.all.IFRAME_shipmentGrid.src = ShipMent;
                    }
                }
            }
            ///////////Status is Shipped/////////////////////////////
            if (status == "278290001") {
                if (scheme != null || IsAdjustment || HOTransfer) {
                    var ShipMent = "http://10.150.80.11:7045/Received.aspx?Id=" + objectId;
                    if (document.all.IFRAME_shipmentGrid != null) {
                        document.all.IFRAME_shipmentGrid.src = ShipMent;
                    }
                }
            }

            ///////////Status is Received - Readonly Grid/////////////////////////////
            if (status == "278290002") {
                if (scheme != null || IsAdjustment || HOTransfer) {
                    var ShipMent = "http://10.150.80.11:7045/ShipmentCompleted.aspx?Id=" + objectId;
                    if (document.all.IFRAME_shipmentGrid != null) {
                        document.all.IFRAME_shipmentGrid.src = ShipMent;
                    }
                }
            }
        }
    }
}

function SchemeOnChange() {
    if (Xrm.Page.getAttribute("ber_schemeid") != null && Xrm.Page.getAttribute("ber_schemeid").getValue() != null) {
        //show ITDP
        Xrm.Page.getControl("ber_idtp").setVisible(true);
    }
    else {
        Xrm.Page.getControl("ber_idtp").setVisible(false);
    }
}

function AdjustmentReasonOnChange() {
    if (Xrm.Page.getAttribute("ber_adjustmentreason") != null && Xrm.Page.getAttribute("ber_adjustmentreason").getValue() != null && Xrm.Page.getAttribute("ber_adjustmentreason").getValue() == 278290002) {
        Xrm.Page.getControl("ber_purchaseorderid").setVisible(true);
        Xrm.Page.getAttribute("ber_parentstocktransfer").setRequiredLevel("none");
        Xrm.Page.getControl("ber_parentstocktransfer").setVisible(false);

    }
    else if (Xrm.Page.getAttribute("ber_adjustmentreason") != null && Xrm.Page.getAttribute("ber_adjustmentreason").getValue() != null && Xrm.Page.getAttribute("ber_adjustmentreason").getValue() == 278290001) {
        Xrm.Page.getControl("ber_parentstocktransfer").setVisible(true);
        Xrm.Page.getAttribute("ber_parentstocktransfer").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_purchaseorderid").setValue(null);
        Xrm.Page.getControl("ber_purchaseorderid").setVisible(false);
    }
    else {
        Xrm.Page.getAttribute("ber_purchaseorderid").setValue(null);
        Xrm.Page.getAttribute("ber_parentstocktransfer").setValue(null);
        Xrm.Page.getControl("ber_purchaseorderid").setVisible(false);
        Xrm.Page.getAttribute("ber_parentstocktransfer").setRequiredLevel("none");
        Xrm.Page.getControl("ber_parentstocktransfer").setVisible(false);
    }
}

function ShowTIB() {
    if (Xrm.Page.getAttribute("ber_idtp") != null && Xrm.Page.getAttribute("ber_idtp").getValue() != null && Xrm.Page.getAttribute("ber_idtp").getValue() == 1) {
        Xrm.Page.ui.tabs.get(1).setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get(1).setVisible(false);
    }
}

function ReadOnlyFields() {
    if (Xrm.Page.ui.getFormType() != 1) {
        Xrm.Page.getControl("ber_type").setDisabled(true);
        Xrm.Page.getControl("ber_installationrequestid").setDisabled(true);
        Xrm.Page.getControl("ber_schemeid").setDisabled(true);
        Xrm.Page.getControl("ber_from").setDisabled(true);
        Xrm.Page.getControl("ber_to").setDisabled(true);
        Xrm.Page.getControl("ber_adjustmentreason").setDisabled(true);
    }
}