function ValidatePhoneNumbers(fieldName) {
    if (Xrm.Page.getAttribute(fieldName) != null && Xrm.Page.getAttribute(fieldName) != undefined) {
        var PhoneNo = Xrm.Page.getAttribute(fieldName).getValue();
        PhoneNo = PhoneNo.replace(/\s/g, ""); // to remove white spaces
        var length = (PhoneNo.toString()).length;
        if (length == 12 && !isNaN(PhoneNo)) {
            Xrm.Page.getAttribute(fieldName).setValue(PhoneNo);
            return true;
        }
        else {
            Xrm.Page.getAttribute(fieldName).setValue('');
            alert("Please Enter Valid Phone Number.");
            event.returnValue = false;
            return false;
        }
    }
}
           