function setOrderFormReadOnly() {
    if (Xrm.Page.ui.getFormType() == 2) {
        var StatusReason = Xrm.Page.getAttribute("statuscode").getValue();



        if (StatusReason == 3 || StatusReason == 278290000 || StatusReason == 278290003 || StatusReason == 278290004 || StatusReason == 278290005)
            disableFormFields("statuscode", StatusReason, "true")
    }
}



function setAccountFormReadOnly() {

    // debugger;

    if (Xrm.Page.ui.getFormType() == 2) {
        var IsAdmin = UserHasRole("System Administrator");
        var IsAdmin2 = UserHasRole("Advanced Call Center Manager");



        var Status = Xrm.Page.getAttribute("statecode").getValue();
        if (Status == 0 && (IsAdmin || IsAdmin2)) {
            //Nothing
        }
        else {
            //Disable Form
            disableFormFields("statecode", Status, "true")

        }

    }

}







function disableFormFields(fieldname, fieldvalue, onOff) {
    var value = Xrm.Page.getAttribute(fieldname).getValue();



    if (value != null) {
        var fieldtype = Xrm.Page.getControl(fieldname).getControlType();
        if (fieldtype == "optionset") {
            value = Xrm.Page.getAttribute(fieldname).getSelectedOption().value;
        }
        if (fieldtype == "lookup") {
            value = value[0].name;
        }
        if (value == fieldvalue) {
            Xrm.Page.ui.controls.forEach(function (control, index) {
                if (doesControlHaveAttribute(control)) {
                    control.setDisabled(onOff);
                }
            });
        }
    }
}



function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}































////////////////////////////////////////////////////







function SetVisibleHotlist_Dealer() {



    var CustomerType = Xrm.Page.getAttribute("customertypecode").getValue();
    var Hotlist = Xrm.Page.getAttribute("ber_hotlistdealer").getValue();



    if (CustomerType != 5) {
        Xrm.Page.ui.controls.get("ber_hotlistdealer").setVisible(false);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);
    }



    else if (CustomerType == 5) {



        Xrm.Page.ui.controls.get("ber_hotlistdealer").setVisible(true);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);



    }



    else {



    }



}













function CheckHotlist() {



    var Hotlist = Xrm.Page.getAttribute("ber_hotlistdealer").getValue();





    if (Hotlist != null && Hotlist == 1) {



        // Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(true);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(true);
        Xrm.Page.data.entity.attributes.get("ber_reason").setRequiredLevel("required");



    }



    else if (Hotlist != null) {



        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);
        // Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(false);



    }



}