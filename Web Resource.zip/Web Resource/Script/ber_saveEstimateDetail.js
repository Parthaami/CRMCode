// JScript source code
function CleanFormWindow() {

    if (document.getElementById("IFRAME_quotationitem").readyState == "complete") {

        var frameDoc = document.getElementById("IFRAME_quotationitem").contentWindow.document;

        if (frameDoc != null && frameDoc.getElementById("contentIFrame") != null) {

            frameDoc.getElementById("minimizeribbon").fireEvent("onclick");

            //       frameDoc.getElementById("crmTopBar").style.display = "none";
            //      frameDoc.getElementById("crmContentPanel").style.top = "0px";
        }
    }
}


function HideNavBar() {
    var Status = Xrm.Page.getAttribute("statuscode").getValue();
    if (Status == 1 || Status == 278290001 || Status == 278290000) {
        var items = Xrm.Page.ui.navigation.items.get();
        for (var i in items) {
            var item = items[i];
            if (item.getVisible()) {
                item.setVisible(false);
            }
        }
    }
}





function Form_OnLoad() {

    // Xrm.Page.ui.controls.get("IFRAME_quotationitem").onreadystatechange = CleanFormWindow();



    //var formType = Xrm.Page.ui.getFormType();
    //if (formType == '2') {
    //    //set IFrame URL
    //    //IFRAME_control is Iframe which displays CRM form
    //    var iFrame = Xrm.Page.ui.controls.get("IFRAME_quotationitem");

    //    //Get Estimate Detail ID

    //    var estdetId = Xrm.Page.data.entity.getId();
    //    if (estdetId == null) {
    //        Xrm.Page.getControl(iFrame).setVisible(false);
    //    }
    //    else {

    //        var serverUrl = Xrm.Page.context.getClientUrl();

    //        Xrm.Page.ui.controls.get("IFRAME_quotationitem").setSrc("/main.aspx?etn=ber_quotationitem&extraqs=ber_estimateid%3d" + estdetId + "&pagetype=entityrecord");

    //    }
    //    try {
    //        //  setTimeout("CleanFormWindow();", 5000);
    //    }
    //    catch (e) {

    //    }

    //}

    if (UserHasRole('HO Home Decor User')) {
        Xrm.Page.getControl("ber_br").setDisabled(false);
    }
    ManageWorkOrder();

    var Status = Xrm.Page.getAttribute("statuscode").getValue();
    var WO = Xrm.Page.getAttribute("ber_workorder").getValue();
    var EstimateId = Xrm.Page.data.entity.getId();

    if (WO == 1 && (Status == 278290000 || Status == 278290002)) {
        var columns = ['AnnotationId'];
        var filter = "ObjectId/Id eq guid'" + EstimateId + "'";
        var collection = CrmRestKit.RetrieveMultiple('Annotation', columns, filter);
        if (collection != null && collection.results != null && collection.results.length > 0) {
            Xrm.Page.ui.tabs.get(1).setVisible(true);
            document.getElementById("crmNavBar").parentElement.style.display = "";
            document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 1;
            Xrm.Page.ui.tabs.get("Payments").setVisible(true);
        }
        else {
            document.getElementById("crmNavBar").parentElement.style.display = "none";
            document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2;
        }
    }
    else if (WO == 0 && (Status == 278290000 || Status == 278290002)) {
        if (Xrm.Page.getAttribute("ber_collection") != null && Xrm.Page.getAttribute("ber_collection").getValue() != null && Xrm.Page.getAttribute("ber_collection").getValue() > 0) {
            document.getElementById("crmNavBar").parentElement.style.display = "";
            document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 1;
            Xrm.Page.ui.tabs.get("Payments").setVisible(true);
        }
        else {
            document.getElementById("crmNavBar").parentElement.style.display = "none";
            document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2;
            Xrm.Page.ui.tabs.get("Payments").setVisible(true);
        }
    }
    else {
        document.getElementById("crmNavBar").parentElement.style.display = "none";
        document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2;
    }



}

function FormRefresh() {
    var estId = Xrm.Page.data.entity.getId();
    //window.location.reload(true);
    Xrm.Utility.openEntityForm("ber_estimatedetails", estId.replace(/[{}]/g, ""));
}

function saveEstimateDetail() {
    Xrm.Page.data.entity.save();
}



function ChangeEstimateDiscount() {
    if (UserHasRole('HO Home Decor User')) {
        Xrm.Page.getAttribute("ber_maxapproveddiscount").setValue(Xrm.Page.getAttribute("ber_discount").getValue());
        Xrm.Page.getAttribute("ber_maxapproveddiscount").setSubmitMode("always");
        //Xrm.Page.data.entity.save();
    }
    else if (Xrm.Page.getAttribute("ber_maxapproveddiscount") != null && Xrm.Page.getAttribute("ber_maxapproveddiscount").getValue() != null) {
        if (Xrm.Page.getAttribute("ber_discount") != null && Xrm.Page.getAttribute("ber_discount").getValue() != null) {
            if (Xrm.Page.getAttribute("ber_maxapproveddiscount").getValue() < Xrm.Page.getAttribute("ber_discount").getValue()) {
                alert('You are not allowed to enter discount per. more than ' + Xrm.Page.getAttribute("ber_maxapproveddiscount").getValue() + '%.For more discount send estimate to HO User approval.');
                Xrm.Page.getAttribute("ber_discount").setValue(null);
                event.returnValue = false;
            }
        }
    }
    else {
        if (Xrm.Page.getAttribute("ber_discount") != null) {
            var Discount = Xrm.Page.getAttribute("ber_discount").getValue();
            if (Discount != null && Discount > 10) {
                alert('You are not allowed to enter discount per. more than 10%.For more discount send estimate to HO User approval.');
                Xrm.Page.getAttribute("ber_discount").setValue(null);
                event.returnValue = false;
            }
        }
    }
}


function CalculateNetAmt() {
    var TotalAmt = 0;
    var Discount = 0;

    if (Xrm.Page.getAttribute("ber_grandtotal").getValue() != null) {
        TotalAmt = Xrm.Page.getAttribute("ber_grandtotal").getValue();

        if (Xrm.Page.getAttribute("ber_discount").getValue() != null) {
            if (TotalAmt > 0) {
                var DiscountAmt = (TotalAmt * Xrm.Page.getAttribute("ber_discount").getValue()) / 100;
                TotalAmt = TotalAmt - DiscountAmt;
                Xrm.Page.getAttribute("ber_discountamount").setValue(DiscountAmt);
                Xrm.Page.getAttribute("ber_discountamount").setSubmitMode("always");

            }
        }
        if (Xrm.Page.getAttribute("ber_adjustment").getValue() != null) {
            TotalAmt = TotalAmt - Xrm.Page.getAttribute("ber_adjustment").getValue();
        }
        var TAmt = Math.ceil(TotalAmt * 10) / 10;
        Xrm.Page.getAttribute("ber_netamount").setValue(TAmt);
        Xrm.Page.getAttribute("ber_netamount").setSubmitMode("always");

        if (Xrm.Page.getAttribute("ber_collection") != null && Xrm.Page.getAttribute("ber_collection").getValue() != null) {
            if ((TotalAmt - Xrm.Page.getAttribute("ber_collection").getValue()) > 0) {
                Xrm.Page.getAttribute("ber_pending").setValue(TotalAmt - Xrm.Page.getAttribute("ber_collection").getValue());
                Xrm.Page.getAttribute("ber_pending").setSubmitMode("always");
            }
        }
        Xrm.Page.data.entity.save();
        var Status = Xrm.Page.getAttribute("statuscode").getValue();
        if (Status == 278290000 && Xrm.Page.getAttribute("ber_collection") != null && Xrm.Page.getAttribute("ber_collection").getValue() != null) {
            var items = Xrm.Page.ui.navigation.items.get();
            for (var i in items) {
                var item = items[i];
                if (!item.getVisible()) {
                    item.setVisible(true);
                }
            }
        }
    }
}

//Work Order Management
function ManageWorkOrder() {

    if (Xrm.Page.getAttribute("statuscode").getValue() == 278290000) {
        Xrm.Page.getControl("ber_workorder").setDisabled(true);
    }

    if (Xrm.Page.getAttribute("ber_workorder").getValue() == 0) {
        Xrm.Page.getControl("ber_workorderdate").setDisabled(true);
        Xrm.Page.getControl("ber_workordernumber").setDisabled(true);
        Xrm.Page.getControl("ber_contactperson").setDisabled(true);
        Xrm.Page.getControl("ber_contactnumber").setDisabled(true);
    }
    else {
        Xrm.Page.getControl("ber_workorderdate").setDisabled(false);
        Xrm.Page.getControl("ber_workordernumber").setDisabled(false);
        Xrm.Page.getControl("ber_contactperson").setDisabled(false);
        Xrm.Page.getControl("ber_contactnumber").setDisabled(false);
    }
}