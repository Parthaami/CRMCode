function NumberFormat()
{
      document.getElementById('ber_instrumentno').value = Xrm.Page.getAttribute('ber_instrumentno').getValue();
}

//Hide Save & Close and other ribbon buttons
function ChequeLoad()
{     
var intervalId = window.setInterval(function ()
	{
		if (window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.SaveAndClose-Large') != null)
		{
			window.clearInterval(intervalId);
			var elem = window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.MainTab.Save-LargeMedium-1');
			var elem1 = window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.SaveAndClose-Large')
			var elem2 = window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.MainTab.Collaborate')
			var elem3 = window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.MainTab.Workflow')
			var elem4 = window.top.document.getElementById('ber_cheques|NoRelationship|Form|Mscrm.Form.ber_cheques.MainTab.ExportData')
			//top menu has loaded
			//Hide the item
			elem.style.display = 'none';
			elem1.style.display = 'none';
			elem2.style.display = 'none';
			elem3.style.display = 'none';
			elem4.style.display = 'none';
		}
	}, 100);
}

function PDCValidation()
{
	if(Xrm.Page.getAttribute("ber_frequency").getValue() == 278290003)
	{
		Xrm.Page.ui.controls.get("ber_advchequehold").setDisabled(false);
	}
	else
	{
		Xrm.Page.getAttribute("ber_advchequehold").setValue(0);
		Xrm.Page.ui.controls.get("ber_advchequehold").setDisabled(true);
	}
if ( Xrm.Page.ui.getFormType() == 2)
{ 
     GeneratePDC();
}
}