function HideShowPaymentTabs() {

    if (Xrm.Page.getAttribute("ber_modeofpayements") != undefined && Xrm.Page.getAttribute("ber_modeofpayements") != null) {
        var PaymentMode = Xrm.Page.getAttribute("ber_modeofpayements").getValue();

        if (PaymentMode == 278290000) {
            
            Xrm.Page.ui.controls.get("ber_bank").setVisible(true);
            Xrm.Page.ui.controls.get("ber_chequeno").setVisible(true);
            Xrm.Page.ui.controls.get("ber_chequedate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_chequebounced").setVisible(true);
            Xrm.Page.ui.controls.get("ber_collectiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_depositiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_clearancedate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_tdsamount").setVisible(true);
            Xrm.Page.ui.controls.get("ber_cardnumber").setVisible(true);
            Xrm.Page.ui.controls.get("ber_amount").setVisible(true);
            Xrm.Page.ui.controls.get("ber_cardnumber").setVisible(false);

        
        }

        else if (PaymentMode == 278290001) {

            Xrm.Page.ui.controls.get("ber_bank").setVisible(true);
            Xrm.Page.ui.controls.get("ber_chequeno").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequedate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequebounced").setVisible(false);
            Xrm.Page.ui.controls.get("ber_collectiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_depositiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_clearancedate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_tdsamount").setVisible(false);
            Xrm.Page.ui.controls.get("ber_cardnumber").setVisible(true);
            Xrm.Page.ui.controls.get("ber_amount").setVisible(true);
           
        }

        else if (PaymentMode == 278290002) {

            Xrm.Page.ui.controls.get("ber_bank").setVisible(true);
            Xrm.Page.ui.controls.get("ber_chequeno").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequedate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequebounced").setVisible(false);
            Xrm.Page.ui.controls.get("ber_collectiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_depositiondate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_clearancedate").setVisible(true);
            Xrm.Page.ui.controls.get("ber_tdsamount").setVisible(false);
            Xrm.Page.ui.controls.get("ber_cardnumber").setVisible(true);
            Xrm.Page.ui.controls.get("ber_amount").setVisible(true);
           
        }

        else {

            Xrm.Page.ui.controls.get("ber_bank").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequeno").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequedate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_chequebounced").setVisible(false);
            Xrm.Page.ui.controls.get("ber_collectiondate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_depositiondate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_clearancedate").setVisible(false);
            Xrm.Page.ui.controls.get("ber_tdsamount").setVisible(false);
            Xrm.Page.ui.controls.get("ber_cardnumber").setVisible(false);
            Xrm.Page.ui.controls.get("ber_amount").setVisible(false);

        }

    }
}




function Hidetabs() {

    Xrm.Page.ui.tabs.get("general").sections.get("Cheque").setVisible(false);
    Xrm.Page.ui.tabs.get("general").sections.get("Debit").setVisible(false);
    Xrm.Page.ui.tabs.get("general").sections.get("Credit").setVisible(false);


}