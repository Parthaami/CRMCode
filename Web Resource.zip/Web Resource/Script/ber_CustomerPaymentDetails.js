// JScript source code

function Form_OnLoad() {  //Attach to the grid refresh event  
setTimeout("SetupGridRefresh();", 2500);
 } 

function SetupGridRefresh()
 { 
 var grid = document.getElementById("CustomerPaymentDetailItems");
  if (grid) {  
grid.attachEvent("onrefresh", FormRefresh); 
 }
 else
 {
  alert("Grid is null"); 
 }
 }  


function FormRefresh() {  
window.location.reload(true);
 }


function PopulateNetamount() {
  
    //On change of Product, populate primer field
    var lookupfield = new Array;

    //Get the lookup field

    lookupfield = Xrm.Page.getAttribute("ber_estimatedetailsid").getValue();

    //This will get the lookup field guid if there is value present in the lookup

    if (lookupfield != null) {

        var lookupid = lookupfield[0].id;

    }
    
            
            var columns = ['*'];
            var filter = "ber_estimatedetailsid eq guid'" + lookupid + "'";
            var collection = CrmRestKit.Retrieve('ber_estimatedetails', lookupid, columns);


            if (collection.ber_NetAmount != null) {
            Xrm.Page.getAttribute("ber_netamount").setValue(parseFloat(eval(collection.ber_NetAmount.Value)));
            }
         
}

function SaveReadOnlyFields()
{
Xrm.Page.getAttribute("ber_netamount").setSubmitMode("always"); 
Xrm.Page.getAttribute("ber_jobdetailid").setSubmitMode("always"); 

}


function PopulateJobDetail() {
    
     var lookupfield = new Array;

    //Get the lookup field

    lookupfield = Xrm.Page.getAttribute("ber_estimatedetailsid").getValue();

    //This will get the lookup field guid if there is value present in the lookup

    if (lookupfield != null) {

        var lookupid = lookupfield[0].id;
        lookupid.toString()
    }
    
            
            var columns = ['*'];
            var filter = "ber_estimatedetailsid eq guid'" + lookupid + "'";
            var collection = CrmRestKit.Retrieve('ber_estimatedetails', lookupid, columns);


            if (collection.ber_JobDetailId != null) {
            var value = new Array(); 
            value[0]= new Object();
            value[0].id=collection.ber_JobDetailId.Id;
            value[0].name=collection.ber_JobDetailId.Name;
            value[0].entityType="ber_jobclosedetail";
            Xrm.Page.getAttribute("ber_jobdetailid").setValue(value); 

            }         
}





function populateNameField(){
    Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_estimatedetailsid").getValue()[0].name + '\\'+ Xrm.Page.getAttribute("ber_netamount").getValue().toString()) ;
    Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 
    }