// Created on : 27th June 13
// Created by  : IBM AMS Team
// Functionality : For lead type BDM, "Lead For" dropdown should only contain "Normal", setting visibility on/off for Leadproduct section.
//===================================================================================================

function LeadFor() {

    // var userid = Xrm.Page.context.getUserId();

    var leadForOptionSet = Xrm.Page.getControl("ber_leadfor");

    // Xrm.Page.getAttribute("ber_bdodgid").setRequiredLevel("none");
    // Xrm.Page.getAttribute("ber_bdoid").setRequiredLevel("none");

    /*
    Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
    Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
    */

    if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != null) {
        if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text == "BDM") {

            // alert("Logged in user : " + userid);
            leadForOptionSet.setVisible(true);
            leadForOptionSet.removeOption(1);
            leadForOptionSet.removeOption(2);

            //Lead Product Section to be visible if Lead Status are Verified, Won and Deal Closed
            //===================================================================================
            if (Xrm.Page.getAttribute("statuscode").getValue() == 2 || Xrm.Page.getAttribute("statuscode").getValue() == 278290000 || Xrm.Page.getAttribute("statuscode").getValue() == 278290005) {
                Xrm.Page.ui.tabs.get("leadproduct").setVisible(true);
                setVisibleSection("leadproduct", "leadproduct_section_2", true)
            }
            else {
                Xrm.Page.ui.tabs.get("leadproduct").setVisible(false);
                setVisibleSection("leadproduct", "leadproduct_section_2", false)
            }

        }
        else
            leadForOptionSet.setVisible(false);
    }
}


//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) {
        }
        else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}