function setStockTakingFieldVisibleForAdmin() {
    // debugger;
    if (Xrm.Page.ui.getFormType() == 1 || Xrm.Page.ui.getFormType() == 2) {
        var IsAdmin = UserHasRole("System Administrator");


        if (IsAdmin) {
            Xrm.Page.ui.controls.get("ber_stocktaking").setVisible(true);
        }
        else {
            // For other roles
            Xrm.Page.ui.controls.get("ber_stocktaking").setVisible(false);
        }
    }
}