function populateNameField()
{
Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_materialrequisitionid").getValue()[0].name );
Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 
Xrm.Page.getAttribute("ber_jobdetailid").setSubmitMode("always"); 


}

function populateJobDetail() {
 
    //On change of Product, populate primer field
    var lookupfield = new Array;

    //Get the lookup field

    lookupfield = Xrm.Page.getAttribute("ber_materialrequisitionid").getValue();

    //This will get the lookup field guid if there is value present in the lookup

    if (lookupfield != null) {

        var lookupid = lookupfield[0].id;
        lookupid.toString()
    }
    
            
            var columns = ['*'];
            var filter = "ber_materialrequisitionid eq guid'" + lookupid + "'";
            var collection = CrmRestKit.Retrieve('ber_materialrequisition', lookupid, columns);


            if (collection.ber_JobDetailId != null) {
            var value = new Array(); 
            value[0]= new Object();
            value[0].id=collection.ber_JobDetailId.Id;
            value[0].name=collection.ber_JobDetailId.Name;
            value[0].entityType="ber_jobclosedetail";
            Xrm.Page.getAttribute("ber_jobdetailid").setValue(value); 


            }
         
}