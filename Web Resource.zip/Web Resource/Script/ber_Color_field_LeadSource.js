function LeadScoreColorChange() {



    if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != undefined) {
        var leadsource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        if (leadsource == 278290018) {
        document.getElementById("ber_ultratech_dealer").style.backgroundColor = "#FF7F50";
         Xrm.Page.data.entity.attributes.get("ber_ultratech_dealer").setValue(true);
        Xrm.Page.getAttribute("ber_ultratech_dealer").setSubmitMode("always");
            //document.getElementById("ber_ultratech_dealer").style.backgroundColor = "#F0F8FF";
            // change back color of field to any color

            if (Xrm.Page.getAttribute("ber_ultratech_dealer") != null) {
                document.getElementById("ber_ultratech_dealer").style.backgroundColor = "#FF7F50";

                Xrm.Page.data.entity.attributes.get("ber_ultratech_dealer").setValue(true);

                Xrm.Page.getAttribute("ber_ultratech_dealer").setSubmitMode("always");
            }





        }



        else {


            if (Xrm.Page.getAttribute("ber_ultratech_dealer") != null) {
                Xrm.Page.data.entity.attributes.get("ber_ultratech_dealer").setValue(false);

                Xrm.Page.getAttribute("ber_ultratech_dealer").setSubmitMode("always");
            }



            //document.getElementById("ber_ultratech_dealer").style.backgroundColor = "#FFD700";



Xrm.Page.data.entity.attributes.get("ber_ultratech_dealer").setValue(false);
 Xrm.Page.getAttribute("ber_ultratech_dealer").setSubmitMode("always");

//document.getElementById("ber_ultratech_dealer").style.backgroundColor = "#FFD700";

        }

}

    }
}













/////////***************    preferred dealer name to be mandatory based on Ultratech dealer    *************/////////////













function leadSourceUltratech() {



    if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != undefined) {
        var leadsource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        if (leadsource == 278290018) {



            Xrm.Page.getAttribute("ber_preferabledealername").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_preferabledealername").setSubmitMode("always");



        }

else{


        else {



            Xrm.Page.getAttribute("ber_preferabledealername").setRequiredLevel("none");

            Xrm.Page.getAttribute("ber_preferabledealername").setSubmitMode("always");



        }



    }

}