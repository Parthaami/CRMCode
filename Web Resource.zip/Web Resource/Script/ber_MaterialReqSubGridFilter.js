function addExistingCustomFilter(gridTypeCode, gridControl, primaryEntityName) {
    var context = Xrm.Page.context;
    var parent = GetParentObject(null, 0);
    if (primaryEntityName != "ber_billdetail") {
        Mscrm.GridRibbonActions.addExistingFromSubGridStandard(gridTypeCode, gridControl);
        return;
    }

    // Add some logic to retrieve information needed to filter your view if you want to
    var estimate = Xrm.Page.getAttribute("ber_estimateid").getValue();
    var dealer = Xrm.Page.getAttribute("ber_dealer").getValue();

    if (estimate != null && dealer != null) {
        var estimateid = estimate[0].id;
        var estimatename = estimate[0].name;

        var dealerid = dealer[0].id;

        //Update the fetch that will be used by the grid.
        var fetch = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                    '<entity name="ber_materialrequisition">' +
                    '<attribute name="ber_materialrequisitionid"/>' +
                    '<attribute name="ber_name"/>' +
                    '<attribute name="ber_estimatedetailsid"/>' +
                    '<attribute name="ber_dealerid"/>' +
                    '<attribute name="ber_customerid"/>' +
                    '<order attribute="ber_name" descending="false"/>' +
                    '<filter type="and">' +
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '<condition attribute="ber_estimatedetailsid" operator="eq" uitype="ber_estimatedetails" value="' + estimateid + '"/>' +
                    '<condition attribute="ber_dealerid" operator="eq" uitype="account" value="' + dealerid + '"/>' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';

        // Add conditions to your fetch xml dynamically

        // Call the generic method with the rights arguments. 
        addExistingFromSubGridCustom({
            gridTypeCode: gridTypeCode, gridControl: gridControl, fetchXml: fetch, name: "Estimate Material Requisition.",
            layoutXml: '<grid name="resultset" object="' + gridTypeCode + '"  jump="ber_name" select="1" icon="1" preview="1">' +
                       '<row name="result" id="ber_materialrequisitionid">' +
                       '<cell name="ber_name" width="300"/>' +
                       '<cell name="ber_estimatedetailsid" width="100"/>' +
                       '<cell name="ber_dealerid" width="100"/>' +
                       '<cell name="ber_customerid" width="100"/>' +
                       '</row>' +
                       '</grid>', parent: parent, context: context
        });
    }
}


function addExistingFromSubGridCustom(params) {
    var relName = params.gridControl.GetParameter("relName"),
        roleOrd = params.gridControl.GetParameter("roleOrd"),
        viewId = "{00000000-0000-0000-0000-000000000001}"; // a dummy view ID
    var parameters = [params.gridTypeCode, "", relName, roleOrd, params.parent];
    var customView = { fetchXml: params.fetchXml, id: viewId, layoutXml: params.layoutXml, name: params.name, recordType: params.gridTypeCode, Type: 0 };

    var callbackRef = Mscrm.Utilities.createCallbackFunctionObject("locAssocObjAction", params.context, parameters, false);
    var lookupItems = LookupObjectsWithCallback(callbackRef, null, "multi", params.gridTypeCode, 0, null, "", null, null, null, null, null, null, viewId, [customView]);
    //var lookupItems = LookupObjects("locAssocObjAction", "multi", params.gridTypeCode, 0, null, "", null, null, null, null, null, null, viewId, [customView]);
    //if (lookupItems && lookupItems.items.length > 0) {
    //    AssociateObjects(crmFormSubmit.crmFormSubmitObjectType.value, crmFormSubmit.crmFormSubmitId.value, params.gridTypeCode, lookupItems, IsNull(roleOrd) || roleOrd == 2, "", relName);
    //}
    fetchRecords(params.fetchXml);
}

function associateRecords(materialRequisitionId) {
    var billId = Xrm.Page.data.entity.getId().replace(/[{}]/g, "");;
    SDK.REST.associateRecords(billId,
       "ber_billdetail",
       "ber_ber_billdetail_ber_materialrequisition",
       materialRequisitionId,
       "ber_materialrequisition",
       function () {
           console.log("Association successful.");
           Xrm.Page.getControl("Material_Requisition").refresh();
       },
       errorHandler);
}

function errorHandler(error) {
    //alert(error.message);
}

function CreateRecord(materialRequisitionId) {
    var entity = new XrmServiceToolkit.Soap.BusinessEntity("ber_ber_billdetail_ber_materialrequisition");
    entity.attributes["ber_materialrequisitionid"] = materialRequisitionId;
    var id = XrmServiceToolkit.Soap.Create(entity);
}

function fetchRecords(fetchXml) {
    var encodedFetchXML = encodeURIComponent(fetchXml);
    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_materialrequisitions?fetchXml=" + encodedFetchXML, true);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (i = 0; i < results.value.length; i++) {
                    var materialRequisitionId = results.value[i]["ber_materialrequisitionid"];
                    // CreateRecord(materialRequisitionId);
                    associateRecords(materialRequisitionId);
                }
            }
        }
    }
    req.send();
}