var ajax_request;

function showLoadingMessage(msg)
{
    tdAreas.style.display = 'none';
    var newdiv = document.createElement('div');
    newdiv.setAttribute('id', "msgDiv");
    newdiv.valign = "middle";
    newdiv.align = "center";
    var divInnerHTML = "<table height='100%' width='100%' style='background-color:#f6f8fa; cursor:wait'>";
    divInnerHTML += "<tr>";
    divInnerHTML += "<td valign='middle' align='center'>";
    divInnerHTML += "<img alt='' src='/_imgs/AdvFind/progress.gif'/>";
    divInnerHTML += "<div/><b>" + msg + "</b>";
    divInnerHTML += "</td></tr></table>";
    newdiv.innerHTML = divInnerHTML;
    newdiv.style.background = '#FFFFFF';
    newdiv.style.fontSize = "15px";
    newdiv.style.zIndex = "1010";
    newdiv.style.width = document.body.clientWidth;
    newdiv.style.height = document.body.clientHeight;
    newdiv.style.position = 'absolute';
    document.body.insertBefore(newdiv, document.body.firstChild);
    document.all.msgDiv.style.visibility = 'visible';
}

function UpdatePDCDate()
{
    if (Xrm.Page.ui.getFormType() == 1)
    {
        showLoadingMessage("Upating PDCs...");

        var startDate = Xrm.Page.getAttribute('ber_rentalstartdate').getValue();
        var Day = startDate.getDate();
        var Month = startDate.getMonth();
        var Year = startDate.getFullYear();
        var serverURL = window.location.protocol + "//" + window.location.host;
        var _orgName = Xrm.Page.context.getOrgUniqueName();
        var ObjId = Xrm.Page.getAttribute('ber_installationrequest');
        if (ObjId == null)
        {
            return;
        }
        var webServiceURL = serverURL + "/ISV/" + _orgName + "/ColorBankService/Service.asmx?";

        //var req_params = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><UpdatePDCDate xmlns="http://tempuri.org/"><strGuid>' + ObjId + '</strGuid></UpdatePDCDate></soap:Body></soap:Envelope>';
        var req_params = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><UpdatePDCDate xmlns="http://tempuri.org/"><strGuid>' + ObjId.getValue()[0].id.replace("{", "").replace("}", "") + '</strGuid><nDay>' + Day + '</nDay><nMonth>' + Month + '</nMonth><nYear>' + Year + '</nYear></UpdatePDCDate></soap:Body></soap:Envelope>';
        window.XMLHttpRequest = new XMLHttpRequest();

        try
        {
            if (window.XMLHttpRequest)
            {
                ajax_request = new XMLHttpRequest();
            }
        }
        catch (trymicrosoft)
        {
            try
            {
                ajax_request = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (othermicrosoft)
            {
                try
                {
                    ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
                }
                catch (failed)
                {
                    ajax_request = false;
                }
            }
        }

        ajax_request.open("POST", webServiceURL, true);
        ajax_request.setRequestHeader("Content-Type", "text/xml;charset=utf-8");
        ajax_request.onreadystatechange = receiveXML_SOAPDataItem;
        ajax_request.send(req_params);
    }
}

function receiveXML_SOAPDataItem()
{
    if (ajax_request.readyState == 4)
    {
        if (ajax_request.status == 200)
        {
            var xmldata = ajax_request.responseXML
            var result = xmldata.getElementsByTagName("UpdatePDCDateResult");
            if (result.length > 0)
            {
                document.all.msgDiv.style.visibility = 'hidden';
            }
            window.location.reload(true);
        }
    }
}