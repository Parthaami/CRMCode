function contactUpdate(id, entityObject, odataSetName, successCallback, errorCallback) {
    var context = Xrm.Page.context;
    // var serverUrl = context.getServerUrl();
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    // var serverUrl = "http://10.62.163.60:6505/BergerQA";

    //The XRM OData end-point
    var ODATA_ENDPOINT = "/XRMServices/2011/OrganizationData.svc";

    //id is required
    if (!id) {
        alert("record id is required.");
        return;
    }
    //odataSetName is required, i.e. "AccountSet"
    if (!odataSetName) {
        alert("odataSetName is required.");
        return;
    }

    //Parse the entity object into JSON
    var jsonEntity = window.JSON.stringify(entityObject);

    //Asynchronous AJAX function to Update a CRM record using OData
    $.ajax({
        type: "POST",
        async: false,
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        data: jsonEntity,
        url: serverUrl + ODATA_ENDPOINT + "/" + odataSetName + "(guid'" + id + "')",
        beforeSend: function (XMLHttpRequest) {
            //Specifying this header ensures that the results will be returned as JSON.             
            XMLHttpRequest.setRequestHeader("Accept", "application/json");

            //Specify the HTTP method MERGE to update just the changes you are submitting.             
            XMLHttpRequest.setRequestHeader("X-HTTP-Method", "MERGE");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            //The MERGE does not return any data at all, so we'll add the id 
            //onto the data object so it can be leveraged in a Callback. When data 
            //is used in the callback function, the field will be named generically, "id"
            data = new Object();
            data.id = id;
            if (successCallback) {
                successCallback(data, textStatus, XmlHttpRequest);
            }
        },
        error: function (XmlHttpRequest, textStatus, errorThrown) {
            if (errorCallback)
                errorCallback(XmlHttpRequest, textStatus, errorThrown);
            else
                errorHandler(XmlHttpRequest, textStatus, errorThrown);
        }
    });
}


function errorHandler(xmlHttpRequest, textStatus, errorThrow) {
    alert("Error : " + textStatus + ": " + xmlHttpRequest.statusText);
}

//Called upon successful Account update.
function updateContactCompleted(data, textStatus, XmlHttpRequest) {
    //Get back the Account JSON object
    var contact = data;
    // alert("Contact updated: id = " + contact.id);
    Xrm.Page.getAttribute("ber_epstatusset").setValue() == true;
}

function SetEPStatus() {
    //  debugger;
    if ((Xrm.Page.getAttribute("ber_epstatusset").getValue() == false || Xrm.Page.getAttribute("ber_epstatusset").getValue() == null) && Xrm.Page.getAttribute("statuscode").getValue() == 278290000) {
        var updateStatus = false;
        var painter = Xrm.Page.getAttribute("ber_painterid").getValue();
        var item = Xrm.Page.getAttribute("ber_itemid").getValue();
        if (painter != null && painter != undefined) {
            var painterid = painter[0].id;
            var lookupRecordGuid = painterid.replace("{", "").replace("}", "");

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=ber_epstatus&$filter=contactid eq " + lookupRecordGuid, false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var result = JSON.parse(req.response);
                if (result != null) {
                    var ber_epstatus = result.value[0]["ber_epstatus"];
                    var ber_epstatus_formatted = result.value[0]["ber_epstatus@OData.Community.Display.V1.FormattedValue"];
                    //  alert(ber_epstatus);
                    // alert(ber_epstatus_formatted);
                }
            }

            // If status is XP, do nothing
            if (ber_epstatus != 278290000) {
                var itemid = item[0].id;
                var lookupitemid = itemid.replace("{", "").replace("}", "");
                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value&$filter=_ber_painterid_value eq " + lookupRecordGuid + " and  _ber_itemid_value eq " + lookupitemid + " and  statuscode eq 278290000", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.send();
                if (req.response != null && req.response != "") {
                    var result = JSON.parse(req.response);
                    if (result != null) {
                        if (result.value.length > 0) {

                            //   alert(result.value.length);
                            var _ber_itemid_value = result.value[0]["_ber_itemid_value"];
                            var _ber_itemid_value_formatted = result.value[0]["_ber_itemid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_itemid_value_lookuplogicalname = result.value[0]["_ber_itemid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            //// Do Nothing
                            /*if(EPICollection.results.length == 1)
                            {
                            var contact = {
                            // EP Status = XP
                            ber_epstatus: {  Value: 278290000 }
                            }; 
                            //updateRecord exists in JQueryRESTDataOperationFunctions.js
                            contactUpdate(painterid, contact, "ContactSet", updateContactCompleted, null);
                            }*/
                        }
                        else {

                            var req = new XMLHttpRequest();
                            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value&$filter=_ber_painterid_value eq " + lookupRecordGuid + " and  statuscode eq 278290000", false);
                            req.setRequestHeader("OData-MaxVersion", "4.0");
                            req.setRequestHeader("OData-Version", "4.0");
                            req.setRequestHeader("Accept", "application/json");
                            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            req.send();
                            if (req.response != null && req.response != "") {
                                var result = JSON.parse(req.response);
                                if (result != null) {
                                    if (result.value.length > 0) {
                                        var _ber_itemid_value = result.value[0]["_ber_itemid_value"];
                                        var _ber_itemid_value_formatted = result.value[0]["_ber_itemid_value@OData.Community.Display.V1.FormattedValue"];
                                        var _ber_itemid_value_lookuplogicalname = result.value[0]["_ber_itemid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                                        // if(EPICollection1.results.length == 1)
                                        // Ep Status = PXP
                                        if (ber_epstatus == 278290003) {
                                            var contact = {
                                                // EP Status = XP
                                                ber_epstatus: { Value: 278290000 }
                                            };
                                            //updateRecord exists in JQueryRESTDataOperationFunctions.js
                                            contactUpdate(painterid, contact, "ContactSet", updateContactCompleted, null);
                                        }
                                        else {
                                            var contact = {
                                                // EP Status = PXP
                                                ber_epstatus: { Value: 278290003 }
                                            };
                                            //updateRecord exists in JQueryRESTDataOperationFunctions.js
                                            contactUpdate(painterid, contact, "ContactSet", updateContactCompleted, null);
                                        }
                                    }
                                    else {
                                        var contact = {
                                            // EP Status = PXP
                                            ber_epstatus: { Value: 278290003 }
                                        };
                                        //updateRecord exists in JQueryRESTDataOperationFunctions.js
                                        contactUpdate(painterid, contact, "ContactSet", updateContactCompleted, null);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


function OnLoad() {
    //   debugger;
    var dealer = Xrm.Page.getAttribute("ber_dealer").getValue();
    if (dealer == null) {
        var painter = Xrm.Page.getAttribute("ber_painterid").getValue();
        var painterId = painter[0].id;
        painterId = painterId.replace("{", "").replace("}", "");
        var columns = ['ber_DealerId'];

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts(" + painterId + ")?$select=_ber_dealerid_value", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var _ber_dealerid_value = result["_ber_dealerid_value"];
                var _ber_dealerid_value_formatted = result["_ber_dealerid_value@OData.Community.Display.V1.FormattedValue"];
            }
        }
        if (_ber_dealerid_value != null) {
            var dealerLooukup = new Array();
            dealerLooukup[0] = RestToJsLookup(_ber_dealerid_value, _ber_dealerid_value_formatted);
            if (dealerLooukup[0] != null) {
                Xrm.Page.getAttribute("ber_dealer").setValue(dealerLooukup);
            }
        }

        /*
        var Contact = CrmRestKit.Retrieve('Contact', painterId, columns);
        if (Contact != null && Contact != undefined) 
        {
        if (Contact.ber_DealerId != null) 
        {
        var dealerLooukup = new Array();
        dealerLooukup[0] = RestToJsLookup(Contact.ber_DealerId);
        if (dealerLooukup[0] != null) {
        Xrm.Page.getAttribute("ber_dealer").setValue(dealerLooukup);
        }
        }
        }
        */
    }
    var status = Xrm.Page.getAttribute("statuscode").getValue();
    var InstrumentNo = Xrm.Page.getAttribute("ber_name").getValue();
    var Checkduplicate = Xrm.Page.getAttribute("ber_checkduplicate").getValue();


    if (status == 278290000 && InstrumentNo != null && Checkduplicate == true) {
        // Xrm.Page.getControl("statuscode").setDisabled(true);
        Xrm.Page.getControl("statuscode").removeOption("1");
        Xrm.Page.getControl("ber_name").setDisabled(true);
        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_name").setRequiredLevel("required");
    }

    else if ((Checkduplicate == false)) {

        Xrm.Page.getAttribute("ber_name").setValue(null);
        Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
        Xrm.Page.getControl("ber_name").setDisabled(false);


        Xrm.Page.getAttribute("statuscode").setValue(1);
        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");


    }
}

function onChangeStatus() {
    var status = Xrm.Page.getAttribute("statuscode").getValue();
    if (status == 278290000) {
        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_name").setRequiredLevel("required");
        var date = new Date();
        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(date);
        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
    }
    else {
        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_name").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
    }
}

function setendDate() {
    var startDate = Xrm.Page.getAttribute("ber_startdate").getValue();
    var endDate;
    if (startDate != null && startDate != undefined) {
        endDate = new Date(startDate.getFullYear() + 1, startDate.getMonth(), startDate.getDate() - 1);
    }
    Xrm.Page.getAttribute("ber_enddate").setValue(endDate);
}

function approvalrole() {
    //debugger;
    var roleName = "Paint Express Approver";
    var PEapprovar = CheckUserRole(roleName);
    if (PEapprovar) {
        Xrm.Page.ui.controls.get("statuscode").setDisabled(false);
    }
    else {
        Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
    }
}

///*******************************Common Funtions *********************************************************
function RestToJsLookup(guid, name) {
    var jslookup = null;
    jslookup = new Object();
    jslookup.id = guid;
    if (name != null) {
        jslookup.name = name;
    }
    else {
        jslookup.name = "";
    }
    jslookup.entityType = "account";
    return jslookup;
}

//Check login User has role passed as parameter
function CheckUserRole(roleName) {
    var currentUserRoles = Xrm.Page.context.getUserRoles();
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == roleName) {
            return true;
        }
    }
    return false;
}

//Get Rolename based on RoleId
function GetRoleName(roleId) {
    //var serverUrl = Xrm.Page.context.getServerUrl();
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
    var roleName = null;
    $.ajax(
        {
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                roleName = data.d.results[0].Name;
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
        }
    );
    return roleName;
}









/////////////////////////////////////
/*
function Disablefields() {
var status = Xrm.Page.getAttribute("statuscode").getValue();
if (Xrm.Page.getAttribute("ber_name") != undefined && Xrm.Page.getAttribute("ber_name").getValue() != null) {
var InstrumentNo = Xrm.Page.getAttribute("ber_name").getValue();

}

if (status == 278290000 && InstrumentNo != null) {
Xrm.Page.getControl("statuscode").removeOption("1");
Xrm.Page.getControl("ber_name").setDisabled(true);

}

}
*/








function CheckDuplicate(executionObj) {
    var status = Xrm.Page.getAttribute("statuscode").getValue();
    if (status == 1 && Xrm.Page.getAttribute("ber_name").getValue() != null) {
        Xrm.Page.getAttribute("ber_name").setValue(null);
        Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
        Xrm.Page.getControl("ber_name").setDisabled(false);
        alert("Status must be approved during enrolment of serial number for tool");
        executionObj.getEventArgs().preventDefault();

    }

}