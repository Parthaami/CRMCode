function DFFOnChange() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (Xrm.Page.getAttribute("ber_dff") != null && Xrm.Page.getAttribute("ber_dff").getValue() != null) {
        var DFF = Xrm.Page.getAttribute("ber_dff").getValue();
        if (DFF == 1) {
            Xrm.Page.getControl("ber_consigneename").setVisible(true);
            Xrm.Page.getControl("ber_addressline1").setVisible(true);
            Xrm.Page.getControl("ber_addressline2").setVisible(true);
            Xrm.Page.getControl("ber_range").setVisible(true);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(true);
            Xrm.Page.getControl("ber_commissionerate").setVisible(true);
            Xrm.Page.getControl("ber_eccno").setVisible(true);
            Xrm.Page.getControl("ber_ceregnno").setVisible(true);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(true);

            Xrm.Page.getAttribute("ber_paymentmode").setValue(null);
            Xrm.Page.getAttribute("ber_chequenumber").setValue(null);


            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_paymentmode").setVisible(false);
            Xrm.Page.getControl("ber_chequenumber").setVisible(false);


            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);

            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
            Xrm.Page.ui.controls.get("ber_thirdpartyname").setDisabled(true);

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");



            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("none");
            setVisibleSection("general", "dffdetails", true);
            setVisibleSection("general", "prolinkdetails", false);
        }

        else if (DFF == 2) {
            Xrm.Page.getControl("ber_paymentmode").setVisible(true);
            Xrm.Page.getControl("ber_chequenumber").setVisible(true);

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");


            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("none");

            Xrm.Page.getAttribute("ber_consigneename").setValue(null);
            Xrm.Page.getAttribute("ber_addressline1").setValue(null);
            Xrm.Page.getAttribute("ber_addressline2").setValue(null);
            Xrm.Page.getAttribute("ber_range").setValue(null);
            Xrm.Page.getAttribute("ber_adressofcedivision").setValue(null);
            Xrm.Page.getAttribute("ber_commissionerate").setValue(null);
            Xrm.Page.getAttribute("ber_eccno").setValue(null);
            Xrm.Page.getAttribute("ber_ceregnno").setValue(null);
            Xrm.Page.getAttribute("ber_thirdpartyname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_consigneename").setVisible(false);
            Xrm.Page.getControl("ber_addressline1").setVisible(false);
            Xrm.Page.getControl("ber_addressline2").setVisible(false);
            Xrm.Page.getControl("ber_range").setVisible(false);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(false);
            Xrm.Page.getControl("ber_commissionerate").setVisible(false);
            Xrm.Page.getControl("ber_eccno").setVisible(false);
            Xrm.Page.getControl("ber_ceregnno").setVisible(false);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);
            setVisibleSection("general", "dffdetails", false);
            setVisibleSection("general", "prolinkdetails", false);
        }

        else if (DFF == 3) {
            Xrm.Page.getControl("ber_paymentmode").setVisible(true);
            Xrm.Page.getControl("ber_chequenumber").setVisible(true);



            Xrm.Page.getControl("ber_consigneename").setVisible(true);
            Xrm.Page.getControl("ber_addressline1").setVisible(true);
            Xrm.Page.getControl("ber_addressline2").setVisible(true);
            Xrm.Page.getControl("ber_range").setVisible(true);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(true);
            Xrm.Page.getControl("ber_commissionerate").setVisible(true);
            Xrm.Page.getControl("ber_eccno").setVisible(true);
            Xrm.Page.getControl("ber_ceregnno").setVisible(true);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(true);

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("none");

            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);
            setVisibleSection("general", "dffdetails", true);
            setVisibleSection("general", "prolinkdetails", false);
        }

        else if (DFF == 4) {
            Xrm.Page.getControl("ber_paymentmode").setVisible(true);


            Xrm.Page.getControl("ber_chequenumber").setVisible(true);



            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(true);

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("required");

            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");



            Xrm.Page.getAttribute("ber_consigneename").setValue(null);
            Xrm.Page.getAttribute("ber_addressline1").setValue(null);
            Xrm.Page.getAttribute("ber_addressline2").setValue(null);
            Xrm.Page.getAttribute("ber_range").setValue(null);
            Xrm.Page.getAttribute("ber_adressofcedivision").setValue(null);
            Xrm.Page.getAttribute("ber_commissionerate").setValue(null);
            Xrm.Page.getAttribute("ber_eccno").setValue(null);
            Xrm.Page.getAttribute("ber_ceregnno").setValue(null);
            Xrm.Page.getAttribute("ber_thirdpartyname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_consigneename").setVisible(false);
            Xrm.Page.getControl("ber_addressline1").setVisible(false);
            Xrm.Page.getControl("ber_addressline2").setVisible(false);
            Xrm.Page.getControl("ber_range").setVisible(false);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(false);
            Xrm.Page.getControl("ber_commissionerate").setVisible(false);
            Xrm.Page.getControl("ber_eccno").setVisible(false);
            Xrm.Page.getControl("ber_ceregnno").setVisible(false);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);
            setVisibleSection("general", "dffdetails", false);
            setVisibleSection("general", "prolinkdetails", true);
        }
        else if (DFF == 5) {
            Xrm.Page.getControl("ber_paymentmode").setVisible(true);
            Xrm.Page.getControl("ber_chequenumber").setVisible(true);


            Xrm.Page.getControl("ber_consigneename").setVisible(true);
            Xrm.Page.getControl("ber_addressline1").setVisible(true);
            Xrm.Page.getControl("ber_addressline2").setVisible(true);
            Xrm.Page.getControl("ber_range").setVisible(true);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(true);
            Xrm.Page.getControl("ber_commissionerate").setVisible(true);
            Xrm.Page.getControl("ber_eccno").setVisible(true);
            Xrm.Page.getControl("ber_ceregnno").setVisible(true);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(true);
            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(true);

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");


            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");



            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("required");

            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);
            setVisibleSection("general", "dffdetails", true);
            setVisibleSection("general", "prolinkdetails", true);

            Xrm.Page.ui.controls.get("ber_thirdpartyname").setDisabled(true);
        }

        else if (DFF == 6) {

            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(true);
            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(true);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(true);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(true);

            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");

            Xrm.Page.getAttribute("ber_paymentmode").setValue(null);
            Xrm.Page.getAttribute("ber_chequenumber").setValue(null);


            Xrm.Page.getAttribute("ber_consigneename").setValue(null);
            Xrm.Page.getAttribute("ber_addressline1").setValue(null);
            Xrm.Page.getAttribute("ber_addressline2").setValue(null);
            Xrm.Page.getAttribute("ber_range").setValue(null);
            Xrm.Page.getAttribute("ber_adressofcedivision").setValue(null);
            Xrm.Page.getAttribute("ber_commissionerate").setValue(null);
            Xrm.Page.getAttribute("ber_eccno").setValue(null);
            Xrm.Page.getAttribute("ber_ceregnno").setValue(null);
            Xrm.Page.getAttribute("ber_thirdpartyname").setValue(null);

            Xrm.Page.getControl("ber_paymentmode").setVisible(false);
            Xrm.Page.getControl("ber_chequenumber").setVisible(false);


            Xrm.Page.getControl("ber_consigneename").setVisible(false);
            Xrm.Page.getControl("ber_addressline1").setVisible(false);
            Xrm.Page.getControl("ber_addressline2").setVisible(false);
            Xrm.Page.getControl("ber_range").setVisible(false);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(false);
            Xrm.Page.getControl("ber_commissionerate").setVisible(false);
            Xrm.Page.getControl("ber_eccno").setVisible(false);
            Xrm.Page.getControl("ber_ceregnno").setVisible(false);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(false);
            setVisibleSection("general", "dffdetails", false);
            setVisibleSection("general", "prolinkdetails", true);
        }

        else if (DFF == 7) {
            Xrm.Page.getControl("ber_consigneename").setVisible(true);
            Xrm.Page.getControl("ber_addressline1").setVisible(true);
            Xrm.Page.getControl("ber_addressline2").setVisible(true);
            Xrm.Page.getControl("ber_range").setVisible(true);
            Xrm.Page.getControl("ber_adressofcedivision").setVisible(true);
            Xrm.Page.getControl("ber_commissionerate").setVisible(true);
            Xrm.Page.getControl("ber_eccno").setVisible(true);
            Xrm.Page.getControl("ber_ceregnno").setVisible(true);
            Xrm.Page.getControl("ber_thirdpartyname").setVisible(true);
            Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(true);

            Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("required");

            Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");

            Xrm.Page.getAttribute("ber_paymentmode").setValue(null);
            Xrm.Page.getAttribute("ber_chequenumber").setValue(null);


            Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
            Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);

            Xrm.Page.getControl("ber_paymentmode").setVisible(false);
            Xrm.Page.getControl("ber_chequenumber").setVisible(false);


            Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
            Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);
            setVisibleSection("general", "dffdetails", true);
            setVisibleSection("general", "prolinkdetails", true);
        }
    }
    else {

        Xrm.Page.getControl("ber_consigneename").setVisible(false);
        Xrm.Page.getControl("ber_addressline1").setVisible(false);
        Xrm.Page.getControl("ber_addressline2").setVisible(false);
        Xrm.Page.getControl("ber_range").setVisible(false);
        Xrm.Page.getControl("ber_adressofcedivision").setVisible(false);
        Xrm.Page.getControl("ber_commissionerate").setVisible(false);
        Xrm.Page.getControl("ber_eccno").setVisible(false);
        Xrm.Page.getControl("ber_ceregnno").setVisible(false);
        Xrm.Page.getControl("ber_thirdpartyname").setVisible(false);
        Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(false);
        Xrm.Page.getControl("ber_paymentmode").setVisible(false);
        Xrm.Page.getControl("ber_chequenumber").setVisible(false);


        Xrm.Page.getControl("ber_prolinkdetailsprojectcode").setVisible(false);
        Xrm.Page.getControl("ber_prolinkdetailscontractorname").setVisible(false);
        Xrm.Page.getControl("ber_prolinkdetailsarchitectname").setVisible(false);
        Xrm.Page.getControl("ber_prolinkdetailsbuildername").setVisible(false);

        Xrm.Page.getAttribute("ber_consigneename").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_thirdpartyname").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_paymentmode").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_chequenumber").setRequiredLevel("none");

        Xrm.Page.getAttribute("ber_paymentmode").setValue(null);
        Xrm.Page.getAttribute("ber_chequenumber").setValue(null);


        Xrm.Page.getAttribute("ber_prolinkdetailsprojectcode").setValue(null);
        Xrm.Page.getAttribute("ber_prolinkdetailscontractorname").setValue(null);
        Xrm.Page.getAttribute("ber_prolinkdetailsarchitectname").setValue(null);
        Xrm.Page.getAttribute("ber_prolinkdetailsbuildername").setValue(null);
        Xrm.Page.getAttribute("ber_consigneename").setValue(null);
        Xrm.Page.getAttribute("ber_addressline1").setValue(null);
        Xrm.Page.getAttribute("ber_addressline2").setValue(null);
        Xrm.Page.getAttribute("ber_range").setValue(null);
        Xrm.Page.getAttribute("ber_adressofcedivision").setValue(null);
        Xrm.Page.getAttribute("ber_commissionerate").setValue(null);
        Xrm.Page.getAttribute("ber_eccno").setValue(null);
        Xrm.Page.getAttribute("ber_ceregnno").setValue(null);
        Xrm.Page.getAttribute("ber_thirdpartyname").setValue(null);
        setVisibleSection("general", "dffdetails", false);
        setVisibleSection("general", "prolinkdetails", false);
        if (!isCrmForMobile) {
            Xrm.Page.ui.controls.get("IFRAME_ChequeNumber").setVisible(false);
        }
        else {
            Xrm.Page.getControl("ber_chequenumbermobile").setVisible(false);
        }

    }
}

//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) {
        }
        else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

//As payment mode field is visible on-demand, order grid will expanded automatically. 
//So we are forcefully collapse the order tab by the follwing code.
function showHideTabs() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (Xrm.Page.ui.getFormType() == 2 || Xrm.Page.getAttribute("ordernumber").getValue() != null) {
        if (!isCrmForMobile) {
            Xrm.Page.ui.tabs.get("tab_6").setFocus();
            Xrm.Page.ui.tabs.get("tab_6").setDisplayState("expanded");
            Xrm.Page.ui.tabs.get("notes").setDisplayState("expanded");
            Xrm.Page.ui.tabs.get("general").setDisplayState("collapsed");
        }
    }
}