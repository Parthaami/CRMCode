function depofill() {
    //debugger;
    if (Xrm.Page.getAttribute("ber_dealerid").getValue() != null) {
        var AccId = Xrm.Page.getAttribute("ber_dealerid").getValue()[0].id;
        AccId = AccId.replace("{", "").replace("}", "");

        $.ajax({
            type: "GET",
            async: false,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + AccId + ")?$select=_ber_depotid_value",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processdata: false,
            crossDomain: true,
            success: function (msg) {

                collection = msg;

            },
            error: function (msg) {
                alert('error fetching the accounts information from crm organization');
            },
        });

        if (collection != null) {
            var depoName = collection["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
            var depot_id = collection["_ber_depotid_value"];
            var depotlogicalname = collection["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

            if (depot_id != null && depot_id != "") {
                var depotid = new Array();
                depotid[0] = new Object();
                depotid[0].id = depot_id;
                depotid[0].name = depoName;
                depotid[0].entityType = depotlogicalname;
                Xrm.Page.getControl("ber_depotid").setDisabled(false);
                Xrm.Page.getAttribute("ber_depotid").setValue(depotid);
                Xrm.Page.getAttribute("ber_depotid").setSubmitMode("always");
                Xrm.Page.getControl("ber_depotid").setDisabled(true);
            }
        }
        else {
            Xrm.Page.getControl("ber_depotid").setDisabled(false);
            Xrm.Page.getAttribute("ber_depotid").setValue(null);
            Xrm.Page.getControl("ber_depotid").setDisabled(true);
        }
    }
    else {
        Xrm.Page.getControl("ber_depotid").setDisabled(false);
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        Xrm.Page.getControl("ber_depotid").setDisabled(true);
    }
}