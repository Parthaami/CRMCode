// JavaScript source code
function OnDealerTypeSelection() {
    //debugger;

    if (Xrm.Page.getAttribute("ber_dealertype")) {
        if (Xrm.Page.getAttribute("ber_dealertype").getValue() == false) {
            Xrm.Page.getControl("ber_dealerid").setDisabled(false);
            Xrm.Page.getControl("ber_dealercode").setDisabled(true);
            setVisibleSection("general", "general_section_15", false);   //added by Madhymita on 13th June,2018 due to multidealer functionality
            // Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
            // Xrm.Page.getAttribute("ber_otherdealers").setRequiredLevel("none");
        }
        else if (Xrm.Page.getAttribute("ber_dealertype").getValue() == true) {
            Xrm.Page.getControl("ber_dealerid").setDisabled(true);
            Xrm.Page.getControl("ber_dealercode").setDisabled(false);
            setVisibleSection("general", "general_section_15", true);   //added by Madhymita on 13th June,2018 due to multidealer functionality
            //Xrm.Page.getAttribute("ber_otherdealers").setRequiredLevel("required");
            //Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
            // filterOtherDealersByDepot();
        }
    }
}



function filterOtherDealersByDepot() {

    //document.getElementById("ber_otherdealers").disableViewPicker = 0;
    $("#ber_otherdealers").find("img").attr("disableviewpicker", "0");

    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        if (_depotId != null) {
            // _depotId = _depotId.replace("{", "");
            //_depotId = _depotId.replace("}", "");
            var view_otherdealersdisplayname = "Other XP Dealers By Depot";
            //var view_otherdealersId = GetuniqueGuid();;
            //var view_otherdealersId = Xrm.Page.getControl("ber_otherdealers").getDefaultView();
            var view_otherdealersId = "{A95FAC25-5EA4-4017-8AC2-CD933B696AB2}";
            var IsDefaultView = true;

            layoutxml_otherdealers = '<grid name="resultset" object="1" jump="ber_otherdealers" select="1" icon="2" preview="1">' +
                    '<row name="result" id="ber_otherdealerid">' +
                    '<cell name="ber_name" width="100" />' +
                    '<cell name="ber_otherdealers" width="100" />' +
                    '<cell name="ber_dealerpincode" width="100" />' +
            '<cell name="ber_otherdealerdepotid" width="150"  />' +
              '</row>' +
              '</grid>';

            fetchxml_otherdealers = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="ber_otherdealer">' +
                    '<attribute name="createdon" />' +
                    '<attribute name="ber_name" />' +
                    '<attribute name="ber_otherdealers" />' +
                    '<attribute name="ber_dealerpincode" />' +
                    '<attribute name="ber_otherdealerid" />' +
                    '<attribute name="ber_otherdealerdepotid" />' +
                    '<order attribute="createdon" descending="false" />' +
                    '<filter type="and">' +
                      '<condition attribute="statecode" operator="eq" value="0" />' +
                      '<condition attribute="ber_otherdealerdepotid" operator="eq"  uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                  '</entity>' +
                '</fetch>';

            if (Xrm.Page.getControl("ber_otherdealers") != null) {
                Xrm.Page.getControl("ber_otherdealers").addCustomView(view_otherdealersId, "ber_otherdealer", view_otherdealersdisplayname, fetchxml_otherdealers, layoutxml_otherdealers, IsDefaultView);
                Xrm.Page.getControl("ber_otherdealers").setDefaultView(view_otherdealersId);
            }
            //document.getElementById("ber_otherdealers").disableViewPicker = 1;
            $("#ber_otherdealers").find("img").attr("disableviewpicker", "1")

        }
    }

}




function GetuniqueGuid() {
    var a = function () {
        return (65536 * (1 + Math.random()) | 0).toString(16).substring(1);
    };
    return "{" + (a() + a() + "-" + a() + "-" + a() + "-" + a() + "-" + a() + a() + a()) + "}";
}



function OnloadSetDealerType() {

    if (Xrm.Page.getAttribute("ber_dealertype") != null) {
        if (Xrm.Page.getAttribute("ber_dealertype").getValue() == null) {
            Xrm.Page.getAttribute("ber_dealertype").setValue(0);
        }
        else if (Xrm.Page.getAttribute("ber_dealertype")) {
            if (Xrm.Page.getAttribute("ber_dealertype").getValue() == false) {
                Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                Xrm.Page.getControl("ber_dealercode").setDisabled(true);      //added by Madhymita on 13th June,2018 due to multidealer functionality

            }
            else if (Xrm.Page.getAttribute("ber_dealertype").getValue() == true) {
                Xrm.Page.getControl("ber_dealerid").setDisabled(true);
                Xrm.Page.getControl("ber_dealercode").setDisabled(false);        //added by Madhymita on 13th June,2018 due to multidealer functionality

            }
        }
    }
}

function OnLeadDealerSelection() {
    if (Xrm.Page.getAttribute("ber_dealercode").getValue() != null) {
        Xrm.Page.getAttribute("ber_dealercode").setValue(null);

    }
}

/*
function OnOtherDealerSelection() {
//debugger;

if (Xrm.Page.getAttribute("ber_otherdealers").getValue() != null) {
var accountid = new Array();
accountid[0] = new Object();
var AccId = Xrm.Page.getAttribute("ber_otherdealers").getValue()[0].id;
var columns = ['ber_OtherDealers'];
var filter = "ber_otherdealerId eq (Guid'" + AccId + "')";
var collection = CrmRestKit.RetrieveMultiple('ber_otherdealer', columns, filter);
if (collection != null && collection.results != null && collection.results.length > 0) {
if (collection.results[0].ber_OtherDealers != null) {
accountid[0].id = collection.results[0].ber_OtherDealers.Id;
accountid[0].name = collection.results[0].ber_OtherDealers.Name;
accountid[0].entityType = collection.results[0].ber_OtherDealers.LogicalName;
// Xrm.Page.getControl("ber_dealerid").setDisabled(false);
Xrm.Page.getAttribute("ber_dealerid").setValue(accountid);
Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");
// Xrm.Page.getControl("ber_dealerid").setDisabled(true);
}
}

}
}

*/

function DealerTypeSeletionVisibility() {

    //debugger;

    if (Xrm.Page.getAttribute("statuscode").getValue() == 278290007) {
        if (Xrm.Page.getControl("ber_dealertype") != null) {
            Xrm.Page.getControl("ber_dealertype").setVisible(false);
        }

        if (Xrm.Page.getControl("ber_dealercode") != null) {
            Xrm.Page.getControl("ber_dealercode").setVisible(false);
        }

    }
    else {
        if (Xrm.Page.getControl("ber_dealertype") != null) {
            Xrm.Page.getControl("ber_dealertype").setVisible(true);
        }
        OnloadSetDealerType();
    }
}


function filterPaintersByDepot() {

    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        var LeadSource = Xrm.Page.getAttribute("leadsourcecode").getValue();

        if (Xrm.Page.getAttribute("ber_xpa") != undefined && Xrm.Page.getAttribute("ber_xpa").getValue() != null) {
            var XPA = Xrm.Page.getAttribute("ber_xpa").getValue();
            var XPAId = (Xrm.Page.getAttribute("ber_xpa").getValue())[0].id;
        }

        if (_depotId != null && XPAId != null) {
            setXPAPainter();
        }
        else {
            if (_depotId != null && LeadSource == 278290033 || LeadSource == 278290034 || LeadSource == 278290035 || LeadSource == 278290055) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_PaintersByDepotDisplayname = "Retails project Painters ";
                //var view_PaintersByDepotId = GetuniqueGuid();
                //var view_PaintersByDepotId = Xrm.Page.getControl("ber_masterpainterid1").getDefaultView();
                var view_PaintersByDepotId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
                var IsDefaultView = true;

                layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                        '<row name="result" id="contactid">' +
                        '<cell name="fullname" width="100" />' +
                        '<cell name="ber_exteriorpainterrating" width="100" />' +
                        '<cell name="ber_corepainterscp" width="100" />' +
                        '<cell name="ber_epstatus" width="100" />' +
                        '<cell name="ber_painterrating" width="100" />' +
                        '<cell name="ber_dealerid" width="100" />' +
                        '<cell name="ber_depotid" width="100" />' +
                        '<cell name="mobilephone" width="100" />' +
                        '<cell name="ber_preferredlanguage1" width="100" />' +
                        '<cell name="ber_preferredlanguage2" width="100" />' +
                  '</row>' +
                  '</grid>';

                fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                      '<entity name="contact">' +
                        '<attribute name="fullname" />' +
                        '<attribute name="contactid" />' +
                        '<attribute name="ber_corepainterscp" />' +
                        '<attribute name="ber_preferredlanguage2" />' +
                        '<attribute name="ber_preferredlanguage1" />' +
                        '<attribute name="ber_painterrating" />' +
                        '<attribute name="ber_exteriorpainterrating" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="ber_dealerid" />' +
                        '<attribute name="ber_epstatus" />' +
                        '<attribute name="mobilephone" />' +
                        '<order attribute="ber_corepainterscp" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="statecode" operator="eq" value="0" />' +
                          '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                           '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                          '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                        '</filter>' +
                      '</entity>' +
                    '</fetch>';

                if (Xrm.Page.getControl("ber_masterpainterid") != null) {
                    Xrm.Page.getControl("ber_masterpainterid").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                    Xrm.Page.getControl("ber_masterpainterid").setDefaultView(view_PaintersByDepotId);
                }
                //document.getElementById("ber_masterpainterid1").disableViewPicker = 1;
                $("#ber_masterpainterid1").find("img").attr("disableviewpicker", "1");
            }

            else {

                if (_depotId != null && LeadSource != 278290033 || LeadSource != 278290034 || LeadSource != 278290035 || LeadSource == 278290055) {
                    // _depotId = _depotId.replace("{", "");
                    //_depotId = _depotId.replace("}", "");
                    var view_PaintersByDepotDisplayname = "XP/PXP Painters with Sander";
                    //var view_PaintersByDepotId = GetuniqueGuid();
                    //var view_PaintersByDepotId = Xrm.Page.getControl("ber_masterpainterid1").getDefaultView();
                    var view_PaintersByDepotId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
                    var IsDefaultView = true;

                    layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                        '<row name="result" id="contactid">' +
                        '<cell name="fullname" width="100" />' +
                        '<cell name="ber_exteriorpainterrating" width="100" />' +
                        '<cell name="ber_corepainterscp" width="100" />' +
                        '<cell name="ber_epstatus" width="100" />' +
                        '<cell name="ber_painterrating" width="100" />' +
                        '<cell name="ber_havesander" width="100" />' +
                        '<cell name="ber_dealerid" width="100" />' +
                        '<cell name="ber_depotid" width="100" />' +
                        '<cell name="mobilephone" width="100" />' +
                        '<cell name="ber_preferredlanguage1" width="100" />' +
                        '<cell name="ber_preferredlanguage2" width="100" />' +
                  '</row>' +
                  '</grid>';

                    fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                      '<entity name="contact">' +
                        '<attribute name="fullname" />' +
                        '<attribute name="contactid" />' +
                        '<attribute name="ber_corepainterscp" />' +
                        '<attribute name="ber_preferredlanguage2" />' +
                        '<attribute name="ber_preferredlanguage1" />' +
                        '<attribute name="ber_painterrating" />' +
                        '<attribute name="ber_exteriorpainterrating" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="ber_dealerid" />' +
                        '<attribute name="ber_epstatus" />' +
                        '<attribute name="mobilephone" />' +
                        '<attribute name="ber_havesander" />' +
                        '<order attribute="ber_corepainterscp" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="statecode" operator="eq" value="0" />' +
                          '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                           '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                          '<condition attribute="ber_epstatus" operator="in">' +
                            '<value>278290003</value>' +
                            '<value>278290000</value>' +
                          '</condition>' +
                          ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                          '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                        '</filter>' +
                      '</entity>' +
                    '</fetch>';

                    if (Xrm.Page.getControl("ber_masterpainterid") != null) {
                        Xrm.Page.getControl("ber_masterpainterid").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                        Xrm.Page.getControl("ber_masterpainterid").setDefaultView(view_PaintersByDepotId);
                    }
                    //document.getElementById("ber_masterpainterid1").disableViewPicker = 1;
                    $("#ber_masterpainterid1").find("img").attr("disableviewpicker", "1");

                }
            }

        }
    }

}







function setXPAPainter() {

    //XPA Painters

    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        var LeadSource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        if (Xrm.Page.getAttribute("ber_xpa") != undefined || Xrm.Page.getAttribute("ber_xpa").getValue() != null) {
            var XPA = Xrm.Page.getAttribute("ber_xpa").getValue();
            var XPAId = (Xrm.Page.getAttribute("ber_xpa").getValue())[0].id;
        }

        if (XPA != null) {



            var view_PaintersByDepotDisplayname = "XPA Painters ";
            //var view_PaintersByDepotId = GetuniqueGuid();
            //var view_PaintersByDepotId = Xrm.Page.getControl("ber_masterpainterid1").getDefaultView();
            var view_PaintersByDepotId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="fullname" width="100" />' +
                    '<cell name="ber_exteriorpainterrating" width="100" />' +
                    '<cell name="ber_corepainterscp" width="100" />' +
                    '<cell name="ber_epstatus" width="100" />' +
                    '<cell name="ber_painterrating" width="100" />' +
                    '<cell name="ber_dealerid" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_preferredlanguage1" width="100" />' +
                    '<cell name="ber_preferredlanguage2" width="100" />' +
              '</row>' +
              '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="contact">' +
                    '<attribute name="fullname" />' +
                    '<attribute name="contactid" />' +
                    '<attribute name="ber_corepainterscp" />' +
                    '<attribute name="ber_preferredlanguage2" />' +
                    '<attribute name="ber_preferredlanguage1" />' +
                    '<attribute name="ber_painterrating" />' +
                    '<attribute name="ber_exteriorpainterrating" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="ber_dealerid" />' +
                    '<attribute name="ber_epstatus" />' +
                    '<attribute name="mobilephone" />' +
                    '<order attribute="ber_corepainterscp" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="statecode" operator="eq" value="0" />' +
                      '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                       '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                        '<condition attribute="ber_xpa" operator="eq" value="1" /> />' +
                      '<condition attribute="ber_epstatus" operator="in">' +
                        '<value>278290003</value>' +
                        '<value>278290000</value>' +
                      '</condition>' +
                      ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                      '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                      '<condition attribute="contactid" operator="eq" uitype="contact" value="' + XPAId + '" />' +
                    '</filter>' +
                  '</entity>' +
                '</fetch>';

            //alert("1");
            // Xrm.Page.getAttribute("ber_masterpainterid").setValue(null);
            if (Xrm.Page.getControl("ber_masterpainterid") != null) {
                Xrm.Page.getControl("ber_masterpainterid").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                Xrm.Page.getControl("ber_masterpainterid").setDefaultView(view_PaintersByDepotId);
            }
            // document.getElementById("ber_masterpainterid1").disableViewPicker = 1;
            $("#ber_masterpainterid1").find("img").attr("disableviewpicker", "1");



        }
    }




}