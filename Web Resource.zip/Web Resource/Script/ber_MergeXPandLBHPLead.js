// JScript source code

function Selectcontact() {
    if (Xrm.Page.getAttribute("ber_whowill") != undefined || Xrm.Page.getAttribute("ber_whowill") != null) {
        if (UserHasRole("System Administrator") || UserHasRole("Depot User") || UserHasRole("Depot Home Decor User")) {
            // if (UserHasRole("Call Center Manager") || UserHasRole("Call Center Supervisior") || UserHasRole("Call Center User")) 
            if (Xrm.Page.getAttribute("ber_leadtype") !== undefined && Xrm.Page.getAttribute("ber_leadtype") !== null) {

                var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();


            }

            if (leadtype == 278290002) {
                var who = Xrm.Page.data.entity.attributes.get("ber_whowill").getValue();
                if (who == 0) {

                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_xpa").setRequiredLevel("none");
                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setDisabled(true);
                    Xrm.Page.getAttribute("ber_xpa").setValue(null);
                    Xrm.Page.getAttribute("ber_xpa").setSubmitMode("always");
                }
                else if (who == 1) {

                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_xpa").setRequiredLevel("none");
                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setDisabled(true);
                    Xrm.Page.getAttribute("ber_xpa").setValue(null);
                    Xrm.Page.getAttribute("ber_xpa").setSubmitMode("always");
                }

                else if (who == 2) {


                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_xpa").setRequiredLevel("none");
                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setDisabled(true);
                    Xrm.Page.getAttribute("ber_xpa").setValue(null);
                    Xrm.Page.getAttribute("ber_xpa").setSubmitMode("always");
                }

                //XPA

                else if (who == 3) {


                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_xpa").setRequiredLevel("required");
                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setDisabled(false);
                }

                else {

                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_xpa").setDisabled(true);
                    Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_xpa").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_dgcontact").setValue(null);
                    Xrm.Page.getAttribute("ber_tsiid2").setValue(null);
                    Xrm.Page.getAttribute("ber_xpa").setValue(null);
                    Xrm.Page.getAttribute("ber_xpa").setSubmitMode("always");
                }

            }

            else if (leadtype == 278290001) {

                var PickListControl = Xrm.Page.ui.controls.get("ber_whowill");
                PickListControl.removeOption("2");
                PickListControl.removeOption("3");
                Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
                Xrm.Page.ui.controls.get("ber_xpa").setVisible(false);
                var who = Xrm.Page.data.entity.attributes.get("ber_whowill").getValue();
                if (who == 0) {

                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("required");
                    // Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("none");

                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    //  Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setVisible(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);

                }
                else if (who == 1) {

                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("required");
                    //  Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("none");
                    //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                    // Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
                    Xrm.Page.ui.controls.get("ber_xpa").setVisible(false);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);

                }

                /*
                else if (who == 2) {


                Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("none");
                Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("none");
                //Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                // Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(true);
                Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
                Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(false);

                }

                */
                else {

                    Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(true);
                    //  Xrm.Page.ui.controls.get("ber_tsiid2").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
                    // Xrm.Page.getAttribute("ber_tsiid2").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_xpa").setVisible(false);

                    Xrm.Page.getAttribute("ber_dgcontact").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_dgcontact").setValue(null);
                    Xrm.Page.getAttribute("ber_dgcontact").setSubmitMode("always");
                }

            }
        }



        else {

            Xrm.Page.ui.controls.get("ber_dgcontact").setDisabled(true);

        }

    }
}







function CEmandatory() {

    if (Xrm.Page.getAttribute("ber_whowill") != undefined && Xrm.Page.getAttribute("ber_whowill").getValue() != null) {
        var CE = Xrm.Page.getAttribute("ber_whowill").getValue();

        //  alert(CE);
        //var XPAId = (Xrm.Page.getAttribute("ber_xpa").getValue())[0].id;
        if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
            if (CE == 0 || CE == 1 || CE == 2) {
                Xrm.Page.getAttribute("ber_isestimategiven").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("required");
            }

            else if (CE == 3) {
                Xrm.Page.getAttribute("ber_isestimategiven").setRequiredLevel("none");
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");

            }
        }

        else {
            Xrm.Page.getControl("ber_isestimategiven").setDisabled(true);
            Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
            Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setDisabled(true);

        }
    }


}