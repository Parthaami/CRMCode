function LoadProductGrid() {
    //var serverURL = window.location.protocol + "//" + window.location.host.replace("6505", "7025");
    var serverURL = window.location.protocol + "//" + window.location.host + ":7025";
    var _orgName = Xrm.Page.context.getOrgUniqueName();
    debugger;

    if (Xrm.Page.getAttribute("ordernumber").getValue() != null) //Xrm.Page.ui.getFormType() != 1 || 
    {
        var context;
        var objectId;
        var orgName;
        var userId;
        var hostName;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        userId = context.getUserId();
        hostName = window.location.hostname;


        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        userId = userId.replace("{", "");
        userId = userId.replace("}", "");

        var product = serverURL + "/ProductOrder.aspx?OrderId=" + objectId + "&UserId=" + userId;


        // if (document.all.IFRAME_OrderItem != null) {
        //     document.all.IFRAME_OrderItem.setSrc= product;
        // }
        var IFrame = Xrm.Page.ui.controls.get("IFRAME_OrderItem");
        if (IFrame != null) {
            IFrame.setSrc(product)
        }




    }
}