function mobile() 
{
    //debugger;
	
	if (Xrm.Page.getAttribute("ber_masterpainterid") != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != "") {
      
	
	//getting the ID of Contact Lookup on Lead Form 
	
	var lookupValue = Xrm.Page.getAttribute("ber_masterpainterid").getValue();   
	
	
    var BillToId = lookupValue[0].id;
	
	//these  cloumns we have to retrive 
	var columns = ['MobilePhone'];
    
	
	var filter = "ContactId eq guid'" + BillToId + "'";
        
	//here we are calling funtion of webresource CRMRestKit

	var collection = CrmRestKit.RetrieveMultiple('Contact', columns, filter);
	if (collection != null && collection.results != null && collection.results[0].MobilePhone != null){
		
	
	//Retriving the Value from Collection Class
	
	var mobno =collection.results[0].MobilePhone;
	
			
	//Setting the Value with retrived value.
	
	Xrm.Page.getAttribute("ber_paintermobilenumber").setValue(mobno);
	

	}
				
	}
}