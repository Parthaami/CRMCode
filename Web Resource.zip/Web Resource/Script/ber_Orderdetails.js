function getSKULookupDetails() {
    var lookupSKUObj = Xrm.Page.getAttribute("ber_skucode");
    if (lookupSKUObj != null) {
        var lookupSKUObjValue = lookupSKUObj.getValue();
        if (lookupSKUObjValue != null) {
            var lookupEntityName = lookupSKUObjValue[0].entityType; //To get EntityName
            var lookupRecordGuid = lookupSKUObjValue[0].id; // To get record GUID
            var lookupRecordName = lookupSKUObjValue[0].name;

            lookupRecordGuid = lookupRecordGuid.replace("{", "").replace("}", "");

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/products(" + lookupRecordGuid + ")?$select=_ber_shadeid_value,_defaultuomid_value,productnumber", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();

            if (req.response != null && req.response != "") {

                var result = JSON.parse(req.response);

                if (result != null) {

                    var _ber_shadeid_value = result["_ber_shadeid_value"];
                    var _ber_shadeid_value_formatted = result["_ber_shadeid_value@OData.Community.Display.V1.FormattedValue"];

                    var _defaultuomid_value = result["_defaultuomid_value"];
                    var _defaultuomid_value_formatted = result["_defaultuomid_value@OData.Community.Display.V1.FormattedValue"];

                    var productnumber = result["productnumber"];

                    Xrm.Page.getAttribute("ber_shadecodetxt").setValue(_ber_shadeid_value_formatted);
                    Xrm.Page.getAttribute("ber_pack").setValue(_defaultuomid_value_formatted);
                    Xrm.Page.getAttribute("ber_name").setValue(productnumber);
                    _defaultuomid_value = _defaultuomid_value.replace("{", "").replace("}", "");
                    //alert(_defaultuomid_value);
                    Xrm.Page.getAttribute("ber_defaultuomidguid").setValue(_defaultuomid_value);
                    //var varCalculateRecommandedQuantity = CalculateRecommandedQuantity(_defaultuomid_value_formatted, int nQuantity)
                }
            }
        }
    }
}

function CalculateRecommandedQuantity() {
    var nPackSize = Xrm.Page.getAttribute("ber_pack").getValue();
    nPackSize = nPackSize.match(/\d/g);
    nPackSize = nPackSize.join("");
    var nQuantity = Xrm.Page.getAttribute("ber_quantity").getValue();

    var nTmp = Number(nQuantity) % Number(nPackSize);
    nTmp = Number(nTmp);

    if (nPackSize != 0) {
        if (nQuantity > 0 && nTmp != 0) {
            nQuantity = nQuantity + (nPackSize - nTmp);
        }
        Xrm.Page.getAttribute("ber_recommendedquantity").setValue(nQuantity.toString());
    }
    Xrm.Page.getAttribute("ber_availablestock").setValue(null);
}

function checkStockFromERP() {
    var productNumber = Xrm.Page.getAttribute("ber_name").getValue();
    var lookupDepotObj = Xrm.Page.getAttribute("ber_orderfordepot");
    if (lookupDepotObj != null) {
        var lookupDepotObj = lookupDepotObj.getValue();
        if (lookupDepotObj != null) {
            var lookupEntityName = lookupDepotObj[0].entityType; //To get EntityName
            var lookupRecordGuid = lookupDepotObj[0].id; // To get record GUID
            var lookupRecordName = lookupDepotObj[0].name;
        }
    }
    lookupRecordGuid = lookupRecordGuid.replace("{", "").replace("}", "");

    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_depots(" + lookupRecordGuid + ")?$select=ber_depoterpid", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.send();

    if (req.response != null && req.response != "") {
        var result = JSON.parse(req.response);
        if (result != null) {
            var ber_depoterpid = result["ber_depoterpid"];
        }
    }

    //var depotNumber = lookupRecordName.match(/\d/g);
    //depotNumber = depotNumber.join("");
    //var getStock = callStockForSingleSKU(productNumber, depotNumber);
    var getStock = callStockForSingleSKU(productNumber, ber_depoterpid);
    Xrm.Page.getAttribute("ber_availablestock").setValue(getStock);
}

function callStockForSingleSKU(sku, depotid) {
    var stock;
    $.ajax({
        type: "GET",
        async: false,
        url: 'https://bpilcrm.bergerindia.com:6525/oracleconnect.asmx/GetStockForSingleSKU?sku=' + sku + '&depotid=' + depotid,
        contentType: "application/xml; charset=utf-8",
        dataType: "xml",
        processdata: false,
        crossDomain: true,
        success: function (msg) {
            stock = $(msg).find("string").text();
        },
        error: function (msg) {
            stock = '-1';
        },
    });
    ;
    return stock;
}


function GetOrderHeaderDetails() {
    var lookupOrderObj = Xrm.Page.getAttribute("ber_orderidlookupid");
    if (lookupOrderObj != null) {
        var lookupOrderObjValue = lookupOrderObj.getValue();
        if (lookupOrderObjValue != null) {
            var lookupEntityName = lookupOrderObjValue[0].entityType; //To get EntityName
            var lookupRecordGuid = lookupOrderObjValue[0].id; // To get record GUID
            var lookupRecordName = lookupOrderObjValue[0].name;

            lookupRecordGuid = lookupRecordGuid.replace("{", "").replace("}", "");
        }
    }
}



function preventZeroQuantitySave(con) {
    var saveEvent = con.getEventArgs();
    var quantity = Xrm.Page.getAttribute("ber_quantity").getValue();
	alert(quantity);
    if (quantity == null) {
        if (quantity == 0) {
            alert("Zero Order Quantity cannot be saved!");
            saveEvent.preventDefault();
        }
    }
}

function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}
 
 
function disableFormFields() {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveAttribute(control)) {
            control.setDisabled(true);
        }
    });
}

function setFormReadonly()
{
   if(Xrm.Page.ui.getFormType() == 2)
   {
        disableFormFields();
   }

}
