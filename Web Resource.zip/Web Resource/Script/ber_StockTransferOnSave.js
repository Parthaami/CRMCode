function StockTransferOnSave() {
    var type = Xrm.Page.getAttribute("ber_type").getValue();
    var IR;
    var Scheme;
    var from;
    var to;
    if (type != null) {
        if (type == 278290001) {//Transfer
            IR = Xrm.Page.getAttribute("ber_installationrequestid").getValue();
            Scheme = Xrm.Page.getAttribute("ber_schemeid").getValue();
            if (IR != null && Scheme != null) {
                alert('You can select either Installation Request or Scheme');
                event.returnValue = false;
            }
            else if (IR == null && Scheme == null) {
                alert('You have to select either Installation Request or Scheme');
                event.returnValue = false;
            }
        }
        else if (type == 278290000) {//Adjustment
            from = Xrm.Page.getAttribute("ber_from").getValue();
            to = Xrm.Page.getAttribute("ber_to").getValue();

//            if (from != null && to != null) {
//                alert('You can select either From or To');
//                event.returnValue = false;
//            }
//            else if (from == null && to == null) {
//                alert('You have to select either From or To');
//                event.returnValue = false;
//            }
        }
        else if (type == 278290002) {//HO Transfer

        }
    }
}