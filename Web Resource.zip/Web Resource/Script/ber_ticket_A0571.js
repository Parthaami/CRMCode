// Created on 27th June 13
//=========================

function LeadFor() {

    // var userid = Xrm.Page.context.getUserId();

    var leadForOptionSet = Xrm.Page.getControl("ber_leadfor");

    // Xrm.Page.getAttribute("ber_bdodgid").setRequiredLevel("none");
    // Xrm.Page.getAttribute("ber_bdoid").setRequiredLevel("none");

    /*
    Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
    Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
    */

    if (Xrm.Page.getAttribute("ber_leadtype") != null) {
        if (Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290000) {

            // alert("Logged in user : " + userid);
            //Ticket # A0973 Hiding Lead For field
            // leadForOptionSet.setVisible(true);
            leadForOptionSet.removeOption(1);
            leadForOptionSet.removeOption(2);

            //BDM Personnel sectionSection should visible only if Lead type is "BDM"
            //=======================================================================
            setVisibleSection("general", "bdmpersonnel", true)

            //Lead Product Section to be visible if Lead Status are Verified and Won
            //===============================================================================
            if (Xrm.Page.getAttribute("statuscode").getValue() == 2 || Xrm.Page.getAttribute("statuscode").getValue() == 278290000 || Xrm.Page.getAttribute("statuscode").getValue() == 278290005) {
                if (Xrm.Page.ui.tabs.get("leadproduct") != null && Xrm.Page.ui.tabs.get("leadproduct") != undefined) {
                    Xrm.Page.ui.tabs.get("leadproduct").setVisible(true);
                }
                setVisibleSection("leadproduct", "leadproduct_section_2", true)
            }
            else {
                if (Xrm.Page.ui.tabs.get("leadproduct") != null && Xrm.Page.ui.tabs.get("leadproduct") != undefined) {
                    Xrm.Page.ui.tabs.get("leadproduct").setVisible(false);
                }
                setVisibleSection("leadproduct", "leadproduct_section_2", false)
            }

        }
        else if (Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290000) {

            leadForOptionSet.setVisible(false);

            setVisibleSection("general", "bdmpersonnel", false)  //BDM Personnel Section
            setVisibleSection("general", "dealerinfo", false)    // Dealer Info Section
        }
    }
}


//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) {
        }
        else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}