function OnLoadconversionRequired() {

    if (Xrm.Page.getAttribute("ber_leadconversionrequired").getSelectedOption() != null && Xrm.Page.getAttribute("ber_leadconversionrequired").getSelectedOption() != undefined) {
        if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != null && Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != undefined) {
            var leadconversionrequired = Xrm.Page.getAttribute("ber_leadconversionrequired").getSelectedOption().text;
            var leadType = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text;
            if (leadconversionrequired == "Yes") {
                if (leadType == "Home Decor") {
                    Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("none");
                    Xrm.Page.getAttribute("firstname").setRequiredLevel("none");
                    Xrm.Page.getAttribute("lastname").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_followupdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("none");
                    Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("none");
                    Xrm.Page.getAttribute("leadqualitycode").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                }

                else if (leadType == "XP") {
                    Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("none");
                    Xrm.Page.getAttribute("firstname").setRequiredLevel("none");
                    Xrm.Page.getAttribute("lastname").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_followupdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("none");
                    Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("none");
                    Xrm.Page.getAttribute("leadqualitycode").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                    Xrm.Page.getAttribute("ber_dealertype").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_ilabourcost").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_imaterialcost").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_ematerialcost").setRequiredLevel("none");
                    Xrm.Page.getAttribute("ber_elabourcost").setRequiredLevel("none");

                }

                else {

                }


            }


            else {



            }
        }

    }
}





function MakeAllAttributesRequired() {
    if (Xrm.Page.getAttribute("ber_leadconversionrequired") != null && Xrm.Page.getAttribute("ber_leadconversionrequired").getValue() != undefined) {
        var leadconversionrequired = Xrm.Page.getAttribute("ber_leadconversionrequired").getValue();
        if (leadconversionrequired == 1) {

            var attributes = Xrm.Page.data.entity.attributes.get();
            for (var i in attributes) {
                attributes[i].setRequiredLevel("none");
            }
        }
        else if (leadconversionrequired == 2) {

            var attributes = Xrm.Page.data.entity.attributes.get();
            for (var i in attributes) {
                attributes[i].setRequiredLevel("none");
            }

        }

        else {

        }
    }


}






function RemoveconversionItem() {
    var a = Xrm.Page.ui.controls.get("ber_leadconversionrequired");
    if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != null && Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != undefined) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text;
        if (leadtype == "Home Decor") {
            a.removeOption("2");

        }
        else if (leadtype == "XP") {
            a.removeOption("1");

        }

        else {

        }

    }


}


*/



function leadSEType() {
    if (Xrm.Page.getAttribute("statuscode") != null && Xrm.Page.getAttribute("statuscode") != undefined) {
        var StatusReason = Xrm.Page.getAttribute("statuscode").getValue();
    }
    if (UserHasRole("System Administrator")) {
        if (StatusReason == 278290007) {

            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("none");
        }
        else if (StatusReason == 1) {
            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("none");
        }
    }


    else if (UserHasRole("Call Center User")) {
        if (StatusReason == 278290007) {

            Xrm.Page.ui.controls.get("ber_whowill").setVisible(false);
            Xrm.Page.ui.controls.get("ber_dgcontact").setVisible(false);
            Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
        }

        else if (StatusReason == 1) {
            Xrm.Page.ui.controls.get("ber_whowill").setVisible(false);
            Xrm.Page.ui.controls.get("ber_dgcontact").setVisible(false);
            Xrm.Page.ui.controls.get("ber_tsiid2").setVisible(false);
        }
    }


    else {
        Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
    }


}


// if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {

function DisableLeadConversion() {
    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        var depot = Xrm.Page.getAttribute("ber_depotid").getValue();

        if (depot[0].name == "020:Delhi-Okhla" || depot[0].name == "032:Cochin" || depot[0].name == "108:Kolkata-4" || depot[0].name == "104:Gurgaon" || depot[0].name == "031:Bangalore" || depot[0].name == "046:Bangalore-3" || depot[0].name == "136:Bangalore-2A") {
            Xrm.Page.ui.controls.get("ber_leadconversionrequired").setVisible(true); 
        }


        else if (depot[0].name != "020:Delhi-Okhla" || depot[0].name != "032:Cochin" || depot[0].name != "108:Kolkata-4" || depot[0].name != "104:Gurgaon" || depot[0].name != "031:Bangalore" || depot[0].name != "046:Bangalore-3" || depot[0].name != "136:Bangalore-2A") {
        if (UserHasRole("System Administrator")) {
            Xrm.Page.ui.controls.get("ber_leadconversionrequired").setVisible(true);
        }
        else {
            Xrm.Page.ui.controls.get("ber_leadconversionrequired").setVisible(false);

             }
        }
    }

        else if (depot[0].name != "020:Delhi-Okhla" || depot[0].name != "032:Cochin" || depot[0].name != "108:Kolkata-4" || depot[0].name != "104:Gurgaon" || depot[0].name != "031:Bangalore" || depot[0].name != "046:Bangalore-3" || depot[0].name != "136:Bangalore-2A") {
            if (UserHasRole("System Administrator")) {
if (UserHasRole("System Administrator")) {
                Xrm.Page.ui.controls.get("ber_leadconversionrequired").setVisible(true);
            }
            else {
                Xrm.Page.ui.controls.get("ber_leadconversionrequired").setVisible(false);
            }

            }
        }
    }

}


function SetvisibleOtherPainter() {
    var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")

    if (statuscodevalue == "278290009" || statuscodevalue == "278290026" || statuscodevalue == "278290005") {

        if (!isCrmForMobile)
            Xrm.Page.ui.tabs.get("general").sections.get("OtherPainters").setVisible(true);

    }
    else {
        if (!isCrmForMobile)
            Xrm.Page.ui.tabs.get("general").sections.get("OtherPainters").setVisible(false);

    }

}