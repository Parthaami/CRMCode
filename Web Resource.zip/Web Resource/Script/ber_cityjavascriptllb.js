
function MandatoryMinMaxJobAsPerCityType() {
  if (Xrm.Page.getAttribute("ber_citytype").getValue() != undefined || Xrm.Page.getAttribute("ber_citytype").getValue() != null) {
  var citytype = Xrm.Page.getAttribute("ber_citytype");
  if (citytype.getValue() == 278290001)
  {
   Xrm.Page.getAttribute("ber_openjobs").setRequiredLevel("required");
  Xrm.Page.getAttribute("ber_maxjobs").setRequiredLevel("required");
  
  }
  else
  {
  Xrm.Page.getAttribute("ber_openjobs").setRequiredLevel("none");
  Xrm.Page.getAttribute("ber_maxjobs").setRequiredLevel("none");
  }
  }
  }