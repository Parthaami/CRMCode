function StopSaveDepotuser(executionObj) {

    if (UserHasRole("Depot User") || UserHasRole("Depot Home Decor User")) {


        alert("You are not allowed to create or modify CE. Please contact HO");


        executionObj.getEventArgs().preventDefault();


    }

}











function EnableContactFields() {
    var IsAdmin = UserHasRole("System Administrator");
    if (IsAdmin) {


        Xrm.Page.getControl("ber_customertype").setDisabled(false);
        Xrm.Page.getControl("pager").setDisabled(false);
        Xrm.Page.getControl("ber_salutation").setDisabled(false);
        Xrm.Page.getControl("telephone1").setDisabled(false);
        Xrm.Page.getControl("firstname").setDisabled(false);
        Xrm.Page.getControl("lastname").setDisabled(false);
        Xrm.Page.getControl("mobilephone").setDisabled(false);
        Xrm.Page.getControl("emailaddress1").setDisabled(false);
        Xrm.Page.getControl("ber_preferredlanguage1").setDisabled(false);
        Xrm.Page.getControl("ber_preferredlanguage2").setDisabled(false);
        Xrm.Page.getControl("ber_billtoname").setDisabled(false);
        //    Xrm.Page.getControl("ber_ispainterexpress").setDisabled(false);
        //  Xrm.Page.getControl("ber_hotlistpainter").setDisabled(true);
        Xrm.Page.getControl("ber_bdterritory").setDisabled(false);
        Xrm.Page.getControl("address1_line1").setDisabled(false);
        Xrm.Page.getControl("address1_line2").setDisabled(false);
        Xrm.Page.getControl("address1_line3").setDisabled(false);
        Xrm.Page.getControl("ber_dealerid").setDisabled(false);
        Xrm.Page.getControl("ber_stateid").setDisabled(false);
        Xrm.Page.getControl("ber_cityid").setDisabled(false);
        Xrm.Page.getControl("ber_pincodeid").setDisabled(false);
        Xrm.Page.getControl("ber_depotid").setDisabled(false);
        Xrm.Page.getControl("ber_designation").setDisabled(false);
   
    }

    else {


        Xrm.Page.getControl("ber_customertype").setDisabled(true);
        Xrm.Page.getControl("pager").setDisabled(true);
        Xrm.Page.getControl("ber_salutation").setDisabled(true);
        Xrm.Page.getControl("telephone1").setDisabled(true);
        Xrm.Page.getControl("firstname").setDisabled(true);
        Xrm.Page.getControl("lastname").setDisabled(true);
        Xrm.Page.getControl("mobilephone").setDisabled(true);
        Xrm.Page.getControl("emailaddress1").setDisabled(true);
        Xrm.Page.getControl("ber_preferredlanguage1").setDisabled(true);
        Xrm.Page.getControl("ber_preferredlanguage2").setDisabled(true);
        Xrm.Page.getControl("ber_billtoname").setDisabled(true);
         //  Xrm.Page.getControl("ber_ispainterexpress").setDisabled(true);
        //  Xrm.Page.getControl("ber_hotlistpainter").setDisabled(true);
        Xrm.Page.getControl("ber_bdterritory").setDisabled(true);
        Xrm.Page.getControl("address1_line1").setDisabled(true);
        Xrm.Page.getControl("address1_line2").setDisabled(true);
        Xrm.Page.getControl("address1_line3").setDisabled(true);
        Xrm.Page.getControl("ber_dealerid").setDisabled(true);
        Xrm.Page.getControl("ber_stateid").setDisabled(true);
        Xrm.Page.getControl("ber_cityid").setDisabled(true);
        Xrm.Page.getControl("ber_pincodeid").setDisabled(true);
        Xrm.Page.getControl("ber_depotid").setDisabled(true);
       Xrm.Page.getControl("ber_designation").setDisabled(true);

    }

}