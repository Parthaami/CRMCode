function ConvertToButton(fieldname, buttontext, buttonwidth,clickevent, title)

{

 //check if object exists; else return
 if (document.getElementById(fieldname) == null)
{
 return;
 }

 
 functiontocall=clickevent;
 crmForm.all[fieldname].DataValue = buttontext;
 crmForm.all[fieldname].readOnly = true;
 crmForm.all[fieldname].style.borderRight="#3366cc 1px solid";
 crmForm.all[fieldname].style.paddingRight="5px";
 crmForm.all[fieldname].style.borderTop="#3366cc 1px solid";
 crmForm.all[fieldname].style.paddingLeft="5px";
 crmForm.all[fieldname].style.fontSize="11px";
 crmForm.all[fieldname].style.backgroundImage="url(/_imgs/btn_rest.gif)";
 crmForm.all[fieldname].style.borderLeft="#3366cc 1px solid";
 crmForm.all[fieldname].style.width=buttonwidth;
 crmForm.all[fieldname].style.cursor="hand";
 crmForm.all[fieldname].style.lineHeight="18px";
 crmForm.all[fieldname].style.borderBottom="#3366cc 1px solid";
 crmForm.all[fieldname].style.backgroundRepeat="repeat-x";
 crmForm.all[fieldname].style.fontFamily="Tahoma";
 crmForm.all[fieldname].style.height="20px";
 crmForm.all[fieldname].style.backgroundColor="#cee7ff";
 crmForm.all[fieldname].style.textAlign="center";
 crmForm.all[fieldname].style.overflow="hidden";
 crmForm.all[fieldname].attachEvent("onmousedown",push_button);
 crmForm.all[fieldname].attachEvent("onmouseup",release_button);
 crmForm.all[fieldname].attachEvent("onclick",functiontocall);
 crmForm.all[fieldname].style.lineHeight="14px";
 crmForm.all[fieldname+'_c'].style.visibility = 'hidden';
 crmForm.all[fieldname].title=title;
// window.focus();
 

 function push_button(){
 window.event.srcElement.style.borderWidth="2px";
 window.event.srcElement.style.borderStyle="groove ridge ridge groove";
 window.event.srcElement.style.borderColor="#3366cc #4080f0 #4080f0 #3366cc";
 }

 function release_button(){
 window.event.srcElement.style.border="1px solid #3366cc";
 }
}

 

// now the definition of the function to call on button click

function FunctionName()

{

//Xrm.Page.data.entity.save('saveandnew');
Xrm.Page.data.entity.save('save');

//window.location.reload(true);
//window.parent.location.reload(true);
//alert(parent.parent.window.location.href);

parent.parent.window.location.reload(true);
}




function hideribbonbar() {

if (parent.parent.window.document.forms[0] !=null){

parent.document.getElementById("crmTopBar").style.display="none";
parent.document.getElementById("crmContentPanel").style.top = "0px";
document.getElementById("crmNavBar").parentElement.style.display = "none";  //hiding left side nav
document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2; 
document.getElementById("recordSetToolBar").parentElement.style.display = "none";  //Hiding tool bar
document.getElementById("crmFormFooter").parentElement.style.display = "none";

ConvertToButton('ber_buttonfield', 'Save And New','100px',FunctionName,'Button Label');
parent.parent.window.focus();
parent.parent.window.document.forms["crmForm"].elements["ber_name"].focus();
parent.parent.window.document.forms["crmForm"].elements["ber_name"].disabled=true;

}
}



function PopulateProduct() {
    //debugger;
    //On change of Product, populate primer field
    var lookupfield = new Array;

    //Get the lookup field
    lookupfield = Xrm.Page.getAttribute("ber_homepaintingproductid").getValue();

    //This will get the lookup field guid if there is value present in the lookup
    if (lookupfield != null) {
        var lookupid = lookupfield[0].id;
        lookupid.toString()

        var columns = ['*'];
        var filter = "ber_homepaintingproductid eq guid'" + lookupid + "'";
        var collection = CrmRestKit.Retrieve('ber_homepaintingproducts', lookupid, columns);
        if (collection.ber_Primer != null) {
            Xrm.Page.getAttribute("ber_primer").setValue(collection.ber_Primer.toString());
        }
    }
    else {
        Xrm.Page.getAttribute("ber_primer").setValue(null);
    }
}

function PopulateRatePersqft() {
    //On change of Product System, populate rate
    var lookupfield = new Array;

    //Get the lookup field
    lookupfield = Xrm.Page.getAttribute("ber_paintingsystemid").getValue();

    //This will get the lookup field guid if there is value present in the lookup

    if (lookupfield != null) {

        var lookupid = lookupfield[0].id;
        lookupid.toString()
        var columns = ['*'];
        var filter = "ber_productsystemid eq guid'" + lookupid + "'";
        var collection = CrmRestKit.Retrieve('ber_productsystem', lookupid, columns);
        if (collection.ber_Rate != null) {
            Xrm.Page.getAttribute("ber_ratepersqft").setValue(collection.ber_Rate);
        }
    }
    else {
        Xrm.Page.getAttribute("ber_ratepersqft").setValue(null);
    }
}

function PopulatePuttyRate() {
    //On change of Product System, populate rate
    var lookupfield = new Array;
    //Get the lookup field
    lookupfield = Xrm.Page.getAttribute("ber_puttyid").getValue();


    //This will get the lookup field guid if there is value present in the lookup

    if (lookupfield != null) {

        var lookupid = lookupfield[0].id;
        lookupid.toString()

        var columns = ['*'];
        var filter = "ber_puttyid eq guid'" + lookupid + "'";
        var collection = CrmRestKit.Retrieve('ber_putty', lookupid, columns);
        if (collection.ber_Rate != null) {
            Xrm.Page.getAttribute("ber_puttyrate").setValue(collection.ber_Rate);
        }
    }
    else {
        Xrm.Page.getAttribute("ber_puttyrate").setValue(null);
    }
}


function updateFields() {

    //amount-ber_amount
    //Ratepersqft - ber_ratepersqft
    //area - ber_areainsqft
    var ratepersqftfield = Xrm.Page.getAttribute("ber_ratepersqft").getValue();
    var areafield = Xrm.Page.getAttribute("ber_areainsqft").getValue();
    var amountfield = Xrm.Page.getAttribute("ber_amount").getValue();
    //Set Amount
    if ((ratepersqftfield != null) && (areafield != null)) {

        Xrm.Page.getAttribute("ber_amount").setValue(ratepersqftfield * areafield);
    }
    //Populate Amount


    //Total amount- ber_totalamount
    //puttyamt - ber_puttyamount
    var totalamountfield = Xrm.Page.getAttribute("ber_totalamount").getValue();
    var puttyamtfield = Xrm.Page.getAttribute("ber_puttyamount").getValue();



    var puttyratefield = Xrm.Page.getAttribute("ber_puttyrate").getValue();
    var puttyareafield = Xrm.Page.getAttribute("ber_puttyarea").getValue();
    //Set putty Amount
    if ((puttyratefield != null) && (puttyareafield != null)) {
        Xrm.Page.getAttribute("ber_puttyamount").setValue(puttyratefield * puttyareafield);
    }
    amountfield = Xrm.Page.getAttribute("ber_amount").getValue();
    puttyamtfield = Xrm.Page.getAttribute("ber_puttyamount").getValue();
    if (puttyamtfield == null)
        puttyamtfield = 0;
    if (amountfield == null)
        amountfield = 0;

    //Set Total Amount

    Xrm.Page.getAttribute("ber_totalamount").setValue(puttyamtfield + amountfield);
}

function SaveReadOnlyFields() {

    Xrm.Page.getAttribute("ber_primer").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_ratepersqft").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_puttyamount").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_totalamount").setSubmitMode("always");
    //Xrm.Page.getAttribute("ber_oldtotalvalue").setSubmitMode("always"); 
    //Xrm.Page.getAttribute("ber_totaldifference").setSubmitMode("always"); 
    //Xrm.Page.getAttribute("ber_quotationid").setSubmitMode("always"); 
    //Xrm.Page.getAttribute("ber_estimatedetailid").setSubmitMode("always"); 
    //Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 


}
function populateNameFields() {
    Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_paintingarea").getValue().toString() + '\\' + Xrm.Page.getAttribute("ber_homepaintingproductid").getValue()[0].name);
}