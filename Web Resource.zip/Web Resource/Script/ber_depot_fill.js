function FillDepot() {
    if (Xrm.Page.getAttribute("customerid") != null && Xrm.Page.getAttribute("customerid") != 'undefined') {
        if (Xrm.Page.getAttribute("ber_siteid") != null && Xrm.Page.getAttribute("ber_siteid") != 'undefined') {
            if (Xrm.Page.getAttribute("customerid") != null && Xrm.Page.getAttribute("customerid").getValue() != null && Xrm.Page.getAttribute("customerid").getValue()[0].id != null) {
                var CustomerId = Xrm.Page.getAttribute("customerid").getValue()[0].id;
                if (Xrm.Page.getAttribute("ber_siteid") != null && Xrm.Page.getAttribute("ber_siteid").getValue() != null && Xrm.Page.getAttribute("ber_siteid").getValue()[0].id != null) {
                    var BillTo = Xrm.Page.getAttribute("ber_siteid").getValue()[0].id;
                    lookupRecordGuid = BillTo.replace("{", "").replace("}", "");
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + lookupRecordGuid + ")?$select=_ber_depotid_value", false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.send()

                    if (req.response != null && req.response != "") {
                        var result = JSON.parse(req.response);
                        if (result != null) {
                            var _ber_depotid_value = result["_ber_depotid_value"];
                            var _ber_depotid_value_formatted = result["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_depotid_value_lookuplogicalname = result["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var depo = new Array();
                            depo[0] = new Object();
                            depo[0].id = _ber_depotid_value;
                            depo[0].name = _ber_depotid_value_formatted;
                            depo[0].entityType = _ber_depotid_value_lookuplogicalname;
                            if (Xrm.Page.getAttribute("ber_depot") != null) Xrm.Page.getAttribute("ber_depot").setValue(depo);
                            if (Xrm.Page.getControl("ber_depot") != null) Xrm.Page.getControl("ber_depot").setDisabled(true);
                        }
                    }
                }
            }
        }
    }

}