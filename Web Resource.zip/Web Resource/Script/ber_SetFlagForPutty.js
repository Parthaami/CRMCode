// JScript source code

function SetHSPuttySampleFlag() {
    // if (UserHasRole("Depot User") || ("Depot Home Decor User")) {
    if (UserHasRole("System Administrator")) {
        setVisibleSection("general", "general", true);
        Xrm.Page.ui.controls.get("ber_hsputtysampleprovided").setDisabled(false);
        Xrm.Page.ui.controls.get("ber_contact").setDisabled(false);
        Xrm.Page.ui.controls.get("ber_paintermeet").setDisabled(false);


    }

    //else if (UserHasRole("System Administrator")) {
    else if (UserHasRole("Depot User") || ("Depot Home Decor User")) {
        setVisibleSection("general", "general", false);
        Xrm.Page.ui.controls.get("ber_hsputtysampleprovided").setDisabled(false);
    }


    else if (UserHasRole("Call Center Manager") || ("Call Center Manager Additional Functionalities") || ("Call Center User") || ("Call Center User Additional Functionalities")) {
        setVisibleSection("general", "general", false);
        Xrm.Page.ui.controls.get("ber_hsputtysampleprovided").setDisabled(true);
    }

}


function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

//HideShowSection("general", "address", false);