function contactUpdate(id, entityObject, odataSetName, successCallback, errorCallback) {
    var context = Xrm.Page.context;
    // var serverUrl = context.getServerUrl();
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();

    var serverUrl = window.location.protocol + "//" + window.location.host;
    // var serverUrl = "http://10.62.163.60:6505/BergerQA";

    //The XRM OData end-point
    var ODATA_ENDPOINT = "/XRMServices/2011/OrganizationData.svc";

    //id is required
    if (!id) {
        alert("record id is required.");
        return;
    }
    //odataSetName is required, i.e. "AccountSet"
    if (!odataSetName) {
        alert("odataSetName is required.");
        return;
    }

    //Parse the entity object into JSON
    var jsonEntity = window.JSON.stringify(entityObject);

    //Asynchronous AJAX function to Update a CRM record using OData
    $.ajax({
        type: "POST",
        async: false,
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        data: jsonEntity,
        url: serverUrl + ODATA_ENDPOINT + "/" + odataSetName + "(guid'" + id + "')",
        beforeSend: function (XMLHttpRequest) {
            //Specifying this header ensures that the results will be returned as JSON.             
            XMLHttpRequest.setRequestHeader("Accept", "application/json");

            //Specify the HTTP method MERGE to update just the changes you are submitting.             
            XMLHttpRequest.setRequestHeader("X-HTTP-Method", "MERGE");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            //The MERGE does not return any data at all, so we'll add the id 
            //onto the data object so it can be leveraged in a Callback. When data 
            //is used in the callback function, the field will be named generically, "id"
            data = new Object();
            data.id = id;
            if (successCallback) {
                successCallback(data, textStatus, XmlHttpRequest);
            }
        },
        error: function (XmlHttpRequest, textStatus, errorThrown) {
            if (errorCallback)
                errorCallback(XmlHttpRequest, textStatus, errorThrown);
            else
                errorHandler(XmlHttpRequest, textStatus, errorThrown);
        }
    });
}


function errorHandler(xmlHttpRequest, textStatus, errorThrow) {
    alert("Error : " + textStatus + ": " + xmlHttpRequest.statusText);
}

//Called upon successful Account update.
function updatecontactCompleted(data, textStatus, XmlHttpRequest) {

}






function SetcontactField() {

    if (Xrm.Page.getAttribute("ber_itemid") != null && Xrm.Page.getAttribute("ber_itemid").getValue() != null) {
        var ItemName = Xrm.Page.data.entity.attributes.get("ber_itemid").getValue()[0].name;
    }
    var paintExpressItem = Xrm.Page.data.entity.attributes.get("ber_painterid").getValue();
    var Status = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    if (paintExpressItem != null && paintExpressItem != undefined) {

        var paintExpressItemid = paintExpressItem[0].id;
        paintExpressItemid = paintExpressItemid.replace("{", "").replace("}", "");

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts(" + paintExpressItemid + ")?$select=ber_customertype,ber_havesander,contactid", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var CustomerType = result["ber_customertype"];
                var ber_customertype_formatted = result["ber_customertype@OData.Community.Display.V1.FormattedValue"];
                var SanderStatus = result["ber_havesander"];
                var ber_havesander_formatted = result["ber_havesander@OData.Community.Display.V1.FormattedValue"];
            }
        }
        /*
        var paintExpressColumns = ['ber_HaveSander', 'ber_CustomerType', 'ContactId', 'MobilePhone'];
        //   alert("4");
        var paintExpressFilter = "ContactId eq guid'" + paintExpressItemid + "'";
        //   alert("5");
        var paintExpressCollection = CrmRestKit.RetrieveMultiple('Contact', paintExpressColumns, paintExpressFilter);
        if (paintExpressCollection != null && paintExpressCollection != undefined) {
        if (paintExpressCollection.results != null) {
        if (paintExpressCollection.results.length > 0) {

        var collection = paintExpressCollection.results[0];
        var CustomerType = collection.ber_CustomerType.Value;
        var SanderStatus = collection.ber_HaveSander.Value;
        var mobilePhone = collection.MobilePhone;

        }

        }
        }
        */
    }

    if (CustomerType == 278290001 && SanderStatus == null) {
        if (Status == 278290000) {
            if (ItemName == "Dry Wall Sander handheld" || ItemName == "Dry Wall Sander with handle") {

                var contact = {
                    // EP Status = XP
                    ber_HaveSander: { Value: 1 }
                };
                //  alert(contact);
                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                contactUpdate(paintExpressItemid, contact, "ContactSet", updatecontactCompleted, null);

            }

            else {
                var contact = {
                    // EP Status = XP
                    ber_HaveSander: { Value: 2 }
                };

                // alert(contact);

                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                contactUpdate(paintExpressItemid, contact, "ContactSet", updatecontactCompleted, null);

            }
        }
    }

    else if (CustomerType == 278290001 && SanderStatus == 2) {

        if (Status == 278290000) {
            if (ItemName == "Dry Wall Sander handheld" || ItemName == "Dry Wall Sander with handle") {

                var contact = {
                    // EP Status = XP
                    ber_HaveSander: { Value: 1 }
                };
                //  alert(contact);
                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                contactUpdate(paintExpressItemid, contact, "ContactSet", updatecontactCompleted, null);

            }

            else {
                var contact = {
                    // EP Status = XP
                    ber_HaveSander: { Value: 2 }
                };

                // alert(contact);

                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                contactUpdate(paintExpressItemid, contact, "ContactSet", updatecontactCompleted, null);

            }
        }



    }
}