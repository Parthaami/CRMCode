function Form_OnLoad() {
if ((!UserHasRole('System Administrator')) && (!UserHasRole('HO Scheme Manager')) && (!UserHasRole('HO ML Scheme Owner'))) {
        disableDealerPerformanceForm();
    }

 if (Xrm.Page.ui.getFormType() != 1) {
     disableDealerPerformanceForm();
   }
}

function disableDealerPerformanceForm() {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveAttribute(control)) {
            control.setDisabled(true);
        }
    });
}

function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}


function Form_OnSave() {
    if (Xrm.Page.ui.getFormType() == 1 && Xrm.Page.getAttribute("ber_balancequantity").getValue() == null)
    Xrm.Page.getAttribute("ber_balancequantity").setValue(Xrm.Page.getAttribute("ber_requestedquantity").getValue());
    Xrm.Page.getAttribute("ber_balancequantity").setSubmitMode("always");
}