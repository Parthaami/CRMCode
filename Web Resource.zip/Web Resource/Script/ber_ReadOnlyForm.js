//Disable all form controls
DisableForm = function ()
{
    var iframeDoc = document;
    var iframeBody = document.getElementById("crmFormTabContainer");
    hideContent(iframeDoc, iframeBody);
    Xrm.Page.ui.tabs.forEach(
                                    function (tab, index)
                                    {
                                        Xrm.Page.ui.tabs.get(index).add_tabStateChange(function ()
                                        {
                                            var iframeDoc = document;
                                            var iframeBody = document.getElementById("crmFormTabContainer");
                                            var roSpan = document.getElementById("readonlySpan");
                                            if (roSpan != null)
                                            {
                                                iframeBody.removeChild(roSpan);
                                            }
                                            hideContent(iframeDoc, iframeBody);
                                        });
                                    }
                        );


    // Toggle the Ribbon Toolbar to Show/Hide (same as clicking the show/hide Ribbon button)
    //window.top.document.getElementById("minimizeribbon").fireEvent("onclick");

    // Hide the Ribbon Toolbar and move the form Content area to the top of the window.    
    window.top.document.getElementById("crmTopBar").style.display = "none";

    //Move Form Content Aread on top of the windo
    window.top.document.getElementById("crmContentPanel").style.top = "0px"; // Move Form Content&nbsp;area up to top of window, initial style.top&nbsp;is 135px

    window.top.document.getElementById("crmContentPanel").style.height =
     (parseInt(window.top.document.getElementById("crmContentPanel").style.height.replace("px")) + 135) + "px";

    // Hide Left Hand Nav bar / pane
    document.getElementById("crmNavBar").parentElement.style.display = "none";
    document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2;

    // Hide the Breadcrumb and Record Set Toolbar
    document.getElementById("recordSetToolBar").parentElement.style.display = "none";

    // Hide the Form Footer Bar
    document.getElementById("crmFormFooter").parentElement.style.display = "none";
}

hideContent = function (htmlDocument, htmlElement)
{
    var roSpan = htmlDocument.createElement("div");
    roSpan.id = "readonlySpan";

    var roStyle = "position:absolute;";
    roStyle += "z-index:1;";
    roStyle += "left:0px;";
    roStyle += "top:0px;";
    roStyle += "height:" + htmlElement.scrollHeight + "px;";
    roStyle += "text-align:center;";
    roStyle += "font:72px Tahoma;";
    roStyle += "opacity:0.20;";
    roStyle += "-moz-opacity:0.20;";
    roStyle += '-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=20)";';
    roStyle += 'filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=20)"';
    roStyle += "filter: alpha(opacity=20);";
    roStyle += "background-color:white;";

    roSpan.style.cssText = roStyle;
    htmlElement.appendChild(roSpan);
    roSpan.innerHTML = "<div style='margin-top:30%;height:100px;'></div>";
    roSpan.style.zoom = 1;
}

//Enable all form control keep readonly / disable logic.
EnableForm = function ()
{
    var iframeBody = document.getElementById("crmFormTabContainer");
    var roSpan = document.getElementById("readonlySpan");
    if (roSpan != null)
    {
        iframeBody.removeChild(roSpan);
    }
}


function showLoadingMessage()
{

    //tdAreas.style.display = 'none';
    var newdiv = document.createElement('div');
    newdiv.setAttribute('id', "msgDiv");
    //newdiv.setAttribute('style.visibility', "visible");
    newdiv.valign = "middle";
    newdiv.align = "center";
    var divInnerHTML = "<table height='100%' width='100%' style='cursor:wait'>";
    divInnerHTML += "<tr>";
    divInnerHTML += "<td valign='middle' align='center'>";
    divInnerHTML += "<img alt='' src='/_imgs/AdvFind/progress.gif'/>";
    divInnerHTML += "<div/><b>Loading...</b>";
    divInnerHTML += "</td></tr></table>";

    newdiv.innerHTML = divInnerHTML;
    newdiv.style.background = 'Transparent';
    newdiv.style.filter = "alpha(opacity = 100)";
    newdiv.style.fontSize = "15px";
    newdiv.style.zIndex = "1010";
    /*newdiv.style.width = document.body.clientWidth;
    newdiv.style.height = document.body.clientHeight;*/
    newdiv.style.width = "100%";
    newdiv.style.height = "100%";
    newdiv.style.position = 'absolute';
    document.body.insertBefore(newdiv, document.body.firstChild);
    if (document.all.msgDiv != null && document.all.msgDiv != "undefined")
    {
        document.all.msgDiv.style.visibility = 'visible';
    }
}

function hideLoadingMessage()
{
    document.all.msgDiv.style.visibility = 'hidden';
}