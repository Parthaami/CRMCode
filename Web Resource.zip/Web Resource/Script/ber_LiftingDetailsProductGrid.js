function LiftingDetailsProductGrid() {
    if (Xrm.Page.getAttribute("ber_iscreated").getValue() != null && Xrm.Page.getAttribute("ber_name").getValue() != null) { // Xrm.Page.ui.getFormType() != 1) {
        if (Xrm.Page.getAttribute("ber_iscreated").getValue() == false) {
            Xrm.Page.ui.tabs.get("liftingsetails").setVisible(true);
            var context;
            var objectId;
            var orgName;
            var userId;
            var hostName;
            //var serverURL = window.location.protocol + "//" + window.location.host.replace("6505", "7035");
            var serverURL = window.location.protocol + "//" + window.location.host + ":7035";

            context = Xrm.Page.context;
            objectId = Xrm.Page.data.entity.getId();
            orgName = context.getOrgUniqueName();
            hostName = window.location.hostname;

            objectId = objectId.replace("{", "");
            objectId = objectId.replace("}", "");

            if (Xrm.Page.getAttribute("ber_paintermeetid").getValue() != null) {
                var meetplanningid = Xrm.Page.getAttribute("ber_paintermeetid").getValue()[0].id;
                meetplanningid = meetplanningid.replace("{", "");
                meetplanningid = meetplanningid.replace("}", "");
                var product = serverURL + "/LiftingDetails.aspx?LDId=" + objectId + "&MeetPlanningId=" + meetplanningid;

                // document.all.IFRAME_liftingsetails.src = product;
                var IFrame = Xrm.Page.ui.controls.get("IFRAME_liftingsetails");
                IFrame.setSrc(product);
            }
        }
        else {
            Xrm.Page.ui.tabs.get("liftingsetails").setVisible(false);
        }
    }
}

function LiftingDetailsProduct() {
    if (Xrm.Page.getAttribute("ber_iscreated").getValue() == true) {
        Xrm.Page.getAttribute("ber_productid").setRequiredLevel("required");
        Xrm.Page.getControl("ber_productid").setVisible(true);
        Xrm.Page.getControl("ber_reportedquantity").setVisible(true);
    }
    else {
        Xrm.Page.getAttribute("ber_productid").setRequiredLevel("none");
        Xrm.Page.getControl("ber_productid").setVisible(false);
        Xrm.Page.getControl("ber_reportedquantity").setVisible(false);
    }
}