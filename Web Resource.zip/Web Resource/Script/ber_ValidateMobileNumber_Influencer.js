function ValidateNumber() {

    var contactNumber = Xrm.Page.getAttribute("ber_mobilenumber").getValue();
    var n = contactNumber.length;

    var i;
    var returnString = "";

    if (typeof (contactNumber) != "undefined" && contactNumber != null) {
        filteredValues = "1234567890";


        for (i = 0; i < contactNumber.length; i++) {
            var c = contactNumber.charAt(i);
            if (filteredValues.indexOf(c) != -1) {
                returnString += c;
            }
        }
        Xrm.Page.getAttribute("ber_mobilenumber").setValue(returnString);

        if (returnString.length != contactNumber.length) {
            Xrm.Page.getAttribute("ber_mobilenumber").setValue("");
            alert('Only Numeric values are allowed');
           // Xrm.Page.getControl("ber_mobilenumber").setFocus(true);
         //   Xrm.Page.getControl("telephone1").setFocus(true);

        }
    }
    if (n != 10) {
        alert("Mobile Number should be of 10 digits");
        Xrm.Page.getAttribute("ber_mobilenumber").setValue("");
      //  Xrm.Page.getControl("telephone2").setFocus(true);
     //   Xrm.Page.getControl("telephone1").setFocus(true);
    }
}
