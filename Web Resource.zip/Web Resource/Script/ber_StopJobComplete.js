function Form_onsave(executionObj) {
    var event = executionObj.getEventArgs();
    if (Xrm.Page.getAttribute("ber_grandtotal") != undefined && Xrm.Page.getAttribute("ber_grandtotal").getValue() != null) {

        // var shouldSave = true;   
        var Grandtotal = Xrm.Page.getAttribute("ber_grandtotal").getValue();


        var Status = Xrm.Page.getAttribute("statuscode").getValue();

        if (Status == 278290006 && Grandtotal >= 1000) {


        }

        else if (Status == 278290006 && Grandtotal < 1000) {

            alert("Minimum job value has to be  Rs. 1000");

            //Xrm.Page.executionObj.getEventArgs().preventDefault();
            //executionObj.getEventArgs().preventDefault();
            event.preventDefault();
        }

    }

}



function StopJobComplete(executionObj) {
    var event = executionObj.getEventArgs();
    if (Xrm.Page.getAttribute("statuscode") != undefined && Xrm.Page.getAttribute("statuscode").getValue() != null) {
                
        var StatusReason = Xrm.Page.getAttribute("statuscode").getValue();
        if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null) {
            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

        if (leadtype == 278290002 && StatusReason == 278290006) {
            alert("This Lead cannotbe job completed. Please contact to Anustup Chakravarty");
            event.preventDefault();
        }       

    }

}