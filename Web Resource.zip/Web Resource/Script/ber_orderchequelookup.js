function onOrderSaveForMobile() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (isCrmForMobile) {
        if (Xrm.Page.ui.getFormType() == 2) {
            Xrm.Page.getAttribute("ber_ordersubmitted").setValue(true);
        }
        Xrm.Page.getAttribute("ber_ismobileorder").setValue(true);
    }

}


function disableFormFields() {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveAttribute(control)) {
            control.setDisabled(true);
        }
    });
}

function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}

function chequemap() {
    //  debugger;
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    var AccNo = null;
    //Xrm.Page.getControl("ber_chequenumber").setVisible(false);
    var map = false;
    var orgName = Xrm.Page.context.getOrgUniqueName();
    var BilltoId = Xrm.Page.getAttribute("ber_billto").getValue();
    if (BilltoId != null && BilltoId != "" && BilltoId != undefined) {
        var AccId = Xrm.Page.getAttribute("ber_billto").getValue()[0].id;
        AccId = AccId.replace("{", "").replace("}", "");

        $.ajax({
            type: "GET",
            async: false,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + AccId + ")?$select=accountnumber",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processdata: false,
            crossDomain: true,
            success: function (msg) {
                AccNo = msg["accountnumber"];

            },
            error: function (msg) {
                return 'error fetching the cheque from crm organization';
            },
        });

    }
    var ChequeNo = Xrm.Page.getAttribute("ber_chequenumber").getValue();
    if (ChequeNo != null && ChequeNo != "")
        map = true;

    if (isCrmForMobile) {
        if (map)
            Xrm.Page.ui.controls.get("ber_chequenumbermobile").setVisible(true);

    }
    else {
        //var serverURL = window.location.protocol + "//" + window.location.host.replace("6505", "7015");       // This was non-ifd instance
        var serverURL = window.location.protocol + "//" + window.location.host + ":7015";                       // IFD implementation
        var URI = serverURL + "/default.html?AccountNo=" + AccNo + "&ChequeNo=" + ChequeNo + "&map=" + map;
        // debugger;
        //document.all.IFRAME_ChequeNumber.src = URI;
        var IFrame = Xrm.Page.ui.controls.get("IFRAME_ChequeNumber");
        if (IFrame != null) {
            IFrame.setSrc(URI)
        }
    }
}

function chequemaponsave() {
    //***************Submit ClientMap iframe for save*******************//
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (!isCrmForMobile) {
        if (Xrm.Page.getAttribute("ber_paymentmode").getText() == "Cheque") {
            var IFrame = Xrm.Page.ui.controls.get("IFRAME_ChequeNumber");
            if (IFrame != null && IFrame != 'undefined') {
                var OrderGuid = Xrm.Page.data.entity.getId();
                var ChequeNo = "";
                if ($('#IFRAME_ChequeNumber').contents().find('#ChequeNumber') != null && $('#IFRAME_ChequeNumber').contents().find('#ChequeNumber') != 'undefined') {
                    ChequeNo = $('#IFRAME_ChequeNumber').contents().find('#ChequeNumber').val();
                }

                var name = $('#IFRAME_ChequeNumber').contents().find('#MainTextBox').val();

                if (ChequeNo != "" && ChequeNo != null && ChequeNo != 'undefined') {
                    Xrm.Page.getAttribute("ber_chequenumber").setValue(ChequeNo);
                    Xrm.Page.getAttribute("ber_chequenumber").setSubmitMode("always");
                }
                else if (Xrm.Page.getAttribute("ber_chequenumber").getValue() != null) {
                    var CNO = Xrm.Page.getAttribute("ber_chequenumber").getValue();
                    if (CNO != null && CNO != "") {
                        Xrm.Page.getAttribute("ber_chequenumber").setValue(CNO);
                        Xrm.Page.getAttribute("ber_chequenumber").setSubmitMode("always");
                    }
                    else {
                        alert("You must provide a value for Cheque Number.");
                        event.returnValue = false;
                    }
                }
                else {
                    alert("You must provide a value for Cheque Number.");
                    event.returnValue = false;
                }
            }
        }
    }
    else {
        if (Xrm.Page.getAttribute("ber_paymentmode").getText() == "Cheque") {
            var chequeNumber = Xrm.Page.getAttribute("ber_chequenumbermobile").getValue();
            if (chequeNumber != null && chequeNumber != 'undefined' && chequeNumber != "") {
                Xrm.Page.getAttribute("ber_chequenumber").setValue(chequeNumber);
                Xrm.Page.getAttribute("ber_chequenumber").setSubmitMode("always");
            }
            else {
                alert("You must provide a value for Cheque Number.");
                event.returnValue = false;
            }
        }
    }
}
