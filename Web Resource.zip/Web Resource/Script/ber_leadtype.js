function callleadtype() {
    if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != null) {
        var b = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text;
        if (b != null) {
            if (b != "Home Decor") {
                leadtype();
            }

            else {
                // Do Nothing
            }
        }
    }
}



function leadtype() {
    if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype").getValue() != undefined) {
        var leadtypevalue = Xrm.Page.getAttribute("ber_leadtype").getValue();
    }
    if (leadtypevalue == 278290000) {
        setVisibleSection("general", "bdm", true);
        setVisibleSection("general", "homedecore", false);
        setVisibleSection("general", "prolinks", false);
        //setVisibleSection("general","commonsection",true);
        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("required");
    }
    else if (leadtypevalue == 278290001) {
        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecore", false);
        setVisibleSection("general", "prolinks", false);
        //setVisibleSection("general","commonsection",false);
        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
    }
    else if (leadtypevalue == 278290002) {
        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecore", false);
        setVisibleSection("general", "prolinks", false);
        //setVisibleSection("general","commonsection",true);
        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
    }
    else {
        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecore", false);
        setVisibleSection("general", "prolinks", false);
        //setVisibleSection("general","commonsection",false);
        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
    }
}
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) {
        }
        else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

function RemoveOption() {
    var ReconStatusOptions = Xrm.Page.getAttribute("ber_leadtype");
    var PickListControl = Xrm.Page.ui.controls.get("ber_leadtype");
    // var FormType = Xrm.Page.ui.getFormType();

    PickListControl.removeOption(278290000);



}


function EndDateChangeCount() {
    var EndDateCount = Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").getValue();
    var JobDuration1 = Xrm.Page.data.entity.attributes.get("ber_jobduration").getValue;
    var EndDate = Xrm.Page.data.entity.attributes.get("ber_enddate").getValue();
    // EndDateCount = 0;
    if (EndDateCount == null && EndDate != null) {

        EndDateCount = 1;

        var FinalCount = Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setValue(EndDateCount);
        Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setSubmitMode("always");
        JobDuration();

    }

        /*
        else if (EndDate != null && EndDateCount == null) {
    
        EndDateCount = 1;
    
        Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setValue(EndDateCount);
        Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setSubmitMode("always");
        JobDuration();
    
        }
        */

    Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setValue(EndDateCount);
    Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setSubmitMode("always");
    JobDuration();

    }
    */

    else if (EndDateCount > 0 && EndDate != null) {

        EndDateCount++;
        Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setValue(EndDateCount);
        Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").setSubmitMode("always");
        // JobDuration();

    }

    else {

    }

}



function JobDuration() {


    if (Xrm.Page.getAttribute("ber_leadtype") != null) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
    }
    if (Xrm.Page.getAttribute("statuscode") != null)
        var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_startdate").getValue() != null)
        var StartDate = Xrm.Page.data.entity.attributes.get("ber_startdate").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_enddate").getValue() != null)
        var EndDate = Xrm.Page.data.entity.attributes.get("ber_enddate").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").getValue() != null)
        var EndDateChangedcount = Xrm.Page.data.entity.attributes.get("ber_captureenddatecount").getValue();
    if (Xrm.Page.data.entity.attributes.get("ber_jobduration").getValue() != null)
        var JobDuration = Xrm.Page.data.entity.attributes.get("ber_jobduration");

    if (StartDate != null && EndDate != null) {
        var dt1 = StartDate.getTime();
        var dt2 = EndDate.getTime();
        var ONE_DAY = 1000 * 60 * 60 * 24
    }

    if (Xrm.Page.getAttribute("ber_leadtype") !== null && Xrm.Page.data.entity.attributes.get("ber_jobduration").getValue() == null) {
        if (leadtype == 278290002 && dt1 != null && dt2 != null) {
            JobDuration = dt2 - dt1;
            var difference_ms = Math.abs(dt2 - dt1);
            var JobDuration = Math.round(difference_ms / ONE_DAY)

            // alert(JobDuration);
            if (Xrm.Page.data.entity.attributes.get("ber_jobduration") != null) {
                Xrm.Page.data.entity.attributes.get("ber_jobduration").setValue(JobDuration);
                Xrm.Page.data.entity.attributes.get("ber_jobduration").setSubmitMode("always");
            }

        }
        else if (leadtype == 'XP' && EndDateChangedcount != null) {
            // Xrm.Page.ui.controls.get("ber_jobduration").setVisible(true);
            // Xrm.Page.data.entity.attributes.get("ber_jobduration").setSubmitMode("always");

        else {
            Xrm.Page.ui.controls.get("ber_jobduration").setVisible(false);

        }

    }


}











///////////////////////////////////////////////


function CalculateTotalJobValue() {

    // List of Cost Variables-------
    var InteriorLabourCost = 0;
    var InteriorMaterialCost = 0;
    var ExteriorLabourCost = 0;
    var ExteriorMaterialCost = 0;
    var ExteriorTotalCost = 0;
    var TotalLabourCost = 0;
    var TotalMaterialCost = 0;
    var GrandTotal = 0;


    if (Xrm.Page.data.entity.attributes.get("ber_ilabourcost") != null)
        InteriorLabourCost = Xrm.Page.data.entity.attributes.get("ber_ilabourcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_imaterialcost") != null)
        InteriorMaterialCost = Xrm.Page.data.entity.attributes.get("ber_imaterialcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null)
        InteriorTotalCost = Xrm.Page.data.entity.attributes.get("ber_itotal").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_elabourcost") != null)
        ExteriorLabourCost = Xrm.Page.data.entity.attributes.get("ber_elabourcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_ematerialcost") != null)
        ExteriorMaterialCost = Xrm.Page.data.entity.attributes.get("ber_ematerialcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null)
        ExteriorTotalCost = Xrm.Page.data.entity.attributes.get("ber_etotalcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null)
        TotalLabourCost = Xrm.Page.data.entity.attributes.get("ber_tlabourcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null)
        TotalMaterialCost = Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null)
        GrandTotal = Xrm.Page.data.entity.attributes.get("ber_grandtotal").getValue();


    // Interior Total Cost--------

    if (InteriorLabourCost != null && InteriorMaterialCost != null) {

        InteriorTotalCost = InteriorLabourCost + InteriorMaterialCost;
        Xrm.Page.data.entity.attributes.get("ber_itotal").setValue(InteriorTotalCost);
        Xrm.Page.data.entity.attributes.get("ber_itotal").setSubmitMode("always");

        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setValue(InteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setSubmitMode("always");

    }
    else if (InteriorLabourCost != null && InteriorMaterialCost == null) {

        InteriorTotalCost = InteriorLabourCost;
        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setValue(InteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setSubmitMode("always");
    }

    else if (InteriorLabourCost == null && InteriorMaterialCost != null) {

        InteriorTotalCost = InteriorMaterialCost;
        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setValue(InteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_itotal") != null) Xrm.Page.data.entity.attributes.get("ber_itotal").setSubmitMode("always");

    }

    if (ExteriorLabourCost != null && ExteriorMaterialCost != null) {

        ExteriorTotalCost = ExteriorLabourCost + ExteriorMaterialCost;
        Xrm.Page.data.entity.attributes.get("ber_etotalcost").setValue(ExteriorTotalCost);
        Xrm.Page.data.entity.attributes.get("ber_etotalcost").setSubmitMode("always");

        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setValue(ExteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setSubmitMode("always");

    }

    else if (ExteriorLabourCost != null && ExteriorMaterialCost == null) {

        ExteriorTotalCost = ExteriorLabourCost;
        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setValue(ExteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setSubmitMode("always");
    }

    else if (ExteriorLabourCost == null && ExteriorMaterialCost != null) {

        ExteriorTotalCost = InteriorMaterialCost;
        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setValue(ExteriorTotalCost);
        if (Xrm.Page.data.entity.attributes.get("ber_etotalcost") != null) Xrm.Page.data.entity.attributes.get("ber_etotalcost").setSubmitMode("always");
    }

    if (InteriorLabourCost != null && ExteriorLabourCost != null) {

        TotalLabourCost = InteriorLabourCost + ExteriorLabourCost;
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setValue(TotalLabourCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setSubmitMode("always");

    }

    else if (InteriorLabourCost != null && ExteriorLabourCost == null) {
        TotalLabourCost = InteriorLabourCost;
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setValue(TotalLabourCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setSubmitMode("always");

    }

    else if (InteriorLabourCost == null && ExteriorLabourCost != null) {
        TotalLabourCost = ExteriorLabourCost;
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setValue(TotalLabourCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tlabourcost") != null) Xrm.Page.data.entity.attributes.get("ber_tlabourcost").setSubmitMode("always");

    }


    if (InteriorMaterialCost != null && ExteriorMaterialCost != null) {

        TotalMaterialCost = InteriorMaterialCost + ExteriorMaterialCost;
        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setValue(TotalMaterialCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setSubmitMode("always");


    }

    else if (InteriorMaterialCost != null && ExteriorMaterialCost == null) {

        TotalMaterialCost = InteriorMaterialCost;
        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setValue(TotalMaterialCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setSubmitMode("always");


    }

    else if (InteriorMaterialCost == null && ExteriorMaterialCost != null) {

        TotalMaterialCost = ExteriorMaterialCost;
        Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setValue(TotalMaterialCost);
        Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setSubmitMode("always");

        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setValue(TotalMaterialCost);
        if (Xrm.Page.data.entity.attributes.get("ber_tmaterialcost") != null) Xrm.Page.data.entity.attributes.get("ber_tmaterialcost").setSubmitMode("always");
    else {
        // Do Nothing
    }


    }

    if (InteriorTotalCost != null && ExteriorTotalCost != null) {

        GrandTotal = InteriorTotalCost + ExteriorTotalCost;
        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setValue(GrandTotal);
        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setSubmitMode("always");

    }

    else if (InteriorMaterialCost != null && ExteriorTotalCost == null) {

        GrandTotal = InteriorTotalCost;
        Xrm.Page.data.entity.attributes.get("ber_grandtotal").setValue(GrandTotal);
        Xrm.Page.data.entity.attributes.get("ber_grandtotal").setSubmitMode("always");

        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setValue(GrandTotal);
        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setSubmitMode("always");

    }

    else if (InteriorTotalCost == null && ExteriorTotalCost != null) {

        GrandTotal = ExteriorTotalCost;

        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setValue(GrandTotal);
        if (Xrm.Page.data.entity.attributes.get("ber_grandtotal") != null) Xrm.Page.data.entity.attributes.get("ber_grandtotal").setSubmitMode("always");

    else {
        // Do Nothing
    }

}











//////////////////////////////////////////////////


function SetvisibleJobValueSection() {

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    if (StatusReason == 278290007) {
        Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setVisible(false);
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
    }

    else if (StatusReason == 278290005) {
        Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setVisible(true);
        Xrm.Page.data.entity.attributes.get("ber_estimatedpaintingcost").setSubmitMode("always");
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);

        Xrm.Page.data.entity.attributes.get("ber_ilabourcost").setRequiredLevel("required");
        Xrm.Page.data.entity.attributes.get("ber_imaterialcost").setRequiredLevel("required");
        Xrm.Page.data.entity.attributes.get("ber_elabourcost").setRequiredLevel("required");
        Xrm.Page.data.entity.attributes.get("ber_ematerialcost").setRequiredLevel("required");

    }


    else if (StatusReason == 278290006) {


        //  Xrm.Page.ui.controls.get("ber_totalmaterialconsumedvalue").setVisible(true);
        //  Xrm.Page.ui.controls.get("ber_totaljobvalue").setVisible(true);
        //Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setVisible(true);
        Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setDisabled(true);
        Xrm.Page.data.entity.attributes.get("ber_estimatedpaintingcost").setSubmitMode("always");
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);



        //ber_totalmaterialconsumedvalue

    }

    else {
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);

    }

}


//////////////////////////////////////////////////////////////////////








function SetVisibleJobFields() {

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    if (StatusReason == 278290005) {

        Xrm.Page.ui.controls.get("ber_captureenddatecount").setVisible(true);
        Xrm.Page.ui.controls.get("ber_jobduration").setVisible(true);
        Xrm.Page.ui.controls.get("ber_enddate").setVisible(true);
    }

    else {

        Xrm.Page.ui.controls.get("ber_captureenddatecount").setVisible(false);
        Xrm.Page.ui.controls.get("ber_jobduration").setVisible(false);
        Xrm.Page.ui.controls.get("ber_enddate").setVisible(false);

    }


}








/////////////////////////////////

function CalculateConsumedValue() {

    TotalJobValue = Xrm.Page.data.entity.attributes.get("ber_totaljobvalue").getValue();
    ConsumedValue = Xrm.Page.data.entity.attributes.get("ber_totalmaterialconsumedvalue").getValue();
    if (TotalJobValue != null) {

        var CalculatedValue = (TotalJobValue * 45) / 100;
        Xrm.Page.data.entity.attributes.get("ber_totalmaterialconsumedvalue").setValue(CalculatedValue);

    }

}




function SetOtherDealerDisabled() {

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
    var DealerCriteria = Xrm.Page.data.entity.attributes.get("ber_dealerselectioncriteria").getValue();


    if (StatusReason != 278290007 && DealerCriteria == 278290001) {

        Xrm.Page.ui.controls.get("ber_dealercode").setDisabled(true);
    }

    else {
        Xrm.Page.ui.controls.get("ber_dealercode").setDisabled(false);
    }
}







//////////////////////////////////////

function TakeAppointmenttime() {


    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_appointmentdate").getValue() != null) {
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (b != null) {
            if (b == 278290001) {

                var today = new Date();
                // var Count = 0;


                var Year1 = today.getFullYear();
                var Month1 = today.getMonth() + 1;
                var Day1 = today.getDate();
                var dateFormate_today = Day1 + "-" + Month1 + "-" + Year1;
                var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
                var Lead = Xrm.Page.data.entity.attributes.get("ber_leadtype");

                /*
                if (Lead != undefined) {
                var LeadType = Xrm.Page.data.entity.attributes.get("ber_leadtype").getValue();
                alert(LeadType);
                }
                else {
                // Do Nothing
                }


                */
                // var DateC = Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentdatecapture")

                if (Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentdatecapture") != undefined) {
                    var DateCapture = Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentdatecapture").getValue();
                }

                else {
                    // Do Nothing
                }


                if ((DateCapture != null) || (DateCapture != undefined)) {
                    var Year = DateCapture.getFullYear();
                    var Month = DateCapture.getMonth() + 1;
                    var Day = DateCapture.getDate();
                    dateFormate_capturueddate = Day + "-" + Month + "-" + Year;

                }
                else {
                    // Do Nothing
                }

                var Count = Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").getValue();

                var Description = Xrm.Page.data.entity.attributes.get("ber_appointmentdate").getValue();

                if ((LeadType == 278290001) && (DateCapture == null) && (Count == null)) {
                    Count = 1;

                    Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setValue(Count);
                    Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setValue(new Date());
                    Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setSubmitMode("always");
                    Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setSubmitMode("always");

                }


                else if ((LeadType == 278290001) && (Count != null) && (DateCapture != null)) {
                    if (dateFormate_today > dateFormate_capturueddate) {
                        Count++;
                        Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setValue(Count);
                        Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setValue(new Date());
                        Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setSubmitMode("always");
                        Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setSubmitMode("always");
                    }

                }


            }

            else {
                // Do Nothing

            }

        }



    }

}












///////////////////////////////////////////

function SetStatusAppointment() {
    alert("1");
    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_appointmentdate") != null || Xrm.Page.getAttribute("ber_appointmentdate") != undefined) {
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();

        if (b != null) {
            if (b == 278290002) {

                alert("2");
                var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");
                var Appointment = Xrm.Page.data.entity.attributes.get("ber_appointmentdate").getValue();
                alert("3");
                // var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getSelectedOption().text;
                if (Appointment != null) {
                    alert("4");

                    StatusReason.setValue(278290024);
                    Xrm.Page.getAttribute("statuscode").setSubmitMode("always");

                }
            }


        }
    }

}









function SetStatusCSMAssigned() {

    if (Xrm.Page.getAttribute("ber_hdemployeeid") !== undefined && Xrm.Page.getAttribute("ber_hdemployeeid") !== null) {
        var HDEmployee = Xrm.Page.data.entity.attributes.get("ber_hdemployeeid").getValue();

        if (Xrm.Page.getAttribute("ber_leadtype") !== undefined && Xrm.Page.getAttribute("ber_leadtype") !== null) {
            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

        else {
            //Do nothing
        }

        if (Xrm.Page.getAttribute("statuscode") !== undefined && Xrm.Page.getAttribute("statuscode") !== null) {
            var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");
        }
        else {
            //Do nothing
        }

        // var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getSelectedOption().text;
        if (leadtype == 278290001 && HDEmployee != null) {


            StatusReason.setValue(278290029);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
        }


        else {

            // Do Nothing

        }

    }

    else {
        //Do nothing
    }

}





function LeadOptionset() {
    var a = Xrm.Page.ui.controls.get("statuscode");
    var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (leadtype == 278290002 && statuscodevalue == 278290024) {
            a.removeOption("278290007");
            a.removeOption("1");
            a.removeOption("2");
            a.removeOption("278290004");
            a.removeOption("278290006");
            a.removeOption("278290009");
            a.removeOption("278290029");
            a.removeOption("278290030");
            a.removeOption("278290024");

        }
    }
}










////////////////////////////////////


function SetFollowupmandatory() {
    var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();

    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        var leadType = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (leadType == 278290001 && statuscodevalue == 278290024) {
            Xrm.Page.getControl("ber_followupdate").setDisabled(false);
            Xrm.Page.getAttribute("ber_followupdate").setValue(null);
            Xrm.Page.getAttribute("ber_followupdate").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
        }

        else {

            // Do Nothing

        }


    }


    else {

        // Do Nothing

    }
}