/****************************
Developer : Madhumita
Dated : 24th June,2019
Method: IdentityTypeValidation
Functionality : based on Identity type Lead/Service
                Request section will be visible
****************************/



function IdentityTypeValidation() {
    if (Xrm.Page.getAttribute("ber_identitytype") != null && Xrm.Page.getAttribute("ber_identitytype") != undefined) {

        var IdentityType = Xrm.Page.getAttribute("ber_identitytype").getValue();
        if (IdentityType == 278290001) {
            // Identity type = Service Request
            setVisibleSection("General", "ServiceRequest", true);
            if (Xrm.Page.getAttribute("ber_srtype") != null) Xrm.Page.getAttribute("ber_srtype").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_subsrtype") != null) Xrm.Page.getAttribute("ber_subsrtype").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_priority") != null) Xrm.Page.getAttribute("ber_priority").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_resolutiontype") != null) Xrm.Page.getAttribute("ber_resolutiontype").setRequiredLevel("required");


            setVisibleSection("General", "Lead", false);
            if (Xrm.Page.getAttribute("ber_firstname") != null) Xrm.Page.getAttribute("ber_firstname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadconversionrequired") != null) Xrm.Page.getAttribute("ber_leadconversionrequired").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_preferreddatetime") != null) Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_pincode") != null) Xrm.Page.getAttribute("ber_pincode").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_paintingtype") != null) Xrm.Page.getAttribute("ber_paintingtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadopportunity") != null) Xrm.Page.getAttribute("ber_leadopportunity").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_rating") != null) Xrm.Page.getAttribute("ber_rating").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_street1") != null) Xrm.Page.getAttribute("ber_street1").setRequiredLevel("none");
            // if (Xrm.Page.getAttribute("ber_carpetareaapprox") != null) Xrm.Page.getAttribute("ber_carpetareaapprox").setRequiredLevel("none");

        }

            // Identity type = Lead
        else if (IdentityType == 278290000) {


            setVisibleSection("General", "Lead", true);
            var LeadConversion = Xrm.Page.ui.controls.get("ber_leadconversionrequired");
            LeadConversion.removeOption("1");
            LeadConversion.removeOption("2");

            var Leadtype = Xrm.Page.ui.controls.get("ber_leadtype");
            Leadtype.removeOption("278290001");


            if (Xrm.Page.getAttribute("ber_firstname") != null) Xrm.Page.getAttribute("ber_firstname").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_leadconversionrequired") != null) Xrm.Page.getAttribute("ber_leadconversionrequired").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_preferreddatetime") != null) Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_pincode") != null) Xrm.Page.getAttribute("ber_pincode").setRequiredLevel("required");

            if (Xrm.Page.getAttribute("ber_paintingtype") != null) Xrm.Page.getAttribute("ber_paintingtype").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_leadopportunity") != null) Xrm.Page.getAttribute("ber_leadopportunity").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_rating") != null) Xrm.Page.getAttribute("ber_rating").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_street1") != null) Xrm.Page.getAttribute("ber_street1").setRequiredLevel("required");
            // if (Xrm.Page.getAttribute("ber_carpetareaapprox") != null) Xrm.Page.getAttribute("ber_carpetareaapprox").setRequiredLevel("required");


            setVisibleSection("General", "ServiceRequest", false);
            if (Xrm.Page.getAttribute("ber_srtype") != null) Xrm.Page.getAttribute("ber_srtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_subsrtype") != null) Xrm.Page.getAttribute("ber_subsrtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_priority") != null) Xrm.Page.getAttribute("ber_priority").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_resolutiontype") != null) Xrm.Page.getAttribute("ber_resolutiontype").setRequiredLevel("none");


        }

        else if (IdentityType == null) {

            setVisibleSection("General", "Lead", false);
            setVisibleSection("General", "ServiceRequest", false);
            if (Xrm.Page.getAttribute("ber_firstname") != null) Xrm.Page.getAttribute("ber_firstname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lastname") != null) Xrm.Page.getAttribute("ber_lastname").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadconversionrequired") != null) Xrm.Page.getAttribute("ber_leadconversionrequired").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_preferreddatetime") != null) Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_pincode") != null) Xrm.Page.getAttribute("ber_pincode").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_srtype") != null) Xrm.Page.getAttribute("ber_srtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_subsrtype") != null) Xrm.Page.getAttribute("ber_subsrtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_priority") != null) Xrm.Page.getAttribute("ber_priority").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_resolutiontype") != null) Xrm.Page.getAttribute("ber_resolutiontype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_paintingtype") != null) Xrm.Page.getAttribute("ber_paintingtype").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_leadopportunity") != null) Xrm.Page.getAttribute("ber_leadopportunity").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_rating") != null) Xrm.Page.getAttribute("ber_rating").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_street1") != null) Xrm.Page.getAttribute("ber_street1").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_site") != null) Xrm.Page.getAttribute("ber_site").setRequiredLevel("none");

        }
    }

}





/////////////////////////////////////////////////////////////////

/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: VisibilitySR
Functionality : based on SR type corresponding sub SR and associated 
                attributes will visible/hide disable/enabled
****************************/



function VisibilitySR() {
    if (Xrm.Page.getAttribute("ber_srtype") != null && Xrm.Page.getAttribute("ber_srtype") != null) {

        if (Xrm.Page.getAttribute("ber_srtype") != null && Xrm.Page.getAttribute("ber_srtype").getValue() != null) {
            var SRType = Xrm.Page.getAttribute("ber_srtype").getValue();
            var SRTypeName = Xrm.Page.getAttribute("ber_srtype").getValue()[0].name;// == 'Painter - Express Painting'
        }
        if (SRTypeName == 'Dealer - Accounts / Payments' || SRTypeName == 'Dealer - Express Painting' || SRTypeName == 'Dealer - General' || SRTypeName == 'Dealer - Product') {
            if (Xrm.Page.ui.controls.get("ber_dealer") != null) Xrm.Page.ui.controls.get("ber_dealer").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_site") != null) Xrm.Page.ui.controls.get("ber_site").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_lead") != null) Xrm.Page.ui.controls.get("ber_lead").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_ormdepot") != null) Xrm.Page.ui.controls.get("ber_ormdepot").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_painter") != null) Xrm.Page.ui.controls.get("ber_painter").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpressitem1") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem1").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_chargeable") != null) Xrm.Page.ui.controls.get("ber_chargeable").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(false);

            //ber_site
            if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_site") != null) Xrm.Page.getAttribute("ber_site").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_painter") != null) Xrm.Page.getAttribute("ber_painter").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_ormdepot") != null) Xrm.Page.getAttribute("ber_ormdepot").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lead") != null) Xrm.Page.getAttribute("ber_lead").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_paintexpressitem1") != null) Xrm.Page.getAttribute("ber_paintexpressitem1").setRequiredLevel("none");

        }

        else if (SRTypeName == 'Painter - Express Painting') {
            if (Xrm.Page.ui.controls.get("ber_dealer") != null) Xrm.Page.ui.controls.get("ber_dealer").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_site") != null) Xrm.Page.ui.controls.get("ber_site").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_lead") != null) Xrm.Page.ui.controls.get("ber_lead").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_ormdepot") != null) Xrm.Page.ui.controls.get("ber_ormdepot").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_painter") != null) Xrm.Page.ui.controls.get("ber_painter").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_paintexpressitem1") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem1").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_chargeable") != null) Xrm.Page.ui.controls.get("ber_chargeable").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(false);

            if (Xrm.Page.getAttribute("ber_painter") != null) Xrm.Page.getAttribute("ber_painter").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_site") != null) Xrm.Page.getAttribute("ber_site").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lead") != null) Xrm.Page.getAttribute("ber_lead").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_ormdepot") != null) Xrm.Page.getAttribute("ber_ormdepot").setRequiredLevel("none");
        }

        else if (SRTypeName == 'End Customer - Generic') {
            if (Xrm.Page.ui.controls.get("ber_dealer") != null) Xrm.Page.ui.controls.get("ber_dealer").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_site") != null) Xrm.Page.ui.controls.get("ber_site").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_lead") != null) Xrm.Page.ui.controls.get("ber_lead").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_ormdepot") != null) Xrm.Page.ui.controls.get("ber_ormdepot").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_painter") != null) Xrm.Page.ui.controls.get("ber_painter").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpressitem1") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem1").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_chargeable") != null) Xrm.Page.ui.controls.get("ber_chargeable").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(false);

            if (Xrm.Page.getAttribute("ber_painter") != null) Xrm.Page.getAttribute("ber_painter").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_site") != null) Xrm.Page.getAttribute("ber_site").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lead") != null) Xrm.Page.getAttribute("ber_lead").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_paintexpressitem1") != null) Xrm.Page.getAttribute("ber_paintexpressitem1").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_ormdepot") != null) Xrm.Page.getAttribute("ber_ormdepot").setRequiredLevel("required");
        }

        else if (SRTypeName == 'XP LEAD' || SRTypeName == 'Home Decor' || SRTypeName == 'IoT') {

            if (Xrm.Page.ui.controls.get("ber_dealer") != null) Xrm.Page.ui.controls.get("ber_dealer").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_site") != null) Xrm.Page.ui.controls.get("ber_site").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_lead") != null) Xrm.Page.ui.controls.get("ber_lead").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_ormdepot") != null) Xrm.Page.ui.controls.get("ber_ormdepot").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_painter") != null) Xrm.Page.ui.controls.get("ber_painter").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpressitem1") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem1").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_chargeable") != null) Xrm.Page.ui.controls.get("ber_chargeable").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(false);
            if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(false);

            if (Xrm.Page.getAttribute("ber_painter") != null) Xrm.Page.getAttribute("ber_painter").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_site") != null) Xrm.Page.getAttribute("ber_site").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_lead") != null) Xrm.Page.getAttribute("ber_lead").setRequiredLevel("required");
            if (Xrm.Page.getAttribute("ber_paintexpressitem1") != null) Xrm.Page.getAttribute("ber_paintexpressitem1").setRequiredLevel("none");
            if (Xrm.Page.getAttribute("ber_ormdepot") != null) Xrm.Page.getAttribute("ber_ormdepot").setRequiredLevel("none");

        }

    }
}

/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: setVisibleSection
Functionality : A generic method to hide or show sections
****************************/

//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}



/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: RemoveStatus
Functionality : A method to control the visibility
                ofstatuscode in individual stages
****************************/

function RemoveStatus() {
    var a = Xrm.Page.ui.controls.get("statuscode");
    if (Xrm.Page.getAttribute("statuscode") != null && Xrm.Page.getAttribute("statuscode") != undefined) {
        var Action = Xrm.Page.getAttribute("statuscode").getValue();
        // Action = Others
        if (Action == 1) {
            a.removeOption("278290001");

        }

            // Action = New
        else if (Action == 278290002) {
            a.removeOption("1");
            a.removeOption("278290001");
        }


            // Action = In Progress
        else if (Action == 278290000) {
            a.removeOption("1");
            a.removeOption("278290002");

        }

            // Action = Completed
        else if (Action == 278290001) {
            a.removeOption("1");
            a.removeOption("278290000");
            a.removeOption("278290002");
            Xrm.Page.ui.controls.get("statuscode").setDisabled(true);

        }

    }
}



/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: FilteredPaintExpressItem
Functionality : A method to filter a painter express item
                view based on the corresponding painter
****************************/


// Filtered paint Express Item based on painter

function FilteredPaintExpressItem() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (Xrm.Page.getAttribute("ber_paintexpressitem1") != null && Xrm.Page.getAttribute("ber_paintexpressitem1") != undefined) {
        if (!isCrmForMobile) {
            document.getElementById("ber_paintexpressitem1").disableViewPicker = 0;
        }
        else {
            $("#ber_paintexpressitem1").find("img").attr("disableviewpicker", "0");
            //var lookupField = executionContext.getFormContext().getAttribute("ber_paintexpressitem");
            //lookupField.SetParameter("disableViewPicker", "0");
            //var lookupValue = lookupField.getValue();
            //lookupValue.SetParameter("disableViewPicker", "0");
        }
        if (Xrm.Page.getAttribute("ber_painter").getValue() != null && Xrm.Page.getAttribute("ber_painter") != undefined) {
            var Painter = (Xrm.Page.getAttribute("ber_painter").getValue())[0].id;
            if (Xrm.Page.ui.controls.get("ber_paintexpressitem1") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem1").setVisible(true);
            if (Xrm.Page.getAttribute("ber_paintexpressitem1") != null) Xrm.Page.getAttribute("ber_paintexpressitem1").setRequiredLevel("required");
            if (Xrm.Page.ui.controls.get("ber_chargeable") != null) Xrm.Page.ui.controls.get("ber_chargeable").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(true);
            if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(true);
            if (Painter != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered Paint Express item";
                var view_DGId = "{C7034F4F-6F92-4DD7-BD9D-9B9C1E996380}";
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="ber_paintexpressitemid" select="1" icon="2" preview="1">' +
                   '<row name="result" id="ber_paintexpressitemid">' +
                   '<cell name="ber_toolapprovaldate" width="100" />' +
                   '<cell name="ber_itemid" width="100" />' +
                   '<cell name="ber_name" width="200" />' +
             '</row>' +
             '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                 '<entity name="ber_paintexpressitem">' +
                   '<attribute name="ber_name" />' +
                   '<attribute name="ber_paintexpressitemid" />' +
                   '<attribute name="ber_toolapprovaldate" />' +
                   '<attribute name="ber_itemid" />' +
                   '<order attribute="ber_name" descending="false" />' +
                   '<filter type="and">' +
                '<condition attribute="statuscode" operator="eq" value="278290000"/>' +
                     '<condition attribute="ber_painterid" operator="eq"   value="' + Painter + '" />' +
                   '</filter>' +
                 '</entity>' +
               '</fetch>';
                Xrm.Page.getControl("ber_paintexpressitem1").addCustomView(view_DGId, "ber_paintexpressitem", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                Xrm.Page.getControl("ber_paintexpressitem1").setDefaultView(view_DGId);

                if (!isCrmForMobile) {
                    document.getElementById("ber_paintexpressitem1").disableViewPicker = 1;
                }
                else {
                    $("#ber_paintexpressitem1").find("img").attr("disableviewpicker", "1");
                    //var lookupField = executionContext.getFormContext().getAttribute("ber_paintexpressitem");
                    //lookupField.SetParameter("disableViewPicker", "1");
                    //var lookupValue = lookupField.getValue();
                    //lookupValue.SetParameter("disableViewPicker", "1");
                }

            }
        }
    }

}

/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: ForceRefresh
Functionality : A method to reload the form
****************************/


function ForceRefresh() {

    if (Xrm.Page.data.entity.getId() != null && Xrm.Page.data.entity.getId() != 'undefined' && Xrm.Page.data.entity.getId() != '') {
        if (Xrm.Page.getAttribute("ber_identitytype").getValue() != null) {
            ormid = Xrm.Page.data.entity.getId();
            var parameters = {};
            parameters["navbar"] = "on";
            Xrm.Utility.openEntityForm("ber_ormidentity", ormid, parameters)


        }
    }

}



function OnloadORM() {
    if (Xrm.Page.getAttribute("ber_identitytype").getValue() != null && Xrm.Page.getAttribute("ber_identitytype").getValue() != undefined) {

        if (Xrm.Page.ui.controls.get("ber_identitytype") != null) Xrm.Page.ui.controls.get("ber_identitytype").setDisabled(true);
    }
}

