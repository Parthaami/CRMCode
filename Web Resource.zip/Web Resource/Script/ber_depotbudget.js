function fireDepoBudgetPlugin()
{

   Xrm.Page.getAttribute("ber_firedepotplugin").setValue(true);

    Xrm.Page.data.entity.save();

}