
function loadEnquiry() {

    hideLeadsource();
    hideCallinfo();
    OnloadOtherDealerSecion();
    CustomerIntimation();
    LeadTypeDisableTrue();
    RemoveDealerreferral();
  //  OnloadXPAview();
    //  fetchdataDealerPainter();

    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode").getValue();

        if (status == 278290007) {
            setVisibleSection("general", "Job_Value", false);
            setVisibleSection("general", "CC_WC", false);
            setVisibleSection("general", "dealerinfo", false);

        }

        else if (status == 1) {

            setVisibleSection("general", "Job_Value", false);
            setVisibleSection("general", "CC_WC", false);
            setVisibleSection("general", "dealerinfo", false);
        }
    }
}








//////////////////////








//Lead Source hide

function hideLeadsource() {
    if (Xrm.Page.ui.controls.get("leadsourcecode") != null) {


        var a = Xrm.Page.ui.controls.get("leadsourcecode");
        a.removeOption(278290030);
        a.removeOption(278290022);
        a.removeOption(278290026);
        a.removeOption(278290025);
        a.removeOption(278290023);
        a.removeOption(278290029);
        a.removeOption(278290018);
        a.removeOption(1);
        a.removeOption(278290004);
        // a.removeOption(278290038);
        a.removeOption(278290037);
        a.removeOption(278290011);
        a.removeOption(278290002);
        a.removeOption(278290036);
        a.removeOption(278290042);
        a.removeOption(278290043);
        a.removeOption(278290044);
        //   a.removeOption(278290045);
        a.removeOption(278290046);


    }
}





//Lead Source hide

function hideCallinfo() {
    // alert("A");
    var a = Xrm.Page.ui.controls.get("ber_callinfo");
    a.removeOption(278290015);
    a.removeOption(278290013);
    a.removeOption(278290014);
    a.removeOption(278290011);
    a.removeOption(278290012);
    a.removeOption(278290018);

    // a.removeOption(1);


}



///////////  Other dealer section visibility  /////////////////

function OnloadOtherDealerSecion() {
    if (Xrm.Page.getAttribute("ber_dealertype")) {
        if ((Xrm.Page.data.entity.attributes.get("ber_dealerid").getValue() != null) || (Xrm.Page.data.entity.attributes.get("ber_dealerid") != undefined)) {
            var dealertype = Xrm.Page.getAttribute("ber_dealertype").getValue();
            var Dealer = Xrm.Page.getAttribute("ber_dealerid").getValue();
            if (Xrm.Page.getAttribute("ber_dealertype").getValue() == true) {
                setVisibleSection("general", "general_section_15", true);
            }
            else if (Xrm.Page.getAttribute("ber_dealertype").getValue() == false) {
                setVisibleSection("general", "general_section_15", false);
            }
        }


    }
}


//// CC lead type identification flag set ////
var cctag;
function ccleadtag() {

    if (Xrm.Page.getAttribute("ber_callinfo") != undefined && Xrm.Page.getAttribute("ber_callinfo") != null) {

        if (Xrm.Page.getAttribute("ber_callinfo").getValue() == '278290025') {

            Xrm.Page.getAttribute("ber_ccother").setValue(true);
            Xrm.Page.getAttribute("ber_ccother").setSubmitMode("always");
            cctag = Xrm.Page.getAttribute("ber_ccother").getValue();

        }

    }



}


function CustomerIntimation() {

    if (Xrm.Page.getAttribute("ber_attemptstoclosecount") != null && Xrm.Page.getAttribute("ber_attemptstoclosecount") != undefined) {

        var Closecount = Xrm.Page.getAttribute("ber_attemptstoclosecount").getValue();
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        if (status == 278290007) {
            if (Closecount != null && Closecount >= 2) {
                Xrm.Page.getControl("ber_customerintimation").setVisible(true);
            }


            else if (Closecount == null || Closecount < 2) {
                Xrm.Page.getControl("ber_customerintimation").setVisible(false);
            }

        }
        else {
            Xrm.Page.getControl("ber_customerintimation").setVisible(false);
        }
    }
}

//Make leadtype non editable
function LeadTypeDisableTrue() {

    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode").getValue();

        if (status != 278290007) {
            if (UserHasRole("Depot User") || UserHasRole("Depot Home Decor User") || UserHasRole("Call Center User")) {
                Xrm.Page.getControl("ber_leadtype").setDisabled(true);
            }
            else if (UserHasRole("System Administrator")) {
                Xrm.Page.getControl("ber_leadtype").setDisabled(false);
            }
        }

        else if (status == 278290007) {
            Xrm.Page.getControl("ber_leadtype").setDisabled(false);
        }
    }

}


/*
function RemoveDealerreferral() {  
        if (UserHasRole("Depot User")) {
            if (Xrm.Page.ui.controls.get("leadsourcecode") != null) {
                var a = Xrm.Page.ui.controls.get("leadsourcecode");
                a.removeOption(278290022);            
    }
}



*/


function RemoveDealerreferral() {
    var FormType = Xrm.Page.ui.getFormType();
    if (FormType != null) {
        if (Xrm.Page.data.entity.getId() != null && Xrm.Page.data.entity.getId() != 'undefined' && Xrm.Page.data.entity.getId() != '' && FormType == 2) {
            if (UserHasRole("Depot User")) {
                if (Xrm.Page.ui.controls.get("leadsourcecode") != null) {
                    Xrm.Page.ui.controls.get("leadsourcecode").setDisabled(true);
                }
            }
        }

        else if (Xrm.Page.data.entity.getId() == null || Xrm.Page.data.entity.getId() == 'undefined' || Xrm.Page.data.entity.getId() == '') {
            if (UserHasRole("Depot User")) {
                if (Xrm.Page.ui.controls.get("leadsourcecode") != null) {
                    var a = Xrm.Page.ui.controls.get("leadsourcecode");
                    a.removeOption(278290003);
                    a.removeOption(278290033);
                    a.removeOption(278290034);
                    a.removeOption(278290035);
                    a.removeOption(278290057);

                }
            }
        }

    }
}


/////// Added on 22nd May for preview functionality
function fetchdataDealerPainter() {
    var entitytype;

    var today;
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (!isCrmForMobile)
        var today = getServerTime();
    else
        var today = new Date();

    // If dealer is prefilled
    if (Xrm.Page.data.entity.getId() == null || Xrm.Page.data.entity.getId() == 'undefined' || Xrm.Page.data.entity.getId() == '') {
        if (Xrm.Page.getAttribute("ber_dealerid") != null && Xrm.Page.getAttribute("ber_dealerid").getValue() != null && Xrm.Page.getAttribute("ber_dealerid").getValue()[0].id != null) {
            var Dealer = Xrm.Page.getAttribute("ber_dealerid").getValue()[0].id;
            var Dealerguid = Dealer.replace("{", "").replace("}", "");
            entitytype = Xrm.Page.getAttribute("ber_dealerid").getValue()[0].entityType;

            var reqDealer1 = new XMLHttpRequest();
            reqDealer1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=ber_accounttype,_ber_associatedtsiid_value,_ber_dealernameid_value,_ber_depotid_value,_ber_dg_value&$filter=statecode eq 0 and  accountid eq " + Dealerguid, false);
            reqDealer1.setRequestHeader("OData-MaxVersion", "4.0");
            reqDealer1.setRequestHeader("OData-Version", "4.0");
            reqDealer1.setRequestHeader("Accept", "application/json");
            reqDealer1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            reqDealer1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            reqDealer1.send();

            if (reqDealer1.response != null && reqDealer1.response != "") {
                var resultsDealer1 = JSON.parse(reqDealer1.response);
                try {
                    if (resultsDealer1 != null) {
                        //no duplicate record should be allowed
                        if (resultsDealer1.value.length > 0) {
                            var ber_accounttype = resultsDealer1.value[0]["ber_accounttype"];
                            var ber_accounttype_formatted = resultsDealer1.value[0]["ber_accounttype@OData.Community.Display.V1.FormattedValue"];

                            var _ber_associatedtsiid_value = resultsDealer1.value[0]["_ber_associatedtsiid_value"];
                            var _ber_associatedtsiid_value_formatted = resultsDealer1.value[0]["_ber_associatedtsiid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_associatedtsiid_value_lookuplogicalname = resultsDealer1.value[0]["_ber_associatedtsiid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                            var _ber_dealernameid_value = resultsDealer1.value[0]["_ber_dealernameid_value"];
                            var _ber_dealernameid_value_formatted = resultsDealer1.value[0]["_ber_dealernameid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_dealernameid_value_lookuplogicalname = resultsDealer1.value[0]["_ber_dealernameid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var _ber_depotid_value = resultsDealer1.value[0]["_ber_depotid_value"];
                            var _ber_depotid_value_formatted = resultsDealer1.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_depotid_value_lookuplogicalname = resultsDealer1.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                            var _ber_dg_value = resultsDealer1.value[0]["_ber_dg_value"];
                            var _ber_dg_value_formatted = resultsDealer1.value[0]["_ber_dg_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_dg_value_lookuplogicalname = resultsDealer1.value[0]["_ber_dg_value@Microsoft.Dynamics.CRM.lookuplogicalname"];


                            var DGArray = new Array();
                            DGArray[0] = new Object();
                            DGArray[0].id = _ber_dg_value;
                            DGArray[0].name = _ber_dg_value_formatted;
                            DGArray[0].entityType = _ber_dg_value_lookuplogicalname;


                            var DepotArray = new Array();
                            DepotArray[0] = new Object();
                            DepotArray[0].id = _ber_depotid_value;
                            DepotArray[0].name = _ber_depotid_value_formatted;
                            DepotArray[0].entityType = _ber_depotid_value_lookuplogicalname;


                            var TSIArray = new Array();
                            TSIArray[0] = new Object();
                            TSIArray[0].id = _ber_associatedtsiid_value;
                            TSIArray[0].name = _ber_associatedtsiid_value_formatted;
                            TSIArray[0].entityType = _ber_associatedtsiid_value_lookuplogicalname;


                            Xrm.Page.data.entity.attributes.get("ber_newdate").setValue(today);
                            Xrm.Page.getAttribute("ber_newdate").setSubmitMode("always");

                            Xrm.Page.getAttribute("ber_capturedealerallocateddate").setValue(today);
                            Xrm.Page.getAttribute("ber_capturedealerallocateddate").setSubmitMode("always");

                            Xrm.Page.getAttribute("ber_capturece").setValue(today);
                            Xrm.Page.getAttribute("ber_capturece").setSubmitMode("always");

                            Xrm.Page.getAttribute("statuscode").setValue(278290004);
                            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");

                            Xrm.Page.getAttribute("leadsourcecode").setValue(278290059);
                            Xrm.Page.getAttribute("leadsourcecode").setSubmitMode("always");


                            if ((_ber_associatedtsiid_value != null || _ber_associatedtsiid_value !== 'undefined') && (_ber_dg_value != null || _ber_dg_value !== 'undefined')) {

                                Xrm.Page.getAttribute("ber_whowill").setValue(0);
                                Xrm.Page.getAttribute("ber_whowill").setSubmitMode("always");

                                Xrm.Page.getAttribute("ber_dgcontact").setValue(DGArray);
                                Xrm.Page.getAttribute("ber_dgcontact").setSubmitMode("always");

                                Xrm.Page.getAttribute("ber_tsiid2").setValue(TSIArray);
                                Xrm.Page.getAttribute("ber_tsiid2").setSubmitMode("always");

                            }
                            else if ((_ber_associatedtsiid_value != null || _ber_associatedtsiid_value !== 'undefined') && (_ber_dg_value == null && _ber_dg_value == 'undefined')) {
                                Xrm.Page.getAttribute("ber_whowill").setValue(2);
                                Xrm.Page.getAttribute("ber_whowill").setSubmitMode("always");

                                Xrm.Page.getAttribute("ber_tsiid2").setValue(TSIArray);
                                Xrm.Page.getAttribute("ber_tsiid2").setSubmitMode("always");

                            }
                        }
                    }
                }
                catch (err) {
                    alert("Please communicate system administrator in HO for error: " + err);
                }
            }
        }
    }
}

var xmlHttp;
function getServerTime() {
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD', window.location.href.toString(), false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    // addMinutes(xmlHttp.getResponseHeader("Date"), 330)
    var addmin = addMinutes(xmlHttp.getResponseHeader("Date"));

    return addmin
}

function addMinutes(date) {
    var d = new Date(date);
    // alert(typeof (d));
    //return new Date(d.getTime() + 330 * 60000);
    //d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000);
    return d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000)

}



/*********************************************************************************************
Developer Name:      Madhumita
Date :                        12-06-2019
Method:                    ValidateLeadMobileNumber
Functionality:            Validate if any lead has been created with same phonenumber the present
                                  lead with leadsource as "Preview Dealer" is yet to be created
***********************************************************************************************/


function ValidateLeadMobileNumber() {
    if (Xrm.Page.getAttribute("telephone1") != null && Xrm.Page.getAttribute("leadsourcecode") != null) {
        if (Xrm.Page.getAttribute("telephone1").getValue() != null && Xrm.Page.getAttribute("telephone1") != undefined) {
            var leadphonenumber = Xrm.Page.getAttribute("telephone1").getValue();
            if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode") != undefined) {

                var leadsource = Xrm.Page.getAttribute("leadsourcecode").getValue();
            }


            if (leadsource == 278290059) {

                var fetchxmllead = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                    "  <entity name='lead'>" +
                                    "    <attribute name='fullname' />" +
                                    "    <attribute name='companyname' />" +
                                    "    <attribute name='telephone1' />" +
                                    "    <attribute name='leadid' />" +
                                    "    <order attribute='fullname' descending='false' />" +
                                    "    <filter type='and'>" +
                                    "      <condition attribute='createdon' operator='last-x-days' value='365' />" +
                                    "      <condition attribute='telephone1' operator='eq' value='" + leadphonenumber + "'  />" +
                                    "    </filter>" +
                                    "  </entity>" +
                                    "</fetch>";

                var encodedFetchXml = encodeURI(fetchxmllead);
                var queryPath = "/api/data/v8.0/leads?fetchXml=" + encodedFetchXml;

                var hostname = "https://bpilcrmuat.bergerindia.com";
                var seturl = hostname + queryPath;



                var req = new XMLHttpRequest();
                req.open("GET", seturl, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.send();

                if (req.response != null && req.response != "") {
                    var results = JSON.parse(req.response);
                    if (results != null) {
                        //no duplicate record should be allowed
                        if (results.value.length > 0) {
                            alert("A lead with same number already exist in system");
                            Xrm.Page.getAttribute("telephone1").setValue(null);
                            Xrm.Page.getAttribute("telephone1").setSubmitMode("always");
                            // var createdon = results.value[i]["createdon"];
                            // var leadsourcecode = results.value[i]["leadsourcecode"];
                            //  var leadsourcecode_formatted = results.value[i]["leadsourcecode@OData.Community.Display.V1.FormattedValue"];
                            //   var telephone1 = results.value[i]["telephone1"];
                        }
                    }
                }
            }

        }
    }


}


/*********************************************************************************************
Developer Name:      Madhumita
Date :                        22-07-2019
Method:                    ValidateLeadMobileNumber
Functionality:            Validate sub leadtype based on lead type & No of towers, No of stories
***********************************************************************************************/

//Validation for sub lead type

function ValidateSubLeadType() {
    if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290002) {
        if ((Xrm.Page.getAttribute("ber_numberoftowers") != undefined && Xrm.Page.getAttribute("ber_numberoftowers") != null) && (Xrm.Page.getAttribute("ber_noofstories") != undefined && Xrm.Page.getAttribute("ber_noofstories") != null)) {
            if (Xrm.Page.getAttribute("ber_numberoftowers").getValue() != null) {
                var NumberOfTowers = Xrm.Page.getAttribute("ber_numberoftowers").getValue();
            }
            if (Xrm.Page.getAttribute("ber_noofstories").getValue() != null) {
                var NumberOfStories = Xrm.Page.getAttribute("ber_noofstories").getValue();
            }
            if (cctag != true) {
                if (Xrm.Page.getAttribute("ber_subleadtype") != null) {
                    if (NumberOfTowers > 3 || NumberOfStories > 7) {

                        Xrm.Page.getAttribute("ber_subleadtype").setValue(278290000);
                        Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");

                    }

                    else if (NumberOfTowers <= 3 && NumberOfStories <= 7) {

                        Xrm.Page.getAttribute("ber_subleadtype").setValue(null);
                        Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");
                    }

                    else if (NumberOfTowers > 3 && NumberOfStories > 7) {

                        Xrm.Page.getAttribute("ber_subleadtype").setValue(278290000);
                        Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");
                    }
                    else {
                        Xrm.Page.getAttribute("ber_subleadtype").setValue(null);
                        Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");

                    }


                }
                else {
                    Xrm.Page.getAttribute("ber_subleadtype").setValue(null);
                    Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");

                }

            }
            else if (cctag == true) {

                Xrm.Page.getAttribute("ber_subleadtype").setValue(278290002);
                Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");

            }


        }



    }

    else {
        Xrm.Page.getAttribute("ber_subleadtype").setValue(null);
        Xrm.Page.getAttribute("ber_subleadtype").setSubmitMode("always");

    }
}


/*********************************************************************************************
Developer Name:      Madhumita
Date :                        22-07-2019
Method:                    ValidateLeadMobileNumber
Functionality:            Validate for XP leads NoOfTowers ans NoOfStories are blank
                          then force to re-enter both the attribute
***********************************************************************************************/

function NoOfStoriesReqiuired() {
    if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290002) {
        if ((Xrm.Page.getAttribute("ber_numberoftowers") != undefined && Xrm.Page.getAttribute("ber_numberoftowers").getValue() == null) || (Xrm.Page.getAttribute("ber_noofstories") != undefined && Xrm.Page.getAttribute("ber_noofstories").getValue() == null)) {
            alert("Please enter both, No of towers and No of Stories");
            Xrm.Page.getAttribute("ber_numberoftowers").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_noofstories").setRequiredLevel("required");

        }

        else if (Xrm.Page.getAttribute("ber_numberoftowers").getValue() != null && Xrm.Page.getAttribute("ber_noofstories").getValue() != null) {

            ValidateSubLeadType();
        }
    }

}


function OnloadXPAview() {

        if (Xrm.Page.getAttribute("ber_subleadtype") != undefined && Xrm.Page.getAttribute("ber_subleadtype") != null) {
        var SubLeadType = Xrm.Page.getAttribute("ber_subleadtype").getValue();

    


    if (_depotId != null && SubLeadType != '278290002') {

      //  alert("XPA");

        filterXPAByDefaultDepot();


    }


    else if (_depotId != null  && SubLeadType == '278290002') {
       // alert("MM view");
        MMPainterview();
    }

        }

}

function MMPainterview() {

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;

            var view_PaintersByDepotDisplayname = "MM Painters view with Moisture Meter";

            var view_PaintersByDepotId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                                '<row name="result" id="contactid">' +
                                '<cell name="fullname" width="100" />' +
                                '<cell name="ber_exteriorpainterrating" width="100" />' +
                                '<cell name="ber_corepainterscp" width="100" />' +
                                '<cell name="ber_epstatus" width="100" />' +
                                '<cell name="ber_painterrating" width="100" />' +
                                '<cell name="ber_havesander" width="100" />' +
                                '<cell name="ber_havemoisturemeter" width="100" />' +
                                '<cell name="ber_dealerid" width="100" />' +
                                '<cell name="ber_depotid" width="100" />' +
                                '<cell name="mobilephone" width="100" />' +
                                '<cell name="ber_preferredlanguage1" width="100" />' +
                                '<cell name="ber_preferredlanguage2" width="100" />' +
                                '</row>' +
                                '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
           '<entity name="contact">' +
           '<attribute name="fullname" />' +
           '<attribute name="contactid" />' +
           '<attribute name="ber_corepainterscp" />' +
           '<attribute name="ber_preferredlanguage2" />' +
           '<attribute name="ber_preferredlanguage1" />' +
           '<attribute name="ber_painterrating" />' +
           '<attribute name="ber_exteriorpainterrating" />' +
           '<attribute name="ber_depotid" />' +
           '<attribute name="ber_dealerid" />' +
           '<attribute name="ber_epstatus" />' +
           '<attribute name="mobilephone" />' +
           '<attribute name="ber_havesander" />' +
           '<order attribute="ber_corepainterscp" descending="false" />' +
           '<filter type="and">' +
           '<condition attribute="statecode" operator="eq" value="0" />' +
           '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
           '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
            '<filter type="or">' +
            '<condition attribute="ber_subdealer" operator="eq" value="0" />' +
             '<condition attribute="ber_subdealer" operator="null" />' +
            '</filter>' +
          '<condition attribute="ber_parentpainter" operator="null" />' +
           '<condition attribute="ber_epstatus" operator="in">' +
           '<value>278290003</value>' +
           '<value>278290000</value>' +
           '</condition>' +
           ' <condition attribute="ber_havemoisturemeter" operator="eq" value="1" />' +
           '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
           '</filter>' +
           '</entity>' +
           '</fetch>';



            //alert("1");
            // Xrm.Page.getAttribute("ber_masterpainterid").setValue(null);
            if (Xrm.Page.ui.controls.get("ber_xpa") != null) {
                Xrm.Page.ui.controls.get("ber_xpa").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                Xrm.Page.ui.controls.get("ber_xpa").setDefaultView(view_PaintersByDepotId);
            }

            $("#ber_xpa").find("img").attr("disableviewpicker", "1");


        }
    }
}





function filterXPAByDefaultDepot() {

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;

            var view_PaintersByDepotDisplayname = "XPA Painters with Sander & Moisture";
            // var view_PaintersByDepotId = GetuniqueGuid();
            var xpaViewId = "{00000000-0000-0000-00AA-000010001007}";
            //var view_PaintersByDepotId = Xrm.Page.getControl("ber_xpa").getDefaultView();
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                '<row name="result" id="contactid">' +
                '<cell name="fullname" width="100" />' +
                '<cell name="ber_xpamonthlyleadlimit" width="100" />' +
                '<cell name="ber_exteriorpainterrating" width="100" />' +
                '<cell name="ber_corepainterscp" width="100" />' +
                '<cell name="ber_epstatus" width="100" />' +
                '<cell name="ber_painterrating" width="100" />' +
                '<cell name="ber_havesander" width="100" />' +
                '<cell name="ber_dealerid" width="100" />' +
                '<cell name="ber_depotid" width="100" />' +
                '<cell name="mobilephone" width="100" />' +
                '<cell name="ber_preferredlanguage1" width="100" />' +
                '<cell name="ber_preferredlanguage2" width="100" />' +
                '</row>' +
                '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                '<entity name="contact">' +
                '<attribute name="fullname" />' +
                '<attribute name="contactid" />' +
                '<attribute name="ber_xpamonthlyleadlimit" />' +
                '<attribute name="ber_corepainterscp" />' +
                '<attribute name="ber_preferredlanguage2" />' +
                '<attribute name="ber_preferredlanguage1" />' +
                '<attribute name="ber_painterrating" />' +
                '<attribute name="ber_exteriorpainterrating" />' +
                '<attribute name="ber_depotid" />' +
                '<attribute name="ber_dealerid" />' +
                '<attribute name="ber_epstatus" />' +
                '<attribute name="mobilephone" />' +
                '<attribute name="ber_havesander" />' +
                '<order attribute="ber_corepainterscp" descending="false" />' +
                '<filter type="and">' +
                '<condition attribute="statecode" operator="eq" value="0" />' +
                '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                '<filter type="or">' +
                '<condition attribute="ber_subdealer" operator="eq" value="0" />' +
                '<condition attribute="ber_subdealer" operator="null" />' +
                '</filter>' +
                '<condition attribute="ber_parentpainter" operator="null" />' +
                '<condition attribute="ber_xpa" operator="eq" value="1" /> />' +
                '<condition attribute="ber_epstatus" operator="in">' +
                '<value>278290003</value>' +
                '<value>278290000</value>' +
                '</condition>' +
                ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                ' <condition attribute="ber_havemoisturemeter" operator="eq" value="1" />' +
                '<filter type="or">' +
                '<condition attribute="ber_xpamonthlyleadlimit" operator="le" value="20" />' +
                '<condition attribute="ber_xpamonthlyleadlimit" operator="null" />' +
                '</filter>' +
                '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                '</filter>' +
                '</entity>' +
                '</fetch>';

            if (Xrm.Page.ui.controls.get("ber_xpa") != null) {
                Xrm.Page.ui.controls.get("ber_xpa").addCustomView(xpaViewId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                Xrm.Page.ui.controls.get("ber_xpa").setDefaultView(xpaViewId);
            }

            $("#ber_xpa").find("img").attr("disableviewpicker", "1");
        }

    }
}





