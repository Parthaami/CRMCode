function paymentmodeOnChange() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")

    if (Xrm.Page.getAttribute("ber_paymentmode").getSelectedOption() != null) {
        var paymentmodetext = Xrm.Page.getAttribute("ber_paymentmode").getSelectedOption().text;

        if (paymentmodetext != null) {
            if (paymentmodetext == "Cheque") {
                if (isCrmForMobile) {

                    Xrm.Page.ui.controls.get("ber_chequenumbermobile").setVisible(true);
                    PopulateChequeForAccount();

                }
                else {
                    Xrm.Page.ui.controls.get("IFRAME_ChequeNumber").setVisible(true);

                }
            }
            else {
                if (isCrmForMobile) {
                    Xrm.Page.ui.controls.get("ber_chequenumbermobile").setVisible(false)
                    Xrm.Page.getAttribute("ber_chequenumbermobile").setValue(null);
                    Xrm.Page.getAttribute("ber_chequenumber").setValue(null);

                }
                else {
                    Xrm.Page.ui.controls.get("IFRAME_ChequeNumber").setVisible(false);
                    Xrm.Page.getAttribute("ber_chequenumber").setValue(null);
                }
    var AccNo = null;
    //Xrm.Page.getControl("ber_chequenumber").setVisible(false);
    var map = false;
    var orgName = Xrm.Page.context.getOrgUniqueName();
    var BilltoId = Xrm.Page.getAttribute("ber_billto").getValue();
    if (BilltoId != null && BilltoId != "" && BilltoId != undefined) {
        var AccId = Xrm.Page.getAttribute("ber_billto").getValue()[0].id;
        var columns = ['AccountNumber'];
        var filter = "AccountId eq (Guid'" + AccId + "')";
        var collection = CrmRestKit.RetrieveMultiple('Account', columns, filter);
        if (collection != null && collection.results != null && collection.results.length > 0) {
            if (collection.results[0].AccountNumber != null) {
                AccNo = collection.results[0].AccountNumber;
            }
        }
    }
    else {
        if (isCrmForMobile) {
            Xrm.Page.ui.controls.get("ber_chequenumbermobile").setVisible(false)
            Xrm.Page.getAttribute("ber_chequenumbermobile").setValue(null);
            Xrm.Page.getAttribute("ber_chequenumber").setValue(null);

        }
        else {
            Xrm.Page.ui.controls.get("IFRAME_ChequeNumber").setVisible(false);
            Xrm.Page.getAttribute("ber_chequenumber").setValue(null);
        }
    }
    chequemap();

}
