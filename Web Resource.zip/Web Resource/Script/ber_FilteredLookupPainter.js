function FilteredLookupPainter()
{
	var viewId = Xrm.Page.data.entity.getId();
	var entityName = "contact";
	var viewDisplayName = "Painter";
	
	var viewDisplayNameDBO = "BDO/DG";

	var fetchXml="<?xml version='1.0'?><fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'><entity name='contact'><attribute name='fullname'/><attribute name='contactid'/><order descending='false' attribute='fullname'/><filter type='and'><condition attribute='ber_customertype' value='278290001' operator='eq'/></filter> </entity> </fetch>";
	
	var fetchXmlDBO="<?xml version='1.0'?><fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'><entity name='contact'><attribute name='fullname'/><attribute name='contactid'/><order descending='false' attribute='fullname'/><filter type='and'><condition attribute='ber_customertype' value='278290005' operator='eq'/></filter> </entity> </fetch>";

	var layoutXml = "<grid name='resultset' object='2' jump='lastname' select='1' icon='1' preview='1'><row name='result' id='contactid'><cell name='fullname' width='300'/></row></grid>";

	Xrm.Page.getControl("ber_masterpainterid").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);            
	
	Xrm.Page.getControl("ber_bdodgid").addCustomView(viewId, entityName, viewDisplayNameDBO, fetchXmlDBO, layoutXml, true);            

}