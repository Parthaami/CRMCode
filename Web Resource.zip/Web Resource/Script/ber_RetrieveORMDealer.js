/****************************
Developer : Madhumita
Dated : 17th June,2019
Method: SetSite
Functionality : based on parent dealer set the corresponding 
                primary site w.r.t the specific depot
****************************/


function SetSite() {

    if (Xrm.Page.getAttribute("ber_identitytype").getValue() != null && Xrm.Page.getAttribute("ber_identitytype").getValue() != undefined) {
        if (Xrm.Page.getAttribute("ber_dealer") != null && Xrm.Page.getAttribute("ber_dealer").getValue() != null && Xrm.Page.getAttribute("ber_dealer").getValue()[0].id != null) {
            var IdentityType = Xrm.Page.getAttribute("ber_identitytype").getValue();
            if (IdentityType == 278290001) {
                var CustomerId = Xrm.Page.getAttribute("ber_dealer").getValue()[0].id;
                var guid = CustomerId.replace("{", "").replace("}", "");

                var req = new XMLHttpRequest();
                //req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=accountid,_parentaccountid_value&$filter=donotfax eq true and  _parentaccountid_value eq " + guid, false);
                // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=accountid,accountnumber,donotfax,_parentaccountid_value&$filter=donotfax eq false and  _parentaccountid_value eq " + guid, false);
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=accountid,accountnumber,donotfax,name,_parentaccountid_value&$filter=donotfax eq false and  _parentaccountid_value eq " + guid, false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.send();
                if (req.response != null && req.response != "") {
                    var results = JSON.parse(req.response);
                    if (results != null) {

                        var accountid = results.value[0]["accountid"];
                        //  alert(accountid);
                        var accountnumber = results.value[0]["accountnumber"];
                        //   alert(accountnumber);
                        var accountid = results.value[0]["accountid"];
                        var accountnumber = results.value[0]["accountnumber"];
                        var donotfax = results.value[0]["donotfax"];
                        var donotfax_formatted = results.value[0]["donotfax@OData.Community.Display.V1.FormattedValue"];
                        var name = results.value[0]["name"];
                        var _parentaccountid_value = results.value[0]["_parentaccountid_value"];
                        var _parentaccountid_value_formatted = results.value[0]["_parentaccountid_value@OData.Community.Display.V1.FormattedValue"];
                        var _parentaccountid_value_lookuplogicalname = results.value[0]["_parentaccountid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var acc = new Array();
                        acc[0] = new Object();
                        acc[0].id = accountid;
                        acc[0].name = name;
                        acc[0].entityType = "account"
                        Xrm.Page.getAttribute("ber_site").setValue(acc);
                        Xrm.Page.getAttribute("ber_site").setSubmitMode("always");
                        Xrm.Page.getControl("ber_site").setDisabled(true);

                    }
                }
            }
        }

    }



}







/****************************
Developer : Madhumita
Dated : 17th June,2019
Method: setDepot
Functionality : based on inserted pincode the related city,
                state and depot will be set in ORM entity
****************************/


function setDepot() {

    // if (Xrm.Page.getAttribute("ber_identitytype").getValue() != null && Xrm.Page.getAttribute("ber_identitytype").getValue() != undefined) {
    if (Xrm.Page.getAttribute("ber_pincode").getValue() != null && Xrm.Page.getAttribute("ber_pincode") != 'undefined') {
        //   var IdentityType = Xrm.Page.getAttribute("ber_identitytype").getValue();
        //  alert("A");
        //  if (IdentityType == 278290000) {
        var pincode = Xrm.Page.getAttribute("ber_pincode").getValue();
        //  alert(pincode);


        //var isnum = /^\d+$/.test(pincode);
        //alert(isnum);


        if ((pincode != null) && (pincode != undefined) && (/^\d+$/.test(pincode) != false)) {
            var req = new XMLHttpRequest();
            //   req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_pincodes?$select=_ber_cityid_value,ber_name,ber_pincodeid&$filter=statecode eq 0 and  ber_name eq " + pincode, false);
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_pincodes?$select=_ber_cityid_value,ber_name,ber_pincodeid&$filter=ber_name eq '" + pincode + "' and  statecode eq 0 ", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var results = JSON.parse(req.response);
                try {
                    if (results != null) {
                        //no duplicate record should be allowed
                        if (results.value.length > 0) {
                            //    alert(results.value.length);
                            var _ber_cityid_value = results.value[0]["_ber_cityid_value"];
                            var _ber_cityid_value_formatted = results.value[0]["_ber_cityid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_cityid_value_lookuplogicalname = results.value[0]["_ber_cityid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var ber_name = results.value[0]["ber_name"];
                            var ber_pincodeid = results.value[0]["ber_pincodeid"];

                            //   alert(ber_pincodeid);
                        }


                        var req1 = new XMLHttpRequest();
                        //  req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_cities?$select=ber_cityid,_ber_defaultdepotid_value&$filter=ber_cityid eq " + _ber_cityid_value, false);
                        req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_cities?$select=ber_cityid,_ber_stateid_value,_ber_defaultdepotid_value&$filter=ber_cityid eq " + _ber_cityid_value, false);
                        req1.setRequestHeader("OData-MaxVersion", "4.0");
                        req1.setRequestHeader("OData-Version", "4.0");
                        req1.setRequestHeader("Accept", "application/json");
                        req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req1.send();

                        if (req1.response != null && req1.response != "") {
                            var results2 = JSON.parse(req1.response);

                            if (results2 != null) {
                                //no duplicate record should be allowed
                                if (results2.value.length > 0) {
                                    //  alert(results2.value.length);

                                    var ber_cityid = results2.value[0]["ber_cityid"];
                                    var _ber_stateid_value = results2.value[0]["_ber_stateid_value"];
                                    var _ber_stateid_value_formatted = results2.value[0]["_ber_stateid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_stateid_value_lookuplogicalname = results2.value[0]["_ber_stateid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                    var _ber_defaultdepotid_value = results2.value[0]["_ber_defaultdepotid_value"];
                                    var _ber_defaultdepotid_value_formatted = results2.value[0]["_ber_defaultdepotid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_defaultdepotid_value_lookuplogicalname = results2.value[0]["_ber_defaultdepotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                                    // alert(_ber_defaultdepotid_value_formatted);

                                    var DepotArray = new Array();
                                    DepotArray[0] = new Object();
                                    DepotArray[0].id = _ber_defaultdepotid_value;
                                    DepotArray[0].name = _ber_defaultdepotid_value_formatted;
                                    DepotArray[0].entityType = _ber_defaultdepotid_value_lookuplogicalname;

                                    var StateArray = new Array();
                                    StateArray[0] = new Object();
                                    StateArray[0].id = _ber_stateid_value;
                                    StateArray[0].name = _ber_stateid_value_formatted;
                                    StateArray[0].entityType = _ber_stateid_value_lookuplogicalname;

                                    //set the depot field of ORM

                                    Xrm.Page.getAttribute("ber_ormdepot").setValue(DepotArray);
                                    Xrm.Page.getAttribute("ber_ormdepot").setSubmitMode("always");

                                    //set the depot field of city

                                    Xrm.Page.getAttribute("ber_city").setValue(_ber_cityid_value_formatted);
                                    Xrm.Page.getAttribute("ber_city").setSubmitMode("always");

                                    //set the depot field of state

                                    Xrm.Page.getAttribute("ber_state").setValue(_ber_stateid_value_formatted);
                                    Xrm.Page.getAttribute("ber_state").setSubmitMode("always");

                                }
                            }


                        }

                    }
                }
                catch (err) {
                    alert("Please communicate system administrator in HO for error: " + err);
                }
            }
        }
    }
    // }
    // }

}



/****************************
Developer : Madhumita
Dated : 17th June,2019
Method: ValidatePreferredtime
Functionality : On save it will check whether preferred date
                time is in between 9:00 A.M to 9:00 P.M
****************************/

function ValidatePreferredtime(executionObj) {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != null && Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != undefined) {
        var preferreddate = Xrm.Page.getAttribute("ber_preferreddatetime").getValue();
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        //  status == 278290032
        //  if (status == 1 || status == 278290032) {
        var today = new Date();

        var StartingTime = parseFloat("9");

        var EndingTime = parseFloat("21");

        var TimeinHour = parseFloat(preferreddate.getHours()) + parseFloat(preferreddate.getMinutes()) / 60;

        // checking if entered hour is in between office hours

        if ((TimeinHour > StartingTime) && (TimeinHour < EndingTime)) {

        }
        else {
            alert("Please ensure preferred time must be between 9:00 A.M to 9:00 P.M");

            if (!isCrmForMobile)
                Xrm.Page.getAttribute("ber_preferreddatetime").setValue(null);

            executionObj.getEventArgs().preventDefault();

        }

        // }


    }

}


/****************************
Developer : Madhumita
Dated : 17th June,2019
Method: ValidatePreferredtime
Functionality : On change it will check if inserted date 
                time is greater than today's date or not
****************************/


function PreferredDateValidation() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != null && Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != undefined) {
        var a = Xrm.Page.getAttribute("ber_preferreddatetime").getValue();
        var x = new Date((a.getMonth() + 1) + "/" + a.getDate() + "/" + a.getFullYear()).setHours(0, 0, 0, 0);
        var b = new Date();
        var c = new Date((b.getMonth() + 1).toString() + "/" + b.getDate() + "/" + b.getFullYear()).setHours(0, 0, 0, 0);

        // checking if inserted date is greater than or equal to todays date                                  

        if (a != null && x <= c) {
            alert("Date Should be greater than Today's Date.");
            if (!isCrmForMobile)
                Xrm.Page.getAttribute("ber_preferreddatetime").setValue(null);

        }
    }
}




/****************************
Developer : Madhumita
Dated : 17th June,2019
Method: Chargable
Functionality : On change of paintexpressitem it will check 
                whether the tool is under warranty or not
****************************/


// JScript source code
function Chargable(utc) {

    if (Xrm.Page.getAttribute("ber_paintexpressitem1") != undefined && Xrm.Page.getAttribute("ber_paintexpressitem1").getValue() != null) {

        var painterExpressItem = Xrm.Page.getAttribute("ber_paintexpressitem1").getValue();
        var painterExpressItemid = painterExpressItem[0].id;
        var painterExpressItemGUID = painterExpressItemid.replace("{", "").replace("}", "");


        var req = new XMLHttpRequest();
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statecode&$filter=_ber_itemid_value eq " + painterExpressItemGUID, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statecode&$filter=ber_paintexpressitemid eq" + painterExpressItemGUID, false);
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statuscode&$filter=ber_paintexpressitemid eq " + painterExpressItemGUID, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var _ber_itemid_value = result.value[0]["_ber_itemid_value"];
                var _ber_itemid_value_formatted = result.value[0]["_ber_itemid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_itemid_value_lookuplogicalname = result.value[0]["_ber_itemid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_name = result.value[0]["ber_name"];
                var _ber_painterid_value = result.value[0]["_ber_painterid_value"];
                var painteridGUID = _ber_painterid_value.replace("{", "").replace("}", "");
                var _ber_painterid_value_formatted = result.value[0]["_ber_painterid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_painterid_value_lookuplogicalname = result.value[0]["_ber_painterid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_toolapprovaldate = result.value[0]["ber_toolapprovaldate"];
                var statuscode = result.value[0]["statuscode"];
                // var statecode_formatted = result.value[0]["statecode@OData.Community.Display.V1.FormattedValue"];




                if (_ber_itemid_value_formatted != null) {
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(_ber_itemid_value_formatted);
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
                }
                else if (_ber_itemid_value_formatted == null) {
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
                }
            }
        }
    }

    // if painter value exists


    if (_ber_painterid_value != undefined || _ber_painterid_value != null) {

        // if status reason approved and approval date not null

        if (statuscode == 278290000 && ber_toolapprovaldate != null) {

            var req1 = new XMLHttpRequest();
            req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.0/contacts(" + painteridGUID + ")?$select=ber_customertype,ber_toolwiseactivated", false);
            req1.setRequestHeader("OData-MaxVersion", "4.0");
            req1.setRequestHeader("OData-Version", "4.0");
            req1.setRequestHeader("Accept", "application/json");
            req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req1.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
            req1.send();

            if (req1.response != null && req1.response != "") {
                var result1 = JSON.parse(req1.response);
                if (result1 != null) {
                    var CustomerType = result1["ber_customertype"];
                    var Activated = result1["ber_toolwiseactivated"];

                    var laterdate = new Date();

                    var prevdate = HandleODataDate(ber_toolapprovaldate);
                    if (statuscode == 278290000 && ber_toolapprovaldate != null) {
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(prevdate);
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(prevdate);
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");

                    }

                    var prevdateday = prevdate.getDate();
                    var prevdatemonth = prevdate.getMonth() + 1;
                    var prevdateyear = prevdate.getFullYear();

                    var laterdateday = laterdate.getDate();
                    var laterdatemonth = laterdate.getMonth() + 1;
                    var laterdateyear = laterdate.getFullYear();

                    var month, year, totaldays, totalmonth;

                    totalmonth = 0;

                    if (prevdatemonth == laterdatemonth && prevdateyear == laterdateyear) {

                        totaldays = laterdateday - prevdateday;

                        //  alert(totaldays);
                    }

                    else {

                        for (month = prevdatemonth, year = prevdateyear; year <= laterdateyear; month++) {

                            if (month == prevdatemonth && year == prevdateyear)
                            { totaldays = new Date(prevdateyear, prevdatemonth, 0).getDate() - prevdateday; }

                            else if (month == laterdatemonth && year == laterdateyear)
                            { totaldays = totaldays + laterdateday; }

                            else {
                                // totalmonth++;
                                //    totalmonth = totalmonth + 1; 

                                totaldays = totaldays + new Date(year, month, 0).getDate()
                            }

                            if (month == 12) {
                                month = 0;
                                year = year + 1;
                            }

                            if (month == laterdatemonth && year == laterdateyear) {

                                // alert(totaldays);
                                break;
                            }
                        }


                    }

                    if (Activated != null && totaldays != null && ber_toolapprovaldate != null) {

                        // if the painter is toolwise active and duration of days less than 365 days then the tool is under warranty

                        if (Activated == 1 && totaldays <= 365) {

                            Xrm.Page.getAttribute("ber_chargeable").setValue(278290000);
                            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                        }

                            //   if the painter is toolwise active and duration of days greater than 365 days then the tool is not under warranty                                                          Not under warranty

                        else if (Activated == 1 && totaldays > 365) {

                            Xrm.Page.getAttribute("ber_chargeable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                        }

                        //  if the painter is toolwise inactive and duration of days less than 180 days then the tool is not warranty 

                        if (Activated == 2 && totaldays <= 180) {

                            Xrm.Page.getAttribute("ber_chargeable").setValue(278290000);
                            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                        }

                            //  if the painter is toolwise inactive and duration of days greater than 180 days then the tool is not warranty 

                        else if (Activated == 2 && totaldays > 180) {

                            Xrm.Page.getAttribute("ber_chargeable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                        }

                        else if (totaldays == null) {
                            Xrm.Page.getAttribute("ber_chargeable").setValue(null);
                            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                        }
                    }
                    else {
                        Xrm.Page.getAttribute("ber_chargeable").setValue(null);
                        Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
                    }
                }
            }
        }
        else if (statuscode == 1 || ber_toolapprovaldate == null) {
            Xrm.Page.getAttribute("ber_chargeable").setValue(null);
            Xrm.Page.getAttribute("ber_chargeable").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
            Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");

        }


    }

    else {
        Xrm.Page.getAttribute("ber_chargable").setValue(null);
        Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_expresstoolname").setValue(null);
        Xrm.Page.getAttribute("ber_expresstoolname").setSubmitMode("always");

    }

}









function HandleODataDate(dateValue) {

    var returnValue = null;

    try {

        dateValue = dateValue == null ? "" : dateValue.toString();

        if (dateValue != "") {

            //dateValue = dateValue.replace("/", "");

            //dateValue = dateValue.replace("Date(", "");

            //dateValue = dateValue.replace(")", "");

            //dateValue = dateValue.replace("/", "");

            //var returnValue = new Date(parseInt(dateValue));

            //returnValue = isNaN(returnValue) ? null : returnValue;
            var dateValue = new Date(dateValue.substring(0, 10));

            return dateValue;
        }

    }

    catch (Exception) { }

    return returnValue;

}