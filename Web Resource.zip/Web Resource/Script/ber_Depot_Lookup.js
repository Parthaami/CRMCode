function depotlookupshowhide()
{
var masterdepot=Xrm.Page.getAttribute("ber_ismasterdepot").getValue();
if(masterdepot == false)
{
Xrm.Page.ui.controls.get("ber_masterdepotid").setVisible(true);
Xrm.Page.getAttribute("ber_masterdepotid").setRequiredLevel("required");
}
if(masterdepot == true)
{
Xrm.Page.ui.controls.get("ber_masterdepotid").setVisible(false);
Xrm.Page.getAttribute("ber_masterdepotid").setRequiredLevel("none");
}
}