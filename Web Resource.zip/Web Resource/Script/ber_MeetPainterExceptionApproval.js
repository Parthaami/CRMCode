function ExceptionApproval(){
var status=Xrm.Page.getAttribute("statuscode").getValue();
if(status == "278290003" && status !=null){   //Final Points Calculated
if(CheckDisabled("ber_benefitpoints")){
 Xrm.Page.ui.controls.get("ber_benefitpoints").setDisabled(false);
 }
 //AddExceptionPointToNote();
}
if(status == "278290000" && status !=null && UserHasRole("System Administrator","HO BD User")){   //Pending ML Approval
if(CheckDisabled("ber_benefitpoints")){
Xrm.Page.ui.controls.get("ber_benefitpoints").setDisabled(false);
}
if(CheckDisabled("ber_exceptionpointapproved")){
Xrm.Page.ui.controls.get("ber_exceptionpointapproved").setDisabled(false);
}
CheckEmptyOrNot();
var Approved=Xrm.Page.getAttribute("ber_exceptionpointapproved").getValue();
if(Approved==0){
EnableDescription();
  }
 }
}

function CheckEmptyOrNot(){
var Approved=Xrm.Page.getAttribute("ber_exceptionpointapproved").getValue();
if(Approved==null){
Xrm.Page.getAttribute("ber_exceptionpointapproved").setValue(0);
}
}

function AllowToAddPointDescription(GenratingParent){
//debugger;
if(GenratingParent==1){
EnableDescription();
}
else{
var Value=Xrm.Page.getAttribute("ber_exceptionpointapproved").getValue();
if(Value==false){
EnableDescription();
  }
  else{
  DisableDescription();
  }
 }
}

function EnableDescription(){
if(CheckDisabled("ber_description")){
Xrm.Page.ui.controls.get("ber_description").setDisabled(false);
Xrm.Page.getAttribute("ber_description").setSubmitMode("always");
Xrm.Page.data.entity.attributes.get("ber_description").setRequiredLevel("required");
 }
}

function DisableDescription(){
if(CheckDisabled("ber_description")!=true){
Xrm.Page.ui.controls.get("ber_description").setDisabled(true);
Xrm.Page.getAttribute("ber_description").setSubmitMode("always");
Xrm.Page.data.entity.attributes.get("ber_description").setRequiredLevel("none");
 }
}


function CheckDisabled(field){
return Xrm.Page.getControl(field).getDisabled();
}

function AddExceptionPointToNote()
{
//debugger;
var ExceptionPoint = Xrm.Page.getAttribute("ber_benefitpoints").getValue();
var MeetPainterId = Xrm.Page.data.entity.getId();
if(ExceptionPoint >0 && ExceptionPoint !=null){
var Note = Xrm.Page.getAttribute("ber_description").getValue();
var MeetPainterId = Xrm.Page.data.entity.getId();
var UserID = Xrm.Page.context.getUserId();

 var fetchXml =  "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>"+
  "<entity name='annotation'>"+
    "<attribute name='subject' />"+
    "<attribute name='notetext' />"+
    "<attribute name='filename' />"+
    "<attribute name='annotationid' />"+
    "<attribute name='createdon' />"+
    "<order attribute='createdon' descending='false' />"+
    "<filter type='and'>"+
      "<condition attribute='ownerid' operator='eq'  value='"+UserID+"' />"+
    "</filter>"+
    "<link-entity name='ber_paintermeetcontact' from='ber_paintermeetcontactid' to='objectid' alias='ab'>"+
      "<filter type='and'>"+
        "<condition attribute='ber_paintermeetcontactid' operator='eq' value='"+MeetPainterId+"' />"+
      "</filter>"+
    "</link-entity>"+
  "</entity>"+
 "</fetch>";
 
  var Response=RetrieveRecord(fetchXml); 
  if(isEmptyObject(Response) && Response !=null){
  var Description= Response[0].attributes.notetext.value;
  var UpdatedDesc= BuildDescription(Description,Note,ExceptionPoint);
  var id=Response[0].attributes.annotationid.value;
  UpdateNote(id,"annotation",UpdatedDesc);
  Xrm.Page.getAttribute("ber_description").setValue("");
  }
 else{
     var UpdatedDesc= BuildDescription("",Note,ExceptionPoint);
     CreateAnnotation(MeetPainterId,UpdatedDesc,UserID);
	 Xrm.Page.getAttribute("ber_description").setValue("");
    }
 }
}

function BuildDescription(Description,Note,ExceptionPoint){
    var Val =  Description+"\n \n--> "+Note+ " \nExceptionPoint given :- "+ExceptionPoint; 
	return Val;
}

function CreateAnnotation(MeetPainterId,UpdatedDesc,OwnerID){
    var refMeetPainter = new Object();
    refMeetPainter.LogicalName = "ber_paintermeetcontact";
    refMeetPainter.Id = MeetPainterId;
     
	var refUser=new Object();
	refUser.LogicalName = "systemuser";
    refUser.Id = OwnerID;
	
var createNote = new XrmServiceToolkit.Soap.BusinessEntity("annotation");
createNote.attributes["notetext"] = UpdatedDesc;
createNote.attributes["subject"] = "Exception Point";
createNote.attributes["objectid"] = { id: refMeetPainter.Id, logicalName: refMeetPainter.LogicalName, type: "EntityReference" };
createNote.attributes["objecttypecode"] = refMeetPainter.LogicalName;
//createNote.attributes["ownerid"] = refUser;
var NoteId = XrmServiceToolkit.Soap.Create(createNote);
if(NoteId!=null){
var notesFrame = document.getElementById("notescontrol");
        notesFrame.src = notesFrame.src;
 }
}

function isEmptyObject(obj) {
    var name;
    for ( name in obj ) {
        return true;
    }
    return false;
}

/////////////////////////////function set update the EPStatus in contact////////////////////////////////////////////////
function UpdateNote(recordGuid, strEntityName, text) {
   // debugger;
    try {
        var updateRecord = new XrmServiceToolkit.Soap.BusinessEntity(strEntityName, recordGuid);
        updateRecord.attributes["notetext"] = text;
        var response = XrmServiceToolkit.Soap.Update(updateRecord);
        var notesFrame = document.getElementById("notescontrol");
        notesFrame.src = notesFrame.src;
		
	
    }
    catch (e) {
        throw e;
    }

}

////////////////////////////function to Retreive the related fetchxml//////////////////////////////////////////////////////
function RetrieveRecord(fetchXml) {

    try {

        return XrmServiceToolkit.Soap.Fetch(fetchXml);
    }
    catch (e) {
        alert(e.message);
    }
}

function GetRequestObject() {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex) {
            return null;
        }
    }
}


function UserHasRole(roleName1,roleName2) {
//debugger;
    //To Fetch Server Url
	var counter=0;
    var serverUrl = window.location.protocol + "//" + window.location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    //var serverUrl = window.location.protocol + "//" + window.location.host ;

    var userRoles = Xrm.Page.context.getUserRoles();

    for (var i = 0; i < userRoles.length; i++) {
        var roleId = userRoles[i];

        //To Fetch Guid Of given Role Name..
        var oDataEndpointUrl = serverUrl + "/XRMServices/2011/OrganizationData.svc/";
        oDataEndpointUrl += "RoleSet?$top=1&$filter=RoleId eq Guid'" + roleId + "'";

        var service = GetRequestObject();

        if (service != null) {
            service.open("GET", oDataEndpointUrl, false);
            service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
            service.setRequestHeader("Accept", "application/json, text/javascript, */*");
            service.send(null);

            var requestResults = eval('(' + service.responseText + ')').d;

            if (requestResults != null) {
                var role = requestResults.results[0];
                if (role != null) {
                    if ((role.Name == roleName1)||((role.Name == roleName2))) {
                        counter ++;
                    }
                }
            }
        }
    }
	if(counter>0){
   return true;
   }else{
   return false;
   }
}

function FormatNotesControl(AllowInsert, AllowEdit)
{
    var notescontrol = document.getElementById('notescontrol');
    if (notescontrol == null)
        return;
    var url = notescontrol.src;

    if (!AllowInsert)
        url = url.replace("EnableInsert=true", "EnableInsert=false");
    if (!AllowEdit)
        url = url.replace("EnableInlineEdit=true", "EnableInlineEdit=false");

    notescontrol.src = url;
}

function DisableNotesInsert()
{
    FormatNotesControl(false, true);
}

function CheckonSuspectionDateAndReconciliationStatus() {
    if (UserHasRole("System Administrator", "HO BD User")) {
        Xrm.Page.ui.controls.get("ber_suspecteddate").setDisabled(false);
    }
    else {
        Xrm.Page.ui.controls.get("ber_suspecteddate").setDisabled(true);
        var PickListControl = Xrm.Page.getControl("ber_reconciliationstatus");
        PickListControl.removeOption(2);

    }
}