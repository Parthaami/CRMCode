/// <reference path="XrmPageTemplate.js" />

//Disable CreatePDC button for Depot Color Bank User after Entered
function CustomRuleCreatePDC() 
{
    var bookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();
    
    if (UserHasRole('Depot Color Bank'))
     {
         if (bookingStatus == 0)
         {
              return true; 
         }
         return false;
    }
    return true;
}

//Disable Custom Buttons for Depot Color Bank User
function CustomRuleEnableButton() 
{
    if (UserHasRole('Depot Color Bank')) 
    {
        return false;
    }
    return true;
}

function UserHasRole(roleName) {
    //To Fetch Server Url
    var serverUrl = window.location.protocol + "//" + window.location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    //var serverUrl = window.location.protocol + "//" + window.location.host ;

    var userRoles = Xrm.Page.context.getUserRoles();

    for (var i = 0; i < userRoles.length; i++) {
        var roleId = userRoles[i];

        //To Fetch Guid Of given Role Name..
        var oDataEndpointUrl = serverUrl + "/XRMServices/2011/OrganizationData.svc/";
        oDataEndpointUrl += "RoleSet?$top=1&$filter=RoleId eq Guid'" + roleId + "'";

        var service = GetRequestObject();

        if (service != null) {
            service.open("GET", oDataEndpointUrl, false);
            service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
            service.setRequestHeader("Accept", "application/json, text/javascript, */*");
            service.send(null);

            var requestResults = eval('(' + service.responseText + ')').d;

            if (requestResults != null) {
                var role = requestResults.results[0];
                if (role != null) {

                    if (role.Name == roleName) {
                        return true;
                    }
                }
            }
        }
    }
   return false;
};