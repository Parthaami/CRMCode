// JavaScript source code
function leadtype() {

    if (Xrm.Page.getAttribute("ber_leadtype") !== null) {

        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        var leadfor = Xrm.Page.getAttribute("ber_leadfor").getValue();
        var navleadaudit = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadaudit_Lead");
        var navleadproduct = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadproduct_lead");
        var navleadpainter = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadpainter_Lead");
        if (navleadproduct !== null) navleadproduct.setVisible(false);
        if (navleadpainter !== null) navleadpainter.setVisible(false);
        if (leadtype != null) {
            Xrm.Page.ui.controls.get("ber_leadfor").setVisible(false);
            setVisibleSection("general", "address", true);
            setVisibleSection("general", "productdetails", true);

            if (leadtype == 278290002) {

                setVisibleSection("general", "dealerinfo", true);
                if (Xrm.Page.getAttribute("statuscode").getValue() != 278290007) { //------ XP more change on 03122015
                    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");

                    if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                        Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                    if (Xrm.Page.getAttribute("ber_startdate") != null)
                        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                }
                if (Xrm.Page.getAttribute("statuscode").getValue() != null)
                    if (Xrm.Page.getAttribute("statuscode").getValue() == 1 || Xrm.Page.getAttribute("statuscode").getValue() == 278290004) {
                        if (navleadproduct !== null) navleadproduct.setVisible(false);
                        if (navleadpainter !== null) navleadpainter.setVisible(false);
                    } else {
                        if (Xrm.Page.getAttribute("statuscode").getValue() == 2) {

                            if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                                Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                                Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_startdate") != null)
                                Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_enddate") != null)
                                Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null)
                                Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("required");
                        }
                        if (navleadproduct !== null) navleadproduct.setVisible(true);
                        if (navleadpainter !== null) navleadpainter.setVisible(true);

                    } else {

                    if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                        Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                        Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_startdate") != null)
                        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_enddate") != null)
                        Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");

                    if (navleadproduct !== null) navleadproduct.setVisible(false);
                    if (navleadpainter !== null) navleadpainter.setVisible(false);
                }
            } else if (leadtype == 278290001) {
                setVisibleSection("general", "homedecor", true);
                setVisibleSection("general", "dealerinfo", false);

                if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                    Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_startdate") != null)
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");

                if (navleadproduct !== null) navleadproduct.setVisible(false);
                if (navleadpainter !== null) navleadpainter.setVisible(false);
                if (navleadaudit !== null) navleadaudit.setVisible(false);
            }

            else {

            }
        }
    }
}

function SetStatusReasonOnChangeofPinCode() {
    if (Xrm.Page.getAttribute("ber_pincodeid").getValue()[0].name != null) {
        if (Xrm.Page.getAttribute("statuscode").getValue() == 278290007) {
            Xrm.Page.getAttribute("statuscode").setValue(1);
            if (UserHasRole("Call Center User")) {
                Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_preferreddatetime").setDisabled(true);
            }
            else {
                Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("required");
            }


        }

        Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
    }
}

function OnCityChange() {

    if (Xrm.Page.getAttribute("ber_depotid") != null) {
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        if (Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined) {
            var submitMode = "always";
            var city = Xrm.Page.getAttribute("ber_cityid").getValue();
            if (city != null && city != undefined) {
                var cityId = city[0].id;
                var d = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                d += "<entity name = 'ber_city'>";
                d += "<attribute name = 'ber_citytype'/>";
                d += "<attribute name = 'ber_defaultdepotid'/>";
                d += "<attribute name = 'ber_openjobs'/>";
                d += "<attribute name = 'ber_maxjobs'/>";
                d += "<attribute name=  'ber_dealerselection'/>";
                d += "<filter type = 'and'>";
                d += "<condition attribute='ber_cityid' value ='";
                d += cityId;
                d += "' operator = 'eq'/>";
                d += "</filter>";
                d += "</entity>";
                d += "</fetch>";
                var fetchData = XrmServiceToolkit.Soap.Fetch(d);

                if (fetchData[0] != null) {
                    if (fetchData[0].attributes['ber_defaultdepotid'] !== null && fetchData[0].attributes['ber_defaultdepotid'] !== undefined) {
                        var defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
                        var defaultdepotid = fetchData[0].attributes["ber_defaultdepotid"].id;
                        var defaultdepotlogicalname = fetchData[0].attributes["ber_defaultdepotid"].logicalName;
                        Xrm.Page.getAttribute("ber_depotid").setValue([{
                            id: defaultdepotid,
                            name: defaultdepotname,
                            entityType: defaultdepotlogicalname
                        }]);

                        SetStatusReasonOnChangeofPinCode();
                    }

                    ///////////////added by madhumita ---- 29thFeb-2016///////////////


                    if (fetchData[0].attributes['ber_dealerselection'] !== null && fetchData[0].attributes['ber_dealerselection'] !== undefined) {

                        if (fetchData[0].attributes['ber_dealerselection'].value == 1) {

                            if (Xrm.Page.getAttribute("ber_dealerselectioncriteria") != null) Xrm.Page.getAttribute("ber_dealerselectioncriteria").setValue(278290002);
                            if (Xrm.Page.ui.controls.get("ber_dealerselectioncriteria") != null) Xrm.Page.ui.controls.get("ber_dealerselectioncriteria").setDisabled(true);
                            if (Xrm.Page.data.entity.attributes.get("ber_dealerselectioncriteria") != null) Xrm.Page.data.entity.attributes.get("ber_dealerselectioncriteria").setSubmitMode("always");


                        }

                    }




                    if (fetchData[0].attributes['ber_citytype'] !== null && fetchData[0].attributes['ber_citytype'] !== undefined) {
                        // BDM
                        if (fetchData[0].attributes['ber_citytype'].value == 278290000) {

                            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setValue(278290000);
                            if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                        }
                            // Home Decor
                        else if (fetchData[0].attributes['ber_citytype'].value == 278290001) {
                            // Check Open and Max Jobs count
                            var openJobs = fetchData[0].attributes['ber_openjobs'].value;
                            var maxJobs = fetchData[0].attributes['ber_maxjobs'].value;
                            if (openJobs < maxJobs) {

                                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setValue(278290001);
                                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                            } else {

                                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setValue(278290002);
                                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none"); // changed to allow form submit without dealer at enquiry stage

                            }
                        }
                            // XP
                        else if (fetchData[0].attributes['ber_citytype'].value == 278290002) {
                            if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setValue(278290002);

                        }
                        leadtype1();
                    } else {

                        if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setValue(null);

                    }
                }

                SetRSM(); // This will set RSM related to depot on lead form
                OnLoadStatusReasonHierarchy();
            }
        }
    }
}

// added on 25/11/2015
function filterOtherDealersByDepot() {

    $("#ber_otherdealers").find("img").attr("disableviewpicker", "0");

    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        if (_depotId != null) {
            // _depotId = _depotId.replace("{", "");
            //_depotId = _depotId.replace("}", "");
            var view_otherdealersdisplayname = "Other XP Dealers By Depot";
            //var view_otherdealersId = GetuniqueGuid();
            var view_otherdealersId = Xrm.Page.getControl("ber_otherdealers").getDefaultView();
            var IsDefaultView = true;

            layoutxml_otherdealers = '<grid name="resultset" object="1" jump="ber_otherdealers" select="1" icon="2" preview="1">' +
                '<row name="result" id="ber_otherdealerid">' +
                '<cell name="ber_name" width="100" />' +
                '<cell name="ber_otherdealers" width="100" />' +
                '<cell name="ber_dealerpincode" width="100" />' +
                '<cell name="ber_otherdealerdepotid" width="150"  />' +
                '</row>' +
                '</grid>';

            fetchxml_otherdealers = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                '<entity name="ber_otherdealer">' +
                '<attribute name="createdon" />' +
                '<attribute name="ber_name" />' +
                '<attribute name="ber_otherdealers" />' +
                '<attribute name="ber_dealerpincode" />' +
                '<attribute name="ber_otherdealerid" />' +
                '<attribute name="ber_otherdealerdepotid" />' +
                '<order attribute="createdon" descending="false" />' +
                '<filter type="and">' +
                '<condition attribute="statecode" operator="eq" value="0" />' +
                '<condition attribute="ber_otherdealerdepotid" operator="eq"  uitype="ber_depot" value="' + _depotId + '" />' +
                '</filter>' +
                '</entity>' +
                '</fetch>';
            Xrm.Page.getControl("ber_otherdealers").addCustomView(view_otherdealersId, "ber_otherdealer", view_otherdealersdisplayname, fetchxml_otherdealers, layoutxml_otherdealers, IsDefaultView);
            Xrm.Page.getControl("ber_otherdealers").setDefaultView(view_otherdealersId);
            //document.getElementById("ber_otherdealers").disableViewPicker = 1;
            $("#ber_otherdealers").find("img").attr("disableviewpicker", "1");

        }
    }

}


function statusReasonHomeDecor() {
    var a = Xrm.Page.ui.controls.get("statuscode");
    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (leadtype == 278290001) {
            a.removeOption("278290001");
            a.removeOption("278290002");
            a.removeOption("278290004");
            //  a.removeOption("278290006");
            a.removeOption("278290008");
            a.removeOption("278290009");
            a.removeOption("2");
            setVisibleSection("general", "dealerinfo", false);
            setVisibleSection("general", "Job_Value", false);
            setVisibleSection("general", "CC_WC", false);
            // setVisibleSection("general", "dealerinfo", false);

        }

    }
    else if (leadtype == null) {
        // setVisibleSection("general", "dealerinfo", false);
        setVisibleSection("general", "Job_Value", false);
        setVisibleSection("general", "CC_WC", false);
    }
}

/*function SetLeadTypeOnStReasonChange() {

var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
var ldtype = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption();
var ftype = Xrm.Page.ui.getFormType();

if (Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != null && Xrm.Page.getAttribute("ber_leadtype").getSelectedOption() != undefined) {
if (statuscodevalue == 278290015 || statuscodevalue == 4) {
if (Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290001) { // check if LBHP

ldtype.setValue(278290002);
statuscodevalue.setValue(1);
}

}

if (statuscodevalue == 278290019) {
if (Xrm.Page.getAttribute("ber_leadtype").getValue() == 278290002) { // check if LBHP

ldtype.setValue(278290001);
statuscodevalue.setValue(1);
}
}
}
}*/

function OnLoadStatusReasonHierarchy() {
    var b = Xrm.Page.ui.controls.get("statuscode");
    if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        // var leadtype = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text;
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (Xrm.Page.getAttribute("ber_returntopainterstage") != null && Xrm.Page.getAttribute("ber_returntopainterstage") != undefined) {
            var returntopainterstage = Xrm.Page.getAttribute("ber_returntopainterstage").getValue();
        }
        if (leadtype == 278290002) {
            //  var DifferedStatus = Xrm.Page.getAttribute("ber_differedstatus").getValue();
            var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
            switch (statuscodevalue) {
                case 278290007:
                    b.setDisabled(true);
                    b.removeOption("278290005");
                    b.removeOption("278290008");
                    b.removeOption("278290004");
                    b.removeOption("2");
                    b.removeOption("278290001");
                    b.removeOption("278290002");
                    b.removeOption("278290006");
                    b.removeOption("278290009");
                    b.removeOption("278290029");
                    b.removeOption("278290030");
                    b.removeOption("278290008");
                    b.removeOption("278290024");
                    b.removeOption("278290025");
                    b.removeOption("278290027");

                    if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null)
                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_estimatedpainter") != null)
                        Xrm.Page.ui.controls.get("ber_estimatedpainter").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_isestimategiven") != null)
                        Xrm.Page.ui.controls.get("ber_isestimategiven").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_preliminaryserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_serialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null
                        && Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null
                        && Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null) {

                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                    }

                    if (Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) {
                        if (UserHasRole(("Depot User") || ("Depot Home Decor User"))) {
                            setVisibleSection("general", "productdetails", false);
                        }
                    }

                    break;

                case 1:
                    b.setDisabled(true);

                    if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null)
                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_estimatedpainter") != null)
                        Xrm.Page.ui.controls.get("ber_estimatedpainter").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_isestimategiven") != null)
                        Xrm.Page.ui.controls.get("ber_isestimategiven").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_preliminaryserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);


                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_serialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null
                        && Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null
                    ) {

                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                    }


                    break;


                case 278290032:
                    b.setDisabled(true);

                    if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null)
                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);


                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null
                        && Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null
                    ) {

                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                    }

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.getAttribute("ber_nextvisitdate").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_serialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                    break;

                case 278290006:
                    b.setDisabled(true);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");

                    }
                    else {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);

                    }

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                    break;


                case 278290004:
                    b.setDisabled(true);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null)
                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");

                    }
                    else {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);

                    }
                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null) {

                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                    }

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_serialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);


                    break;

                case 278290009:
                    b.setDisabled(false);

                    b.removeOption("278290007");
                    b.removeOption("278290004");
                    b.removeOption("1");
                    b.removeOption("2");
                    b.removeOption("278290001");
                    // b.removeOption("278290009");
                    b.removeOption("278290002");
                    b.removeOption("278290006");
                    b.removeOption("278290029");
                    b.removeOption("278290030");
                    b.removeOption("278290008");
                    b.removeOption("278290024");
                    b.removeOption("278290025");
                    b.removeOption("278290027");
                    b.removeOption("278290032");

                    b.removeOption("278290026");
                    b.removeOption("278290005");
                    b.removeOption("278290004");

                    b.removeOption("278290028");

                    if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null)
                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
                    }
                    else {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);

                    }


                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null) {

                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                    }

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.getAttribute("ber_nextvisitdate").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null)
                        Xrm.Page.getAttribute("ber_quotationvalue").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_serialnumber") != null)
                        Xrm.Page.getAttribute("ber_serialnumber").setRequiredLevel("required");

                    break;

                case 278290026:
                    b.setDisabled(false);
                    b.removeOption("278290007");
                    b.removeOption("1");
                    b.removeOption("2");

                    b.removeOption("278290001");
                    b.removeOption("278290002");
                    b.removeOption("278290006");
                    if (returntopainterstage == false) {
                        b.removeOption("278290009");
                    }
                    else {

                    }
                    b.removeOption("278290029");
                    b.removeOption("278290030");
                    b.removeOption("278290028");
                    //b.removeOption("278290024");
                    b.removeOption("278290008");
                    b.removeOption("278290024");
                    b.removeOption("278290025");
                    b.removeOption("278290027");
                    b.removeOption("278290032");
                    b.removeOption("278290029");
                    b.removeOption("278290028");


                    if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {

                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");

                    }
                    else {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);
                    }
                    Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);
                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null) {

                        Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                    }

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.getAttribute("ber_nextvisitdate").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null)
                        Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                    if (Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) {
                        Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                    }


                    break;

                case 278290005:
                    b.setDisabled(false);
                    b.removeOption("278290007");
                    b.removeOption("1");
                    b.removeOption("2");
                    b.removeOption("278290004");
                    b.removeOption("278290001");
                    b.removeOption("278290002");
                    if (returntopainterstage != null) {
                        if (returntopainterstage == false) {
                            b.removeOption("278290009");
                        }

                        else {

                        }
                    }
                    else {

                    }

                    b.removeOption("278290008");
                    b.removeOption("278290029");
                    b.removeOption("278290030");
                    b.removeOption("278290028");
                    b.removeOption("278290024");
                    b.removeOption("278290025");
                    b.removeOption("278290027");
                    b.removeOption("278290032");
                    b.removeOption("278290029");
                    b.removeOption("278290028");

                    if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");

                    }
                    else {
                        if (Xrm.Page.ui.controls.get("ber_whowill") != null)
                            Xrm.Page.ui.controls.get("ber_whowill").setDisabled(true);

                    }


                    if (Xrm.Page.ui.controls.get("ber_insurancerequired") != null)
                        Xrm.Page.ui.controls.get("ber_insurancerequired").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                        Xrm.Page.ui.controls.get("ber_workorder").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);

                    if (Xrm.Page.ui.controls.get("ber_ilabourcost") != null)
                        Xrm.Page.getAttribute("ber_ilabourcost").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_imaterialcost") != null)
                        Xrm.Page.getAttribute("ber_imaterialcost").setRequiredLevel("required");

                    if (Xrm.Page.ui.controls.get("ber_elabourcost") != null)
                        Xrm.Page.getAttribute("ber_elabourcost").setRequiredLevel("required");


            }
        }
        else {
            if (leadtype == 278290001) {
                var b = Xrm.Page.ui.controls.get("statuscode");
                var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
                switch (statuscodevalue) {
                    case 278290007:
                        Xrm.Page.getControl("statuscode").setDisabled(true);
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);
                        b.removeOption("278290005");
                        b.removeOption("278290008");
                        b.removeOption("278290004");
                        b.removeOption("2");
                        b.removeOption("278290001");
                        b.removeOption("278290002");
                        b.removeOption("278290006");
                        b.removeOption("278290009");
                        b.removeOption("278290032");
                        b.removeOption("278290029");
                        b.removeOption("278290028");

                        if (Xrm.Page.ui.controls.get("ber_estimatedpainter") != null) Xrm.Page.ui.controls.get("ber_estimatedpainter").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_isestimategiven") != null) Xrm.Page.ui.controls.get("ber_isestimategiven").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null) Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_preliminaryserialnumber") != null) Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null) {

                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }

                        if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null) Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_serialnumber") != null) Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null) Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null) Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);
                        break;

                    case 1:


                        if (Xrm.Page.getControl("statuscode") != null) Xrm.Page.getControl("statuscode").setDisabled(true);
                        if (Xrm.Page.getAttribute("statuscode") != null) Xrm.Page.getAttribute("statuscode").setValue(1);
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);
                        if (Xrm.Page.getAttribute("statuscode") != null) Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
                        if (Xrm.Page.getControl("statuscode") != null) Xrm.Page.getControl("statuscode").setDisabled(true);


                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) {

                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }

                        if (Xrm.Page.ui.controls.get("ber_estimatedpainter") != null) Xrm.Page.ui.controls.get("ber_estimatedpainter").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_isestimategiven") != null) Xrm.Page.ui.controls.get("ber_isestimategiven").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpserialnumber") != null) Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_preliminaryserialnumber") != null) Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null) Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_serialnumber") != null) Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpquotationvalue") != null) Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber") != null) Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setVisible(false);

                        break;


                    case 278290032:

                        Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);
                        Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
                        Xrm.Page.getControl("statuscode").setDisabled(true);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) {

                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }

                        if (Xrm.Page.getAttribute("ber_nextvisitdate") != null) Xrm.Page.getAttribute("ber_nextvisitdate").setRequiredLevel("required");
                        if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null) Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);
                        if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null) Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_preliminaryserialnumber") != null) Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_serialnumber") != null) Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);
                        if (Xrm.Page.getAttribute("ber_lbhpquotationvalue") != null) Xrm.Page.getAttribute("ber_lbhpquotationvalue").setRequiredLevel("required");
                        if (Xrm.Page.getAttribute("ber_lbhpquotationserialnumber") != null) Xrm.Page.getAttribute("ber_lbhpquotationserialnumber").setRequiredLevel("required");




                        break;



                    case 278290026:

                        if (Xrm.Page.getControl("statuscode") != null) Xrm.Page.getControl("statuscode").setDisabled(true);
                        b.removeOption("278290007");
                        b.removeOption("1");
                        b.removeOption("278290030");
                        b.removeOption("278290008");
                        b.removeOption("278290004");
                        b.removeOption("278290009");
                        b.removeOption("2");
                        b.removeOption("278290001");
                        b.removeOption("278290002");
                        b.removeOption("278290006");
                        b.removeOption("278290029");

                        b.removeOption("278290028");
                        b.removeOption("278290032");

                        b.removeOption("278290006");
                        if (Xrm.Page.getAttribute("ber_whowill") != null) Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) {

                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }


                        if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                        if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                        if (Xrm.Page.ui.controls.get("ber_quotationvalue") != null) Xrm.Page.ui.controls.get("ber_quotationvalue").setVisible(false);
                        if (Xrm.Page.ui.controls.get("ber_serialnumber") != null) Xrm.Page.ui.controls.get("ber_serialnumber").setVisible(false);
                        if (Xrm.Page.getAttribute("ber_quotationvalue") != null) Xrm.Page.getAttribute("ber_quotationvalue").setRequiredLevel("none");
                        if (Xrm.Page.getAttribute("ber_serialnumber") != null) Xrm.Page.getAttribute("ber_serialnumber").setRequiredLevel("none");
                        if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null) Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);


                        break;




                    case 278290005:

                        Xrm.Page.getControl("statuscode").setDisabled(false);
                        b.removeOption("278290007");
                        b.removeOption("1");
                        b.removeOption("278290008");
                        b.removeOption("278290004");
                        b.removeOption("2");
                        b.removeOption("278290001");
                        b.removeOption("278290002");
                        b.removeOption("278290029");
                        b.removeOption("278290028");
                        b.removeOption("278290030");
                        b.removeOption("278290024");
                        b.removeOption("278290025");
                        b.removeOption("278290027");
                        if (Xrm.Page.getAttribute("ber_whowill") != null) Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct")) {
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false); //leadproduct
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false); //leadprod
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }



                        if (Xrm.Page.ui.controls.get("ber_workorder") != null)
                            Xrm.Page.ui.controls.get("ber_workorder").setVisible(true);

                        if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null) Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                        if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                        if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                        if (Xrm.Page.getControl("ber_totaljobvalue") != null) Xrm.Page.getControl("ber_totaljobvalue").setDisabled(true);
                        if (Xrm.Page.getControl("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getControl("ber_totalmaterialconsumedvalue").setDisabled(true);
                        if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                        if (Xrm.Page.getAttribute("ber_enddate") != null) Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                        if (Xrm.Page.getControl("ber_enddate") != null) Xrm.Page.getControl("ber_enddate").setDisabled(true);
                        if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null) Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                        break;

                    case 278290006:

                        Xrm.Page.getControl("statuscode").setDisabled(true);
                        b.removeOption("278290007");
                        b.removeOption("1");
                        b.removeOption("278290008");
                        b.removeOption("278290004");
                        b.removeOption("2");
                        b.removeOption("278290001");
                        b.removeOption("278290002");
                        b.removeOption("278290024");
                        b.removeOption("278290025");
                        b.removeOption("278290027");
                        b.removeOption("278290029");
                        b.removeOption("278290028");
                        b.removeOption("278290030");

                        if (Xrm.Page.getAttribute("ber_whowill") != null) Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct")) {

                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false); //leadproduct
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false); //leadproduct
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }



                        if (Xrm.Page.ui.controls.get("ber_nextvisitdate") != null) Xrm.Page.ui.controls.get("ber_nextvisitdate").setVisible(true);

                        break;


                    case 278290010:

                        if (Xrm.Page.getControl("statuscode") != null) Xrm.Page.getControl("statuscode").setDisabled(true);

                        b.removeOption("278290007");
                        b.removeOption("1");
                        b.removeOption("278290005");
                        b.removeOption("278290008");
                        b.removeOption("278290004");
                        b.removeOption("2");
                        b.removeOption("278290001");
                        b.removeOption("278290002");
                        b.removeOption("278290006");
                        b.removeOption("278290029");
                        b.removeOption("278290024");
                        b.removeOption("278290025");
                        b.removeOption("278290027");
                        b.removeOption("278290026");

                        b.removeOption("278290028");
                        b.removeOption("278290030");


                        if (Xrm.Page.getAttribute("ber_whowill") != null) Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");
                        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);

                        if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null &&
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct")) {

                            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false); //leadproduct
                            Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false); //leadproduct
                            Xrm.Page.ui.tabs.get("general").sections.get("leadproduct").setVisible(true);
                            Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                        }


                        if (Xrm.Page.ui.controls.get("ber_totaljobvalue") != null) Xrm.Page.ui.controls.get("ber_totaljobvalue").setVisible(true);
                        if (Xrm.Page.getControl("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getControl("ber_totalmaterialconsumedvalue").setDisabled(true);
                        if (Xrm.Page.getControl("ber_totaljobvalue") != null) Xrm.Page.getControl("ber_totaljobvalue").setDisabled(false);
                        if (Xrm.Page.getControl("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getControl("ber_totalmaterialconsumedvalue").setDisabled(false);
                        if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                        if (Xrm.Page.getAttribute("ber_enddate") != null) Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");
                        if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("required");


                        break;
                }
            }
        }
    }
    else {
        b.setDisabled(true);
        if (Xrm.Page.ui.controls.get("ber_returntopainterstage") != null) Xrm.Page.ui.controls.get("ber_returntopainterstage").setVisible(false);
        if (Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(false);
    }
}

function FillDealerAndDepot() {

    var depot = Xrm.Page.getAttribute("ber_depotid");
    var dealerName = Xrm.Page.getAttribute("ber_dealerid");
    if ((depot == null && depot == undefined) || (dealerName == null && dealerName == undefined)) {
        if (Xrm.Page.getAttribute("ber_masterpainterid") != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != "") {
            var PainterId = Xrm.Page.getAttribute("ber_masterpainterid").getValue()[0].id;

            var columns = ['ber_DepotId', 'ber_DealerId'];
            var filter = "ContactId eq guid'" + PainterId + "'";


            var collection = CrmRestKit.RetrieveMultiple('Contact', columns, filter);
            if (collection != null && collection.results != null && collection.results[0] != null) {

                var depoName = null;
                if (collection.results[0].ber_DepotId != null && collection.results[0].ber_DepotId.Id != null) {
                    var depo = new Array();
                    depo[0] = new Object();
                    depo[0].id = collection.results[0].ber_DepotId.Id;
                    depo[0].name = collection.results[0].ber_DepotId.Name;
                    depo[0].entityType = collection.results[0].ber_DepotId.LogicalName;
                    Xrm.Page.getAttribute("ber_depotid").setValue(depo);
                    depoName = depo[0].name;
                } else {
                    //Xrm.Page.getAttribute("ber_depotid").setValue(null);
                    //Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("required");
                }

                if (collection.results[0].ber_DealerId != null && collection.results[0].ber_DealerId.Id != null) {

                    var dealer = new Array();
                    dealer[0] = new Object();
                    dealer[0].id = collection.results[0].ber_DealerId.Id;
                    dealer[0].name = collection.results[0].ber_DealerId.Name;
                    dealer[0].entityType = collection.results[0].ber_DealerId.LogicalName;
                    Xrm.Page.getAttribute("ber_dealerid").setValue(dealer);
                } else {
                    //Xrm.Page.getAttribute("ber_associatedtsiid").setValue(null);
                    //Xrm.Page.getAttribute("ber_associatedtsiid").setRequiredLevel("required");
                }
            }
        }
    }
}

//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

//Function to compare start and end dates under product details section
function startenddateCompare() {
    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
    var status = Xrm.Page.getAttribute("statuscode");
    if (leadtype == 278290002 && status !== null && status.getValue() == 2) {
        if (Xrm.Page.getAttribute("ber_startdate") != null && Xrm.Page.getAttribute("ber_enddate") != null) {
            var startdate = Xrm.Page.getAttribute("ber_startdate").getValue();
            var enddate = Xrm.Page.getAttribute("ber_enddate").getValue();
            if (startdate > enddate) {
                alert("Start date should not be greater than end date");
                Xrm.Page.getAttribute("ber_startdate").setValue(null);
                Xrm.Page.getAttribute("ber_enddate").setValue(null);
                return false;
            }
        }
    }
}
// Function to change status if callInfo is inbound.
// date:11-7-2015
function SetStatusOnChangeOfCallInfo() {
    var type = Xrm.Page.ui.getFormType();
    if (type == 1) {
        if (Xrm.Page.getAttribute("ber_callinfo") !== null && Xrm.Page.getAttribute("ber_callinfo") !== undefined) {
            if (Xrm.Page.getAttribute("ber_callinfo") !== null && Xrm.Page.getAttribute("ber_callinfo") !== undefined) {
                var callinfo = Xrm.Page.getAttribute("ber_callinfo").getValue();
                if (callinfo == '278290000' || callinfo == '278290010') {
                    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
                        Xrm.Page.getAttribute("statuscode").setValue("1");
                    }
                } else {
                    Xrm.Page.getAttribute("statuscode").setValue("278290007");
                }
            }
        }
    }
}



function OnSaveValidation(executionObj) {

    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode");
        if (status.getValue() == 1) {
            var interior = Xrm.Page.getAttribute("ber_interior").getValue();
            var exterior = Xrm.Page.getAttribute("ber_exterior").getValue();

            if (interior == 0 && exterior == 0) {
                if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
                    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (leadtype !== null) {
                        if (leadtype == 278290002) {
                            var event = executionObj.getEventArgs();
                            alert("Unable to save because neither interior nor exterior is selected.");
                            Xrm.Page.ui.controls.get("ber_interior").setFocus();
                            //executionObj.getEventArgs().preventDefault();
                            event.preventDefault();
                        }
                    }
                }

            }

        }
    }
}
function OnLoadSetSelectionCriteria() {
    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        if (status == '1') {
            if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
                var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
                if (leadtype !== null) {
                    if (leadtype == 278290002) {
                        if (Xrm.Page.getAttribute("ber_dealerselectioncriteria") != null && Xrm.Page.getAttribute("ber_dealerselectioncriteria") != undefined) {
                            var dealerselectioncriteria = Xrm.Page.getAttribute("ber_dealerselectioncriteria").getValue();
                            if (dealerselectioncriteria != null) {
                                switch (dealerselectioncriteria) {
                                    case 278290000:
                                        Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                                        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
                                        Xrm.Page.getAttribute("ber_dealername").setRequiredLevel("none");
                                        break;

                                    case 278290001:
                                        Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                                        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                                        Xrm.Page.getAttribute("ber_dealername").setRequiredLevel("required");
                                        break;

                                    case 278290002:
                                        Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                                        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                                        Xrm.Page.getAttribute("ber_dealername").setRequiredLevel("none");
                                        break;
                                }

                            } else {
                                Xrm.Page.getAttribute("ber_dealerselectioncriteria").setValue(278290000);
                                Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                                Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
                                Xrm.Page.getAttribute("ber_dealername").setRequiredLevel("none");
                            }
                        }
                    }
                }
            }

        }

    }
}

function SetStatusOnChangeOfDealer() {
    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode");
        if (status.getValue() == 278290032) {
            Xrm.Page.getAttribute("statuscode").setValue(278290004);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
        }
    }

}

function CopyOriganlAppointment() {
    if (Xrm.Page.getAttribute("ber_orignalappointment").getValue() == null) {
        var appointmentdate = Xrm.Page.getAttribute("ber_appointmentdate").getValue();
        Xrm.Page.getAttribute("ber_orignalappointment").setValue(appointmentdate);
        Xrm.Page.getAttribute("ber_orignalappointment").setSubmitMode("always");
    }
}


function ValidatePainter() {
    if (Xrm.Page.getAttribute("ber_masterpainterid") != null) {
        if (Xrm.Page.getAttribute("ber_masterpainterid").getValue() != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != undefined) {
            var painter = Xrm.Page.getAttribute("ber_masterpainterid").getValue()[0].id;
            var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                '<entity name="contact">' +
                '<attribute name="contactid" />' +
                '<attribute name="ber_epstatus" />' +
                '<order attribute="ber_epstatus" descending="false" />' +
                '<link-entity name="lead" from="ber_masterpainterid" to="contactid" alias="aa">' +
                '<filter type="and">' +

                '<condition attribute="ber_masterpainterid" operator="eq" value="' + painter + '" />' +
                '</filter>' +
                '</link-entity>' +

                '</entity>' +
                '</fetch>';

            var retrievedPainterStatus = XrmServiceToolkit.Soap.Fetch(fetchxml);
            if (retrievedPainterStatus.length > 0) {
                if (retrievedPainterStatus[0].attributes.ber_epstatus != null && retrievedPainterStatus[0].attributes.ber_epstatus != undefined) {
                    if (retrievedPainterStatus[0].attributes.ber_epstatus.formattedValue == "No" || retrievedPainterStatus[0].attributes.ber_epstatus == null || retrievedPainterStatus[0].attributes.ber_epstatus == undefined) {
                        addNotification('Selected Painter is NON XP', 1);
                    }
                }


            }
        }
    }
}

function addNotification(message, level) {

    if (level == 1) { //NON XP 
        Xrm.Page.ui.setFormNotification(message, "error");
    }

}


function SetRSM() {
    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        var depot = Xrm.Page.getAttribute("ber_depotid").getValue();
        if (depot != null && depot != undefined) {
            var depotId = depot[0].id;
            depotId = depotId.replace("{", "");
            depotId = depotId.replace("}", "");
            var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                '<entity name="ber_region">' +
                '<attribute name="ber_regionid" />' +
                '<attribute name="ber_rsm" />' +
                '<link-entity name="ber_depot" from="ber_region" to="ber_regionid" alias="aa">' +
                '<filter type="and">' +
                '<condition attribute="ber_depotid" operator="eq" value="' + depotId + '" />' +
                '</filter>' +
                '</link-entity>' +
                '</entity>' +
                '</fetch>';

            var retrieversm = XrmServiceToolkit.Soap.Fetch(fetchxml);
            if (retrieversm.length > 0) {

                var RSMArray = new Array();
                RSMArray[0] = new Object();
                RSMArray[0].id = retrieversm[0].attributes.ber_rsm.id;
                RSMArray[0].name = retrieversm[0].attributes.ber_rsm.name;
                RSMArray[0].entityType = retrieversm[0].attributes.ber_rsm.logicalName;

                if (Xrm.Page.getAttribute("ber_rsmid") != null) {
                    Xrm.Page.getAttribute("ber_rsmid").setValue(RSMArray);
                    Xrm.Page.getAttribute("ber_rsmid").setSubmitMode("always");
                }
            }
        }
    }
}

function SetCityAndState() {
    if (Xrm.Page.getAttribute("ber_pincodeid") != null) {
        var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
        if (pinCodeId != null) {
            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {
                var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="ber_pincode">' +
                    '<attribute name="ber_pincodeid" />' +
                    '<attribute name="ber_cityid" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_pincodeid" operator="eq" value="' + _pinCode + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                var retrievedCity = XrmServiceToolkit.Soap.Fetch(fetchxml);
                if (retrievedCity.length > 0) {
                    var CityArray = new Array();
                    CityArray[0] = new Object();
                    CityArray[0].id = retrievedCity[0].attributes.ber_cityid.id;
                    CityArray[0].name = retrievedCity[0].attributes.ber_cityid.name;
                    CityArray[0].entityType = retrievedCity[0].attributes.ber_cityid.logicalName;
                    Xrm.Page.getAttribute("ber_cityid").setValue(CityArray);
                    Xrm.Page.getAttribute("ber_cityid").setSubmitMode("always");
                }

                if (retrievedCity[0].attributes.ber_cityid != null) {
                    var CityId = retrievedCity[0].attributes.ber_cityid.id;
                    var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="ber_city">' +
                        '<attribute name="ber_cityid" />' +
                        '<attribute name="ber_citytype" />' +
                        '<attribute name="ber_stateid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" value="' + CityId + '" />' +
                        '</filter>' +
                        '</entity>' +
                        '</fetch>';
                    var retrieveState = XrmServiceToolkit.Soap.Fetch(fetchxml);
                    if (retrieveState.length > 0) {
                        var StateArray = new Array();
                        StateArray[0] = new Object();
                        StateArray[0].id = retrieveState[0].attributes.ber_stateid.id;
                        StateArray[0].name = retrieveState[0].attributes.ber_stateid.name
                        StateArray[0].entityType = retrieveState[0].attributes.ber_stateid.logicalName
                        Xrm.Page.getAttribute("ber_stateid").setValue(StateArray);
                        Xrm.Page.getAttribute("ber_stateid").setSubmitMode("always");
                    }
                }
            }
        }
    }
}

function SetStateAndCountry() {
    if (Xrm.Page.getAttribute("ber_pincodeid") != null) {
        var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
        var x = "0";
        if (pinCodeId != null) {
            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {
                var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="ber_pincode">' +
                    '<attribute name="ber_pincodeid" />' +
                    '<attribute name="ber_cityid" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_pincodeid" operator="eq" value="' + _pinCode + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';

                var retrievedCity = XrmServiceToolkit.Soap.Fetch(fetchxml);
                if (retrievedCity.length > 0) {
                    var CityArray = new Array();
                    CityArray[0] = new Object();
                    CityArray[0].id = retrievedCity[0].attributes.ber_cityid.id;
                    CityArray[0].name = retrievedCity[0].attributes.ber_cityid.name;
                    CityArray[0].entityType = retrievedCity[0].attributes.ber_cityid.logicalName;
                    Xrm.Page.getAttribute("ber_cityid").setValue(CityArray);
                    Xrm.Page.getAttribute("ber_cityid").setSubmitMode("always");




                }

                if (retrievedCity[0].attributes.ber_cityid != null) {
                    var CityId = retrievedCity[0].attributes.ber_cityid.id;
                    var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="ber_city">' +
                        '<attribute name="ber_cityid" />' +
                        '<attribute name="ber_citytype" />' +
                        '<attribute name="ber_stateid" />' +
                        '<attribute name="ber_ischargeable" />' +
                        '<attribute name="ber_applicablecost" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" value="' + CityId + '" />' +
                        '</filter>' +
                        '</entity>' +
                        '</fetch>';
                    var retrieveState = XrmServiceToolkit.Soap.Fetch(fetchxml);
                    if (retrieveState.length > 0) {
                        var StateArray = new Array();
                        StateArray[0] = new Object();
                        StateArray[0].id = retrieveState[0].attributes.ber_stateid.id;
                        StateArray[0].name = retrieveState[0].attributes.ber_stateid.name
                        StateArray[0].entityType = retrieveState[0].attributes.ber_stateid.logicalName
                        // alert(retrieveState[0].attributes.ber_ischargeable);
                        if (Xrm.Page.getAttribute("ber_lockedforad").getValue() != null && Xrm.Page.getAttribute("ber_lockedforad") != undefined) {
                            var LockedforAD = Xrm.Page.getAttribute("ber_lockedforad").getValue();

                            if (LockedforAD == 'Yes') {
                                if (retrieveState[0].attributes.ber_ischargeable != undefined && retrieveState[0].attributes.ber_ischargeable != null) {
                                    alert("Service for this city is chargeable");

                                    var IsChargeable = retrieveState[0].attributes.ber_ischargeable.formattedValue;
                                    Xrm.Page.getAttribute("ber_ischargeable").setValue(IsChargeable);
                                    Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");


                                    if (retrieveState[0].attributes.ber_applicablecost != undefined && retrieveState[0].attributes.ber_applicablecost != null) {

                                        var Cost = retrieveState[0].attributes.ber_applicablecost.formattedValue;
                                        Xrm.Page.getAttribute("ber_servicecost").setValue(Cost);
                                        Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                    }

                                    else {

                                        Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                        Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                        Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                        Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                    }


                                }
                                else {

                                    Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                    Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                    Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                    Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                }

                            }
                            else {
                                var x = "0";
                                Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                            }

                        }

                        Xrm.Page.getAttribute("ber_stateid").setValue(StateArray);
                        Xrm.Page.getAttribute("ber_stateid").setSubmitMode("always");



                        //added by soumen
                        if (retrieveState[0].attributes.ber_citytype != null && retrieveState[0].attributes.ber_citytype != 'undefined') {

                            var cityType = retrieveState[0].attributes.ber_citytype.value;
                            if (cityType == 278290002) {
                                Xrm.Page.getAttribute("address1_line3").setValue("XP");
                            }

                            if (cityType == 278290001) {
                                Xrm.Page.getAttribute("address1_line3").setValue("Home Decor");
                            }

                            if (cityType == 278290000) {
                                Xrm.Page.getAttribute("address1_line3").setValue("BDM");
                            }

                        }

                        OnCityChange();

                        filterDGByDefaultDepot();

                        filterHDByDefaultDepot();

                        FilteredTSI();

                       

                        if (Xrm.Page.getAttribute("ber_subleadtype") != undefined && Xrm.Page.getAttribute("ber_subleadtype") != null) {
                            var SubLeadType = Xrm.Page.getAttribute("ber_subleadtype").getValue();

                       }


                        if (_depotId != null && SubLeadType != '278290002') {

                            filterXPAByDefaultDepot();


                        }
                        

                        else if (_depotId != null && SubLeadType == '278290002') {

                            MMPainterview();
                        }

                       

                    }
                }

            }
        }
        else {
            if (Xrm.Page.getAttribute("ber_cityid") != null) {
                Xrm.Page.getAttribute("ber_cityid").setValue(null);
                Xrm.Page.getAttribute("ber_cityid").setSubmitMode("always");
            }

            if (Xrm.Page.getAttribute("ber_stateid") != null) {
                Xrm.Page.getAttribute("ber_stateid").setValue(null);
                Xrm.Page.getAttribute("ber_stateid").setSubmitMode("always");
            }
        }
    }
}

function DisablePainterOnDealer() {
    if (Xrm.Page.getAttribute("ber_dealerid") != undefined || Xrm.Page.getAttribute("ber_dealerid") != null) {
        var Dealer = Xrm.Page.getAttribute("ber_dealerid").getValue();
        if (Dealer != null) {
            Xrm.Page.getControl("ber_masterpainterid").setDisabled(false);
        } else {
            Xrm.Page.getControl("ber_masterpainterid").setDisabled(true);
        }
    }
}

function HideShowEscalationFeild() {
    if (Xrm.Page.getAttribute("ber_jobstatuschecked") != undefined || Xrm.Page.getAttribute("ber_jobstatuschecked") != null) {
        var jobstatus = Xrm.Page.getAttribute("ber_jobstatuschecked").getValue();
        if (jobstatus == 0) {
            Xrm.Page.getControl("ber_isjobincomplete").setVisible(false);
            Xrm.Page.getAttribute("ber_isjobincomplete").setRequiredLevel("none");
        } else {
            if (jobstatus == 1) {
                Xrm.Page.getControl("ber_isjobincomplete").setVisible(true);
                Xrm.Page.getAttribute("ber_isjobincomplete").setRequiredLevel("required");
            }
        }
    }
}














///////////////////////////////////////////////////////////////

function Taketime() {

    var today = new Date();
    // var Count = 0;
    var dateFormate_capturueddate

    //  var Year1 = today.getFullYear();
    //  var Month1 = today.getMonth() + 1;
    var Day1 = today.getDate();
    //   var dateFormate_today = Day1 + "-" + Month1 + "-" + Year1;
    //  dateFormate_today = new Date(Year1, Month1, Day1).getDate();

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
    if (Xrm.Page.data.entity.attributes.get("ber_leadtype").getValue() != null && Xrm.Page.data.entity.attributes.get("ber_leadtype") != undefined) {
        var LeadType = Xrm.Page.data.entity.attributes.get("ber_leadtype").getValue();
    }
    var DateCapture = Xrm.Page.data.entity.attributes.get("ber_attemptstoclosedate").getValue();

    if ((DateCapture != null) || (DateCapture != undefined)) {
        // var Year = DateCapture.getFullYear();
        // var Month = DateCapture.getMonth();
        var Day2 = DateCapture.getDate();
        //  dateFormate_capturueddate = Day + "-" + Month + "-" + Year;
        // dateFormate_capturueddate = new Date(Year, Month, Day).getDate();
        //dateFormate_capturueddate.getDate()
    }

    var Count = Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").getValue();

    var Description = Xrm.Page.data.entity.attributes.get("description").getValue();

    if ((StatusReason == 278290007) && (DateCapture == null) || (DateCapture != undefined) && (Count == null)) {
        Count = 1;

        Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").setValue(Count);
        Xrm.Page.data.entity.attributes.get("ber_attemptstoclosedate").setValue(new Date());
        Xrm.Page.data.entity.attributes.get("ber_attemptstoclosedate").setSubmitMode("always");
        Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").setSubmitMode("always");

    }


    else if ((StatusReason == 278290007) && (Count != null) && (DateCapture != null) || (DateCapture != undefined)) {
        {
            // if (dateFormate_today > dateFormate_capturueddate) {
            if (Day1 > Day2) {
                Count++;


                Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").setValue(Count);
                Xrm.Page.data.entity.attributes.get("ber_attemptstoclosedate").setValue(new Date());
                Xrm.Page.data.entity.attributes.get("ber_attemptstoclosedate").setSubmitMode("always");
                Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").setSubmitMode("always");

                Xrm.Page.data.entity.attributes.get("ber_customerintimation").setValue(0);
                Xrm.Page.data.entity.attributes.get("ber_customerintimation").setSubmitMode("always");
            }
        }
    }


}


/////////     Set Customer Intimation as Yes


function SetCustomerIntimation() {
    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    if (Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").getValue() != null && Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount") != undefined) {
        var Count = Xrm.Page.data.entity.attributes.get("ber_attemptstoclosecount").getValue();
    }

    //if (Xrm.Page.data.entity.attributes.get("ber_customerintreasted").getValue() != null && Xrm.Page.data.entity.attributes.get("ber_customerintreasted") != undefined) {
    //   var CustomerInterested = Xrm.Page.data.entity.attributes.get("ber_customerintreasted").getValue();
    // }

    if ((StatusReason == 278290007) && (Count == 2)) {
        Xrm.Page.data.entity.attributes.get("ber_customerintreasted").setValue(0);
        Xrm.Page.data.entity.attributes.get("ber_customerintreasted").setSubmitMode("always");
    }
    var CustomerInterested = Xrm.Page.data.entity.attributes.get("ber_customerintreasted").getValue();
    //  alert(CustomerInterested);

}



function SetAppointmentMandatory() {
    if (Xrm.Page.getAttribute("ber_leadtype") != null) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        var AppointmentDate = Xrm.Page.data.entity.attributes.get("ber_appointmentdate").getValue();

        if (StatusReason == 278290024 || StatusReason == 278290025 || StatusReason == 278290026) {
            setVisibleSection("general", "productdetails", true);
            //  Xrm.Page.getAttribute("ber_appointmentdate").setValue(null);
            Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("required");
        }

        else if (StatusReason == 278290027) {
            setVisibleSection("general", "productdetails", true);
            Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_appointmentdate").setValue(null);
            //Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_appointmentdate").setSubmitMode("always");
        }

        else {

            // Do nothing

        }

    }
}








function CaptureNewDate() {

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
    var NewDate = Xrm.Page.data.entity.attributes.get("ber_newdate").getValue();
    var today;
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (!isCrmForMobile)
        var today = getServerTime();
    else
        var today = new Date();
    if (StatusReason == 1 && NewDate == null) {
        Xrm.Page.data.entity.attributes.get("ber_newdate").setValue(today);

    }

    else {



    }


}






function PainterRating_Nonmandatory() {

    var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();

    var NewDate = Xrm.Page.data.entity.attributes.get("leadqualitycode").getValue();

    if (StatusReason == 278290007) {

        Xrm.Page.getAttribute("leadqualitycode").setRequiredLevel("none");

    }

    else {

        // Do Nothing

    }

} // JScript source code







function FollowUpsetnull() {

    if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null) {
        var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (b != null) {
            if (b == 278290002) {
                if (statuscodevalue == 278290005) {
                    Xrm.Page.getAttribute("ber_startdate").setValue(null);
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_startdate").setSubmitMode("always");
                    Xrm.Page.getAttribute("ber_enddate").setValue(null);
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");
                    Xrm.Page.getAttribute("ber_enddate").setSubmitMode("always");

                }

                else {

                }
            }


        }
    }
}






function filterDGByDefaultDepot() {

    if (Xrm.Page.getAttribute("ber_depotid") != null) {
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        if (Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined) {
            var submitMode = "always";
            var city = Xrm.Page.getAttribute("ber_cityid").getValue();
            if (city != null && city != undefined) {
                var cityId = city[0].id;
                var d = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                d += "<entity name = 'ber_city'>";
                d += "<attribute name = 'ber_citytype'/>";
                d += "<attribute name = 'ber_defaultdepotid'/>";
                d += "<attribute name = 'ber_openjobs'/>";
                d += "<attribute name = 'ber_maxjobs'/>";
                d += "<filter type = 'and'>";
                d += "<condition attribute='ber_cityid' value ='";
                d += cityId;
                d += "' operator = 'eq'/>";
                d += "</filter>";
                d += "</entity>";
                d += "</fetch>";
                var fetchData = XrmServiceToolkit.Soap.Fetch(d);
                if (fetchData[0].attributes['ber_defaultdepotid'] !== null && fetchData[0].attributes['ber_defaultdepotid'] !== undefined) {
                    var defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
                    var defaultdepotid = fetchData[0].attributes["ber_defaultdepotid"].id;
                    var defaultdepotlogicalname = fetchData[0].attributes["ber_defaultdepotid"].logicalName;
                    Xrm.Page.getAttribute("ber_depotid").setValue([{
                        id: defaultdepotid,
                        name: defaultdepotname,
                        entityType: defaultdepotlogicalname
                    }]);

                }


            }
        }
    }

    //document.getElementById("ber_dgcontact").disableViewPicker = 0;
    $("#ber_dgcontact").find("img").attr("disableviewpicker", "0");

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
            if (_depotId != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered DG and HD employee by Default depot";
                //var view_DGId = GetuniqueGuid();
                var dgViewId = "{00000000-0000-0000-00AA-000010001007}";
                //var view_DGId = Xrm.Page.getControl("ber_dgcontact").getDefaultView();
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="contactid" select="1" icon="2" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="ber_bdterritory" width="100" />' +
                    '<cell name="ber_cemonthlyleadlimit" width="150" />' +
                    '<cell name="fullname" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_customertype" width="100" />' +
                    '<cell name="ownerid" width="150" />' +
                    '</row>' +
                    '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                    '<entity name="contact">' +
                    '<attribute name="ber_bdterritory" />' +
                    '<attribute name="ber_cemonthlyleadlimit" />' +
                    '<attribute name="fullname" />' +
                    '<attribute name="mobilephone" />' +
                    '<attribute name="contactid" />' +
                    '<attribute name="ownerid" />' +
                    '<attribute name="ber_customertype" />' +

                    '<order attribute="fullname" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_customertype" operator="in">' +
                    '<value>278290005</value>' +
                    '<value>278290012</value>' +
                    '<value>278290006</value>' +
                    '</condition>' +
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '<condition attribute="ber_bdterritory" operator="not-null" />' +
                    '<filter type="or">' +
                    '<condition attribute="ber_cemonthlyleadlimit" operator="le" value="500" />' +
                    '<condition attribute="ber_cemonthlyleadlimit" operator="null" />' +
                    '</filter>' +
                    '<condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="' + defaultdepotid + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';

                if (Xrm.Page.ui.controls.get("ber_dgcontact") != null) {
                    Xrm.Page.ui.controls.get("ber_dgcontact").addCustomView(dgViewId, "contact", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                    Xrm.Page.ui.controls.get("ber_dgcontact").setDefaultView(dgViewId);
                }

                $("#ber_dgcontact").find("img").attr("disableviewpicker", "1");
            }
        }
    }

}








function filterHDByDefaultDepot() {

    if (Xrm.Page.getAttribute("ber_depotid") != null) {
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        if (Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined) {
            var submitMode = "always";
            var city = Xrm.Page.getAttribute("ber_cityid").getValue();
            if (city != null && city != undefined) {
                var cityId = city[0].id;
                var d = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                d += "<entity name = 'ber_city'>";
                d += "<attribute name = 'ber_citytype'/>";
                d += "<attribute name = 'ber_defaultdepotid'/>";
                d += "<attribute name = 'ber_openjobs'/>";
                d += "<attribute name = 'ber_maxjobs'/>";
                d += "<filter type = 'and'>";
                d += "<condition attribute='ber_cityid' value ='";
                d += cityId;
                d += "' operator = 'eq'/>";
                d += "</filter>";
                d += "</entity>";
                d += "</fetch>";
                var fetchData = XrmServiceToolkit.Soap.Fetch(d);
                if (fetchData[0].attributes['ber_defaultdepotid'] !== null && fetchData[0].attributes['ber_defaultdepotid'] !== undefined) {
                    var defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
                    var defaultdepotid = fetchData[0].attributes["ber_defaultdepotid"].id;
                    var defaultdepotlogicalname = fetchData[0].attributes["ber_defaultdepotid"].logicalName;
                    Xrm.Page.getAttribute("ber_depotid").setValue([{
                        id: defaultdepotid,
                        name: defaultdepotname,
                        entityType: defaultdepotlogicalname
                    }]);

                }


            }
        }
    }
    //document.getElementById("ber_hdemployeeid").disableViewPicker = 0;
    $("#ber_hdemployeeid").find("img").attr("disableviewpicker", "0");

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
            if (_depotId != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered DG and HD employee by Default depot";
                //var view_DGId = GetuniqueGuid();
                // var view_DGId = Xrm.Page.getControl("ber_hdemployeeid").getDefaultView();
                var hdViewId = "{00000000-0000-0000-00AA-000010001007}";
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="contactid" select="1" icon="2" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="ber_bdterritory" width="100" />' +
                    '<cell name="fullname" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_customertype" width="100" />' +
                    '<cell name="ownerid" width="150" />' +
                    '</row>' +
                    '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                    '<entity name="contact">' +
                    '<attribute name="ber_bdterritory" />' +
                    '<attribute name="fullname" />' +
                    '<attribute name="mobilephone" />' +
                    '<attribute name="contactid" />' +
                    '<attribute name="ownerid" />' +
                    '<attribute name="ber_customertype" />' +
                    '<order attribute="fullname" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_customertype" operator="in">' +
                    '<value>278290005</value>' +
                    '<value>278290006</value>' +
                    '</condition>' +
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '<condition attribute="ber_bdterritory" operator="not-null" />' +
                    '<condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="' + defaultdepotid + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                if (Xrm.Page.ui.controls.get("ber_hdemployeeid") != null) {
                    Xrm.Page.ui.controls.get("ber_hdemployeeid").addCustomView(hdViewId, "contact", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                    Xrm.Page.ui.controls.get("ber_hdemployeeid").setDefaultView(hdViewId);
                }

                $("#ber_hdemployeeid").find("img").attr("disableviewpicker", "1");

            }
        }
    }
}



function FilteredTSI() {

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() !== null && Xrm.Page.getAttribute("ber_depotid").getValue() !== undefined) {
            Xrm.Page.getAttribute("ber_depotid").setValue(null);
        }
        if (Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined) {
            var submitMode = "always";
            var city = Xrm.Page.getAttribute("ber_cityid").getValue();
            if (city != null && city != undefined) {
                var cityId = city[0].id;
                var d = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                d += "<entity name = 'ber_city'>";
                d += "<attribute name = 'ber_citytype'/>";
                d += "<attribute name = 'ber_defaultdepotid'/>";
                d += "<attribute name = 'ber_openjobs'/>";
                d += "<attribute name = 'ber_maxjobs'/>";
                d += "<filter type = 'and'>";
                d += "<condition attribute='ber_cityid' value ='";
                d += cityId;
                d += "' operator = 'eq'/>";
                d += "</filter>";
                d += "</entity>";
                d += "</fetch>";
                var fetchData = XrmServiceToolkit.Soap.Fetch(d);
                if (fetchData[0].attributes['ber_defaultdepotid'] !== null && fetchData[0].attributes['ber_defaultdepotid'] !== undefined) {
                    var defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
                    var defaultdepotid = fetchData[0].attributes["ber_defaultdepotid"].id;
                    var defaultdepotlogicalname = fetchData[0].attributes["ber_defaultdepotid"].logicalName;
                    Xrm.Page.getAttribute("ber_depotid").setValue([{
                        id: defaultdepotid,
                        name: defaultdepotname,
                        entityType: defaultdepotlogicalname
                    }]);

                }


            }
        }
    }
    if (Xrm.Page.getAttribute("ber_tsiid2") != null && Xrm.Page.getAttribute("ber_tsiid2") != undefined) {

        $("#ber_tsiid2").find("img").attr("disableviewpicker", "0");
    }

    if (Xrm.Page.getAttribute("ber_depotid") != null) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid") != undefined && Xrm.Page.getAttribute("ber_depotid").getValue() != null) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
            if (_depotId != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered Depot wise TSI view";
                //var view_DGId = GetuniqueGuid();
                //var view_DGId = Xrm.Page.getControl("ber_tsiid2").getDefaultView();
                var tsiViewId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="ber_tsiid" select="1" icon="2" preview="1">' +
                    '<row name="result" id="ber_tsiid">' +
                    '<cell name="ber_name" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="ber_mobilenumber" width="100" />' +
                    '<cell name="ber_terr_code" width="100" />' +
                    '</row>' +
                    '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                    '<entity name="ber_tsi">' +
                    '<attribute name="ber_tsiid" />' +
                    '<attribute name="ber_name" />' +
                    '<attribute name="ber_mobilenumber" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="ber_terr_code" />' +
                    '<order attribute="ber_name" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '<condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="' + defaultdepotid + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';

                if (Xrm.Page.ui.controls.get("ber_tsiid2") != null) {
                    Xrm.Page.ui.controls.get("ber_tsiid2").addCustomView(tsiViewId, "ber_tsi", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                    Xrm.Page.ui.controls.get("ber_tsiid2").setDefaultView(tsiViewId);
                }

                $("#ber_tsiid2").find("img").attr("disableviewpicker", "1");
            }
        }
    }

}







function onloadFilter() {

    if (Xrm.Page.getAttribute("ber_pincodeid") != null && Xrm.Page.getAttribute("ber_pincodeid") != undefined) {
        var depot = Xrm.Page.getAttribute("ber_pincodeid");

        filterDGByDefaultDepot();

        filterHDByDefaultDepot();

        FilteredTSI();

        //filterXPAByDefaultDepot();

       

        if (Xrm.Page.getAttribute("ber_subleadtype") != undefined && Xrm.Page.getAttribute("ber_subleadtype") != null) {
            var SubLeadType = Xrm.Page.getAttribute("ber_subleadtype").getValue();

        }


         if (_depotId != null  && SubLeadType != '278290002') {

            filterXPAByDefaultDepot();

         }

      else if (_depotId != null && SubLeadType == '278290002') {

            MMPainterview();
        }

        

      //  MMPainterview();

        $("#header_process_d").css("display", "none");
    }
}







function leadtype1() {

    //debugger;
    //   alert("1");
    if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
        var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
        var navleadaudit = null;
        var navleadproduct = null;
        var navleadpainter = null;

        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        var leadfor = Xrm.Page.getAttribute("ber_leadfor").getValue();

        if (!isCrmForMobile) {
            navleadaudit = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadaudit_Lead");
            navleadproduct = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadproduct_lead");
            navleadpainter = Xrm.Page.ui.navigation.items.get("nav_ber_lead_ber_leadpainter_Lead");
        }

        if (navleadproduct !== null) navleadproduct.setVisible(false);
        if (navleadpainter !== null) navleadpainter.setVisible(false);
        if (leadtype != null) {
            Xrm.Page.ui.controls.get("ber_leadfor").setVisible(false);
            setVisibleSection("general", "address", true);
            setVisibleSection("general", "productdetails", true);
            // setVisibleSection("general", "commonsection", true);
            if (leadtype == 278290002) {
                // setVisibleSection("general", "productdetails", true);
                setVisibleSection("general", "dealerinfo", true);
                if (Xrm.Page.getAttribute("statuscode").getValue() != 278290007) { //------ XP more change on 03122015

                    if (Xrm.Page.getAttribute("ber_dealerid") != null)
                        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");

                    if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                        Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                    if (UserHasRole("Call Center User") || ("Call Center User Additional Functionalities")) {
                        if (Xrm.Page.getAttribute("ber_startdate") != null)
                            Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");

                    }
                    else {
                        if (Xrm.Page.getAttribute("ber_startdate") != null)
                            Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                    }
                }
                if (Xrm.Page.getAttribute("statuscode").getValue() != null)
                    if (Xrm.Page.getAttribute("statuscode").getValue() == 1 || Xrm.Page.getAttribute("statuscode").getValue() == 278290004) {
                        if (navleadproduct !== null) navleadproduct.setVisible(false);
                        if (navleadpainter !== null) navleadpainter.setVisible(false);
                    } else {
                        if (Xrm.Page.getAttribute("statuscode").getValue() == 2) {

                            if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                                Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                                Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_startdate") != null)
                                Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_enddate") != null)
                                Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");

                            if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null)
                                Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("required");

                        }
                        if (navleadproduct !== null) navleadproduct.setVisible(true);
                        if (navleadpainter !== null) navleadpainter.setVisible(true);

                    } else {

                    if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                        Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                        Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_startdate") != null)
                        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");

                    if (Xrm.Page.getAttribute("ber_enddate") != null)
                        Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");

                    if (navleadproduct !== null) navleadproduct.setVisible(false);
                    if (navleadpainter !== null) navleadpainter.setVisible(false);
                }
            } else if (leadtype == 278290001) {
                setVisibleSection("general", "homedecor", true);
                setVisibleSection("general", "dealerinfo", false);
                if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                    Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_startdate") != null)
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");

                if (navleadproduct !== null) navleadproduct.setVisible(false);
                if (navleadpainter !== null) navleadpainter.setVisible(false);
                if (navleadaudit !== null) navleadaudit.setVisible(false);
            }

            else {

            }
        }
    }
}





// XPA filtered list



function filterXPAByDefaultDepot() {

    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;

            var view_PaintersByDepotDisplayname = "XPA Painters with Sander";
            // var view_PaintersByDepotId = GetuniqueGuid();
            var xpaViewId = "{00000000-0000-0000-00AA-000010001007}";
            //var view_PaintersByDepotId = Xrm.Page.getControl("ber_xpa").getDefaultView();
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                '<row name="result" id="contactid">' +
                '<cell name="fullname" width="100" />' +
                '<cell name="ber_xpamonthlyleadlimit" width="100" />' +
                '<cell name="ber_exteriorpainterrating" width="100" />' +
                '<cell name="ber_corepainterscp" width="100" />' +
                '<cell name="ber_epstatus" width="100" />' +
                '<cell name="ber_painterrating" width="100" />' +
                '<cell name="ber_havesander" width="100" />' +
                '<cell name="ber_dealerid" width="100" />' +
                '<cell name="ber_depotid" width="100" />' +
                '<cell name="mobilephone" width="100" />' +
                '<cell name="ber_preferredlanguage1" width="100" />' +
                '<cell name="ber_preferredlanguage2" width="100" />' +
                '</row>' +
                '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                '<entity name="contact">' +
                '<attribute name="fullname" />' +
                '<attribute name="contactid" />' +
                '<attribute name="ber_xpamonthlyleadlimit" />' +
                '<attribute name="ber_corepainterscp" />' +
                '<attribute name="ber_preferredlanguage2" />' +
                '<attribute name="ber_preferredlanguage1" />' +
                '<attribute name="ber_painterrating" />' +
                '<attribute name="ber_exteriorpainterrating" />' +
                '<attribute name="ber_depotid" />' +
                '<attribute name="ber_dealerid" />' +
                '<attribute name="ber_epstatus" />' +
                '<attribute name="mobilephone" />' +
                '<attribute name="ber_havesander" />' +
                '<order attribute="ber_corepainterscp" descending="false" />' +
                '<filter type="and">' +
                '<condition attribute="statecode" operator="eq" value="0" />' +
                '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                '<filter type="or">' +
                '<condition attribute="ber_subdealer" operator="eq" value="0" />' +
                '<condition attribute="ber_subdealer" operator="null" />' +
                '</filter>' +
                '<condition attribute="ber_parentpainter" operator="null" />' +
                '<condition attribute="ber_xpa" operator="eq" value="1" /> />' +
                '<condition attribute="ber_epstatus" operator="in">' +
                '<value>278290003</value>' +
                '<value>278290000</value>' +
                '</condition>' +
                ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                ' <condition attribute="ber_havemoisturemeter" operator="eq" value="1" />' +
                '<filter type="or">' +
                '<condition attribute="ber_xpamonthlyleadlimit" operator="le" value="20" />' +
                '<condition attribute="ber_xpamonthlyleadlimit" operator="null" />' +
                '</filter>' +
                '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                '</filter>' +
                '</entity>' +
                '</fetch>';

            if (Xrm.Page.ui.controls.get("ber_xpa") != null) {
                Xrm.Page.ui.controls.get("ber_xpa").addCustomView(xpaViewId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
                Xrm.Page.ui.controls.get("ber_xpa").setDefaultView(xpaViewId);
            }

            $("#ber_xpa").find("img").attr("disableviewpicker", "1");
        }

    }

}


/////// MM view //////////////////////



function MMPainterview() {


    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;

        var view_PaintersByDepotDisplayname = "MM Painters view with Moisture Meter";

        var view_PaintersByDepotId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
        var IsDefaultView = true;

        layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                            '<row name="result" id="contactid">' +
                            '<cell name="fullname" width="100" />' +
                            '<cell name="ber_exteriorpainterrating" width="100" />' +
                            '<cell name="ber_corepainterscp" width="100" />' +
                            '<cell name="ber_epstatus" width="100" />' +
                            '<cell name="ber_painterrating" width="100" />' +
                            '<cell name="ber_havesander" width="100" />' +
                            '<cell name="ber_havemoisturemeter" width="100" />' +
                            '<cell name="ber_dealerid" width="100" />' +
                            '<cell name="ber_depotid" width="100" />' +
                            '<cell name="mobilephone" width="100" />' +
                            '<cell name="ber_preferredlanguage1" width="100" />' +
                            '<cell name="ber_preferredlanguage2" width="100" />' +
                            '</row>' +
                            '</grid>';

        fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
       '<entity name="contact">' +
       '<attribute name="fullname" />' +
       '<attribute name="contactid" />' +
       '<attribute name="ber_corepainterscp" />' +
       '<attribute name="ber_preferredlanguage2" />' +
       '<attribute name="ber_preferredlanguage1" />' +
       '<attribute name="ber_painterrating" />' +
       '<attribute name="ber_exteriorpainterrating" />' +
       '<attribute name="ber_depotid" />' +
       '<attribute name="ber_dealerid" />' +
       '<attribute name="ber_epstatus" />' +
       '<attribute name="mobilephone" />' +
       '<attribute name="ber_havesander" />' +
       '<order attribute="ber_corepainterscp" descending="false" />' +
       '<filter type="and">' +
       '<condition attribute="statecode" operator="eq" value="0" />' +
       '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
       '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
        '<filter type="or">' +
        '<condition attribute="ber_subdealer" operator="eq" value="0" />' +
         '<condition attribute="ber_subdealer" operator="null" />' +
        '</filter>' +
      '<condition attribute="ber_parentpainter" operator="null" />' +
       '<condition attribute="ber_epstatus" operator="in">' +
       '<value>278290003</value>' +
       '<value>278290000</value>' +
       '</condition>' +
       ' <condition attribute="ber_havemoisturemeter" operator="eq" value="1" />' +
       '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
       '</filter>' +
       '</entity>' +
       '</fetch>';

        

        //alert("1");
        // Xrm.Page.getAttribute("ber_masterpainterid").setValue(null);
        if (Xrm.Page.ui.controls.get("ber_xpa") != null) {
            Xrm.Page.ui.controls.get("ber_xpa").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
            Xrm.Page.ui.controls.get("ber_xpa").setDefaultView(view_PaintersByDepotId);
        }

        $("#ber_xpa").find("img").attr("disableviewpicker", "1");


    }
}



var xmlHttp;
function getServerTime() {
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD', window.location.href.toString(), false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    // addMinutes(xmlHttp.getResponseHeader("Date"), 330)
    var addmin = addMinutes(xmlHttp.getResponseHeader("Date"));

    return addmin
}

function addMinutes(date) {
    var d = new Date(date);
    // alert(typeof (d));
    //return new Date(d.getTime() + 330 * 60000);
    //d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000);
    return d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000)

}












function OnSaveIsChargeable() {
    if (Xrm.Page.getAttribute("ber_pincodeid") != null) {

        var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
        var x = "0";
        if (pinCodeId != null) {

            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {
                var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="ber_pincode">' +
                    '<attribute name="ber_pincodeid" />' +
                    '<attribute name="ber_cityid" />' +
                    '<filter type="and">' +
                    '<condition attribute="ber_pincodeid" operator="eq" value="' + _pinCode + '" />' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';

                var retrievedCity = XrmServiceToolkit.Soap.Fetch(fetchxml);

                if (retrievedCity.length > 0) {
                    var CityArray = new Array();
                    CityArray[0] = new Object();
                    CityArray[0].id = retrievedCity[0].attributes.ber_cityid.id;
                    CityArray[0].name = retrievedCity[0].attributes.ber_cityid.name;
                    CityArray[0].entityType = retrievedCity[0].attributes.ber_cityid.logicalName;
                    Xrm.Page.getAttribute("ber_cityid").setValue(CityArray);
                    Xrm.Page.getAttribute("ber_cityid").setSubmitMode("always");

                }
                if (retrievedCity[0].attributes.ber_cityid != null) {
                    var CityId = retrievedCity[0].attributes.ber_cityid.id;
                    var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="ber_city">' +
                        '<attribute name="ber_cityid" />' +
                        '<attribute name="ber_citytype" />' +
                        '<attribute name="ber_stateid" />' +
                        '<attribute name="ber_ischargeable" />' +
                        '<attribute name="ber_applicablecost" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" value="' + CityId + '" />' +
                        '</filter>' +
                        '</entity>' +
                        '</fetch>';
                    var retrieveState = XrmServiceToolkit.Soap.Fetch(fetchxml);
                    if (retrieveState.length > 0) {
                        var StateArray = new Array();
                        StateArray[0] = new Object();
                        StateArray[0].id = retrieveState[0].attributes.ber_stateid.id;
                        StateArray[0].name = retrieveState[0].attributes.ber_stateid.name
                        StateArray[0].entityType = retrieveState[0].attributes.ber_stateid.logicalName
                        // alert(retrieveState[0].attributes.ber_ischargeable);
                        if (Xrm.Page.getAttribute("ber_lockedforad").getValue() != null && Xrm.Page.getAttribute("ber_lockedforad") != undefined) {
                            var LockedforAD = Xrm.Page.getAttribute("ber_lockedforad").getValue();

                            if (LockedforAD == 'Yes') {
                                if (retrieveState[0].attributes.ber_ischargeable != undefined && retrieveState[0].attributes.ber_ischargeable != null) {
                                    // alert("Service for this city is chargeable");

                                    var IsChargeable = retrieveState[0].attributes.ber_ischargeable.formattedValue;
                                    Xrm.Page.getAttribute("ber_ischargeable").setValue(IsChargeable);
                                    Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");


                                    if (retrieveState[0].attributes.ber_applicablecost != undefined && retrieveState[0].attributes.ber_applicablecost != null) {

                                        var Cost = retrieveState[0].attributes.ber_applicablecost.formattedValue;
                                        Xrm.Page.getAttribute("ber_servicecost").setValue(Cost);
                                        Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                    }

                                    else {

                                        Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                        Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                        Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                        Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                    }


                                }
                                else {

                                    Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                    Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                    Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                    Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                                }

                            }
                            else {
                                var x = "0";
                                Xrm.Page.getAttribute("ber_ischargeable").setValue("No");
                                Xrm.Page.getAttribute("ber_ischargeable").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_servicecost").setValue(x);
                                Xrm.Page.getAttribute("ber_servicecost").setSubmitMode("always");

                            }

                        }


                    }
                }
            }
        }
    }
}



