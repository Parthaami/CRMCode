function leadsource() {

    if (Xrm.Page.getAttribute("statuscode").getValue() != null) {
        if (Xrm.Page.getAttribute("statuscode").getValue() == 1) {
            if (Xrm.Page.getControl("ber_previewcenterid") != null && Xrm.Page.getControl("ber_previewcenterid") != undefined) {
                Xrm.Page.getControl("ber_previewcenterid").setDisabled(true);
            }
        }
    }
    var leadsrc = Xrm.Page.getAttribute("leadsourcecode").getValue();
    var leadtypevalue = Xrm.Page.getAttribute("ber_leadtype").getValue();

    if (leadtypevalue == 278290000) {
        //Xrm.Page.getAttribute("ber_workorder").setValue("0");                                          
        //Xrm.Page.getAttribute("ber_workorderdate").setValue("");                                          
        //Xrm.Page.getAttribute("ber_workordernumber").setValue("");	

        Xrm.Page.getAttribute("ber_hdemployeeid").setValue(null);
        if (Xrm.Page.getAttribute("ber_hdemployeeid") != null)
            Xrm.Page.getAttribute("ber_hdemployeeid").setValue(null);

        if (Xrm.Page.getAttribute("statuscode").getValue() != 1) {
            setVisibleSection("general", "leadproduct", true);
            if (Xrm.Page.ui.tabs.get("leadproduct") != null && Xrm.Page.ui.tabs.get("leadproduct") != undefined) {
                Xrm.Page.ui.tabs.get("leadproduct").setDisplayState('collapsed');
            }

        }

        if (UserHasRole("Call Center Manager") || UserHasRole("Call Center Supervisior") || UserHasRole("Call Center User")) {
            setVisibleSection("general", "bdm", false);

            if (Xrm.Page.getAttribute("ber_dealerid") != null)
                Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");

            if (Xrm.Page.getAttribute("ber_depotid") != null)
                Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");

            if (Xrm.Page.getAttribute("ber_dealerid") != null)
                Xrm.Page.getControl("ber_dealerid").setVisible(false);

            if (Xrm.Page.getAttribute("ber_depotid") != null)
                Xrm.Page.getControl("ber_depotid").setVisible(false);

        } else {
            setVisibleSection("general", "bdm", true);
            if (Xrm.Page.ui.getFormType() != 1) {
                if (Xrm.Page.getAttribute("ber_dealerid") != null)
                    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_depotid") != null)
                    Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_dealerid") != null)
                    Xrm.Page.getControl("ber_dealerid").setVisible(true);

                if (Xrm.Page.getAttribute("ber_depotid") != null)
                    Xrm.Page.getControl("ber_depotid").setVisible(true);
            }
        }
        setVisibleSection("general", "homedecor", false);
        setVisibleSection("general", "prolinks", false);
        setVisibleSection("general", "estimates", false);
        setVisibleSection("general", "productdetails", false);

        /*
        if (leadsrc == 1) {
            //show following fields
            Xrm.Page.getControl("ber_leadforid").setVisible(true);
            Xrm.Page.getAttribute("ber_leadforid").setRequiredLevel("required");

    } else if (leadtypevalue == 278290001) {
        //Xrm.Page.ui.tabs.get("leadproduct").setVisible(false);

        setVisibleSection("general", "leadproduct", false);
        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "productdetails", true);
        setVisibleSection("general", "prolinks", false);

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getControl("ber_dealerid").setVisible(false);

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getControl("ber_depotid").setVisible(false);

        if (UserHasRole("Call Center Manager") || UserHasRole("Call Center Supervisior") || UserHasRole("Call Center User")) {
            setVisibleSection("general", "homedecor", false);
        } else {
            setVisibleSection("general", "homedecor", true);
        }
        if (Xrm.Page.getAttribute("statuscode").getValue() == 3 || Xrm.Page.getAttribute("statuscode").getValue() == 278290005) {
            setVisibleSection("general", "estimates", true);
        } else {
            setVisibleSection("general", "estimates", false);
        }


    } else if (leadtypevalue == 278290002) {
        setVisibleSection("general", "productdetails", true);

        if (Xrm.Page.getAttribute("ber_hdemployeeid") != null)
            Xrm.Page.getControl("ber_hdemployeeid").setVisible(false);

        setVisibleSection("general", "leadproduct", false);
        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecor", false);
        setVisibleSection("general", "prolinks", false);

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getControl("ber_dealerid").setVisible(true);

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getControl("ber_depotid").setVisible(true);


        setVisibleSection("general", "estimates", false);

    } else {

        if (Xrm.Page.getAttribute("ber_hdemployeeid") != null)
            Xrm.Page.getControl("ber_hdemployeeid").setVisible(false);

        setVisibleSection("general", "leadproduct", false);

        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecor", false);
        setVisibleSection("general", "prolinks", false);
        setVisibleSection("general", "estimates", false);
        setVisibleSection("general", "productdetails", false);
        Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");
        Xrm.Page.getControl("ber_dealerid").setVisible(false);
        Xrm.Page.getControl("ber_depotid").setVisible(false);

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getControl("ber_dealerid").setVisible(false);

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getControl("ber_depotid").setVisible(false);

    }

    if (Xrm.Page.ui.getFormType() == 1) {
        setVisibleSection("general", "productdetails", false);

        if (Xrm.Page.getAttribute("ber_hdemployeeid") != null)
            Xrm.Page.getControl("ber_hdemployeeid").setVisible(false);


        setVisibleSection("general", "leadproduct", false);

        setVisibleSection("general", "bdm", false);
        setVisibleSection("general", "homedecor", false);
        setVisibleSection("general", "prolinks", false);

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("none");

        if (Xrm.Page.getAttribute("ber_dealerid") != null)
            Xrm.Page.getControl("ber_dealerid").setVisible(false);

        if (Xrm.Page.getAttribute("ber_depotid") != null)
            Xrm.Page.getControl("ber_depotid").setVisible(false);

        setVisibleSection("general", "estimates", false);
    }

    if (Xrm.Page.getAttribute("leadsourcecode").getValue() == 278290002) {

        if (Xrm.Page.getAttribute("ber_leadcontactid") != null)
            Xrm.Page.getControl("ber_leadcontactid").setVisible(true);

    } else {
        if (Xrm.Page.getAttribute("ber_leadcontactid") != null)
            Xrm.Page.getControl("ber_leadcontactid").setVisible(false);

    }
}



function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

function UserHasRole(roleName) {
    //To Fetch Server Url
    var serverUrl = Xrm.Page.context.getClientUrl();


    var userRoles = Xrm.Page.context.getUserRoles();

    for (var i = 0; i < userRoles.length; i++) {
        var roleId = userRoles[i];

        //To Fetch Guid Of given Role Name..
        var oDataEndpointUrl = serverUrl + "/XRMServices/2011/OrganizationData.svc/";
        oDataEndpointUrl += "RoleSet?$top=1&$filter=RoleId eq Guid'" + roleId + "'";

        var service = GetRequestObject();

        if (service != null) {
            service.open("GET", oDataEndpointUrl, false);
            service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
            service.setRequestHeader("Accept", "application/json, text/javascript, */*");
            service.send(null);

            var requestResults = eval('(' + service.responseText + ')').d;

            if (requestResults != null) {
                var role = requestResults.results[0];
                if (role != null) {

                    if (role.Name == roleName) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
};

function GetRequestObject() {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    } else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        } catch (ex) {
            return null;
        }
    }
};

function GuidsAreEqual(guid1, guid2) {
    var isEqual = false;

    if (guid1 == null || guid2 == null) {
        isEqual = false;
    } else {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
};


function updateRecordRole(recordId, value) {
    try {
        //debugger;
        var interestedobj = {};
        // interestedobj. = allow;
        interestedobj.CompanyName = value;
        CrmRestKit.Update("Lead", recordId, interestedobj);
    } catch (Exception) {
        //  throw (Exception);
    }
}

function validateCarpetArea() {
    var carpetArea = Xrm.Page.getAttribute("ber_carpetarea").getValue();
    var leadtypevalue = Xrm.Page.getAttribute("ber_leadtype").getValue();
    var statuscode = Xrm.Page.getAttribute("statuscode").getValue();
    if (leadtypevalue == 278290002) {
        if (Xrm.Page.getAttribute("statuscode").getValue() != null) {
            if (Xrm.Page.getAttribute("statuscode").getValue() == 2) {
                if (carpetArea > 0) {
                    return true;
                } else {
                    alert("Carpet Area should be greater than 0");
                    return false;
                }
            }
        }
    }
}

function ValidateNumber() {

    var contactNumber = Xrm.Page.getAttribute("telephone1").getValue();
    var n = contactNumber.length;

    var i;
    var returnString = "";

    if (typeof (contactNumber) != "undefined" && contactNumber != null) {
        filteredValues = "1234567890";

        for (i = 0; i < contactNumber.length; i++) {
            var c = contactNumber.charAt(i);
            if (filteredValues.indexOf(c) != -1) {
                returnString += c;
            }
        }
        Xrm.Page.getAttribute("telephone1").setValue(returnString);

        if (returnString.length != contactNumber.length) {
            Xrm.Page.getAttribute("telephone1").setValue("");
            alert('Only Integers are allowed');
            Xrm.Page.getControl("telephone2").setFocus(true);
            Xrm.Page.getControl("telephone1").setFocus(true);

        }
    }
    if (n != 10) {
        alert("Mobile Number should be of 10 digits");
        Xrm.Page.getAttribute("telephone1").setValue("");
        Xrm.Page.getControl("telephone2").setFocus(true);
        Xrm.Page.getControl("telephone1").setFocus(true);
    }
}

function RoleBasedFeildVisibility() {
    var userid = Xrm.Page.context.getUserId();
    var ownerid = Xrm.Page.getAttribute("ownerid").getValue()[0].id;
    if (userid != ownerid && !UserHasRole("System Administrator")) {
        Xrm.Page.getControl("ber_cityid").setDisabled(false);
        Xrm.Page.getControl("ber_stateid").setDisabled(false);
    }
    else {
        Xrm.Page.getControl("ber_cityid").setDisabled(true);
        Xrm.Page.getControl("ber_stateid").setDisabled(true);
    }
}

function HideRibbon() {
    if (Xrm.Page.ui.getFormType() != 1 || Xrm.Page.getAttribute("subject").getValue() != null) {
        // Ticket # A0973 Disabeling Lead Type on Form Type Update
        var userid = Xrm.Page.context.getUserId();
        var ownerid = Xrm.Page.getAttribute("ownerid").getValue()[0].id;

        if (userid != ownerid && !UserHasRole("System Administrator") && !UserHasRole("HO Home Decor User")) {
            return false;
        }
        return true;
    }
}
