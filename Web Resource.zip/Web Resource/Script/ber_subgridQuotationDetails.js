function Form_OnLoad() {  //Attach to the grid refresh event  
setTimeout("SetupGridRefresh();", 2500);
 } 

function SetupGridRefresh()
 { 
 var grid = document.getElementById("QuotationDetails");
  if (grid) {  
         grid.attachEvent("onrefresh", FormRefresh); 
 }
 else
 {
  alert("Grid is null"); 
 }
 }  


function FormRefresh() {  
window.location.reload(true);
 }