


///////////////////////////////////////////////////////



function SetDepot() {

    if (Xrm.Page.getAttribute("ber_lead") != undefined && Xrm.Page.getAttribute("ber_lead").getValue() != null) {

        var lead = Xrm.Page.getAttribute("ber_lead").getValue();

        var leadid = lead[0].id;

        var leadColumns = ['FullName', 'ber_DepotId'];

        var leadFilter = "LeadId eq guid'" + leadid + "'";

        var leadCollection = CrmRestKit.RetrieveMultiple('Lead', leadColumns, leadFilter);
        if (leadCollection != null && leadCollection != undefined) {
            if (leadCollection.results != null) {
                if (leadCollection.results.length > 0) {
                    var collection = leadCollection.results[0];
                    var DepotId = collection.ber_DepotId.Id;
                    var defaultdepotlogicalname = collection.ber_DepotId.LogicalName;
                   // var DepotName = collection.ber_DepotId.Name;

                    if (DepotId != null) {
                       // var DepotId = collection.ber_DepotId.Id;
                        var DepotName = collection.ber_DepotId.Name;

                        Xrm.Page.getAttribute("ber_depot").setValue([{
                            id: DepotId,
                            name: DepotName,
                            entityType: defaultdepotlogicalname
                        }]);
                        //Xrm.Page.getAttribute("ber_depot").setValue(DepotName);
                       // Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
                    }

                    else if (collection.DepotId == null) {
                        //  var ItemName = collection.ber_ItemId.Name;
                        Xrm.Page.getAttribute("ber_depot").setValue(null);
                        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
                    }
                }
            }
        }
    }

    else {
        Xrm.Page.getAttribute("ber_depot").setValue(null);
        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
    }
}


/*



Xrm.Page.getAttribute("ber_depotid").setValue([{
                    id: defaultdepotid,
                    name: defaultdepotname,
                    entityType: defaultdepotlogicalname
                }]);


                */