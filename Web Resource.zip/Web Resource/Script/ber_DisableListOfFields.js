function disabledFields() {
    Xrm.Page.data.entity.attributes.forEach(function (attribute, index) {
        var control = Xrm.Page.getControl(attribute.getName());
        if (control) {
            control.setDisabled(true)
        }
    });
}

function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

function HideAll() {

    var formLabel;
    var currForm = Xrm.Page.ui.formSelector.getCurrentItem();
    // alert(currForm);
    formLabel = currForm.getLabel();
    //alert(formLabel);
    //this code to show the ribbon if only the current opened form is Partner, 
    //otherwise remain disable/hidden
    if (formLabel == "Painter Form") {
        if (UserHasRole("Depot User") == true || UserHasRole("Depot Home Decor User") == true) {
            disabledFields();

            setVisibleSection("details", "meets", false);
            setVisibleSection("details", "liftingdetails", false);
            setVisibleSection("details", "details_section_3", false);
            setVisibleSection("details", "details_section_4", false);
            setVisibleSection("details", "details_section_5", false);
            setVisibleSection("details", "details_section_6", false);
            setVisibleSection("Paint Express Items", "productdetails", false);
            // setVisibleSection("general", "tab_4_section_1", false);

        }

        else if (UserHasRole("Call Center User") == true || UserHasRole("Call Center User Additional Functionalities") == true) {
            disabledFields();
        }
    }

}

