function setDatesRequiredLevel() {
    if (Xrm.Page.getAttribute("ber_type") != null && Xrm.Page.getAttribute("ber_type").getValue() != null && Xrm.Page.getAttribute("ber_type").getValue() != 278290003
 && Xrm.Page.getAttribute("ber_schemerequired") != null && Xrm.Page.getAttribute("ber_schemerequired").getValue() != null && Xrm.Page.getAttribute("ber_schemerequired").getValue()) {
        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_finalpointcalculationdate").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_sellinconsiderationdate").setRequiredLevel("required");
    }
    else {
        Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_finalpointcalculationdate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_sellinconsiderationdate").setRequiredLevel("none");
    }
}

function MakeReadonly() {
    debugger;

    var type = Xrm.Page.getAttribute("ber_type").getValue();
    if (type == "278290002" && type != null) {  //Master Painter Type
        Xrm.Page.ui.controls.get("ber_totalpointroundedby").setDisabled(false);
        Xrm.Page.ui.controls.get("ber_limitofredeemedpoint").setDisabled(false);

    }
    else {
        Xrm.Page.ui.controls.get("ber_totalpointroundedby").setDisabled(true);
        Xrm.Page.ui.controls.get("ber_limitofredeemedpoint").setDisabled(true);
        Xrm.Page.getAttribute("ber_totalpointroundedby").setValue(0);
        Xrm.Page.getAttribute("ber_limitofredeemedpoint").setValue(0);


    }


}








function Reconrequired() {
    var ReconValue = Xrm.Page.data.entity.attributes.get("ber_reconciliationprocess").getValue();
    var Status = Xrm.Page.ui.controls.get("ber_cutoffdurationofsuspension");
    if (UserHasRole("System Administrator", "HO BD User")) {
        if (ReconValue != null) {

            if (ReconValue == false) {
                Status.setDisabled(true);
                Xrm.Page.data.entity.attributes.get("ber_reconciliationprocess").setValue(false);
                Xrm.Page.data.entity.attributes.get("ber_cutoffdurationofsuspension").setValue(null);
            }

            else
                Status.setDisabled(false);


        }
    }

}



function masterType() {
    var MasterType = Xrm.Page.data.entity.attributes.get("ber_type").getText();
    var ReconValue1 = Xrm.Page.ui.controls.get("ber_reconciliationprocess");
    var ReconValue = Xrm.Page.data.entity.attributes.get("ber_reconciliationprocess").getValue();
    var Status = Xrm.Page.ui.controls.get("ber_cutoffdurationofsuspension");

    if (UserHasRole("System Administrator", "HO BD User")) {
        if (MasterType != null) {
            if (MasterType == "Master Painter") {
                ReconValue1.setDisabled(false);
                if (ReconValue == true) {
                    Status.setDisabled(false);

                }
            }

            else {
                ReconValue1.setDisabled(true);
                Status.setDisabled(true);
                var resetValue = Xrm.Page.data.entity.attributes.get("ber_reconciliationprocess").setValue(false);
                //alert(resetValue);
                var duration = Xrm.Page.data.entity.attributes.get("ber_cutoffdurationofsuspension").setValue(null);
                // alert(duration);
            }

        }


    }
    else {
        ReconValue1.setDisabled(true);
        Status.setDisabled(true);
    }
}


var serverUrl = Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/";


function UserHasRole(roleName) {
    //Get Business unit id
    var loggedinUser = Xrm.Page.context.getUserId();
    var oDataEndpointUrl = serverUrl;
    oDataEndpointUrl += "SystemUserSet?$select=BusinessUnitId&$filter=SystemUserId eq guid'" + loggedinUser + "'";
    requestResults1 = RestCall(oDataEndpointUrl);
    if (requestResults1 != null && requestResults1.results.length == 1) {
        var BU = requestResults1.results[0];
        var BUid = BU.BusinessUnitId;

        var oDataEndpointUrl = serverUrl;
        oDataEndpointUrl += "RoleSet?$filter=Name eq'" + roleName + "'" + "and BusinessUnitId/Id eq guid'" + BUid.Id + "'";
        requestResults = RestCall(oDataEndpointUrl);

        if (requestResults != null && requestResults.results.length == 1) {
            var role = requestResults.results[0];
            var id = role.RoleId;
            var currentUserRoles = Xrm.Page.context.getUserRoles();
            for (var i = 0; i < currentUserRoles.length; i++) {
                var userRole = currentUserRoles[i];
                if (GuidsAreEqual(userRole, id)) {
                    return true;
                }
            }
        }
    }
    return false;
};

//Rest call Sync
function RestCall(oDataEndpointUrl) {
    var service = getXMLHttpRequest();
    if (service != null) {
        service.open("GET", oDataEndpointUrl, false);
        service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
        service.setRequestHeader("Accept", "application/json, text/javascript, */*");
        service.send(null);
        var requestResults = eval('(' + service.responseText + ')').d;
        return requestResults;
    }
    else
        null;
};


function GuidsAreEqual(guid1, guid2) {
    var isEqual = false;

    if (guid1 == null || guid2 == null) {
        isEqual = false;
    }
    else {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
};

getXMLHttpRequest = function () {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex) {
            return null;
        }
    }
};
