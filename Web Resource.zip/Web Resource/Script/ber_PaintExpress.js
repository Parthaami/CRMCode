function OnStatusReasonChange()
{
//debugger;
  var statusReason = Xrm.Page.getAttribute("statuscode").getValue();

  if(statusReason == 278290000)
   {
      Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
   }
  else
   {
       Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
   }
}

function setendDate()
{
//debugger;
         var startDate = Xrm.Page.getAttribute("ber_startdate").getValue();
         var endDate;
         if(startDate != null && startDate != undefined)
          {
            endDate  = new Date(startDate.getFullYear() + 1,startDate.getMonth(),startDate.getDate() - 1);
          }
         Xrm.Page.getAttribute("ber_enddate").setValue(endDate);
}


function paintexpressBtn()
{
//alert("Paint Express");
//debugger;
var parameters = {};

    parameters["ber_painterid"] = Xrm.Page.data.entity.getId().toString();
    parameters["ber_painteridname"] = Xrm.Page.getAttribute("fullname").getValue();

    	if(Xrm.Page.getAttribute("firstname") != null && Xrm.Page.getAttribute("firstname") != undefined)
	{
	 parameters["ber_firstname"] = Xrm.Page.getAttribute("firstname").getValue();
	}
	
	if(Xrm.Page.getAttribute("lastname") != null && Xrm.Page.getAttribute("lastname") != undefined)
	{
	 parameters["ber_lastname"] = Xrm.Page.getAttribute("lastname").getValue();
	}
	
	if(Xrm.Page.getAttribute("mobilephone") != null && Xrm.Page.getAttribute("mobilephone") != undefined)
	{
	 parameters["ber_mobileno"] = Xrm.Page.getAttribute("mobilephone").getValue();
	}

                     	if(Xrm.Page.getAttribute("address1_line1") != null && Xrm.Page.getAttribute("address1_line1") != undefined)
	{
	 parameters["ber_address1"] = Xrm.Page.getAttribute("address1_line1").getValue();
	}
		
	if(Xrm.Page.getAttribute("address1_line2") != null && Xrm.Page.getAttribute("address1_line2") != undefined)
	{
	 parameters["ber_address2"] = Xrm.Page.getAttribute("address1_line2").getValue();
	}
	
	if(Xrm.Page.getAttribute("address1_line3") != null && Xrm.Page.getAttribute("address1_line3") != undefined)
	{
	 parameters["ber_address3"] = Xrm.Page.getAttribute("address1_line3").getValue();
	}                     

                    if(Xrm.Page.getAttribute("ber_dealerid") != null && Xrm.Page.getAttribute("ber_dealerid") != undefined)
                    {
					if(Xrm.Page.getAttribute("ber_dealerid").getValue() != null)
					{
						parameters["ber_dealerid"] = Xrm.Page.getAttribute("ber_dealerid").getValue()[0].id;
						parameters["ber_dealeridname"] = Xrm.Page.getAttribute("ber_dealerid").getValue()[0].name;
					}
					}

   if(Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined)
    {
	if(Xrm.Page.getAttribute("ber_depotid").getValue() != null)
	{
	  parameters["ber_depotid"] = Xrm.Page.getAttribute("ber_depotid").getValue()[0].id;
	  parameters["ber_depotidname"] = Xrm.Page.getAttribute("ber_depotid").getValue()[0].name;
	}
	}
	
	if(Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined)
    {
	if(Xrm.Page.getAttribute("ber_cityid").getValue() != null)
	{
	  parameters["ber_cityid"] = Xrm.Page.getAttribute("ber_cityid").getValue()[0].id;
	  parameters["ber_cityidname"] = Xrm.Page.getAttribute("ber_cityid").getValue()[0].name;
	}
	}
	
	if(Xrm.Page.getAttribute("ber_stateid") != null && Xrm.Page.getAttribute("ber_stateid") != undefined)
    {
	if(Xrm.Page.getAttribute("ber_stateid").getValue() != null)
	{
	  parameters["ber_stateid"] = Xrm.Page.getAttribute("ber_stateid").getValue()[0].id;
	  parameters["ber_stateidname"] = Xrm.Page.getAttribute("ber_stateid").getValue()[0].name;
	}
	}
	
	if(Xrm.Page.getAttribute("ber_pincodeid") != null && Xrm.Page.getAttribute("ber_pincodeid") != undefined)
    {
	if(Xrm.Page.getAttribute("ber_pincodeid").getValue() != null)
	{
	  parameters["ber_pincodeid"] = Xrm.Page.getAttribute("ber_pincodeid").getValue()[0].id;
	  parameters["ber_pincodeidname"] = Xrm.Page.getAttribute("ber_pincodeid").getValue()[0].name;
	}
	}

  Xrm.Utility.openEntityForm("ber_paintexpress", null, parameters);
}

function checkpainter()
{
	if(Xrm.Page.getAttribute("ber_painterid").getValue() != null && Xrm.Page.getAttribute("ber_painteroldnew").getValue() == 1)
	{
		Xrm.Page.getControl("ber_painterid").setDisabled(true);
	}
}

function approvalrole()
{
	var PEapprovar = UserHasRole("c99a426c-2c0b-e411-ad8c-5cf3fc98c336","1ae7ba8e-3e80-46fc-a8fc-ac7207bbf507");
	if(PEapprovar)
	{
		Xrm.Page.ui.controls.get("statuscode").setDisabled(false);
	}
	else
	{
		Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
	}
}

///*******************************Common Funtions *********************************************************
//The following function checks if the specified user has a specified user role:
function UserHasRole(roleNameAdmin,roleNameCC) {
    var roleArray = Xrm.Page.context.getUserRoles();
    if (roleArray != null && roleArray.length > 0) {
        for (var i = 0; i < roleArray.length; i++) {
			var roleid = roleArray[i];
			//alert(roleid);
			if(roleid == roleNameAdmin || roleid == roleNameCC)
			{
				return true;
			}
            /*var columns = ['Name'];
            var roleObj = CrmRestKit.Retrieve("Role", roleArray[i], columns);
            if (roleObj != null && roleObj != undefined) {
                if (roleObj.Name == roleName) {
                    return true;
                }
            }*/
        }
    }
    return false;
}