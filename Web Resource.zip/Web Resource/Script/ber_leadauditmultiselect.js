//Web
// var_sc_optionset >>  Provide logical-name for Option Set field
// var_sc_optionsetvalue >> Provide logical-name for field which will
//                          store the multi selected values for Option Set
// OS >> Provide Options of the Optionset field
//       (Ex:- Xrm.Page.getAttribute("Option Set field logical-name").getOptions())
// OSV >> Provide text field object which will store the
//        multi selected values for Option Set
//       (Ex:- document.getElementById("text field logical-name"))

// Method to convert an optionset to multi select OptionSet
function ConvertToMultiSelect(var_sc_optionset, var_sc_optionsetvalue) {
   
    var OS = Xrm.Page.getAttribute(var_sc_optionset).getOptions();

    var OSV = document.getElementById(var_sc_optionsetvalue);

    if (OS != null && OSV != null) {

        document.getElementById(var_sc_optionset).style.display = "none";

        // Create a DIV container
        var addDiv = document.createElement("div");
        addDiv.id = var_sc_optionsetvalue + "_m";
        addDiv.style.width = "100%";
        addDiv.style.height = "80px";
        addDiv.style.background = "#ffffff";
        addDiv.style.color = "white";
        addDiv.style.overflow = "auto";
        addDiv.style.border = "1px #6699cc solid";
        document.getElementById(var_sc_optionset).parentNode.appendChild(addDiv);

        // Declaration of variables will be used in the loop depending upon the browser
        var initialValue = 0;
        var maxValue = 0;

        var nAgt = navigator.userAgent;

        if (nAgt.indexOf("Firefox") != -1) {  // If the broswer is "Firefox" 

            initialValue = 1;
            maxValue = OS.length;

        }
        else if (nAgt.indexOf("Chrome") != -1 || nAgt.indexOf("IE") != -1) { // If the browser is Chrome or IE

            initialValue = 0;
            maxValue = OS.length - 1;
        }
        else if (nAgt.indexOf("Safari") != -1) {  // If the browser id "Safari"

            initialValue = 1;
            maxValue = OS.length;
        }

        // Initialise checkbox controls
        for (var i = initialValue; i < maxValue; i++) {
            var pOption = OS[i];
			if(pOption.value!= "null"){
            if (!IsChecked(pOption.text, var_sc_optionsetvalue)) {
                var addInput = document.createElement("input");
                addInput.type = "checkbox";
                addInput.id = var_sc_optionset + "_" + pOption.text;
                addInput.style.border = "none";
                addInput.style.width = "25px";
                addInput.style.align = "left";
                addInput.style.color = "#000000";
                addInput.onclick = function (e) {
                    OnChangeSave(var_sc_optionset, var_sc_optionsetvalue, e);
                    OnSave(var_sc_optionset, var_sc_optionsetvalue);
                    checkLengthAndUncheckAnyOption(var_sc_optionset, var_sc_optionsetvalue, e);

                }
            }
            else {

                var addInput = document.createElement("input");
                addInput.type = "checkbox";
                addInput.id = var_sc_optionset + "_" + pOption.text;
                addInput.checked = true;
                addInput.setAttribute("checked", true);
                addInput.checked = "checked";
                addInput.defaultChecked = true;
                addInput.style.border = "none";
                addInput.style.width = "25px";
                addInput.style.align = "left";
                addInput.style.color = "#000000";
                addInput.onclick = function (e) {

                    OnChangeSave(var_sc_optionset, var_sc_optionsetvalue, e);
                    OnSave(var_sc_optionset, var_sc_optionsetvalue);
                    checkLengthAndUncheckAnyOption(var_sc_optionset, var_sc_optionsetvalue, e);

                }

            }

            //Create Label
            var addLabel = document.createElement("label");
            addLabel.style.color = "#000000";
            addLabel.innerHTML = pOption.text;

            var addBr = document.createElement("br"); // it's a 'br' flag

            document.getElementById(var_sc_optionset).nextSibling.appendChild(addInput);
            document.getElementById(var_sc_optionset).nextSibling.appendChild(addLabel);
            document.getElementById(var_sc_optionset).nextSibling.appendChild(addBr);
			}
        }
    }
}

// Check if it is selected
function IsChecked(pText, optionSetValue) {
    //debugger;
    var selectedValue = Xrm.Page.getAttribute(optionSetValue).getValue();

    if (selectedValue != "" && selectedValue != null) {
        var OSVT = selectedValue.split(",");

        for (var i = 0; i < OSVT.length; i++) {
            if (OSVT[i] == pText)
                return true;
        }
    }

    return false;
}

// On Change: checks selected option 
// var_sc_optionsetvalue >> Provide logical-name for field which will
//                          store the multi selected values for Option Set
// optionSet>> Provide logical-name of Option Set field 
function OnChangeSave(optionSet, var_sc_optionsetvalue, e) {
    //debugger;

    var OS = document.getElementById(optionSet);
    var options = Xrm.Page.getAttribute(optionSet).getOptions();
    var getInput = OS.nextSibling.getElementsByTagName("input");
    var result = "";
    var result1 = "";
    var nAgt = navigator.userAgent;
    
    

    for (var i = 0; i < getInput.length; i++) {
        if (getInput[i].checked) {

            result += getInput[i].nextSibling.innerHTML + ",";

            if (nAgt.indexOf("Firefox") != -1) {  //If the broswer is "Firefox"
                result1 += options[i + 1].value + ",";

            }

            else if (nAgt.indexOf("Chrome") != -1 || nAgt.indexOf("IE") != -1) { //If the browser is Chrome or IE

                result1 += options[i].value + ",";

            }

            else if (nAgt.indexOf("Safari") != -1) {  //If the browser id "Safari"

                result1 += options[i + 1].value + ",";

            }
        }
        
    }
}







// On Save/Load: Updates optionset Value field with selected options
function OnSave(optionSet, var_sc_optionsetvalue) {
    //debugger;
    var OS = document.getElementById(optionSet);
    var options = Xrm.Page.getAttribute(optionSet).getOptions();
    var getInput = OS.nextSibling.getElementsByTagName("input");
    var result = "";
    var result1 = "";
    var nAgt = navigator.userAgent;

    for (var i = 0; i < getInput.length; i++) {
        if (getInput[i].checked) {

            result += getInput[i].nextSibling.innerHTML + ",";

            if (nAgt.indexOf("Chrome") != -1 || nAgt.indexOf("IE") != -1) { //If the browser is Chrome or IE

                result1 += options[i].value + ",";

            }
        }
    }

    Xrm.Page.getAttribute(var_sc_optionsetvalue).setValue(result);

}

// On Change: uncheck Any Day/Time as per selected option
function checkLengthAndUncheckAnyOption(optionSet, var_sc_optionsetvalue, e) {
    //debugger;
    var OS = document.getElementById(optionSet);
    var getInput = OS.nextSibling.getElementsByTagName("input");
    var optionSetValue = Xrm.Page.getAttribute(var_sc_optionsetvalue).getValue();
    var checkedOption = e.target.id;
    var resultAllOptions = "";
    var resultSelectedOption = "";

    if (optionSetValue != null) {
        
        var optionId = "";
        var containId = null;

            for (var i = 0; i < getInput.length; i++) {
                optionId = getInput[i].id;
                if (getInput[i].checked) {
                    resultSelectedOption += getInput[i].nextSibling.innerHTML + ",";
                }

                
                
            }
        
    }
}