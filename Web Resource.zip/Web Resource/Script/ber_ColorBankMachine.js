function LoadMain()
{
     var status = Xrm.Page.getAttribute("ber_status").getValue();
     if ( status == 278290001 )
     {
          Xrm.Page.getAttribute("ber_rentalstartdate").setRequiredLevel("required");
      }
}

function AutoPopulateLookup()
{
    if (Xrm.Page.ui.getFormType() == 1)
    {
        //Retrieve Instllation Request Id from Lookup 
        var IR = Xrm.Page.getAttribute("ber_installationrequest");
        var IRValue, IRId;
        var Cols = ['*'];

        if (IR != null)
        {
            IRValue = IR.getValue();

            if (IRValue != null)
            {
                IRId = IRValue[0].id;
            }
        }

        //Retrieve Installation Request record
        var InstallRqst = CrmRestKit.Retrieve('ber_installationrequest', IRId, Cols);

        if (InstallRqst != null)
        {
            if (InstallRqst.ber_DealerId != null)
            {
                var value = new Array();
                value[0] = new Object();
                value[0].id = InstallRqst.ber_DealerId.Id;
                value[0].name = InstallRqst.ber_DealerId.Name;
                value[0].entityType = InstallRqst.ber_DealerId.LogicalName;

                Xrm.Page.getAttribute("ber_dealer").setValue(value);

                var Depot = CrmRestKit.Retrieve('Account', InstallRqst.ber_DealerId.Id, Cols);

                if (Depot != null)
                {
                    if (Depot.ber_DepotId != null)
                    {
                        var DepotLookup = new Array();
                        DepotLookup[0] = new Object();
                        DepotLookup[0].id = Depot.ber_DepotId.Id;
                        DepotLookup[0].name = Depot.ber_DepotId.Name;
                        DepotLookup[0].entityType = Depot.ber_DepotId.LogicalName;

                        Xrm.Page.getAttribute("ber_depot").setValue(DepotLookup);
                    }
                }
            }
        }
    }
}