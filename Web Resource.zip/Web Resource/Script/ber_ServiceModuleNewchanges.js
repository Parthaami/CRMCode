function FilteredPaintExpressItem() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (Xrm.Page.getAttribute("ber_paintexpressitem") != null && Xrm.Page.getAttribute("ber_paintexpressitem") != undefined) {
        if (!isCrmForMobile) {
            document.getElementById("ber_paintexpressitem").disableViewPicker = 0;
        }
        else {
            $("#ber_paintexpressitem").find("img").attr("disableviewpicker", "0");
            //var lookupField = executionContext.getFormContext().getAttribute("ber_paintexpressitem");
            //lookupField.SetParameter("disableViewPicker", "0");
            //var lookupValue = lookupField.getValue();
            //lookupValue.SetParameter("disableViewPicker", "0");
        }
        if (Xrm.Page.getAttribute("customerid").getValue() != null && Xrm.Page.getAttribute("customerid") != undefined) {
            var Painter = (Xrm.Page.getAttribute("customerid").getValue())[0].id;
            if (Painter != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered Paint Express item";
                var view_DGId = "{C7034F4F-6F92-4DD7-BD9D-9B9C1E996380}";
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="ber_paintexpressitemid" select="1" icon="2" preview="1">' +
                   '<row name="result" id="ber_paintexpressitemid">' +
                   '<cell name="ber_toolapprovaldate" width="100" />' +
                   '<cell name="ber_itemid" width="100" />' +
                   '<cell name="ber_name" width="200" />' +
             '</row>' +
             '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                 '<entity name="ber_paintexpressitem">' +
                   '<attribute name="ber_name" />' +
                   '<attribute name="ber_paintexpressitemid" />' +
                   '<attribute name="ber_toolapprovaldate" />' +
                   '<attribute name="ber_itemid" />' +
                   '<order attribute="ber_name" descending="false" />' +
                   '<filter type="and">' +
                '<condition attribute="statuscode" operator="eq" value="278290000"/>' +
                     '<condition attribute="ber_painterid" operator="eq"   value="' + Painter + '" />' +
                   '</filter>' +
                 '</entity>' +
               '</fetch>';
                Xrm.Page.getControl("ber_paintexpressitem").addCustomView(view_DGId, "ber_paintexpressitem", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                Xrm.Page.getControl("ber_paintexpressitem").setDefaultView(view_DGId);

                if (!isCrmForMobile) {
                    document.getElementById("ber_paintexpressitem").disableViewPicker = 1;
                }
                else {
                    $("#ber_paintexpressitem").find("img").attr("disableviewpicker", "1");
                    //var lookupField = executionContext.getFormContext().getAttribute("ber_paintexpressitem");
                    //lookupField.SetParameter("disableViewPicker", "1");
                    //var lookupValue = lookupField.getValue();
                    //lookupValue.SetParameter("disableViewPicker", "1");
                }

            }
        }
    }

}