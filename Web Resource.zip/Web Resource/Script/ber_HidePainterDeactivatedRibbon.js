var serverUrl = Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/";

function UserHasRole(roleName) {


    //Get Business unit id
    var loggedinUser = Xrm.Page.context.getUserId();
    var oDataEndpointUrl = serverUrl;
    oDataEndpointUrl += "SystemUserSet?$select=BusinessUnitId&$filter=SystemUserId eq guid'" + loggedinUser + "'";
    requestResults1 = RestCall(oDataEndpointUrl);
    if (requestResults1 != null && requestResults1.results.length == 1) {
        var BU = requestResults1.results[0];
        var BUid = BU.BusinessUnitId;

        var oDataEndpointUrl = serverUrl;
        oDataEndpointUrl += "RoleSet?$filter=Name eq'" + roleName + "'" + "and BusinessUnitId/Id eq guid'" + BUid.Id + "'";
        requestResults = RestCall(oDataEndpointUrl);

        if (requestResults != null && requestResults.results.length == 1) {
            var role = requestResults.results[0];
            var id = role.RoleId;
            var currentUserRoles = Xrm.Page.context.getUserRoles();
            for (var i = 0; i < currentUserRoles.length; i++) {
                var userRole = currentUserRoles[i];
                if (GuidsAreEqual(userRole, id)) {
                    return true;
                }
            }
        }
    }
    return false;
};

//Rest call Sync
function RestCall(oDataEndpointUrl) {
    var service = getXMLHttpRequest();
    if (service != null) {
        service.open("GET", oDataEndpointUrl, false);
        service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
        service.setRequestHeader("Accept", "application/json, text/javascript, */*");
        service.send(null);
        var requestResults = eval('(' + service.responseText + ')').d;
        return requestResults;
    }
    else
        null;
};


function GuidsAreEqual(guid1, guid2) {
    var isEqual = false;

    if (guid1 == null || guid2 == null) {
        isEqual = false;
    }
    else {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
};

getXMLHttpRequest = function () {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex) {
            return null;
        }
    }
};


function hidebutton1() {
    // var FormType = Xrm.Page.ui.getFormType();
    // if (Xrm.Page.data.entity.getId() != null && Xrm.Page.data.entity.getId() != 'undefined' && Xrm.Page.data.entity.getId() != '' && FormType == 2){
    // var formLabel;
    // var currForm = Xrm.Page.ui.formSelector.getCurrentItem();
    // alert(currForm);
    //formLabel = currForm.getLabel();
    //alert(formLabel);
    //this code to show the ribbon if only the current opened form is Partner, 
    //otherwise remain disable/hidden
    //if (formLabel == "Information" || formLabel == "Painter Form" || formLabel == "Sub Painter Form" || formLabel == "SubDealer Form") //change this with your own specific form name
    //{
    if (UserHasRole("System Administrator")) {
        //alert("admin user");
        return true;
    }

    else if (!UserHasRole("System Administrator")) {
        // alert("non admin");
        return false;
    }
    //you can also apply the different/reverse rule here, for example you want to hide if form is Partner

    //}
    //}
}




