<html><head><meta charset="utf-8"><style type="text/css">P { margin: 0; }</style><style type="text/css">P { margin: 0; }</style><style type="text/css">P { margin: 0; }</style><style type="text/css">P { margin: 0; }</style><style type="text/css">P { margin: 0; }</style></head><body onfocusout="parent.setEmailRange();">
    <iframe width="100%" height="100%" src="https://bpilcrm.bergerindia.com:6585/login.aspx" frameborder="0"></iframe>

</body></html>