//Disable lookups onload of Inventory Location.
function InventoryLocationOnload() {
    //debugger;
    var depot = Xrm.Page.getAttribute("ber_depot").getValue();
    var dealer = Xrm.Page.getAttribute("ber_dealer").getValue();
    var rdc = Xrm.Page.getAttribute("ber_regionaldistributioncenter").getValue();
    if (depot == null && dealer == null && rdc == null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }
    else if (depot != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(true);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(true);
    }
    else if (dealer != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(true);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(true);
    }
    else if (rdc != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(true);
        Xrm.Page.getControl("ber_dealer").setDisabled(true);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }

    if (Xrm.Page.ui.getFormType() != 1) {
        loadIFrame();
    }
    else {
        document.getElementById("IFRAME_IntransitItems").src = "about:blank";
    }
}

//Load Fetch Xml View inside Iframe
function loadIFrame() {
    var inventoylocationid = Xrm.Page.data.entity.getId();

    var FetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"<entity name='ber_stocktransferitems'>" +
"<attribute name='ber_stocktransferitemsid'/>" +
"<attribute name='ber_stocktransfer'/>" +
"<attribute name='ber_requiredquantity'/>" +
"<attribute name='ber_shippedquantity'/>" +
"<attribute name='ber_itemid'/>" +
"<attribute name='ber_condition'/>" +
"<order attribute='ber_stocktransfer' descending='false'/>" +
"<filter type='and'>" +
"<condition attribute='ber_transfertype' operator='eq' value='278290000'/>" +
"<condition attribute='ber_inventorylocationid' operator='eq' value='" + inventoylocationid + "'/>" +
"</filter>" +
"<link-entity name='ber_stocktransfer' from='ber_stocktransferid' to='ber_stocktransfer' alias='aa'>" +
"<filter type='and'>" +
"<condition attribute='ber_status' operator='eq' value='278290001'/>" +
"</filter>" +
"</link-entity>" +
"</entity>" +
"</fetch>";

    var LayoutXML = "<grid name='resultset' object='10030' jump='ber_name' select='1' icon='1' preview='1'>" +
"<row name='result' id='ber_stocktransferitemsid'>" +
"<cell name='ber_stocktransfer' width='100'/>" +
"<cell name='ber_condition' width='100'/>" +
"<cell name='ber_itemid' width='100'/>" +
"<cell name='ber_shippedquantity' width='100'/>" +
"<cell name='ber_requiredquantity' width='200'/>" +
"</row>" +
"</grid>";


    gLoad_IFrameByFetch("IFRAME_IntransitItems", "ber_stocktransferitems", FetchXML, LayoutXML, "{DFF585BE-3E63-4F0C-86DF-F15910B708FE}", 0, 10030);

}


gLoad_IFrameByFetch = function (iFrameId, entityName, fetchXml, layoutXml, defaultAdvancedFindViewId, tabNo, entityTypeCode) {

    var iFrame = document.getElementById(iFrameId);
    if (iFrame != null) {
        iFrame.src = "about:blank";
    }
    else {

        return;

    }
    window.fetchEntity = new FetchViewer(iFrameId);

    fetchEntity.WithParentContext = true;

    fetchEntity.EntityCode = entityTypeCode;

    fetchEntity.FetchXml = fetchXml;

    fetchEntity.LayoutXml = layoutXml;

    fetchEntity.Entity = entityName;
    fetchEntity.QueryId = defaultAdvancedFindViewId;  //"{00000000-0000-0000-00AA-000000666400}"; 

    fetchEntity.RegisterOnTab(tabNo);

    function FetchViewer(iframeId) {
        var Instance = this;
        var vDynamicForm;
        var m_iframeTab;
        var m_iframeDoc;
        var m_iframeShowModalDialogFunc = null;
        var m_windowAutoFunc = null;
        Instance.WithParentContext = false;
        Instance.EntityCode = 0;
        Instance.Entity = "";
        Instance.Iframe = null;
        Instance.FetchXml = "";
        Instance.QueryId = "";
        Instance.LayoutXml = "";
        Instance.RegisterOnTab = function (tabIndex) {
            Instance.Iframe = document.getElementById(iframeId);
            if (!Instance.Iframe) {
                return alert("Iframe " + iframeId + " is undefined");
            }
            m_iframeDoc = getIframeDocument();
            var loadingGifHTML = "<table height='100%' width='100%' style='cursor:wait'>";
            loadingGifHTML += "<tr>";
            loadingGifHTML += "<td valign='middle' align='center'>";
            loadingGifHTML += "<img alt='' src='/_imgs/AdvFind/progress.gif'/>";
            loadingGifHTML += "<div/><b>Loading View...</b>";
            loadingGifHTML += "</td></tr></table>";
            m_iframeDoc.body.innerHTML = loadingGifHTML;
            if (parseInt("0" + tabIndex) == 0) {
                Instance.Refresh();
            }
            else {
                Instance.Iframe.attachEvent("onreadystatechange", RefreshOnReadyStateChange);
            }

        }

        function RefreshOnReadyStateChange() {
            if (Instance.Iframe.readyState != 'complete') {
                return;
            }

            Instance.Refresh();

        }


        Instance.Refresh = function () {
            if (!Instance.Iframe) {
                return alert("Iframe " + iframeId + " is undefined");
            }

            m_iframeDoc = getIframeDocument();
            Instance.Iframe.detachEvent("onreadystatechange", RefreshOnReadyStateChange);
            var create = m_iframeDoc.createElement;
            var append1 = m_iframeDoc.appendChild;
            vDynamicForm = create("<FORM name='vDynamicForm' method='post'>");
            var append2 = vDynamicForm.appendChild;
            append2(create("<INPUT type='hidden' name='FetchXml'>"));
            append2(create("<INPUT type='hidden' name='LayoutXml'>"));
            append2(create("<INPUT type='hidden' name='EntityName'>"));
            append2(create("<INPUT type='hidden' name='DefaultAdvFindViewId'>"));
            append2(create("<INPUT type='hidden' name='ViewType'>"));
            append1(vDynamicForm);
            vDynamicForm.action = "/" + ORG_UNIQUE_NAME + "/AdvancedFind/fetchData.aspx";
            vDynamicForm.FetchXml.value = Instance.FetchXml;
            vDynamicForm.LayoutXml.value = Instance.LayoutXml;
            vDynamicForm.EntityName.value = Instance.Entity;
            vDynamicForm.DefaultAdvFindViewId.value = Instance.QueryId;
            vDynamicForm.ViewType.value = 1039;
            vDynamicForm.submit();
            Instance.Iframe.attachEvent("onreadystatechange", OnViewReady);
        }


        function OnViewReady() {
            if (Instance.Iframe.readyState != 'complete') {
                return;
            }
            Instance.Iframe.style.border = 0;
            Instance.Iframe.detachEvent("onreadystatechange", OnViewReady);
            if (Instance.WithParentContext == true) {
                getIframeWindow().open = OnWindowOpen;
            }

            if (m_iframeShowModalDialogFunc == null) {
                m_iframeShowModalDialogFunc = getIframeWindow().showModalDialog;
                getIframeWindow().showModalDialog = OnIframeShowModalDialog;
            }

            if (Instance.EntityCode > 0) {
                if (m_windowAutoFunc == null) {
                    m_windowAutoFunc = window.auto;
                    window.auto = OnWindowAuto;
                }
            }

            m_iframeDoc = getIframeDocument();
            m_iframeDoc.body.scroll = "no";
            m_iframeDoc.body.style.padding = "0px";
        }

        function OnWindowOpen(url, name, features) {
            //new window 
            if (url.indexOf('?') == -1) {
                if (url.indexOf('userdefined') == -1) {
                    url = url + "?_CreateFromType=" + crmForm.ObjectTypeCode + "&_CreateFromId=" + crmForm.ObjectId;
                }
                else {
                    url = url + "?_CreateFromType=" + crmForm.ObjectTypeCode + "&_CreateFromId=" + crmForm.ObjectId + "&etc=" + Instance.EntityCode + "#";
                }
            }
            return window.open(url, name, features);
        }


        function OnIframeShowModalDialog(sUrl, vArguments, sFeatures) {
            m_iframeShowModalDialogFunc(sUrl, vArguments, sFeatures);
            Instance.Refresh();
        }


        function OnWindowAuto(otc) {
            if (otc == Instance.EntityCode) {
                getIframeDocument().all.crmGrid.Refresh();
            }
            m_windowAutoFunc(otc);
        }


        function getIframeDocument() {
            return getIframeWindow().document;
        }


        function getIframeWindow() {
            return Instance.Iframe.contentWindow;
        }
    }
}









//Disable lookups onchange of depot.
function depot_onchange() {
    var depot = Xrm.Page.getAttribute("ber_depot").getValue();
    if (depot == null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }
    else if (depot != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(true);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(true);
    }
}


//Disable lookups onchange of dealer.
function dealer_onchange() {
    var dealer = Xrm.Page.getAttribute("ber_dealer").getValue();
    if (dealer == null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }
    else if (dealer != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(true);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(true);
    }
}


//Disable lookups onchange of rdc.
function rdc_onchange() {
    var rdc = Xrm.Page.getAttribute("ber_regionaldistributioncenter").getValue();
    if (rdc == null) {
        Xrm.Page.getControl("ber_depot").setDisabled(false);
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }
    else if (rdc != null) {
        Xrm.Page.getControl("ber_depot").setDisabled(true);
        Xrm.Page.getControl("ber_dealer").setDisabled(true);
        Xrm.Page.getControl("ber_regionaldistributioncenter").setDisabled(false);
    }
}