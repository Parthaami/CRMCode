function onloadstartdateremove() {

    if (Xrm.Page.getAttribute("ber_leadtype") != null) {
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
        var statuscode = Xrm.Page.getAttribute("statuscode").getValue();
        if (b != null) {
            if (b == 278290002 && statuscode == 1) {
                Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (UserHasRole("Call Center User") || ("Call Center User Additional Functionalities")) {
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
                    Xrm.Page.ui.controls.get("ber_startdate").setVisible(false);
                    Xrm.Page.ui.controls.get("ber_enddate").setVisible(false);
                }


                else if(UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")){
                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                    Xrm.Page.ui.controls.get("ber_startdate").setVisible(true);
                    Xrm.Page.ui.controls.get("ber_enddate").setVisible(true);
                }
                // Xrm.Page.getAttribute("leadsourcecode").setRequiredLevel("required");
            }
        }
    }
}