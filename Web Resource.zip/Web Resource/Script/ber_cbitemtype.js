function fcbitemtype()
{
	if(Xrm.Page.getAttribute("ber_itemtype").getValue() != null)
	{
		var itemtypevalue = Xrm.Page.getAttribute("ber_itemtype").getValue();
		if(itemtypevalue == 278290001)
		{
			Xrm.Page.getAttribute("ber_machinetype").setRequiredLevel("required");
			Xrm.Page.getControl("ber_machinetype").setVisible(true);
                                                            Xrm.Page.getControl("ber_brand").setVisible(true);
		}
		else
		{
			Xrm.Page.getAttribute("ber_machinetype").setRequiredLevel("none");
			Xrm.Page.getControl("ber_machinetype").setVisible(false);
			Xrm.Page.getAttribute("ber_machinetype").setValue(null);
                                                            Xrm.Page.getControl("ber_brand").setVisible(false);
		}
	}
	else
	{
		Xrm.Page.getAttribute("ber_machinetype").setRequiredLevel("none");
		Xrm.Page.getControl("ber_machinetype").setVisible(false);
		Xrm.Page.getAttribute("ber_machinetype").setValue(null);
                                        Xrm.Page.getControl("ber_brand").setVisible(false);
 
	}
}