function CaptureDate() {

    if (Xrm.Page.getAttribute("statuscode") != null && Xrm.Page.getAttribute("statuscode") != undefined) {

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }
        var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();

        //  var today = new Date();
        var today = getServerTime();

        if (leadtype == 278290002) {

            if (statuscodevalue == 278290004) {
                //     alert("1");

                if (Xrm.Page.getAttribute("ber_capturedealerallocateddate") != undefined && Xrm.Page.getAttribute("ber_capturedealerallocateddate").getValue() == null) {

                    //alert(today);

                    var CaptureDate = Xrm.Page.getAttribute("ber_capturedealerallocateddate").setValue(today);

                    Xrm.Page.getAttribute("ber_capturedealerallocateddate").setSubmitMode("always");

                }
            }

            else if (statuscodevalue == 278290009) {

                if (Xrm.Page.getAttribute("ber_painterallocationdate") != undefined && Xrm.Page.getAttribute("ber_painterallocationdate").getValue() == null) {
                    //    alert("2");
                    //alert(today);
                    var CaptureDate = Xrm.Page.getAttribute("ber_painterallocationdate").setValue(today);

                    Xrm.Page.getAttribute("ber_painterallocationdate").setSubmitMode("always");
                }
            }


            else if (statuscodevalue == 278290005) {
                if (Xrm.Page.getAttribute("ber_wondate") != undefined && Xrm.Page.getAttribute("ber_wondate").getValue() == null) {
                    //      alert("3");
                    var CaptureDate = Xrm.Page.getAttribute("ber_wondate").setValue(today);

                    Xrm.Page.getAttribute("ber_wondate").setSubmitMode("always");

                }
            }


            else if (statuscodevalue == 278290006) {

                if (Xrm.Page.getAttribute("ber_capturejobcompleteddate") != undefined && Xrm.Page.getAttribute("ber_capturejobcompleteddate").getValue() == null) {
                    //         alert("4");
                    var CaptureDate = Xrm.Page.getAttribute("ber_capturejobcompleteddate").setValue(today);

                    Xrm.Page.getAttribute("ber_capturejobcompleteddate").setSubmitMode("always");

                }

            }

        }

        else if (leadtype == 278290001) {

            if (statuscodevalue == 278290006) {

                if (Xrm.Page.getAttribute("ber_capturejobcompleteddate") != undefined && Xrm.Page.getAttribute("ber_capturejobcompleteddate").getValue() == null) {
                    //         alert("4");
                    var CaptureDate = Xrm.Page.getAttribute("ber_capturejobcompleteddate").setValue(today);

                    Xrm.Page.getAttribute("ber_capturejobcompleteddate").setSubmitMode("always");

                }

            }

        }

    }
}

function ShowHideFields() {
    var status = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
    if (Xrm.Page.getAttribute("subject").getValue() != null) {
        Xrm.Page.data.setFormDirty(false);
        var Id = Xrm.Page.data.entity.getId();
        if (Id != "") {
            Xrm.Utility.openEntityForm("lead", Id.replace(/[{}]/g, ""));
        }
    }
}

function SetStatusDealer() {

    //  var today = new Date();
    if (Xrm.Page.getAttribute("ber_leadtype") !== undefined && Xrm.Page.getAttribute("ber_leadtype") !== null) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
    }
    if (Xrm.Page.getAttribute("ber_dealerid") != undefined && Xrm.Page.getAttribute("ber_dealerid").getValue() != null && Xrm.Page.getAttribute("ber_masterpainterid").getValue() == null) {
        var Dealer = Xrm.Page.data.entity.attributes.get("ber_dealerid").getValue();

        var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");
        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        if (Dealer != null && StatusReasonValue == 278290032 && leadtype == 278290002) {

            // if (Xrm.Page.getAttribute("ber_capturedealerallocationdate") != undefined && Xrm.Page.getAttribute("ber_capturedealerallocationdate").getValue() == null) {

            //    var CaptureDate = Xrm.Page.getAttribute("ber_capturedealerallocationdate").setValue(today);
            //       Xrm.Page.getAttribute("ber_capturedealerallocationdate").setSubmitMode("always");
            //    }
            StatusReason.setValue(278290004);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
            Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
        }
    }
    else if (Xrm.Page.getAttribute("ber_masterpainterid") != undefined && Xrm.Page.getAttribute("ber_masterpainterid").getValue() != null && Xrm.Page.getAttribute("ber_dealerid").getValue() != null) {

        var Painter = Xrm.Page.data.entity.attributes.get("ber_masterpainterid").getValue();
        var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");
        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        if (Painter != null && StatusReasonValue == 278290004 && leadtype == 278290002) {

            // if (Xrm.Page.getAttribute("ber_painterallocationdate") != undefined && Xrm.Page.getAttribute("ber_painterallocationdate").getValue() == null) {

            //   var CaptureDate = Xrm.Page.getAttribute("ber_painterallocationdate").setValue(today);
            //   Xrm.Page.getAttribute("ber_painterallocationdate").setSubmitMode("always");
            //  }

            StatusReason.setValue(278290009);
            Xrm.Page.getAttribute("statuscode").setSubmitMode("always");
            Xrm.Page.ui.controls.get("statuscode").setDisabled(true);
        }
    }
}







function SetLeadSourceOnly() {
    if (Xrm.Page.getAttribute("statuscode") != undefined && Xrm.Page.getAttribute("statuscode") != null) {
        // var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        // var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode");
        var StatusReasonValue = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        if (StatusReasonValue == 278290007) {
            if (Xrm.Page.getControl("leadsourcecode") != null)
                Xrm.Page.getControl("leadsourcecode").setDisabled(false);




        }

        else if (StatusReasonValue == 1) {
            if (Xrm.Page.getControl("leadsourcecode") != null) {
                Xrm.Page.getControl("leadsourcecode").setDisabled(false);
                Xrm.Page.getAttribute("leadsourcecode").setRequiredLevel("required");
            }


        }

    }
}


function LeadSource_RetailHomeDecor() {

    if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null) {

        var LeadType = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (LeadType == 278290001) {

            var b = Xrm.Page.ui.controls.get("leadsourcecode");

            b.removeOption("278290033");
            b.removeOption("278290034");
            b.removeOption("278290035");

        }

        else {

        }

    }

}












var xmlHttp;
function getServerTime() {
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD', window.location.href.toString(), false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    // addMinutes(xmlHttp.getResponseHeader("Date"), 330)
    var addmin = addMinutes(xmlHttp.getResponseHeader("Date"));

    return addmin
}

function addMinutes(date) {
    var d = new Date(date);
    // alert(typeof (d));
    //return new Date(d.getTime() + 330 * 60000);
    //d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000);
    return d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000)

}