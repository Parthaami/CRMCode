function getLeadData(executionObj) {
    if (Xrm.Page.getAttribute("ber_lead") != null && Xrm.Page.getAttribute("ber_lead") != undefined) {
        if (Xrm.Page.getAttribute("ber_otherpaintertype") != null && Xrm.Page.getAttribute("ber_otherpaintertype") != undefined) {
            var OtherPainterType = Xrm.Page.getAttribute("ber_otherpaintertype").getValue();
            var lead = Xrm.Page.getAttribute("ber_lead").getValue();
            //Form type codes: Create (1), Update (2), Read Only (3), Disabled (4), Bulk Edit (6)
            var FormType = Xrm.Page.ui.getFormType();

        }
        if (lead != null && lead != undefined) {
            var leadId = lead[0].id;
            // alert(lead);
            var fetchxml = '<fetch distinct="false" mapping="logical" output-format="xml-platform" version="1.0">' +
                                 '<entity name="ber_otherpainter">' +
                                  '<attribute name="ber_otherpainterid"/>' +
                                   '<attribute name="createdon"/>' +
                                   '<attribute name="ber_name"/>' +
                                   '<attribute name="ber_otherpaintertype"/>' +
                                   '<attribute name="ber_lead"/>' +
                                   '<attribute name="ber_otherpainterassignment"/>' +
                                   '<order descending="false" attribute="ber_name"/>' +
                                   '<filter type="and">' +
                                   '<condition attribute="ber_otherpaintertype" operator="eq" value="' + OtherPainterType + '" />' +
                                   '</filter>' +
                                   '<link-entity name="lead" from="leadid" to="ber_lead" alias="aa">' +
                                   '<filter type="and">' +
                                   '<condition attribute="leadid"  uitype="lead" value="' + leadId + '" operator="eq"/>' +
                                   '</filter>' +
                                   '</link-entity>' +
                                    '</entity>' +
                                    '</fetch>';

            var retrieved = XrmServiceToolkit.Soap.Fetch(fetchxml);
            var RecordLength = retrieved.length;
            // alert(RecordLength);
            //ar defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
            // var leadotherPainterType = retrieved[0].attributes["ber_otherpaintertype"].value;
            if (FormType == 1 && RecordLength == 1) {
                alert("Already one record of similar type is present with the lead");
                executionObj.getEventArgs().preventDefault();

            }

            else if (FormType == 2) {
                Xrm.Page.ui.controls.get("ber_otherpaintertype").setDisabled(true);
            }

            else {

            }


        }

    }
}