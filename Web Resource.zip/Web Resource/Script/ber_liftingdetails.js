function ContactChange() {
    if (Xrm.Page.getAttribute("ber_contactid").getValue() != null && Xrm.Page.getAttribute("ber_contactid").getValue() != undefined) {
        var contact = Xrm.Page.getAttribute("ber_contactid").getValue();
        if (contact != null && contact != undefined && contact[0].id != null) {

            //Need to change....
            //var columns = ['ber_DealerId'];
            //var filter = "ContactId eq guid'" + contact[0].id + "'";
            //var collection = CrmRestKit.RetrieveMultiple('Contact', columns, filter);
            //
            //contact[0].id.replace("{", "").replace("}", "")
            var collection;
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_dealerid_value&$filter=contactid eq " + contact[0].id.replace("{", "").replace("}", ""),
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                    XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                },
                async: false,
                success: function (data, textStatus, xhr) {
                    collection = data;
                    for (var i = 0; i < collection.value.length; i++) {
                        var _ber_dealerid_value = collection.value[i]["_ber_dealerid_value"];
                        var _ber_dealerid_value_formatted = collection.value[i]["_ber_dealerid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_dealerid_value_lookuplogicalname = collection.value[i]["_ber_dealerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    }
                },
                error: function (xhr, textStatus, errorThrown) {
                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                }
            });


            if (collection != null && collection.value != null && collection.value[0] != null) {
                var DealerId = collection.value[0]["_ber_dealerid_value"];
                var value = new Array();
                value[0] = new Object();
                value[0].id = DealerId.Id;
                value[0].name = DealerId.Name;
                value[0].entityType = "account";

                if (DealerId.Id != null) {
                    Xrm.Page.getAttribute("ber_dealerid").setValue(value);
                    Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");
                } else {
                    Xrm.Page.getAttribute("ber_dealerid").setValue(null);
                }
                onchangecontact()
            }
        }
    }
}

function filterPainterMeetLookup() {
    if (Xrm.Page.getAttribute("ber_contactid").getValue() != null && Xrm.Page.getAttribute("ber_contactid").getValue() != undefined) {
        var contact = Xrm.Page.getAttribute("ber_contactid").getValue();
        if (contact != null && contact != undefined && contact[0].id != null) {
            Xrm.Page.getControl("ber_paintermeetid").setDisabled(false);
            if (Xrm.Page.getAttribute("ber_enteredfrom").getValue() != null && Xrm.Page.getAttribute("ber_enteredfrom").getValue() != undefined) {
                var contactId = contact[0].id,
                contactType = contact[0].entityType,
                viewDisplayName = null,
                viewId = null,
                isDefaultView = true,
                layoutxml = '<grid name="resultset" object="10052" jump="ber_name" select="1" icon="1" preview="1">' +
                            '<row name="result" id="ber_paintermeetid">' +
                            '<cell name="ber_name" width="200"/>' +
                            '<cell name="ber_depot" width="150"/>' +
                            '<cell name="ab.ber_type" width="150" disableSorting="1"/>' +
                            '<cell name="createdon" width="100"/>' +
                            '</row></grid>';

                var today = new Date();
                var month = today.getMonth() + 1;
                var todaydate = today.getFullYear() + '-' + month + '-' + today.getDate();

                enteredBy = Xrm.Page.getAttribute("ber_enteredfrom").getValue();
                if (enteredBy != null && enteredBy == "278290001")//Painter
                {
                    fetchxml =
						'<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
						'<entity name="ber_paintermeet">' +
						'<attribute name="ber_name" />' +
						'<attribute name="createdon" />' +
						'<attribute name="ber_depot" />' +
						'<attribute name="ber_dealer" />' +
						'<attribute name="ber_paintermeetid" />' +
						'<order attribute="ber_name" descending="false" />' +
						'<link-entity name="ber_paintermeetcontact" from="ber_paintermeet" to="ber_paintermeetid" alias="aa">' +
						'<filter type="and">' +
						'<condition attribute="statecode" operator="eq" value="0" />' +
						'<condition attribute="ber_contact" operator="eq" value="' + contact[0].id + '" />' +
						'</filter>' +
						'</link-entity>' +
						'<link-entity name="ber_meet" from="ber_meetid" to="ber_meet" alias="ab">' +
                        '<attribute name="ber_type"/>' +
						'<filter type="and">' +
						'<condition attribute="ber_paintercall" operator="eq" value="1" />' +
                        '<condition attribute="ber_schemerequired" operator="eq" value="1" />' +
						'<filter type="or">' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="gt" value="' + todaydate + '" />' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="null" />' +
						'</filter></filter>' +
						'</link-entity>' +
						'</entity>' +
						'</fetch>';
                }
                else {
                    fetchxml =
						'<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
						'<entity name="ber_paintermeet">' +
						'<attribute name="ber_name" />' +
						'<attribute name="createdon" />' +
						'<attribute name="ber_depot" />' +
						'<attribute name="ber_dealer" />' +
						'<attribute name="ber_paintermeetid" />' +
						'<order attribute="ber_name" descending="false" />' +
						'<link-entity name="ber_paintermeetcontact" from="ber_paintermeet" to="ber_paintermeetid" alias="aa">' +
						'<filter type="and">' +
						'<condition attribute="statecode" operator="eq" value="0" />' +
						'<condition attribute="ber_contact" operator="eq" value="' + contact[0].id + '" />' +
						'</filter>' +
						'</link-entity>' +
						'<link-entity name="ber_meet" from="ber_meetid" to="ber_meet" alias="ab">' +
                        '<attribute name="ber_type"/>' +
						'<filter type="and">' +
						'<condition attribute="ber_dealercall" operator="eq" value="1" />' +
                        '<condition attribute="ber_schemerequired" operator="eq" value="1" />' +
						'<filter type="or">' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="gt" value="' + todaydate + '" />' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="null" />' +
						'</filter></filter>' +
						'</link-entity>' +
						'</entity>' +
						'</fetch>';
                }
                if (contactType == "contact") {
                    viewDisplayName = 'Related PainterMeet (Contact-PainterMeet)';
                    // viewId = GetuniqueGuid();
                    // viewId = Xrm.Page.getControl('ber_paintermeetid').getDefaultView();
                    var painterViewId = "{BD469418-9757-41C0-8255-2A54C18AB710}";
                    Xrm.Page.getControl('ber_paintermeetid').addCustomView(painterViewId, 'ber_paintermeet', viewDisplayName, fetchxml, layoutxml, isDefaultView);
                    Xrm.Page.getControl('ber_paintermeetid').setDefaultView(painterViewId);
                }
            }
        }
        else {
            //If painter is not selected disable painter meet lookup as well.
            Xrm.Page.getControl("ber_paintermeetid").setDisabled(true);
        }
    }
    else {
        //If painter is not selected disable painter meet lookup as well.
        Xrm.Page.getControl("ber_paintermeetid").setDisabled(true);
    }
}

function onchangecontact() {
    Xrm.Page.getAttribute("ber_paintermeetid").setValue(null);
}

function onloadenteredby() {
    if (Xrm.Page.getAttribute("ber_contactid").getValue() != null && Xrm.Page.getAttribute("ber_contactid").getValue() != undefined && Xrm.Page.getAttribute("ber_enteredfrom").getValue() == null) {
        Xrm.Page.getAttribute("ber_enteredfrom").setValue(278290001);
        Xrm.Page.getAttribute("ber_enteredfrom").setSubmitMode("always");
    }
}

function filterDealerLookup() {
    //debugger;
    if (Xrm.Page.getAttribute("ber_paintermeetid").getValue() != null && Xrm.Page.getAttribute("ber_paintermeetid").getValue() != undefined) {
        var MeetPlanningLookup = Xrm.Page.getAttribute("ber_paintermeetid").getValue();

        //Need to change
        //var meetPlanningColumns = ['ber_Depot'];
        //var meetPlanningFilter = "ber_paintermeetId eq guid'" + MeetPlanningLookup[0].id + "'";
        //var meetPlanningCollection = CrmRestKit.RetrieveMultiple('ber_paintermeet', meetPlanningColumns, meetPlanningFilter);
        //

        var meetPlanningCollection;
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintermeets?$select=_ber_depot_value&$filter=ber_paintermeetid eq " + MeetPlanningLookup[0].id.replace("{", "").replace("}", ""),
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: false,
            success: function (data, textStatus, xhr) {
                meetPlanningCollection = data;
                for (var i = 0; i < meetPlanningCollection.value.length; i++) {
                    var _ber_depot_value = meetPlanningCollection.value[i]["_ber_depot_value"];
                    var _ber_depot_value_formatted = meetPlanningCollection.value[i]["_ber_depot_value@OData.Community.Display.V1.FormattedValue"];
                    var _ber_depot_value_lookuplogicalname = meetPlanningCollection.value[i]["_ber_depot_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });

        if (meetPlanningCollection != null && meetPlanningCollection.value != null && meetPlanningCollection.value.length > 0) {
            if (meetPlanningCollection.value[0]["_ber_depot_value"] != null && meetPlanningCollection.value[0] != null) {

                //
                // var depotColumns = ['ber_CityId'];
                // var depotFilter = "ber_depotId eq guid'" + meetPlanningCollection.results[0].ber_Depot.Id + "'";
                // var depotCollection = CrmRestKit.RetrieveMultiple('ber_depot', depotColumns, depotFilter);
                //
                var depotCollection;

                $.ajax({
                    type: "GET",
                    contentType: "application/json; charset=utf-8",
                    datatype: "json",
                    url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_depots?$select=_ber_cityid_value&$filter=ber_depotid eq " + meetPlanningCollection.value[0]["_ber_depot_value"].replace("{", "").replace("}", ""),
                    beforeSend: function (XMLHttpRequest) {
                        XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                        XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                        XMLHttpRequest.setRequestHeader("Accept", "application/json");
                        XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    },
                    async: false,
                    success: function (data, textStatus, xhr) {
                        depotCollection = data;
                        for (var i = 0; i < depotCollection.value.length; i++) {
                            var _ber_cityid_value = depotCollection.value[i]["_ber_cityid_value"];
                            var _ber_cityid_value_formatted = depotCollection.value[i]["_ber_cityid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_cityid_value_lookuplogicalname = depotCollection.value[i]["_ber_cityid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        }
                    },
                    error: function (xhr, textStatus, errorThrown) {
                        Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                    }
                });

                if (depotCollection != null && depotCollection.results != null && depotCollection.results.length > 0) {
                    if (depotCollection.results[0].ber_CityId != null && depotCollection.results[0].ber_CityId.Id != null) {
                        var painterCityId = depotCollection.results[0].ber_CityId.Id;
                        viewDisplayName = null;
                        viewId = null;
                        isDefaultView = true;

                        layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                        '<row name="result" id="accountid">' +
					    '<cell name="name" width="200" />' +
                        '<cell name="accountnumber" width="100" />' +
						//Ticket A0985, Add Customer Category to Dealers view
						'<cell name="accountcategorycode" width="100" />' +
                        '<cell name="telephone1" width="100" />' +
                        '<cell name="customertypecode" width="100" />' +
                        '<cell name="ber_depotid" width="100" />' +
                        '<cell name="address1_city" width="100" />' +
					    '<cell name="address1_line2" width="150" />' +
                        '<cell name="address1_line3" width="150" />' +
                        '</row>' +
					    '</grid>';

                        /*
                        // Ticket # A0775
                        fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="account">' +
                        '<attribute name="name" />' +
                        '<attribute name="accountnumber" />' +
                        '<attribute name="telephone1" />' +
                        '<attribute name="customertypecode" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="accountid" />' +
                        '<attribute name="address1_line2" />' +
                        '<attribute name="address1_line3" />' +
                        '<attribute name="address1_city" />' +
                        '<order attribute="name" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="parentaccountid" operator="null" />' +
                        '</filter>' +
                        '<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="aa">' +
                        '<attribute name="ber_cityid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
                        '</filter>' +
                        '</link-entity>' +
                        '</entity>' +
                        '</fetch>';
                        */

                        //Commented for ticket # A0809
                        /*
                        fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="account">' +
                        '<attribute name="name" />' +
                        '<attribute name="accountnumber" />' +
                        '<attribute name="telephone1" />' +
                        '<attribute name="customertypecode" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="accountid" />' +
                        '<attribute name="address1_line2" />' +
                        '<attribute name="address1_line3" />' +
                        '<attribute name="address1_city" />' +
                        '<order attribute="name" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="parentaccountid" operator="null" />' +
                        '</filter>' +
                        '<filter type="and">' +
                        '<condition attribute="statecode" operator="eq" value="0"/>' +
                        '</filter>' +
                        '<filter type="and">' +
                        '<condition attribute="customertypecode" operator="eq" value="5"/>' +
                        '</filter>' +
                        '<filter type="and">' +
                        '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
                        '</filter>' +
                        '<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="aa">' +
                        '<attribute name="ber_cityid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
                        '</filter>' +
                        '</link-entity>' +
                        '</entity>' +
                        '</fetch>';
                        */

                        //Commented -Reference CR A1057 - Implement New Business Rule
                        /*
                        fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="account">' +
                        '<attribute name="name" />' +
                        '<attribute name="accountnumber" />' +
                        '<attribute name="telephone1" />' +
                        '<attribute name="customertypecode" />' +
						//Ticket A0985, Add Customer Category to Dealers view
						'<attribute name="accountcategorycode" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="accountid" />' +
                        '<attribute name="address1_line2" />' +
                        '<attribute name="address1_line3" />' +
                        '<attribute name="address1_city" />' +
                        '<order attribute="name" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="parentaccountid" operator="null" />' +
                        '</filter>' +
                        '<filter type="and">' +
                        //Dealer Status = Active
                        '<condition attribute="statecode" operator="eq" value="0"/>' +
                        '</filter>' +
                        '<filter type="and">' +
                        //Customer Type => 2 = Acroma Dlr, 3 = ALT DSTRB , 5 = Dealer and 9 = Ultratech
						// Removed value 2  for ticket A0985
                        '<condition attribute="customertypecode" operator="in"><value>3</value><value>5</value><value>9</value></condition>' +
                        '</filter>' +
                        '<filter type="and">' +
						//Ticket A0985, Add Customer Category: GC - 278290000/SC - 278290001/STA - 2/FS - 278290003
						//Ticket A1051, Add Customer Category: SGC - 278290004
						'<condition attribute="accountcategorycode" operator="in"><value>278290000</value><value>278290001</value><value>2</value><value>278290003</value><value>278290004</value></condition>' +
						'</filter>' +
						'<filter type="and">' +
                        // Sales Channel 1 = Retail
                        '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
                        '</filter>' +
                        '<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="aa">' +
                        '<attribute name="ber_cityid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
                        '</filter>' +
                        '</link-entity>' +
                        '</entity>' +
                        '</fetch>';
						*/

                        //Reference CR A1057 - New Business Rule to Filter Dealer
                        //=======================================================
                        //Dealer Lookup will show all active  Dealer (Parent Account) within Depot�s City  which are 

                        //  1. Belongs to Retail Sales Channel
                        //  2. Dealer Participated in Master Painter Meet Plan - Dealers have Master Painter Meet Plan or Dealer is selected 
                        //     to sell product for Master Painter Meet Scheme
                        //=======================================================

                        fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="account">' +
                        '<attribute name="name" />' +
                        '<attribute name="accountnumber" />' +
                        '<attribute name="telephone1" />' +
                        '<attribute name="customertypecode" />' +
						//Ticket A0985, Add Customer Category to Dealers view
						'<attribute name="accountcategorycode" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="accountid" />' +
                        '<attribute name="address1_line2" />' +
                        '<attribute name="address1_line3" />' +
                        '<attribute name="address1_city" />' +
                        '<order attribute="name" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="parentaccountid" operator="null" />' +
                        '</filter>' +
                        '<filter type="and">' +
                        //Dealer Status = Active
                        '<condition attribute="statecode" operator="eq" value="0"/>' +
                        '</filter>' +
						'<filter type="and">' +
                        // Sales Channel 1 = Retail
                        '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
                        '</filter>' +
						'<filter type="and">' +
						// Dealer Participated in Master Painter Meet Plan 
						//   - Dealers have Master Painter Meet Plan or Dealer is selected to sell product for Master Painter Meet Scheme
						'<condition attribute="ber_mpdealer" operator="eq" value="1" />' +
						'</filter>' +
                        '<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="d">' +
                        '<attribute name="ber_cityid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
                        '</filter>' +
                        '</link-entity>' +
                        '</entity>' +
                        '</fetch>';


                        viewDisplayName = 'Dealers';
                        //viewId = GetuniqueGuid();
                        //viewId = Xrm.Page.getControl('ber_dealerid').getDefaultView();
                        var dealerViewId = "{15C63745-0A6E-4322-8416-A62C84D90278}";

                        Xrm.Page.getControl('ber_dealerid').addCustomView(dealerViewId, 'account', viewDisplayName, fetchxml, layoutxml, isDefaultView);
                        Xrm.Page.getControl('ber_dealerid').setDefaultView(dealerViewId);
                        Xrm.Page.getControl("ber_dealerid").setDisabled(false);
                    }
                }
            }
        }
    }
    else {
        Xrm.Page.getControl("ber_dealerid").setDisabled(true);
    }
}

/*
function filterDealerLookup() {
if (Xrm.Page.getAttribute("ber_paintermeetid").getValue() != null && Xrm.Page.getAttribute("ber_paintermeetid").getValue() != undefined) {
var MeetPlanningLookup = Xrm.Page.getAttribute("ber_paintermeetid").getValue();
var meetPlanningColumns = ['ber_Depot'];
var meetPlanningFilter = "ber_paintermeetId eq guid'" + MeetPlanningLookup[0].id + "'";
var meetPlanningCollection = CrmRestKit.RetrieveMultiple('ber_paintermeet', meetPlanningColumns, meetPlanningFilter);
if (meetPlanningCollection != null && meetPlanningCollection.results != null && meetPlanningCollection.results.length > 0) {
if (meetPlanningCollection.results[0].ber_Depot != null && meetPlanningCollection.results[0].ber_Depot.Id != null) {
var depotColumns = ['ber_CityId'];
var depotFilter = "ber_depotId eq guid'" + meetPlanningCollection.results[0].ber_Depot.Id + "'";
var depotCollection = CrmRestKit.RetrieveMultiple('ber_depot', depotColumns, depotFilter);
if (depotCollection != null && depotCollection.results != null && depotCollection.results.length > 0) {
if (depotCollection.results[0].ber_CityId != null && depotCollection.results[0].ber_CityId.Id != null) {
var painterCityId = depotCollection.results[0].ber_CityId.Id;
viewDisplayName = null;
viewId = null;
isDefaultView = true;

layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
'<row name="result" id="accountid">' +
'<cell name="name" width="200" />' +
'<cell name="accountnumber" width="100" />' +
'<cell name="customertypecode" width="100" />' +
'<cell name="ber_depotid" width="100" />' +
'<cell name="address1_city" width="100" />' +
'<cell name="address1_line2" width="150" />' +
'<cell name="address1_line3" width="150" />' +
'</row>' +
'</grid>';

fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
'<entity name="account">' +
'<attribute name="name" />' +
'<attribute name="accountnumber" />' +
'<attribute name="customertypecode" />' +
'<attribute name="ber_depotid" />' +
'<attribute name="accountid" />' +
'<attribute name="address1_line2" />' +
'<attribute name="address1_line3" />' +
'<attribute name="address1_city" />' +
'<order attribute="name" descending="false" />' +
'<filter type="and">' +
'<condition attribute="parentaccountid" operator="null" />' +
'</filter>' +
'<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="aa">' +
'<attribute name="ber_cityid" />' +
'<filter type="and">' +
'<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
'</filter>' +
'</link-entity>' +
'</entity>' +
'</fetch>';

viewDisplayName = 'Dealers';
viewId = GetuniqueGuid();

Xrm.Page.getControl('ber_dealerid').addCustomView(viewId, 'account', viewDisplayName, fetchxml, layoutxml, isDefaultView);
Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId);
Xrm.Page.getControl("ber_dealerid").setDisabled(false);
}
}
}
}
}
else {
Xrm.Page.getControl("ber_dealerid").setDisabled(true);
}
}

*/

function GetuniqueGuid() {
    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };
    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';
};

function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) {
        }
        else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

function setdisableonloadofliftingdetails() {
    if (Xrm.Page.getAttribute("ber_enteredfrom").getValue() != null && Xrm.Page.getAttribute("ber_enteredfrom").getValue() != undefined) {
        contact = Xrm.Page.getAttribute("ber_enteredfrom").getValue();
        if (contact != null && contact == "278290001") {
            Xrm.Page.getControl("ber_verifiedquantity").setDisabled(true);
            Xrm.Page.getControl("ber_verifiedunit").setDisabled(true);
        }
    }
}

function setreportedquantityvalue() {
    if (Xrm.Page.getAttribute("ber_enteredfrom").getValue() != null && Xrm.Page.getAttribute("ber_enteredfrom").getValue() != undefined) {
        var contact = Xrm.Page.getAttribute("ber_enteredfrom").getValue();
        if (contact != null && contact == "278290000") {
            var reportedquantity = Xrm.Page.getAttribute("ber_verifiedquantity").getValue();
            var reportedunit = Xrm.Page.getAttribute("ber_verifiedunit").getvalue();
            Xrm.Page.getAttribute("ber_reportedquantity").setValue(reportedquantity);
            Xrm.Page.getAttribute("ber_reportedquantity").setValue(reportedunit);
        }
    }
}

function DisableFormIfNotLaunched() {
    if (Xrm.Page.getAttribute("ber_paintermeetid").getValue() != null && Xrm.Page.getAttribute("ber_paintermeetid").getValue() != undefined) {
        var PainterMeetId = Xrm.Page.getAttribute("ber_paintermeetid").getValue()[0].id;

        // Modify  
        //var columns = ['ber_ApprovalStatus'];
        //var filter = "ber_paintermeetId eq (Guid'" + PainterMeetId + "')";
        //var collection = CrmRestKit.RetrieveMultiple('ber_paintermeet', columns, filter);
        //

        var collection;
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintermeets?$filter=ber_paintermeetid eq " + PainterMeetId.replace("{", "").replace("}", ""),
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: false,
            success: function (data, textStatus, xhr) {
                collection = data;
                for (var i = 0; i < collection.value.length; i++) {
                    var ber_paintermeetid = collection.value[i]["ber_ApprovalStatus"];
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });


        if (collection != null && collection.value != null && collection.value.length > 0) {
            if (collection.value[i]["ber_ApprovalStatus"] != null) {
                if (collection.value[i]["ber_ApprovalStatus"] == 278290003) {
                    alert('Final Points are calculated for this scheme! No lifting details can be added!'); Xrm.Page.ui.close();
                }
                else if (collection.value[i]["ber_ApprovalStatus"] != 278290002 && collection.value[i]["ber_ApprovalStatus"] != 278290005) {
                    alert('Scheme is not launched ! No lifting details can be added!'); Xrm.Page.ui.close();
                }
            }
        }
    }
}