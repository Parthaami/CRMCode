function XPLeadTemplate() {

    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (!isCrmForMobile) {
        if (Xrm.Page.getAttribute("ber_leadid") != undefined && Xrm.Page.getAttribute("ber_leadid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid") != undefined && Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'XP LEAD') {

            //var SRType = Xrm.Page.getAttribute("pcl_srtypeid").getValue();
            var Lead = Xrm.Page.getAttribute("ber_leadid").getValue();
            var leadid = Lead[0].id;
            var leadguid = leadid.replace("{", "").replace("}", "");

            /*
            var leadColumns = ['LeadId', 'Subject', 'CreatedOn', 'ber_TSIid2', 'ber_Whowill', 'StatusCode', 'FullName', 'Telephone1', 'Address1_Line1', 'ber_DepotId', 'ber_MasterPainterId', 'ber_DGcontact', 'ber_XPA', 'ber_paintermobilenumber', 'ber_DGMobileNumber'];
            var leadFilter = "LeadId eq guid'" + leadid + "'";
            var leadCollection = CrmRestKit.RetrieveMultiple('Lead', leadColumns, leadFilter);
            if (leadCollection != null && leadCollection != undefined) {
            if (leadCollection.results != null) {
            if (leadCollection.results.length > 0) {
            var collection = leadCollection.results[0];
            var Id = collection.Subject;
            var statusReason = collection.StatusCode.Value;
            var Name = collection.FullName;
            var Calldate = collection.CreatedOn;
            Calldate = Calldate.replace("/Date(", "");
            Calldate = Calldate.replace(")/", "");
            var dateValue = new Date(parseInt(Calldate, 10));
            var year = dateValue.getFullYear() + "";
            var month = (dateValue.getMonth() + 1) + "";
            var day = dateValue.getDate() + "";
            var dateFormat = day + "-" + month + "-" + year;
            var phone = collection.Telephone1;
            var address = collection.Address1_Line1;
            var Depot = collection.ber_DepotId.Name;
            var PainterName = collection.ber_MasterPainterId.Name;
            var PainterMobilenumber = collection.ber_paintermobilenumber;
            var CE = collection.ber_DGcontact.Name;
            var XPA = collection.ber_XPA.Name;
            var CEId = collection.ber_DGcontact.Id;
            var TSIid = collection.ber_TSIid2.Id;
            var TSIName = collection.ber_TSIid2.Name;
            var CustomerExecutive = collection.ber_Whowill.Value;
            //   to get the DG mobile number
            //  alert(TSIid);
            // alert(CustomerExecutive);
            if (CEId != undefined && CEId != null) {
            var DGContactColumns = ['ContactId', 'MobilePhone'];
            var DGContactFilter = "ContactId eq guid'" + CEId + "'";
            var DGContactCollection = CrmRestKit.RetrieveMultiple('Contact', DGContactColumns, DGContactFilter);
            if (DGContactCollection != null && DGContactCollection != undefined) {
            if (DGContactCollection.results != null) {
            if (DGContactCollection.results.length > 0) {

            var collection1 = DGContactCollection.results[0];
            var phoneDG = collection1.MobilePhone;

            }
            }
            }
            }


            if (TSIid != undefined && TSIid != null) {
            var TSIColumns = ['ber_tsiId', 'ber_mobilenumber'];
            var TSIFilter = "ber_tsiId eq guid'" + TSIid + "'";
            var TSICollection = CrmRestKit.RetrieveMultiple('ber_tsi', TSIColumns, TSIFilter);
            if (TSICollection != null && TSICollection != undefined) {
            if (TSICollection.results != null) {
            if (TSICollection.results.length > 0) {

            var collection2 = TSICollection.results[0];
            var TSImobile = collection2.ber_mobilenumber;
            //  alert(TSImobile);

            }
            }
            }
            }

            */

            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads?$select=address1_line1,_ber_depotid_value,_ber_dgcontact_value,ber_dgmobilenumber,_ber_masterpainterid_value,ber_paintermobilenumber,_ber_tsiid2_value,ber_whowill,_ber_xpa_value,createdon,fullname,leadid,statuscode,subject,telephone1&$filter=leadid eq " + leadguid, false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var result = JSON.parse(req.response);
                if (result != null) {
                    var result = JSON.parse(req.response);
                    var address1_line1 = result.value[0]["address1_line1"];
                    var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                    // alert(ber_whowill_formatted);
                    var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                    var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    if (result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"] == "DG" || result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"] == "CSM") {
                        var _ber_dgcontact_value = result.value[0]["_ber_dgcontact_value"];
                        var DGId = _ber_dgcontact_value.replace("{", "").replace("}", "");
                        var _ber_dgcontact_value_formatted = result.value[0]["_ber_dgcontact_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_dgcontact_value_lookuplogicalname = result.value[0]["_ber_dgcontact_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        // var ber_dgmobilenumber = results.value[0]["ber_dgmobilenumber"];
                    }
                    if (result.value[0]["_ber_masterpainterid_value"] != null && result.value[0]["_ber_masterpainterid_value"] != undefined) {
                        var _ber_masterpainterid_value = result.value[0]["_ber_masterpainterid_value"];
                        var MasterPainterId = _ber_masterpainterid_value.replace("{", "").replace("}", "");
                        var _ber_masterpainterid_value_formatted = result.value[0]["_ber_masterpainterid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_masterpainterid_value_lookuplogicalname = result.value[0]["_ber_masterpainterid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                        //  var ber_paintermobilenumber = result.value[0]["ber_paintermobilenumber"];
                    }
                    if (result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"] != null && result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"] != undefined) {
                        var _ber_tsiid2_value = result.value[0]["_ber_tsiid2_value"];
                        var TSIId = _ber_tsiid2_value.replace("{", "").replace("}", "");
                        var _ber_tsiid2_value_formatted = result.value[0]["_ber_tsiid2_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_tsiid2_value_lookuplogicalname = result.value[0]["_ber_tsiid2_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    }
                    var ber_whowill = result.value[0]["ber_whowill"];
                    var ber_whowill_formatted = result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"];
                    if (result.value[0]["ber_whowill@OData.Community.Display.V1.FormattedValue"] == "XPA") {
                        var _ber_xpa_value = result.value[0]["_ber_xpa_value"];
                        var _ber_xpa_value_formatted = result.value[0]["_ber_xpa_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_xpa_value_lookuplogicalname = result.value[0]["_ber_xpa_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                    }
                    var createdon = result.value[0]["createdon"];
                    // var Calldate = collection.CreatedOn;
                    createdon = createdon.replace("/Date(", "");
                    createdon = createdon.replace(")/", "");
                    var dateValue = new Date(parseInt(createdon, 10));
                    var year = dateValue.getFullYear() + "";
                    var month = (dateValue.getMonth() + 1) + "";
                    var day = dateValue.getDate() + "";
                    var dateFormat = day + "-" + month + "-" + year;
                    var fullname = result.value[0]["fullname"];
                    var leadid = result.value[0]["leadid"];
                    var statuscode = result.value[0]["statuscode"];
                    var subject = result.value[0]["subject"];
                    var telephone1 = result.value[0]["telephone1"];
                }
            }
            if (DGId != null && DGId != undefined) {
                var req1 = new XMLHttpRequest();
                req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=contactid,mobilephone&$filter=contactid eq " + DGId, false);
                req1.setRequestHeader("OData-MaxVersion", "4.0");
                req1.setRequestHeader("OData-Version", "4.0");
                req1.setRequestHeader("Accept", "application/json");
                req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req1.send();
                if (req1.response != null && req1.response != "") {
                    var result1 = JSON.parse(req1.response);
                    if (result1 != null) {
                        var result1 = JSON.parse(req1.response);
                        var contactid = result1.value[0]["contactid"];
                        var DG_mobilephone = result1.value[0]["mobilephone"];
                    }
                }
            }

            if (TSIId != null && TSIId != undefined) {
                var req2 = new XMLHttpRequest();
                req2.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis?$select=ber_mobilenumber,ber_tsiid&$filter=ber_tsiid eq " + TSIId, false);
                req2.setRequestHeader("OData-MaxVersion", "4.0");
                req2.setRequestHeader("OData-Version", "4.0");
                req2.setRequestHeader("Accept", "application/json");
                req2.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req2.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req2.send();
                if (req2.response != null && req2.response != "") {
                    var result2 = JSON.parse(req2.response);
                    if (result2 != null) {
                        var result2 = JSON.parse(req2.response);
                        var TSI_ber_mobilenumber = result2.value[0]["ber_mobilenumber"];
                        var ber_tsiid = result2.value[0]["ber_tsiid"];
                    }
                }
            }

            if (MasterPainterId != null && MasterPainterId != undefined) {
                var req3 = new XMLHttpRequest();
                req3.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=contactid,mobilephone&$filter=contactid eq " + MasterPainterId, false);
                req3.setRequestHeader("OData-MaxVersion", "4.0");
                req3.setRequestHeader("OData-Version", "4.0");
                req3.setRequestHeader("Accept", "application/json");
                req3.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req3.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req3.send();
                if (req3.response != null && req3.response != "") {
                    var result3 = JSON.parse(req3.response);
                    var contactid = result3.value[0]["contactid"];
                    var PainterMobilephone = result3.value[0]["mobilephone"];
                }
            }

        }

        //Enquiry
        if (statuscode == '278290007') {
            Xrm.Page.getAttribute("description").setValue("Lead Id : " + leadid + "\r\n" + "Lead Creation Date : " + dateFormat + "\r\n" + "Customer Name : " + fullname + "\r\n" + "Customer Contact Number :" + telephone1 + "\r\n" + "Customer Calling Number : " + "\r\n" + "Customer Address : " + address1_line1 + "\r\n" + "Depot : " + _ber_depotid_value_formatted + "\r\n\n" + "Customer Complaint : " + "\r\n\n" + "Painter Name : " + "\r\n" + "Painter Mobile number : " + "\r\n" + "CE Name : " + "\r\n" + "CE Contact Number : " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        // New stage
        else if (statuscode == '1') {
            Xrm.Page.getAttribute("description").setValue("Lead Id : " + leadid + "\r\n" + "Lead Creation Date : " + dateFormat + "\r\n" + "Customer Name : " + fullname + "\r\n" + "Customer Contact Number :" + telephone1 + "\r\n" + "Customer Calling Number : " + "\r\n" + "Customer Address : " + address1_line1 + "\r\n" + "Depot : " + _ber_depotid_value_formatted + "\r\n\n" + "Customer Complaint : " + "\r\n\n" + "Painter Name : " + "\r\n" + "Painter Mobile number : " + "\r\n" + "CE Name : " + "\r\n" + "CE Contact Number : " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive DG/CSM
        else if (statuscode == '278290032' && (ber_whowill == '0' || ber_whowill == '1')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id : " + leadid + "\r\n" + "Lead Creation Date : " + dateFormat + "\r\n" + "Customer Name : " + fullname + "\r\n" + "Customer Contact Number :" + telephone1 + "\r\n" + "Customer Calling Number : " + "\r\n" + "Customer Address : " + address1_line1 + "\r\n" + "Depot : " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name : " + "\r\n" + "Painter Mobile number : " + "\r\n" + "CE Name : " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number : " + DG_mobilephone + "\r\n" + "TSI : " + "\r\n" + "TSI Mobile Number : " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //XPA
        else if (statuscode == '278290032' && (ber_whowill == '3')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id : " + leadid + "\r\n" + "Lead Creation Date : " + dateFormat + "\r\n" + "Customer Name : " + fullname + "\r\n" + "Customer Contact Number :" + telephone1 + "\r\n" + "Customer Calling Number : " + "\r\n" + "Customer Address : " + address1_line1 + "\r\n" + "Depot : " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name : " + "\r\n" + "Painter Mobile number : " + "\r\n" + "CE Name : " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number : " + DG_mobilephone + "\r\n" + "XPA Name:" + _ber_xpa_value_formatted + "\r\n" + "TSI : " + "\r\n" + "TSI Mobile Number : " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive TSI
        else if (statuscode == '278290032' && ber_whowill == '2') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + "\r\n" + "Painter Mobile number :  " + "\r\n" + "CE Name :  " + _ber_tsiid2_value_formatted + "\r\n" + "CE Contact Number :  " + TSI_ber_mobilenumber + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive DG/CSM && status = Dealer allocated
        else if (statuscode == '278290004' && (ber_whowill == '0' || ber_whowill == '1')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + "\r\n" + "Painter Mobile number :  " + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        ////customer executive XPA && status = Dealer allocated
        else if (statuscode == '278290004' && (ber_whowill == '3')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + "\r\n" + "Painter Mobile number :  " + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "XPA Name:" + _ber_xpa_value_formatted + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }
        //customer executive TSI && status = Dealer allocated
        else if (statuscode == '278290004' && ber_whowill == '2') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot : " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + "\r\n" + "Painter Mobile number :  " + "\r\n" + "CE Name : " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive DG/CSM && status = painter allocated
        else if (statuscode == '278290009' && (ber_whowill == '0' || ber_whowill == '1')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :   " + fullname + "\r\n" + "Customer Contact Number :   " + telephone1 + "\r\n" + "Customer Calling Number :   " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive TSI && status = painter allocated
        else if (statuscode == '278290009' && ber_whowill == '2') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive XPA && status = painter allocated
        else if (statuscode == '278290009' && ber_whowill == '3') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "XPA Name:" + _ber_xpa_value_formatted + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive DG/CSM && status = Quotation Given
        else if (statuscode == '278290026' && (ber_whowill == '0' || ber_whowill == '1')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");

        }

        //customer executive TSI && status = Quotation Given

        else if (statuscode == '278290026' && ber_whowill == '2') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name : " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive DG/CSM && status = Won
        else if (statuscode == '278290005' && (ber_whowill == '0' || ber_whowill == '1')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive TSI && status = Won
        else if (statuscode == '278290005' && ber_whowill == '2') {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        //customer executive XPA && status = Won
        else if (statuscode == '278290005' && (ber_whowill == '3')) {
            Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + _ber_depotid_value_formatted + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "XPA Name:" + _ber_xpa_value_formatted + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }

        // lead lost
        else if (statuscode == '278290014' || statuscode == '278290019' || statuscode == '278290016' || statuscode == '4' || statuscode == '5' || statuscode == '6' || statuscode == '278290011' || statuscode == '278290012' || statuscode == '278290013' || statuscode == '278290017' || statuscode == '278290018' || statuscode == '278290020' || statuscode == '7' || statuscode == '278290021' || statuscode == '278290022' || statuscode == '278290023' || statuscode == '278290033' || statuscode == '278290034') {
            if (ber_whowill == null) {
                Xrm.Page.getAttribute("description").setValue("Lead Id : " + leadid + "\r\n" + "Lead Creation Date : " + dateFormat + "\r\n" + "Customer Name : " + fullname + "\r\n" + "Customer Contact Number :" + telephone1 + "\r\n" + "Customer Calling Number : " + "\r\n" + "Customer Address : " + address1_line1 + "\r\n" + "Depot : " + Depot + "\r\n\n" + "Customer Complaint : " + "\r\n\n" + "Painter Name : " + "\r\n" + "Painter Mobile number : " + "\r\n" + "CE Name : " + "\r\n" + "CE Contact Number : " + "\r\n");
                Xrm.Page.getAttribute("description").setSubmitMode("always");
            }

            else if (ber_whowill == '0' || ber_whowill == '1') {
                Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + Depot + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
                Xrm.Page.getAttribute("description").setSubmitMode("always");
            }

            else if (ber_whowill == '2') {
                Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + Depot + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "TSI :  " + _ber_tsiid2_value_formatted + "\r\n" + "TSI Mobile Number :  " + TSI_ber_mobilenumber + "\r\n");
                Xrm.Page.getAttribute("description").setSubmitMode("always");
            }

            else if (ber_whowill == '3') {
                Xrm.Page.getAttribute("description").setValue("Lead Id :  " + leadid + "\r\n" + "Lead Creation Date :  " + dateFormat + "\r\n" + "Customer Name :  " + fullname + "\r\n" + "Customer Contact Number :  " + telephone1 + "\r\n" + "Customer Calling Number :  " + "\r\n" + "Customer Address :  " + address1_line1 + "\r\n" + "Depot :  " + Depot + "\r\n" + "Customer Complaint : " + "\r\n" + "Painter Name :  " + _ber_masterpainterid_value_formatted + "\r\n" + "Painter Mobile number :  " + PainterMobilephone + "\r\n" + "CE Name :  " + _ber_dgcontact_value_formatted + "\r\n" + "CE Contact Number :  " + DG_mobilephone + "\r\n" + "XPA Name:" + _ber_xpa_value_formatted + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
                Xrm.Page.getAttribute("description").setSubmitMode("always");
            }
        }

        }



        else {
            Xrm.Page.getAttribute("description").setValue(null);
            Xrm.Page.getAttribute("description").setSubmitMode("always");
        }
    }


    else {
        Xrm.Page.getAttribute("description").setValue(null);
        Xrm.Page.getAttribute("description").setSubmitMode("always");
    }


}