function ber_EmployeeUpdate_YearOC() {
    if ((Xrm.Page.getAttribute("ber_month").getSelectedOption() != null) && (Xrm.Page.getAttribute("ber_year").getSelectedOption() != null)){
        var monthval = Xrm.Page.getAttribute("ber_month").getText();
        var Yearval = Xrm.Page.getAttribute("ber_year").getText();
        Xrm.Page.getAttribute("ber_name").setValue(monthval.toString() + '-' + Yearval.toString());
        }


}