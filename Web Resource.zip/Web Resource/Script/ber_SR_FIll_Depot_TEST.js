function FillDepottest() {
    //debugger;
    if (Xrm.Page.getAttribute("customerid") != null && Xrm.Page.getAttribute("customerid") != 'undefined') {
         if (Xrm.Page.getAttribute("customerid") != null && Xrm.Page.getAttribute("customerid").getValue() != null &&    Xrm.Page.getAttribute("customerid").getValue()[0].id != null) {
                
	var CustomerId = Xrm.Page.getAttribute("customerid").getValue()[0].id;
                               
	  var BillTo = Xrm.Page.getAttribute("customerid").getValue()[0].id;
                        var BillTocolumns = ['ber_DepotId'];
                        var BillTofilter = "AccountId eq guid'" + BillTo + "'";
                        var collection = CrmRestKit.RetrieveMultiple('Account', BillTocolumns, BillTofilter);
                        if (collection != null && collection.results != null && collection.results[0].ber_DepotId != null) {
                            var depo = new Array();
                            depo[0] = new Object();
                            depo[0].id = collection.results[0].ber_DepotId.Id;
                            depo[0].name = collection.results[0].ber_DepotId.Name;
                            depo[0].entityType = collection.results[0].ber_DepotId.LogicalName;
                            Xrm.Page.getAttribute("ber_depot").setValue(depo);
                            Xrm.Page.getControl("ber_depot").setDisabled(true);
                        }
                }
            
        }
    }
   