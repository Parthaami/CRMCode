var _url = "http://10.150.80.11:7035";

function fnOnFormSave() {
    Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_bookingstatus").setSubmitMode("always");
}

function LoadMain() {
    ApplyUserAccess();

    Xrm.Page.getControl("ber_pdccreated").setVisible(false);

    /////////////////////////After PDCs Crated => Disable PDC Cheque Details Section ///////////////////////
    if (Xrm.Page.getAttribute("ber_pdccreated").getValue() == true) {
        Xrm.Page.ui.tabs.get(4).setDisplayState("collapsed");
        var ctrlName = Xrm.Page.ui.controls.get();
        for (var i in ctrlName) {
            var ctrl = ctrlName[i];
            var ctrlSection = ctrl.getParent().getLabel();
            if (ctrlSection == "PDC Detail Section") {
                ctrl.setDisabled(true);
            }
        }
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////
    LoadBookingItemGrid();
}

function ApplyUserAccess() {
    var UserRoles = Xrm.Page.context.getUserRoles();
    for (i = 0; i < UserRoles.length; i++) {
        if (UserRoles[i].toUpperCase() == '15BB5A8D-E7A4-E111-B527-18A90548E1D3') {
            var bookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();
            if (bookingStatus == 278290000 || bookingStatus == 278290001 || bookingStatus == 278290002
          || bookingStatus == 278290006 || bookingStatus == 278290007 || bookingStatus == 278290008) {
                DisableForm();
                return;
            }
        }
    }
}

function OnInstallationRequestLoad() {
    /*window.parent.location = "http://192.168.1.109:5555/BergerDev/_forms/print/print.aspx?allsubgridspages=false&formid=d089f338-36c1-4ff0-a653-6fee375b964e&id=%7b40E6EB5D-CC07-E211-8243-18A90548E1D3%7d&objectType=10022&title=Installation%20Request%3a%20WF%20Assignment%20Test%20-%20Microsoft%20Dynamics%20CRM";*/
}

//Hide Shop Board Required Section
function ShopBoardOnchange() {
    var shopboard = Xrm.Page.getAttribute("ber_shopboardrequired").getValue();
    if (shopboard == 278290000) {
        Xrm.Page.ui.tabs.get("Tab_bookinginformation").sections.get("shop_board_section").setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get("Tab_bookinginformation").sections.get("shop_board_section").setVisible(false);
    }
}

function LoadBookingItemGrid() {
    //debugger;
    //var pdcCreated = Xrm.Page.getAttribute("ber_pdccreated").getValue();
    //var bookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();

    ///////////Set Cheque Field to Required when Status is Received And PDC's not Created/////////////////
    /*if (bookingStatus == 278290001 && pdcCreated == false)
    {
        Xrm.Page.getAttribute("ber_pdcnoofcheques").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_pdcbankname").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_pdcmicrno").setRequiredLevel("recommended");
        Xrm.Page.getAttribute("ber_pdcbranchname").setRequiredLevel("recommended");
       // Xrm.Page.getAttribute("ber_pdctownname").setRequiredLevel("recommended");
        Xrm.Page.getAttribute("ber_pdcinstrumentno").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_pdcamount").setRequiredLevel("required");
    }*/

    ///////////Set RDC Field to Required when Status is Received and PDC's Created////////////////////
    /*if (bookingStatus == 278290001 && pdcCreated == true)
    {
        Xrm.Page.getAttribute("ber_rdcid").setRequiredLevel("required");
    }
    else
    {
        var RDCField = Xrm.Page.ui.controls.get("ber_rdcid");
        RDCField.setDisabled(true);
    }*/

    /////////// Load Booking Items Grid//////////////////
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    if (Xrm.Page.ui.getFormType() != 1) {
        var context;
        var objectId;
        var orgName;
        //var userId;
        var hostName;
        var rdcId, dlrId, rdc, dlr;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();

        orgName = context.getOrgUniqueName();
        //userId = context.getUserId();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");


        //var BookingItemGrid = serverURL + "/ISV/" + _orgName + "/ColorBank/BookingRequestItems.aspx?Id=" + objectId;
        var _url = _url + "/ColorBank/BookingRequestItems.aspx?Id=" + objectId;
        if (document.all.IFRAME_StockTransfer != null) {
            document.all.IFRAME_StockTransfer.src = _url;
        }
    }
}