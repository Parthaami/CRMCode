function setDepotOnDealer()
{
//debugger;
var dealer=null;
dealer=Xrm.Page.getAttribute("ber_dealerid");
if(dealer!=null || dealer.getValue()!=null)
{
var DealerGUID = dealer.getValue()[0].id;
var columns = ['ber_DepotId'];
var dealerEntity = CrmRestKit.Retrieve('Account', DealerGUID, columns);
 if(dealerEntity!=null && dealerEntity.ber_DepotId!=null)
   {
      var DepotEntity=new Array();
      DepotEntity[0]=new Object();
      DepotEntity[0].id=dealerEntity.ber_DepotId.Id;
      DepotEntity[0].name=dealerEntity.ber_DepotId.Name;
      DepotEntity[0].entityType=dealerEntity.ber_DepotId.LogicalName;   
      Xrm.Page.getAttribute("ber_depotid").setValue(DepotEntity);
        } 
    } 	
}

function addNotification(message, level) {
    //var notificationsArea = document.getElementById('crmNotifications');
    //if (notificationsArea == null) {
    //    return;
    //}

    if (level == 1) { //critical 
        Xrm.Page.ui.setFormNotification(message, 'ERROR', '1');
        //notificationsArea.AddNotification('mep1', 1, 'source', message);
    }
    if (level == 2) { //Info 
        Xrm.Page.ui.setFormNotification(message, 'INFORMATION', '3');
        //notificationsArea.AddNotification('mep3', 3, 'source', message);
    }
    if (level == 3) { //Warning 
        Xrm.Page.ui.setFormNotification(message, 'WARNING', '2');
        //notificationsArea.AddNotification('mep2', 2, 'source', message);
    }
    if (message == "") {
        Xrm.Page.ui.setFormNotification(null, null, null);
    }
}

function ValidatePainterInMeets() {
    if (Xrm.Page.ui.getFormType() != 1 && Xrm.Page.getAttribute("ber_customertype") != null && Xrm.Page.getAttribute("ber_customertype").getValue() == 278290001) {
        var PainterId = Xrm.Page.data.entity.getId();
        var today = new Date();
        var month = today.getMonth() + 1;
        var todaydate = today.getFullYear() + '-' + month + '-' + today.getDate();

        var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
						'<entity name="ber_paintermeet">' +
						'<attribute name="ber_name" />' +
						'<attribute name="createdon" />' +
						'<attribute name="ber_depot" />' +
						'<attribute name="ber_dealer" />' +
						'<attribute name="ber_paintermeetid" />' +
						'<order attribute="ber_name" descending="false" />' +
						'<link-entity name="ber_paintermeetcontact" from="ber_paintermeet" to="ber_paintermeetid" alias="aa">' +
						'<filter type="and">' +
						'<condition attribute="statecode" operator="eq" value="0" />' +
						'<condition attribute="ber_contact" operator="eq" value="' + PainterId + '" />' +
						'</filter>' +
						'</link-entity>' +
						'<link-entity name="ber_meet" from="ber_meetid" to="ber_meet" alias="ab">' +
                        '<attribute name="ber_type"/>' +
						'<filter type="and">' +
						'<condition attribute="ber_schemerequired" operator="eq" value="1" />' +
						'<filter type="or">' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="gt" value="' + todaydate + '" />' +
                        '<condition attribute="ber_finalpointcalculationdate" operator="null" />' +
						'</filter></filter>' +
						'</link-entity>' +
						'</entity>' +
						'</fetch>';

        var retrievedPainterMeets = XrmServiceToolkit.Soap.Fetch(fetchxml);
        if (retrievedPainterMeets.length > 0) {
            addNotification('', 1);
        }
        else {
            addNotification("This Painter is not registered in any 'Lift & Win' Scheme.", 1);
        }
    }
}