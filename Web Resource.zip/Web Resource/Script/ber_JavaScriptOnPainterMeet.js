jQ = $.noConflict();


function setSchemeSchedule() {
    //debugger;

    if (Xrm.Page.getAttribute("ber_meet").getValue() != null) {
        var meettypeid = new Array();
        meettypeid[0] = new Object();
        var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;
        var columns = ['*'];
        var filter = "ber_meetId eq (Guid'" + MeetId + "')";
        var collection = CrmRestKit.RetrieveMultiple('ber_meet', columns, filter);
        if (collection != null && collection.results != null && collection.results.length > 0) {
            // var PMType=collection.results[0].ber_Type.Value;
            //  var isSchemeRequired=collection.results[0.ber_SchemeRequired;
            //  if(isSchemeRequired)
            //   {
            //       Xrm.Page.getAttribute("ber_schemestartdate").setRequiredLevel("required");
            //      Xrm.Page.getAttribute("ber_schemeenddate").setRequiredLevel("required");
            //    }
            //   Date eDate=collection.results[0].ber_EndDate;
            //Date sDate=collection.results[0].ber_StartDate;

        }
    }
}



function LoadPainterGrid() {
    if (Xrm.Page.getAttribute("ber_meet").getValue() != null) {
        var meettypeid = new Array();
        meettypeid[0] = new Object();
        var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;
        var columns = ['ber_Type'];


        /*  Commented By Partha on 7- Jan -2018
        var filter = "ber_meetId eq (Guid'" + MeetId + "')";
        var collection = CrmRestKit.RetrieveMultiple('ber_meet', columns, filter);
        if (collection != null && collection.results != null && collection.results.length > 0) {
            var PMType = collection.results[0].ber_Type.Value;
        }
       */
        // Written by Partha using  Web API
        jQ.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            processdata: false,
            crossDomain: true,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets(" + MeetId + ")?$select=ber_meetId",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            success: function (data, textStatus, xhr) {
                var result = data;
                PMType = result["ber_type"];
                ber_type_formatted = result["ber_type@OData.Community.Display.V1.FormattedValue"];
            },
            error: function (msg) {
                alert('error fetching the meet information from crm organization');
            },
        });


        var serverURL = window.location.protocol + "//" + window.location.host;
        var _orgName = Xrm.Page.context.getOrgUniqueName();


        if (Xrm.Page.ui.getFormType() != 1) {
            var context;
            var objectId;
            var orgName;
            var userId;
            var hostName;

            context = Xrm.Page.context;
            objectId = Xrm.Page.data.entity.getId();
            orgName = context.getOrgUniqueName();
            userId = context.getUserId();
            hostName = window.location.hostname;

            var PMStatus = Xrm.Page.getAttribute("statuscode").getValue();

            var DealerGuid = Xrm.Page.getAttribute("ber_dealer").getValue()[0].id;
            //var PMType=Xrm.Page.getAttribute("ber_meettype").getValue();
            var DepotGuid = Xrm.Page.getAttribute("ber_depot").getValue()[0].id;

            DealerGuid = DealerGuid.replace("{", "");
            DealerGuid = DealerGuid.replace("}", "");

            objectId = objectId.replace("{", "");
            objectId = objectId.replace("}", "");

            //var product = "http://10.62.163.102/ProductOrder.aspx?OrderId=" + objectId + "&UserId=" + userId;
            //var product = serverURL  + "/ISV/"+ _orgName  +"/OrderItemGrid/ProductOrder.aspx?OrderId=" + objectId + "&UserId=" + userId;
            var painter = serverURL + "/ISV/" + _orgName + "/PainterMeetGrid/Default.aspx?PMGuid=" + objectId + "&PMStatus=" + PMStatus + "&DealerGuid=" + DealerGuid + "&PMType=" + PMType + "&DepotGuid=" + DepotGuid;

            if (document.all.IFRAME_PainterGrid != null) {
                document.all.IFRAME_PainterGrid.src = painter;
            }
        }
    }
}


function showDealerAfterDepot() {
    if (Xrm.Page.getAttribute("ber_depot") != null && Xrm.Page.getAttribute("ber_depot").getValue() != null) {
        Xrm.Page.getControl("ber_dealer").setDisabled(false);
    }
    else {
        Xrm.Page.getControl("ber_dealer").setDisabled(true);
        Xrm.Page.getAttribute("ber_dealer").setValue(null);
    }
}


function hideNshowGrid() {
    if (Xrm.Page.ui.getFormType() == 1) {
        var tab = Xrm.Page.ui.tabs.get("meetpainters");
        Xrm.Page.ui.tabs.get("meetpainters").setVisible(false);
        Xrm.Page.getAttribute("ber_enrolledpainters").setValue(0);
    }
    else if (Xrm.Page.ui.getFormType() != 1) {

        if (Xrm.Page.getAttribute("statuscode").getValue() == 278290004 || Xrm.Page.getAttribute("statuscode").getValue() == 278290005 || Xrm.Page.getAttribute("statuscode").getValue() == 278290006) {
            Xrm.Page.ui.tabs.get("meetpainters").setVisible(true);
        }
            //if else
            //{
            // meet=Xrm.Page.getAttribute("ber_meet").getValue();
            //   if ( meet== null )
            //     {
            //      Xrm.Page.ui.tabs.get("painterregistration").setVisible(false);
            //     }
            //}
        else {
            Xrm.Page.ui.tabs.get("meetpainters").setVisible(false);
        }
    }
}

function LaunchedStatus() {
    if (Xrm.Page.getAttribute("statuscode").getValue() == 278290004) {
        disableFormFields("statuscode", 278290004, "true");
    }
}
function disableFormFields(fieldname, fieldvalue, onOff) {
    var value = Xrm.Page.getAttribute(fieldname).getValue();

    if (value != null) {
        var fieldtype = Xrm.Page.getControl(fieldname).getControlType();
        if (fieldtype == "optionset") {
            value = Xrm.Page.getAttribute(fieldname).getSelectedOption().value;
        }
        if (fieldtype == "lookup") {
            value = value[0].name;
        }
        if (value == fieldvalue) {
            Xrm.Page.ui.controls.forEach(function (control, index) {
                if (doesControlHaveAttribute(control)) {
                    control.setDisabled(onOff);
                }
            });
        }
    }
}

function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}

function checkUser() {
    //debugger;
    if (Xrm.Page.ui.getFormType() != 1) {
        var context;
        var userId;

        context = Xrm.Page.context;
        userId = context.getUserId();
        if (!UserHasRole('System Administrator')) {
            if (Xrm.Page.getAttribute("ber_currentapproverid").getValue() != null) {
                if (Xrm.Page.getAttribute("ber_currentapproverid").getValue()[0].id != userId) {
                    //  DisableForm();
                    disableAllFields(true);
                }
            }
        }
    }
}

function disableAllFields(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, i) {
        if (control && control.getDisabled && !control.getDisabled()) {
            control.setDisabled(onOff);
        }
    });
}

function UserHasRole(roleName) {
    //To Fetch Server Url
    var serverUrl = window.location.protocol + "//" + window.location.host //+ "/" + Xrm.Page.context.getOrgUniqueName();
    //var serverUrl = window.location.protocol + "//" + window.location.host ;

    var userRoles = Xrm.Page.context.getUserRoles();

    for (var i = 0; i < userRoles.length; i++) {
        var roleId = userRoles[i];

        //To Fetch Guid Of given Role Name..
        var oDataEndpointUrl = serverUrl + "/XRMServices/2011/OrganizationData.svc/";
        oDataEndpointUrl += "RoleSet?$top=1&$filter=RoleId eq Guid'" + roleId + "'";

        var service = GetRequestObject();

        if (service != null) {
            service.open("GET", oDataEndpointUrl, false);
            service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
            service.setRequestHeader("Accept", "application/json, text/javascript, */*");
            service.send(null);

            var requestResults = eval('(' + service.responseText + ')').d;

            if (requestResults != null) {
                var role = requestResults.results[0];
                if (role != null) {

                    if (role.Name == roleName) {
                        return true;
                    }
                }
            }
        }
    }
    return false;
};
function GetRequestObject() {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex) {
            return null;
        }
    }
};

function GuidsAreEqual(guid1, guid2) {
    var isEqual = false;

    if (guid1 == null || guid2 == null) {
        isEqual = false;
    }
    else {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
};


function Apply_MeetDealerLookupFilter() {
    var ber_type;
    var ber_type_formatted;

    if (Xrm.Page.getAttribute("ber_meet").getValue() != null && Xrm.Page.getAttribute("ber_meet").getValue() != undefined) {
        var meet = Xrm.Page.getAttribute("ber_meet").getValue();

        jQ.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            processdata: false,
            crossDomain: true,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets(" + meet[0].id.replace("{", "").replace("}", "") + ")?$select=ber_type",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            success: function (data, textStatus, xhr) {
                var result = data;
                ber_type = result["ber_type"];
                ber_type_formatted = result["ber_type@OData.Community.Display.V1.FormattedValue"];
            },
            error: function (msg) {
                alert('error fetching the meet information from crm organization');
            },
        });

        var CBID = "00000000-0000-0000-0000-000000000000";
        if (Xrm.Page.getAttribute("ber_colorbankmachineid").getValue() != null) {
            CBID = Xrm.Page.getAttribute("ber_colorbankmachineid").getValue()[0].id;
        }

        var meetId = meet[0].id;
        var meetType = meet[0].entityType;
        var viewDisplayName = null;
        var viewId = null;
        var isDefaultView = true;
        var layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">'
							+ '<row name="result" id="accountid">'
							+ '<cell name="accountnumber" width="100"/>'
							+ '<cell name="name" width="125"/>'
                            + '<cell name="address1_line2" width="150"/>'
							+ '</row>'
							+ '</grid>';

        var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">'
								+ '<entity name="account">'
								+ '<attribute name="name"/>'
								+ '<attribute name="accountnumber"/>'
								+ '<attribute name="accountid"/>'
                                + '<attribute name="address1_line2"/>'
								+ '<order attribute="name" descending="false"/>'
								+ '<link-entity name="ber_meetdealers" from="ber_dealer" to="accountid" alias="ab">'
								+ '<filter type="and">'
								+ '<condition attribute="ber_meet" operator="eq" value="' + meetId + '"/>'
                                + '<condition attribute="parentaccountid" operator="null"/>'
								+ '<condition attribute="statecode" operator="eq" value="0"/>'
								+ '</filter>'
								+ '</link-entity>'
								+ '</entity>'
								+ '</fetch>';

        var fetchxmlalldealers = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
											+ '<entity name="account">'
											+ '<attribute name="name"/>'
											+ '<attribute name="accountnumber"/>'
											+ '<attribute name="accountid"/>'
                                            + '<attribute name="address1_line2"/>'
											+ '<order attribute="name" descending="false"/>'
											+ '<filter type="and">'
											+ '<condition attribute="parentaccountid" operator="null"/>'
											+ '<condition attribute="statecode" operator="eq" value="0"/>'
											+ '</filter></entity></fetch>';

        var fetchxmlforgcsc = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
										+ '<entity name="account">'
										+ '<attribute name="name"/>'
										+ '<attribute name="accountnumber"/>'
										+ '<attribute name="accountid"/>'
                                        + '<attribute name="address1_line2"/>'
										+ '<order attribute="name" descending="false"/>'
										+ '<filter type="and">'
										+ '<condition attribute="parentaccountid" operator="null"/>'
										+ '<condition attribute="statecode" operator="eq" value="0"/>'
										+ '<condition attribute="accountcategorycode" operator="in">'
										+ '<value>278290000</value><value>278290001</value><value>2</value>'
										+ '</condition></filter></entity></fetch>';

        var fetchxmlforcb = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">'
								+ '<entity name="account">'
								+ '<attribute name="name"/><attribute name="accountnumber"/><attribute name="accountid"/><attribute name="address1_line2"/>'
								+ '<order attribute="name" descending="false"/>'
								+ '<link-entity name="ber_colorbankmachine" from="ber_dealer" to="accountid" alias="aa">'
								+ '<filter type="and"><condition attribute="ber_colorbankmachineid" operator="eq" value="' + CBID + '"/>'
								+ '</filter></link-entity></entity></fetch>';

        viewDisplayName = 'Related Dealer (Dealer-Meet-Connection)';
        var painterViewId = "{15C63745-0A6E-4322-8416-A62C84D90278}";

        if (ber_type != null) {
            if (ber_type_formatted != 278290001) {
                CBID = "";
            }
            if (ber_type_formatted == 278290004 || ber_type_formatted == 278290006) {
                Xrm.Page.getControl('ber_dealer').addCustomView(painterViewId, 'account', viewDisplayName, fetchxml, layoutxml, isDefaultView);
            }
            else if (ber_type_formatted == 278290005) {
                Xrm.Page.getControl('ber_dealer').addCustomView(painterViewId, 'account', viewDisplayName, fetchxmlforgcsc, layoutxml, isDefaultView);
            }
            else if (ber_type_formatted == 278290001 && CBID != "00000000-0000-0000-0000-000000000000") {
                Xrm.Page.getControl('ber_dealer').addCustomView(painterViewId, 'account', viewDisplayName, fetchxmlforcb, layoutxml, isDefaultView);
            }
            else if (CBID != "00000000-0000-0000-0000-000000000000") {
                Xrm.Page.getControl('ber_dealer').addCustomView(painterViewId, 'account', viewDisplayName, fetchxmlalldealers, layoutxml, isDefaultView);
            }
        }
        else {
            Xrm.Page.getControl('ber_dealer').addCustomView(painterViewId, 'account', viewDisplayName, fetchxmlalldealers, layoutxml, isDefaultView);
        }
        Xrm.Page.getControl('ber_dealer').setDefaultView(painterViewId);
    }
}


function SetMeetLookup() {
    //debugger;
    var today = new Date();
    var month = today.getMonth() + 1;
    var todaydate = today.getFullYear() + '-' + month + '-' + today.getDate();
    var viewDisplayName = null,
                viewId = null,
                isDefaultView = true,
               layoutxml = '<grid name="resultset" object="10079" jump="ber_name" select="1" icon="1" preview="1"><row name="result" id="ber_meetid">'
							+ '<cell name="ber_meetnumber" width="100"/><cell name="ber_name" width="150"/><cell name="ber_type" width="100"/>'
							+ '<cell name="ber_lastplanningdate" width="100"/><cell name="ber_schemerequired" width="100"/>'
							+ '<cell name="createdon" width="125"/></row></grid>'

    fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
							+ '<entity name="ber_meet">'
							+ '<attribute name="ber_meetid"/>'
							+ '<attribute name="ber_name"/><attribute name="createdon"/><attribute name="ber_schemerequired"/>'
							+ '<order attribute="ber_name" descending="false"/>'
                            + '<filter type="and">'
                            + '<condition attribute="statecode" operator="eq" value="0" />'
                            + '</filter>'
							+ '<filter type="and"><filter type="or">'
							+ '<condition attribute="ber_lastplanningdate" operator="on-or-after" value="' + todaydate + '"/>'
							+ '<condition attribute="ber_lastplanningdate" operator="null"/>'
                           // + '<condition attribute="statecode" operator="eq" value="0" />'
							+ '</filter></filter></entity></fetch>'



    viewDisplayName = 'Available Meets';
    //viewId = GetuniqueGuid();
    viewId = Xrm.Page.getControl('ber_meet').getDefaultView();
    var bermeetViewId = "{BD469418-9757-41C0-8255-2A54C18AB791}";
    Xrm.Page.getControl('ber_meet').addCustomView(bermeetViewId, 'ber_meet', viewDisplayName, fetchxml, layoutxml, isDefaultView);
    Xrm.Page.getControl('ber_meet').setDefaultView(bermeetViewId);


}


function GetuniqueGuid() {

    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };

    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';

};

function setapprover() {
    if (Xrm.Page.ui.getFormType() == 1) {
        var owner = Xrm.Page.getAttribute("ownerid").getValue();

        if (Xrm.Page.getAttribute("ber_currentapproverid").getValue(owner) == null)
            Xrm.Page.getAttribute("ber_currentapproverid").setValue(owner);
    }
}

function depotfill() {
    var result;
    var _ber_depotid_value;
    var _ber_depotid_value_formatted;
    var _ber_depotid_value_lookuplogicalname;

    if (Xrm.Page.getAttribute("ber_dealer").getValue() != null) {
        var DealerId = Xrm.Page.getAttribute("ber_dealer").getValue()[0].id.replace("{", "").replace("}", "");

        /*
        jQ.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            processdata: false,
            crossDomain: true,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + DealerId + ")?$select=_ber_depotid_value",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },

            success: function (data, textStatus, xhr) {
                result = data;
                _ber_depotid_value = result["_ber_depotid_value"];
                _ber_depotid_value_formatted = result["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                _ber_depotid_value_lookuplogicalname = result["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
            },
            error: function (xhr, textStatus, errorThrown) {
                alert('error fetching the accounts information from crm organization');
            }
        });
        */


        var req = new XMLHttpRequest();

        url = "$select=_ber_depotid_value&$filter=accountid eq " + DealerId + " and  statecode eq 0";
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?" + url, false);

        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        var _ber_depotid_value = results.value[i]["_ber_depotid_value"];
                        var _ber_depotid_value_formatted = results.value[i]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_depotid_value_lookuplogicalname = results.value[i]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        if (results != null && _ber_depotid_value != null) {
                            var depo = new Array();
                            depo[0] = new Object();
                            depo[0].id = _ber_depotid_value;
                            depo[0].name = _ber_depotid_value_formatted;
                            depo[0].entityType = _ber_depotid_value_lookuplogicalname;

                            Xrm.Page.getAttribute("ber_depot").setValue(depo);
                            Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
                            //Xrm.Page.getControl("ber_depot").setDisabled(true);
                        }
                    }
                }
            }
            else {
                Xrm.Utility.alertDialog(this.statusText);
            }
        };
        req.send();


        /*
        if (results != null && _ber_depotid_value != null) {
            var depo = new Array();
            depo[0] = new Object();
            depo[0].id = _ber_depotid_value;
            depo[0].name = _ber_depotid_value_formatted;
            depo[0].entityType = _ber_depotid_value_lookuplogicalname;

            Xrm.Page.getAttribute("ber_depot").setValue(depo);
            Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
            //Xrm.Page.getControl("ber_depot").setDisabled(true);
        }
        */
    }
    else {
        Xrm.Page.getAttribute("ber_depot").setValue(null);
        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
        //Xrm.Page.getControl("ber_depot").setDisabled(true);
    }
}

function DateSet() {
    //    debugger;
    if (Xrm.Page.getAttribute("ber_meet").getValue() != null) {
        var meettypeid = new Array();
        meettypeid[0] = new Object();
        var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;

        /*  Commented By Partha on 7- Jan -2018
        var columns = ['ber_Type', 'ber_MaxPainters', 'ber_FinalPointCalculated', 'ber_FinalPointCalculationDate', 'ber_MaxBudgetPerPainter', 'ber_SchemeRequired', 'ber_StartDate', 'ber_EndDate', 'ber_SellInConsiderationdate'];
        var filter = "ber_meetId eq (Guid'" + MeetId + "')";
        var collection = CrmRestKit.RetrieveMultiple('ber_meet', columns, filter);
        */

        // Written by Partha using  Web API
        //var ber_schemerequired = null;
        //var ber_startdate = null;
        //var ber_enddate = null;
        //var ber_finalpointcalculationdate = null;
        //var ber_sellinconsiderationdate = null;
        //var ber_finalpointcalculated = null;
        //var ber_type = null;

        //var urlTest = Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets?$select=ber_enddate,ber_finalpointcalculated,ber_finalpointcalculationdate,ber_maxbudgetperpainter,ber_maxpainters,ber_schemerequired,ber_sellinconsiderationdate,ber_startdate,ber_type&$filter=ber_meetid eq " + MeetId.replace("{", "").replace("}", "") + "";
        //alert(urlTest);

        //$.ajax({
        //    type: "GET",
        //    contentType: "application/json; charset=utf-8",
        //    datatype: "json",
        //    processdata: false,
        //    crossDomain: true,
        //    url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets(" + MeetId.replace("{", "").replace("}", "") + ")?$select=ber_type,ber_MaxPainters,ber_FinalPointCalculated,ber_FinalPointCalculationDate,ber_MaxBudgetPerPainter,ber_SchemeRequired,ber_StartDate,ber_EndDate,ber_SellInConsiderationdate",
        //    beforeSend: function (XMLHttpRequest) {
        //        XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        //    },
        //    success: function (data, textStatus, xhr) {
        //        var result = data;
        //        ber_type = result["ber_type"];
        //        ber_type_formatted = result["ber_type@OData.Community.Display.V1.FormattedValue"];
        //        ber_SchemeRequired = result["ber_SchemeRequired"];
        //        ber_SchemeRequired_formatted = result["ber_SchemeRequired@OData.Community.Display.V1.FormattedValue"];
        //        ber_StartDate = result["ber_StartDate"];
        //        ber_StartDate_formatted = result["ber_StartDate@OData.Community.Display.V1.FormattedValue"];
        //        ber_FinalPointCalculationDate = result["ber_FinalPointCalculationDate"];
        //        ber_FinalPointCalculationDate_formatted = result["ber_FinalPointCalculationDate@OData.Community.Display.V1.FormattedValue"];
        //        ber_SellInConsiderationdate = result["ber_SellInConsiderationdate"];
        //        ber_SellInConsiderationdate_formatted = result["ber_SellInConsiderationdate@OData.Community.Display.V1.FormattedValue"];
        //        ber_SellInConsiderationdate = result["ber_SellInConsiderationdate"];
        //        ber_SellInConsiderationdate_formatted = result["ber_SellInConsiderationdate@OData.Community.Display.V1.FormattedValue"];
        //        ber_FinalPointCalculated = result["ber_FinalPointCalculated"];
        //        ber_FinalPointCalculated_formatted = result["ber_FinalPointCalculated@OData.Community.Display.V1.FormattedValue"];

        //    },
        //    error: function (msg) {
        //        alert('error fetching the meet information from crm organization');
        //    },
        //});


        //$.ajax({
        //    type: "GET",
        //    contentType: "application/json; charset=utf-8",
        //    datatype: "json",
        //    url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets?$select=ber_enddate,ber_finalpointcalculated,ber_finalpointcalculationdate,ber_maxbudgetperpainter,ber_maxpainters,ber_schemerequired,ber_sellinconsiderationdate,ber_startdate,ber_type&$filter=ber_meetid eq " + MeetId.replace("{", "").replace("}", "") + "",
        //    beforeSend: function (XMLHttpRequest) {
        //        XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
        //        XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
        //        XMLHttpRequest.setRequestHeader("Accept", "application/json");
        //        XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        //    },
        //    async: true,
        //    success: function (data, textStatus, xhr) {
        //        var results = data;
        //        for (var i = 0; i < results.value.length; i++) {
        //             ber_enddate = results.value[i]["ber_enddate"];
        //             ber_finalpointcalculated = results.value[i]["ber_finalpointcalculated"];
        //            var ber_finalpointcalculated_formatted = results.value[i]["ber_finalpointcalculated@OData.Community.Display.V1.FormattedValue"];
        //             ber_finalpointcalculationdate = results.value[i]["ber_finalpointcalculationdate"];
        //             ber_maxbudgetperpainter = results.value[i]["ber_maxbudgetperpainter"];
        //            var ber_maxbudgetperpainter_formatted = results.value[i]["ber_maxbudgetperpainter@OData.Community.Display.V1.FormattedValue"];
        //             ber_maxpainters = results.value[i]["ber_maxpainters"];
        //            var ber_maxpainters_formatted = results.value[i]["ber_maxpainters@OData.Community.Display.V1.FormattedValue"];
        //             ber_schemerequired = results.value[i]["ber_schemerequired"];
        //            var ber_schemerequired_formatted = results.value[i]["ber_schemerequired@OData.Community.Display.V1.FormattedValue"];
        //             ber_sellinconsiderationdate = results.value[i]["ber_sellinconsiderationdate"];
        //             ber_startdate = results.value[i]["ber_startdate"];
        //             ber_type = results.value[i]["ber_type"];
        //            var ber_type_formatted = results.value[i]["ber_type@OData.Community.Display.V1.FormattedValue"];
        //        }
        //    },
        //    error: function (xhr, textStatus, errorThrown) {
        //        Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
        //    }
        //});


        //var test = "https://bpilcrm.bergerindia.com/api/data/v8.2/ber_meets?$select=ber_enddate,ber_finalpointcalculated,ber_finalpointcalculationdate,ber_maxbudgetperpainter,ber_maxpainters,ber_schemerequired,ber_sellinconsiderationdate,ber_startdate,ber_type&$filter=ber_meetid%20eq%209C1328E6-465B-E811-A2EC-0050568C4E59%20and%20%20statecode%20eq%200";

        var req = new XMLHttpRequest();

        url = "$select=ber_enddate,ber_finalpointcalculated,ber_finalpointcalculationdate,ber_maxbudgetperpainter,ber_maxpainters,ber_schemerequired,ber_sellinconsiderationdate,ber_startdate,ber_type&$filter=ber_meetid eq " + MeetId.replace("{", "").replace("}", "") + " and  statecode eq 0";
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets?" + url, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets?$select=ber_enddate,ber_finalpointcalculated,ber_finalpointcalculationdate,ber_maxbudgetperpainter,ber_maxpainters,ber_schemerequired,ber_sellinconsiderationdate,ber_startdate,ber_type&$filter=ber_meetid eq " + MeetId, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                        var ber_enddate = results.value[i]["ber_enddate"];
                        var ber_finalpointcalculated = results.value[i]["ber_finalpointcalculated"];
                        var ber_finalpointcalculated_formatted = results.value[i]["ber_finalpointcalculated@OData.Community.Display.V1.FormattedValue"];
                        var ber_finalpointcalculationdate = results.value[i]["ber_finalpointcalculationdate"];
                        var ber_maxbudgetperpainter = results.value[i]["ber_maxbudgetperpainter"];
                        var ber_maxbudgetperpainter_formatted = results.value[i]["ber_maxbudgetperpainter@OData.Community.Display.V1.FormattedValue"];
                        var ber_maxpainters = results.value[i]["ber_maxpainters"];
                        var ber_maxpainters_formatted = results.value[i]["ber_maxpainters@OData.Community.Display.V1.FormattedValue"];
                        var ber_schemerequired = results.value[i]["ber_schemerequired"];
                        var ber_schemerequired_formatted = results.value[i]["ber_schemerequired@OData.Community.Display.V1.FormattedValue"];
                        var ber_sellinconsiderationdate = results.value[i]["ber_sellinconsiderationdate"];
                        var ber_startdate = results.value[i]["ber_startdate"];
                        var ber_type = results.value[i]["ber_type"];
                        var ber_type_formatted = results.value[i]["ber_type@OData.Community.Display.V1.FormattedValue"];

                        //if (collection.results[0].ber_SchemeRequired == true) {
                        if (ber_schemerequired == true) {
                            Xrm.Page.getAttribute("ber_schemestartdate").setRequiredLevel("required");
                            Xrm.Page.getAttribute("ber_schemeenddate").setRequiredLevel("required");
                            Xrm.Page.getAttribute("ber_finalpointcalculationdate").setRequiredLevel("required");
                            Xrm.Page.getAttribute("ber_sellinconsiderationdate").setRequiredLevel("required");

                            //if (collection.results[0].ber_StartDate != null) {
                            if (ber_startdate != null) {
                                // Xrm.Page.getAttribute("ber_schemestartdate").setValue(new Date(parseInt(collection.results[0].ber_StartDate.split("(")[1].split(")")[0])));
                                //alert(ber_startdate.split("(")[1].split(")"));
                                //Xrm.Page.getAttribute("ber_schemestartdate").setValue(new Date(parseInt(ber_startdate)));
                                Xrm.Page.getAttribute("ber_schemestartdate").setValue(new Date(ber_startdate.substring(0, 10)));
                                Xrm.Page.getAttribute("ber_schemestartdate").setSubmitMode("always");
                            }
                            //if (collection.results[0].ber_EndDate != null) {
                            if (ber_enddate != null) {
                                //Xrm.Page.getAttribute("ber_schemeenddate").setValue(new Date(parseInt(collection.results[0].ber_EndDate.split("(")[1].split(")")[0])));
                                Xrm.Page.getAttribute("ber_schemeenddate").setValue(new Date(ber_enddate.substring(0, 10)));
                                Xrm.Page.getAttribute("ber_schemeenddate").setSubmitMode("always");
                            }
                            //if (collection.results[0].ber_FinalPointCalculationDate != null) {
                            if (ber_finalpointcalculationdate != null) {
                                //Xrm.Page.getAttribute("ber_finalpointcalculationdate").setValue(new Date(parseInt(collection.results[0].ber_FinalPointCalculationDate.split("(")[1].split(")")[0])));
                                Xrm.Page.getAttribute("ber_finalpointcalculationdate").setValue(new Date(ber_finalpointcalculationdate.substring(0, 10)));
                                Xrm.Page.getAttribute("ber_finalpointcalculationdate").setSubmitMode("always");
                            }
                            //if (collection.results[0].ber_SellInConsiderationdate != null) {
                            if (ber_sellinconsiderationdate != null) {
                                //Xrm.Page.getAttribute("ber_sellinconsiderationdate").setValue(new Date(parseInt(collection.results[0].ber_SellInConsiderationdate.split("(")[1].split(")")[0])));
                                Xrm.Page.getAttribute("ber_sellinconsiderationdate").setValue(new Date(ber_sellinconsiderationdate.substring(0, 10)));
                                Xrm.Page.getAttribute("ber_sellinconsiderationdate").setSubmitMode("always");
                            }
                            //if (collection.results[0].ber_FinalPointCalculated != null) {
                            if (ber_finalpointcalculated != null) {
                                // Xrm.Page.getAttribute("ber_finalpointcalculated").setValue(collection.results[0].ber_FinalPointCalculated);
                                Xrm.Page.getAttribute("ber_finalpointcalculated").setValue(ber_finalpointcalculated);
                                Xrm.Page.getAttribute("ber_finalpointcalculated").setSubmitMode("always");
                            }
                            //If MISC scheme Start/End Dates are editable else readonly
                            var status = Xrm.Page.getAttribute("statuscode").getValue();

                            //if (collection.results[0].ber_Type != null && collection.results[0].ber_Type.Value != 278290003) {
                            if (ber_type != null && ber_type.Value != 278290003) {
                                Xrm.Page.getControl("ber_schemestartdate").setDisabled(true);
                                Xrm.Page.getControl("ber_schemeenddate").setDisabled(true);
                                Xrm.Page.getControl("ber_finalpointcalculationdate").setDisabled(true);
                                Xrm.Page.getControl("ber_sellinconsiderationdate").setDisabled(true);
                            }
                            else {
                                if (status != 1 && status != 278290000 && status != 278290001) {
                                    Xrm.Page.getControl("ber_schemestartdate").setDisabled(true);
                                    Xrm.Page.getControl("ber_schemeenddate").setDisabled(true);
                                    Xrm.Page.getControl("ber_finalpointcalculationdate").setDisabled(true);
                                    Xrm.Page.getControl("ber_sellinconsiderationdate").setDisabled(true);
                                }
                                else {
                                    Xrm.Page.getControl("ber_schemestartdate").setDisabled(false);
                                    Xrm.Page.getControl("ber_schemeenddate").setDisabled(false);
                                    Xrm.Page.getControl("ber_finalpointcalculationdate").setDisabled(false);
                                    Xrm.Page.getControl("ber_sellinconsiderationdate").setDisabled(false);
                                }
                            }
                        }
                        else {
                            Xrm.Page.getAttribute("ber_schemestartdate").setRequiredLevel("none");
                            Xrm.Page.getAttribute("ber_schemeenddate").setRequiredLevel("none");
                            Xrm.Page.getAttribute("ber_finalpointcalculationdate").setRequiredLevel("none");
                            Xrm.Page.getAttribute("ber_sellinconsiderationdate").setRequiredLevel("none");

                            Xrm.Page.getControl("ber_schemestartdate").setDisabled(false);
                            Xrm.Page.getControl("ber_schemeenddate").setDisabled(false);
                            Xrm.Page.getControl("ber_finalpointcalculationdate").setDisabled(false);
                            Xrm.Page.getControl("ber_sellinconsiderationdate").setDisabled(false);
                        }
                        //if (collection.results[0].ber_Type.Value == 278290001) {
                        if (ber_type == 278290001) {
                            //Xrm.Page.getControl("ber_colorbankmachineid").setVisible(true);
                            //Xrm.Page.getAttribute("ber_colorbankmachineid").setRequiredLevel("required");
                        }
                        else {
                            //Xrm.Page.getControl("ber_colorbankmachineid").setVisible(false);
                            //Xrm.Page.getAttribute("ber_colorbankmachineid").setRequiredLevel("none");
                        }

                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();



    }
    else { //If Meet is not selected
        Xrm.Page.getAttribute("ber_schemestartdate").setValue(null);
        Xrm.Page.getAttribute("ber_schemeenddate").setValue(null);
        Xrm.Page.getAttribute("ber_finalpointcalculationdate").setValue(null);
        Xrm.Page.getAttribute("ber_sellinconsiderationdate").setValue(null);

        Xrm.Page.getAttribute("ber_schemestartdate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_schemeenddate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_finalpointcalculationdate").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_sellinconsiderationdate").setRequiredLevel("none");

        Xrm.Page.getControl("ber_schemestartdate").setDisabled(true);
        Xrm.Page.getControl("ber_schemeenddate").setDisabled(true);
        Xrm.Page.getControl("ber_finalpointcalculationdate").setDisabled(true);
        Xrm.Page.getControl("ber_sellinconsiderationdate").setDisabled(true);
    }
}

function enrolledPainter() {
    if (!UserHasRole('System Administrator')) {
        Xrm.Page.getControl("ber_enrolledpainters").setVisible(false);

    }
}






//////////////////******************/////////////////////////




function ValidateMeetDealer() {
    if (Xrm.Page.getAttribute("ber_meet").getValue() != null && Xrm.Page.getAttribute("ber_meet") != undefined) {
        var Meet = Xrm.Page.getAttribute("ber_meet").getValue();
        var MeetGuid = Meet[0].id;

        if (Xrm.Page.getAttribute("ber_dealer").getValue() != null && Xrm.Page.getAttribute("ber_dealer") != undefined) {

            var Dealer = Xrm.Page.getAttribute("ber_dealer").getValue();
            var DealerGuid = Dealer[0].id;
        }

        if (MeetGuid != null && DealerGuid != null) {

            var fetchxmlMeet = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                "  <entity name='ber_paintermeet'>" +
                                "    <attribute name='ber_name' />" +
                                "    <attribute name='createdon' />" +
                                "    <attribute name='ber_depot' />" +
                                "    <attribute name='ber_dealer' />" +
                                "    <attribute name='ber_paintermeetid' />" +
                            "    <order attribute='ber_name' descending='false' />" +
                            "    <filter type='and'>" +
                            "      <condition attribute='ber_meet' operator='eq'  uitype='ber_meet' value='" + MeetGuid + "' />" +
                            "      <condition attribute='ber_dealer' operator='eq' uitype='account' value='" + DealerGuid + "' />" +
                            "      <condition attribute='statecode' operator='eq' value='0' />" +
                            "    </filter>" +
                            "  </entity>" +
                            "</fetch>"

            var encodedFetchXml = encodeURI(fetchxmlMeet);
            var queryPath = "/api/data/v8.0/ber_paintermeets?fetchXml=" + encodedFetchXml;

            var hostname = "https://bpilcrmuat.bergerindia.com";
            var seturl = hostname + queryPath;


            var req = new XMLHttpRequest();
            req.open("GET", seturl, false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var results = JSON.parse(req.response);
                if (results != null) {
                    //no duplicate record should be allowed
                    if (results.value.length > 0) {
                        var MeetPlanningId = results.value[0].ber_name;

                        Xrm.Page.getAttribute("ber_dealer").setValue(null);
                        Xrm.Page.getAttribute("ber_dealer").setSubmitMode("always");
                        Xrm.Page.getAttribute("ber_depot").setValue(null);
                        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");

                        alert("This Dealer is already linked with the specific meet via Meet ID : " + MeetPlanningId);


                    }

                }

            }

        }
    }
}
