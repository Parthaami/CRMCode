function openestimatedetails() {
    debugger;
    var serverurl = window.location.protocol + "//" + window.location.host;
    var objectId = Xrm.Page.data.entity.getId();
    var context = Xrm.Page.context;
    var orgName = context.getOrgUniqueName();
    var leadname = Xrm.Page.getAttribute("fullname").getValue();
    var value = new Array;
    value = Xrm.Page.getAttribute("ber_leadcontactid").getValue();
    var DepotValue = new Array;
    DepotValue = Xrm.Page.getAttribute("ber_depotid").getValue();

    var br;

    var BillToName = "";
    if (Xrm.Page.getAttribute("ber_salutation") != null && Xrm.Page.getAttribute("ber_salutation").getValue()) {
        if (Xrm.Page.getAttribute("ber_salutation").getValue() == 278290000)
            BillToName += "Mr. ";
        else if (Xrm.Page.getAttribute("ber_salutation").getValue() == 278290001)
            BillToName += "Mrs. ";
        else if (Xrm.Page.getAttribute("ber_salutation").getValue() == 278290002)
            BillToName += "Ms. ";
        else if (Xrm.Page.getAttribute("ber_salutation").getValue() == 278290003)
            BillToName += "Dr. ";
        else if (Xrm.Page.getAttribute("ber_salutation").getValue() == 278290004)
            BillToName += "M/s. ";

    }
    BillToName += Xrm.Page.getAttribute("firstname").getValue() + " " + Xrm.Page.getAttribute("lastname").getValue();

    if (value != null) {

       

        if (SetBR(DepotValue[0].id) != null) {
            br = SetBR(DepotValue[0].id).toString();
        }
        

        var Extras = "ber_customerid=" + value[0].id;
        var customerName = value[0].name.replace("&", "%26");
        Extras += "&ber_customeridname=" + customerName;
        Extras += "&ber_leadid=" + objectId;
        Extras += "&ber_leadidname=" + leadname.replace("&", "%26");
        Extras += "&ber_depotid=" + DepotValue[0].id;
        Extras += "&ber_depotidname=" + DepotValue[0].name.replace("&", "%26");
        if ((br != null) || (typeof br !="undefined")) {
            Extras += "&ber_br=" + br;
        }
        Extras += "&ber_billtoname=" + BillToName;


        strUrl = serverurl + "/" + orgName + "/main.aspx?etn=ber_estimatedetails&extraqs=" + encodeURIComponent(Extras) + "&pagetype=entityrecord&rof=false";
        window.open(strUrl);
    }
    else {
        alert('Generating Lead Customer Kindly refresh page');
    }
}
function SetBR(Depot) {
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var Org = "/BPIL";
    var queryUrl = serverUrl + Org + "/xrmservices/2011/OrganizationData.svc/ber_depotSet?$select=ber_BR_percent&$filter=ber_depotId eq guid'" + Depot + "'";

    var req = new XMLHttpRequest();
    req.open("GET", queryUrl, false);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json");
    req.send();

    var resp = JSON.parse(req.responseText).d;

    return resp.results[0].ber_BR_percent;


}