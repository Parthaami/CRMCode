function PhoneCallOnLoad() {
    // debugger;
    if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category").getValue() == "CallTagging") {
        Xrm.Page.ui.tabs.get("CallTagging").setVisible(true);
        callCTI();
    }

    //document.all.IFRAME_LiftingDetailsGrid.src = "about:blank";
    Xrm.Page.getControl("category").setDisabled(true);
    Xrm.Page.getControl("subcategory").setDisabled(true);
    Xrm.Page.getControl("ber_assignedtoqueueid").setVisible(false);


    if (Xrm.Page.ui.getFormType() == 1) {
        Xrm.Page.getControl("ber_closurecode").setDisabled(true);
        Xrm.Page.getAttribute("ber_closurecode").setRequiredLevel("none");
    }
    if (Xrm.Page.ui.getFormType() == 2) {
        Xrm.Page.getControl("ber_closurecode").setDisabled(false);
        Xrm.Page.getAttribute("ber_closurecode").setRequiredLevel("required");

        if (Xrm.Page.getAttribute("ber_closurecode") != null && Xrm.Page.getAttribute("ber_closurecode").getValue() != null) {
            var ClosureCode = Xrm.Page.getAttribute("ber_closurecode").getValue();
            if (ClosureCode == 278290004) {
                Xrm.Page.getControl("ber_nextdatetime").setVisible(true);
                Xrm.Page.getAttribute("ber_nextdatetime").setRequiredLevel("required");
            }
            else if (ClosureCode == 278290000) {
                if (Xrm.Page.getAttribute("category").getValue() == "CB Complaint") {
                    if (Xrm.Page.getAttribute("subcategory").getValue() == "Query Resolved") {
                        Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("required");
                    }
                }
            }
        }
    }
}

function CSATHideShow() {
    //debugger;
    if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category").getValue() == "XP CSAT") {
        setVisibleSection("phonecall", "CSAT_Survey", true);
        Xrm.Page.getAttribute("ber_wasourofficestaffcourteousandhelpful").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wasourproposalclearanddetailedenough").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_didwekeepthesitecleanorderly").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wereyoupleasedwiththequalityofour").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_csatpainterrating").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wasthecontractorcourteous").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue").setRequiredLevel("none");
    }
    else {

        setVisibleSection("phonecall", "CSAT_Survey", false);
        Xrm.Page.getAttribute("ber_wasourofficestaffcourteousandhelpful").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wasourproposalclearanddetailedenough").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_didwekeepthesitecleanorderly").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wereyoupleasedwiththequalityofour").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_csatpainterrating").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_wasthecontractorcourteous").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue").setRequiredLevel("none");
    }
}
//Function to show-hide section
function setVisibleSection(tabname, sectionname, show) {
    var oTabName = Xrm.Page.ui.tabs.get(tabname);
    if (oTabName != null) {
        if (sectionname == null) { } else {
            var oSection = oTabName.sections.get(sectionname);
            if (oSection != null) {
                oSection.setVisible(show);
            }
        }
    }
}

function callCTI() {
    var serverURL = window.location.protocol + "//" + window.location.host;
    if (Xrm.Page.getAttribute("phonenumber") != null && Xrm.Page.getAttribute("phonenumber").getValue() != null) {
        var mobile = Xrm.Page.getAttribute("phonenumber").getValue();

        //var webServiceURL = "http://10.150.80.11:6535/BergerCRMService.asmx";
        var webServiceURL = serverURL + ":6535/BergerCRMService.asmx";
        var req_params = '<?xml version="1.0" encoding="utf-8"?>' +
                         '<soap:Envelope ' +
                         'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' +
                         'xmlns:xsd="http://www.w3.org/2001/XMLSchema" ' +
                         'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">' +
                         '<soap:Body>' +
                         '<GetUrl xmlns="http://bergerindia.org/">' +
                         '<ContactNo>' + mobile + '</ContactNo>' +
                         '</GetUrl>' +
                         '</soap:Body>' +
                         '</soap:Envelope>';
        try {
            if (window.XMLHttpRequest) {
                ajax_request = new XMLHttpRequest();
            }
        }

        catch (trymicrosoft) {
            try {
                ajax_request = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (othermicrosoft) {
                try {
                    ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
                }
                catch (failed) {
                    ajax_request = false;
                }
            }
        }

        ajax_request.open("POST", webServiceURL, true);
        ajax_request.setRequestHeader("Content-Type", "text/xml;charset=utf-8");
        //yourownvariable.setHeader("Access-Control-Allow-Origin:", "origin url of your site");
        //yourownvariable.setHeader("Access-Control-Allow-Methods", "GET, POST,PUT");
        ajax_request.onreadystatechange = receiveXML_SOAPDataItem;
        ajax_request.send(req_params);
    }
}

function receiveXML_SOAPDataItem() {

    if (ajax_request.readyState == 4) {
        if (ajax_request.status == 200) {
            try {
                var myXML = ajax_request.responseText;
                var getUrl = $(myXML).find("URL").text();
                var ex = getUrl.split("&")[0];
                var phno = Xrm.Page.getAttribute("phonenumber").getValue();
                debugger;
                if (ex != "Ex=N") {
                    var type = getUrl.split("&")[1].split("=")[1];
                    var code = getUrl.split("&")[2].split("=")[1];
                    if (type == "D") {


                        // Need to be changed 
                        ////..............................................................................................................................................................
                        //var columns = ['AccountId', 'Name'];
                        //var filter = "ParentAccountId/Id eq null and (Telephone1 eq '" + phno + "'or Telephone2 eq '" + phno + "'or Telephone3 eq '" + phno + "'or Address1_Telephone1 eq '" + phno + "')";
                        //var collection = CrmRestKit.RetrieveMultiple('Account', columns, filter);
                        // .................................................................................................................................................................................

                        var collection;

                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=accountid,name&$filter=_parentaccountid_value eq null and  telephone1 eq '" + phno + "' or  telephone2 eq '" + phno + "' or  telephone3 eq '" + phno + "' or  address1_telephone1 eq '" + phno + "'",
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                collection = data;
                                for (var i = 0; i < collection.value.length; i++) {
                                    var accountid = collection.value[i]["accountid"];
                                    var name = collection.value[i]["name"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });



                        if (collection != null && collection.value != null && collection.value.length == 1) {
                            //For Dealer
                            Xrm.Page.getAttribute("ber_headercaller").setValue(1);
                            var id = collection.value[0]["AccountId"];
                            var name = collection.value[0]["Name"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].entityType = "account";
                            lookupValue[0].type = 1;

                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                Xrm.Page.getAttribute("from").setValue(lookupValue);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                Xrm.Page.getAttribute("to").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);

                            //show following fields to Dealer
                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                            Xrm.Page.getControl("ber_orderbooked").setVisible(true);
                            Xrm.Page.getControl("ber_orderbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_srbooked").setVisible(true);
                            Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_pacreated").setVisible(true);
                            Xrm.Page.getControl("ber_pacreatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                            Xrm.Page.getControl("ber_leadgenregisteredtext").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsupdated").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsupdatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_calldropped").setVisible(true);
                            Xrm.Page.getControl("ber_dispatchquery").setVisible(true);

                            Xrm.Page.getControl("ber_stockenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paymentenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_invcndnenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_orderenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsverified").setVisible(true);
                            Xrm.Page.getControl("ber_schemeenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbtargetenquiry").setVisible(true);
                        }
                        else {
                            Xrm.Page.getAttribute("ber_headercaller").setValue(1);

                            //Filter lookup for dealers
                            var viewId = "{1DFB2B35-B07C-44D1-868D-258DEEAB88E2}";
                            var entityName = "account";
                            var viewDisplayName = "Sender Accounts";
                            var PhoneNumber = Xrm.Page.getAttribute('phonenumber').getValue();

                            var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                            "<entity name='account'>" +
                                            "<attribute name='name' />" +
                                            "<attribute name='primarycontactid' />" +
                                            "<attribute name='telephone1' />" +
                                            "<attribute name='accountid' />" +
                                            "<order attribute='name' descending='false' />" +
                                            "<filter type='and'>" +
                                            "<condition attribute='telephone1' operator='eq' value='" + PhoneNumber + "' />" +
                                            "<condition attribute='parentaccountid' operator='null' />" +
                                            "</filter>" +
                                            "<link-entity name='account' from='accountid' to='parentaccountid' visible='false' link-type='outer' alias='PA'>" +
                                            "<attribute name='accountnumber'/>" +
                                            "</link-entity>" +
                                            "</entity>" +
                                            "</fetch>";

                            var layoutXml = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'>" +
                                            "<row name='result' id='accountid'>" +
                                            "<cell name='name' width='300' />" +
                                            "<cell name='primarycontactid' width='150' />" +
                                            "<cell name='telephone1' width='100' />" +
                                            "<cell name='accountnumber' width='100' />" +
                                            "</row>" +
                                            "</grid>";

                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                Xrm.Page.getAttribute("from").setRequiredLevel("required");
                                document.getElementById("from").setAttribute("lookuptypes", "1");
                                Xrm.Page.getControl("from").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);
                                Xrm.Page.getControl("from").setDefaultView(viewId);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                Xrm.Page.getAttribute("to").setRequiredLevel("required");
                                document.getElementById("to").setAttribute("lookuptypes", "1");
                                Xrm.Page.getControl("to").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);
                                Xrm.Page.getControl("to").setDefaultView(viewId);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            //show following fields to Dealer
                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                            Xrm.Page.getControl("ber_orderbooked").setVisible(true);
                            Xrm.Page.getControl("ber_orderbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_srbooked").setVisible(true);
                            Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_pacreated").setVisible(true);
                            Xrm.Page.getControl("ber_pacreatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                            Xrm.Page.getControl("ber_leadgenregisteredtext").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsupdated").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsupdatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_calldropped").setVisible(true);
                            Xrm.Page.getControl("ber_dispatchquery").setVisible(true);

                            Xrm.Page.getControl("ber_stockenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paymentenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_invcndnenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_orderenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_painterpointsverified").setVisible(true);
                            Xrm.Page.getControl("ber_schemeenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbtargetenquiry").setVisible(true);
                        }
                    }

                    if (type == "R") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(2);

                        // var columns = ['ber_rsm'];
                        // var filter = "ber_regionId eq guid'" + code + "'";
                        // var collection = CrmRestKit.RetrieveMultiple('ber_region', columns, filter);

                        var collection;
                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_regions?$select=_ber_rsm_value&$filter=ber_regionid eq " + code,
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                collection = data;
                                for (var i = 0; i < collection.value.length; i++) {
                                    var _ber_rsm_value = collection.value[i]["_ber_rsm_value"];
                                    var _ber_rsm_value_formatted = collection.value[i]["_ber_rsm_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_rsm_value_lookuplogicalname = collection.value[i]["_ber_rsm_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });


                        if (collection != null && collection.value != null && collection.value.length == 1) {

                            var id = collection.results[0]["_ber_rsm_value"];
                            //var name = collection.results[0].ber_rsm.Name;
                            var name = collection.value[i]["_ber_rsm_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].type = 8;
                            lookupValue[0].entityType = collection.results[0].ber_rsm.LogicalName;
                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                Xrm.Page.getAttribute("from").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setSubmitMode("always");
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                Xrm.Page.getAttribute("to").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }

                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                            Xrm.Page.getControl("ber_orderbooked").setVisible(true);
                            Xrm.Page.getControl("ber_orderbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_srbooked").setVisible(true);
                            Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_pacreated").setVisible(true);
                            Xrm.Page.getControl("ber_pacreatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_dispatchquery").setVisible(true);

                            Xrm.Page.getControl("ber_stockenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paymentenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_invcndnenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_orderenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_schemeenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbtargetenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_calldropped").setVisible(true);
                        }
                    }
                    if (type == "B") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(3);

                        //var columns = ['ber_DepotUser'];
                        //var filter = "ber_depotId eq guid'" + code + "'";
                        //var collection = CrmRestKit.RetrieveMultiple('ber_depot', columns, filter);


                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_depots?$select=_ber_depotuser_value&$filter=ber_depotid eq" + code,
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                collection = data;
                                for (var i = 0; i < collection.value.length; i++) {
                                    var _ber_depotuser_value = collection.value[i]["_ber_depotuser_value"];
                                    var _ber_depotuser_value_formatted = collection.value[i]["_ber_depotuser_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_depotuser_value_lookuplogicalname = collection.value[i]["_ber_depotuser_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });


                        if (collection != null && collection.value != null && collection.value.length == 1) {
                            var id = collection.value[0]["_ber_depotuser_value"];
                            //var name = collection.results[0].ber_DepotUser.Name;
                            var name = collection.value[i]["_ber_depotuser_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].type = 8;
                            lookupValue[0].entityType = collection.results[0].ber_DepotUser.LogicalName;

                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {

                                Xrm.Page.getAttribute("from").setValue(lookupValue);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {

                                Xrm.Page.getAttribute("to").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }

                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                            Xrm.Page.getControl("ber_orderbooked").setVisible(true);
                            Xrm.Page.getControl("ber_orderbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_srbooked").setVisible(true);
                            Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_pacreated").setVisible(true);
                            Xrm.Page.getControl("ber_pacreatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_dispatchquery").setVisible(true);

                            Xrm.Page.getControl("ber_stockenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paymentenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_invcndnenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_orderenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_schemeenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbtargetenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_calldropped").setVisible(true);
                        }
                    }
                    if (type == "T") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(4);

                        //var columns = ['ber_tsiId', 'ber_name'];
                        //var filter = "ber_tsiId eq guid'" + code + "'";
                        //var collection = CrmRestKit.RetrieveMultiple('ber_tsi', columns, filter);

                        var collection;
                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis?$select=ber_name,ber_tsiid&$filter=ber_tsiid eq code",
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                collection = data;
                                for (var i = 0; i < results.value.length; i++) {
                                    var ber_name = results.value[i]["ber_name"];
                                    var ber_tsiid = results.value[i]["ber_tsiid"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });


                        if (collection != null && collection.value != null && collection.value.length == 1) {
                            var id = collection.value[0]["ber_tsiid"];
                            var name = collection.value[0]["ber_name"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].entityType = "ber_tsi";
                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                //Xrm.Page.getAttribute("from").setValue(lookupValue);
                                Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                //Xrm.Page.getAttribute("to").setValue(lookupValue);
                                Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }

                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                            Xrm.Page.getControl("ber_orderbooked").setVisible(true);
                            Xrm.Page.getControl("ber_orderbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_srbooked").setVisible(true);
                            Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                            Xrm.Page.getControl("ber_pacreated").setVisible(true);
                            Xrm.Page.getControl("ber_pacreatedtext").setVisible(true);
                            Xrm.Page.getControl("ber_dispatchquery").setVisible(true);

                            Xrm.Page.getControl("ber_stockenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paymentenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_invcndnenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_orderenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_paenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_schemeenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_cbtargetenquiry").setVisible(true);
                            Xrm.Page.getControl("ber_calldropped").setVisible(true);
                        }
                    }
                    if (type == "CBSD") {//Sub Dealer
                        Xrm.Page.getAttribute("ber_headercaller").setValue(10);
                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_srbooked").setVisible(true);
                        Xrm.Page.getControl("ber_srbookedtext").setVisible(true);
                        Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                        Xrm.Page.getControl("ber_cbinstallationrequestenquiry").setVisible(true);
                    }
                    if (type == "DG") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(5);
                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregisteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsentered").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsenteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_srbooked").setVisible(true);
                        Xrm.Page.getControl("ber_srbookedtext").setVisible(true);

                        Xrm.Page.getControl("ber_painterquery").setVisible(true);
                        Xrm.Page.getControl("ber_calldropped").setVisible(true);
                    }
                    if (type == "BDO") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(6);

                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregisteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsentered").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsenteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_srbooked").setVisible(true);
                        Xrm.Page.getControl("ber_srbookedtext").setVisible(true);

                        Xrm.Page.getControl("ber_painterquery").setVisible(true);
                        Xrm.Page.getControl("ber_calldropped").setVisible(true);

                    }
                    if (type == "BDM") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(7);

                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                        Xrm.Page.getControl("ber_leadgenregisteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsentered").setVisible(true);
                        Xrm.Page.getControl("ber_painterpointsenteredtext").setVisible(true);
                        Xrm.Page.getControl("ber_srbooked").setVisible(true);
                        Xrm.Page.getControl("ber_srbookedtext").setVisible(true);

                        Xrm.Page.getControl("ber_painterquery").setVisible(true);
                        Xrm.Page.getControl("ber_calldropped").setVisible(true);

                    }
                    if (type == "RSC") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(8);

                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_srclosure").setVisible(true);
                        Xrm.Page.getControl("ber_srclosuretext").setVisible(true);

                        Xrm.Page.getControl("ber_srenquiry").setVisible(true);
                        Xrm.Page.getControl("ber_calldropped").setVisible(true);
                    }
                    if (type == "P") {
                        Xrm.Page.getAttribute("ber_headercaller").setValue(9);

                        Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        Xrm.Page.getControl("ber_srbooked").setVisible(true);
                        Xrm.Page.getControl("ber_srbookedtext").setVisible(true);

                        Xrm.Page.getControl("ber_pointsupdated").setVisible(true);
                        Xrm.Page.getControl("ber_pointsenquiry").setVisible(true);
                        Xrm.Page.getControl("ber_calldropped").setVisible(true);

                    }
                    if (type == "BDM" || type == "RSC") {
                        //var columns = ['SystemUserId', 'FullName'];
                        //var filter = "SystemUserId eq guid'" + code + "'";
                        //var collection = CrmRestKit.RetrieveMultiple('SystemUser', columns, filter);
                        var collection;
                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers?$select=fullname,systemuserid&$filter=systemuserid eq code",
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                var results = data;
                                for (var i = 0; i < results.value.length; i++) {
                                    var fullname = results.value[i]["fullname"];
                                    var systemuserid = results.value[i]["systemuserid"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });

                        if (collection != null && collection.value != null && collection.value.length == 1) {
                            var id = collection.value[0]["systemuserid"];
                            var name = collection.value[0]["fullname"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].entityType = "systemuser";

                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                Xrm.Page.getAttribute("from").setValue(lookupValue);
                                //Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                Xrm.Page.getAttribute("to").setValue(lookupValue);
                                //Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                        }
                    }

                    if (type == "DG" || type == "BDO" || type == "P") {

                        /*
                        var columns = ['ContactId', 'FullName'];
                        var filter = "ContactId eq guid'" + code + "'";
                        var collection = CrmRestKit.RetrieveMultiple('Contact', columns, filter);
                        */

                        $.ajax({
                            type: "GET",
                            contentType: "application/json; charset=utf-8",
                            datatype: "json",
                            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=contactid,fullname&$filter=contactid eq " + code,
                            beforeSend: function (XMLHttpRequest) {
                                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                            },
                            async: false,
                            success: function (data, textStatus, xhr) {
                                var results = data;
                                for (var i = 0; i < results.value.length; i++) {
                                    var contactid = results.value[i]["contactid"];
                                    var fullname = results.value[i]["fullname"];
                                }
                            },
                            error: function (xhr, textStatus, errorThrown) {
                                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                            }
                        });

                        if (collection != null && collection.value != null && collection.value.length == 1) {
                            var id = collection.value["contactid"];
                            var name = collection.value["fullname"];
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = id;
                            lookupValue[0].name = name;
                            lookupValue[0].entityType = "contact";
                            lookupValue[0].type = 2;

                            if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                                Xrm.Page.getAttribute("from").setValue(lookupValue);
                                Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                            else {
                                Xrm.Page.getAttribute("to").setValue(lookupValue);
                                Xrm.Page.getAttribute("regardingobjectid").setValue(lookupValue);
                                Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                            }
                        }
                    }
                }
                else {
                    Xrm.Page.ui.tabs.get("CallTagging").sections.get("CallTagging_section_2").setVisible(true);
                    Xrm.Page.getControl("ber_notregistered").setVisible(true);
                    Xrm.Page.getControl("ber_leadgenregistered").setVisible(true);
                    Xrm.Page.getControl("ber_leadenquiry").setVisible(true);
                    Xrm.Page.getControl("ber_prankabusivecall").setVisible(true);

                    if (Xrm.Page.getAttribute("directioncode").getValue() == false) {
                        Xrm.Page.getAttribute("to").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                        Xrm.Page.getAttribute("from").setValue(null);
                    }
                    else {
                        Xrm.Page.getAttribute("from").setValue(Xrm.Page.getAttribute("ownerid").getValue());
                        Xrm.Page.getAttribute("to").setValue(null);
                    }
                }
            }
            catch (Exception) {
            }
        }
    }
}


function ClosureCodeChange() {
    if (Xrm.Page.getAttribute("ber_closurecode") != null && Xrm.Page.getAttribute("ber_closurecode").getValue() != null) {
        var ClosureCode = Xrm.Page.getAttribute("ber_closurecode").getValue();
        if (ClosureCode == 278290004) {
            Xrm.Page.getControl("ber_nextdatetime").setVisible(true);
            Xrm.Page.getAttribute("ber_nextdatetime").setRequiredLevel("required");
        }
        else {
            Xrm.Page.getControl("ber_nextdatetime").setVisible(false);
            Xrm.Page.getAttribute("ber_nextdatetime").setRequiredLevel("none");
        }
        if (ClosureCode == 278290000) {
            if (Xrm.Page.getAttribute("category").getValue() == "CB Complaint") {
                if (Xrm.Page.getAttribute("subcategory").getValue() == "Query Resolved") {
                    Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("required");
                }
                else {
                    Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("none");
                }
            }
            else {
                Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("none");
            }
        }
        else {
            Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("none");
        }
        if (ClosureCode == 278290003) {
            if (Xrm.Page.getAttribute("category").getValue() == "CB Warranty" && Xrm.Page.getAttribute("subcategory").getValue() == "AMC Outbound Call") {
                Xrm.Page.getControl("ber_dealeraccepted").setVisible(true);
            }
            else {
                Xrm.Page.getControl("ber_dealeraccepted").setVisible(false);
            }
        }
        else {
            Xrm.Page.getControl("ber_dealeraccepted").setVisible(false);
        }
    }
    else {
        Xrm.Page.getControl("ber_nextdatetime").setVisible(false);
        Xrm.Page.getAttribute("ber_nextdatetime").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_closuredatetime").setRequiredLevel("none");
    }
}


function LoadLiftingDetailsGrid() {
    // debugger;
    var serverURL = window.location.protocol + "//" + window.location.host;

    alert(serverURL);
    var _orgName = Xrm.Page.context.getOrgUniqueName();


    if (Xrm.Page.ui.getFormType() != 1) {
        if (Xrm.Page.getAttribute("category").getValue() == "Painter Meet") {
            if (Xrm.Page.getAttribute("subcategory").getValue() == "Lifting Details Verification") {
                Xrm.Page.ui.tabs.get('Phone_Grid').sections.get("Phone_Main_Grid").setVisible(true); //SHOW SECTION 

                var context;
                var objectId;
                var orgName;
                var userId;
                var hostName;

                context = Xrm.Page.context;
                objectId = Xrm.Page.data.entity.getId();
                orgName = context.getOrgUniqueName();
                userId = context.getUserId();
                hostName = window.location.hostname;

                var arr = Xrm.Page.getAttribute("to");
                var DealerGuid = arr.getValue()[0].id;


                DealerGuid = DealerGuid.replace("{", "");
                DealerGuid = DealerGuid.replace("}", "");

                var ld = "http//10.150.80.11:7035/LiftingDetailsVerificationGrid.aspx?Id=" + DealerGuid;

                if (document.all.IFRAME_LiftingDetailsGrid != null) {
                    document.all.IFRAME_LiftingDetailsGrid.src = ld;
                }
            }
        }
    }
}

function SenderChange() {
    if (Xrm.Page.getAttribute("directioncode").getValue() == false && Xrm.Page.getAttribute('from') != null && Xrm.Page.getAttribute('from').getValue() != null) {
        if (Xrm.Page.getAttribute('from').getValue()[0].type != 8) {
            Xrm.Page.getAttribute('regardingobjectid').setValue(Xrm.Page.getAttribute('from').getValue());
        }
    }
    else if (Xrm.Page.getAttribute("directioncode").getValue() == true && Xrm.Page.getAttribute('to') != null && Xrm.Page.getAttribute('to').getValue() != null) {
        if (Xrm.Page.getAttribute('to').getValue() != 8) {
            Xrm.Page.getAttribute('regardingobjectid').setValue(Xrm.Page.getAttribute('to').getValue());
        }
    }
    else {
        Xrm.Page.getAttribute('regardingobjectid').setValue(null);
    }
}







function HideShowTab(tabName, visible) {
    try {
        Xrm.Page.ui.tabs.get(tabName).setVisible(visible);
    }
    catch (err) { }
}

//HideShowTab("general", false);



function WonLeadSurvey() {
    //debugger;
    var UpdateStatus = Xrm.Page.ui.controls.get("ber_updatestatus");
    if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category").getValue() == "Won Lead Survey") {
        // setVisibleSection("Phone_Call_Servey", "Tool_Confirmation_Survey", true);
        HideShowTab("Phone_Call_Servey", true);
        UpdateStatus.setVisible(true);
        Xrm.Page.getAttribute("ber_updatestatus").setRequiredLevel("required");

    }
    else {

        // setVisibleSection("Phone_Call_Servey", "Tool_Confirmation_Survey", false);
        HideShowTab("Phone_Call_Servey", false);
        UpdateStatus.setVisible(false);
        //Xrm.Page.getAttribute("ber_updatestatus").setRequiredLevel("none");

    }
}






















function LeadUpdate(id, entityObject, odataSetName, successCallback, errorCallback) {
    var context = Xrm.Page.context;
    // var serverUrl = context.getServerUrl();
    var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    // var serverUrl = "http://10.62.163.60:6505/BergerQA";

    //The XRM OData end-point
    var ODATA_ENDPOINT = "/XRMServices/2011/OrganizationData.svc";

    //id is required
    if (!id) {
        alert("record id is required.");
        return;
    }
    //odataSetName is required, i.e. "AccountSet"
    if (!odataSetName) {
        alert("odataSetName is required.");
        return;
    }

    //Parse the entity object into JSON
    var jsonEntity = window.JSON.stringify(entityObject);

    //Asynchronous AJAX function to Update a CRM record using OData
    $.ajax({
        type: "POST",
        async: false,
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        data: jsonEntity,
        url: serverUrl + ODATA_ENDPOINT + "/" + odataSetName + "(guid'" + id + "')",
        beforeSend: function (XMLHttpRequest) {
            //Specifying this header ensures that the results will be returned as JSON.             
            XMLHttpRequest.setRequestHeader("Accept", "application/json");

            //Specify the HTTP method MERGE to update just the changes you are submitting.             
            XMLHttpRequest.setRequestHeader("X-HTTP-Method", "MERGE");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            //The MERGE does not return any data at all, so we'll add the id 
            //onto the data object so it can be leveraged in a Callback. When data 
            //is used in the callback function, the field will be named generically, "id"
            data = new Object();
            data.id = id;
            if (successCallback) {
                successCallback(data, textStatus, XmlHttpRequest);
            }
        },
        error: function (XmlHttpRequest, textStatus, errorThrown) {
            if (errorCallback)
                errorCallback(XmlHttpRequest, textStatus, errorThrown);
            else
                errorHandler(XmlHttpRequest, textStatus, errorThrown);
        }
    });
}


function errorHandler(xmlHttpRequest, textStatus, errorThrow) {
    alert("Error : " + textStatus + ": " + xmlHttpRequest.statusText);
}

//Called upon successful Account update.
function updateLeadCompleted(data, textStatus, XmlHttpRequest) {
    //Get back the Account JSON object
    // var lead = data;
    // alert("Lead updated: id = " + lead.id);
    //  Xrm.Page.getAttribute("statuscode").setValue() == true;
}



/*function SetDefaultCurrency() {
var lookupData = new Array();
var lookupItem = new Object();
lookupItem.id = "{BEFE5DB9-F9DB-E111-8D9A-5EF3FC9CC7BB}";
lookupItem.entityType = "transactioncurrency";
lookupItem.name = "Rupee;";
lookupData[0] = lookupItem;
Xrm.Page.getAttribute("transactioncurrencyid").setValue(lookupData);
}
*/


function SetLeadStatus() {  //  debugger;
    var CalculatedValue = null;
    if (Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue") != undefined && Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue") != null) {

        var leadphonecall = Xrm.Page.getAttribute("regardingobjectid").getValue();

        var Category = Xrm.Page.getAttribute("category").getValue();

        if (Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue").getValue() != null) {

            var Paintingcost = Xrm.Page.getAttribute("ber_whatisthecostofpaintingvalue").getValue();
            CalculatedValue = (Paintingcost * 45) / 100
        }



        var UpdateStatus = Xrm.Page.getAttribute("ber_updatestatus").getValue();


        if (leadphonecall != null && leadphonecall != undefined) {
            var leadPhonecallid = leadphonecall[0].id;
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads?$select=ber_totaljobvalue,statuscode&$filter=leadid eq " + leadPhonecallid, true);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var results = JSON.parse(this.response);
                if (results != null) {
                    if (results.value.length > 0) {

                        var ber_totaljobvalue = results.value[i]["ber_totaljobvalue"];
                        var ber_totaljobvalue_formatted = results.value[i]["ber_totaljobvalue@OData.Community.Display.V1.FormattedValue"];
                        var statuscode = results.value[i]["statuscode"];
                    }
                }
            }


            var cleartotaljob = 0;
            // If status is XP, do nothing{


            if (statuscode == 278290005 && Category == "Won Lead Survey" && UpdateStatus == 2) {

                var lead1 = {
                    // EP Status = XP
                    StatusCode: { Value: 278290008 }
                };
                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                LeadUpdate(leadPhonecallid, lead1, "LeadSet", updateLeadCompleted, null);


            }

            else if (statuscode == 278290010 && Category == "XP CSAT") {

                var lead1 = new Object();
                if (Paintingcost != null)
                    lead1.ber_totaljobvalue = { Value: Paintingcost.toFixed(2) };

                else
                    // lead1.ber_totaljobvalue = { Value: cleartotaljob.toFixed(2) };
                    lead1.ber_totaljobvalue = { Value: null }; //parseFloat(eval(cleartotaljob))


                if (CalculatedValue != null)
                    lead1.ber_totalmaterialconsumedvalue = { Value: CalculatedValue.toFixed(2) };

                //updateRecord exists in JQueryRESTDataOperationFunctions.js
                LeadUpdate(leadPhonecallid, lead1, "LeadSet", updateLeadCompleted, null);

            }

        }
    }


}






/*

function SetConsumedValue() {
//  debugger;
if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category").getValue() == "XP CSAT" ){
//var updateStatus = false;
		
var leadphonecall = Xrm.Page.getAttribute("regardingobjectid").getValue();
// var item = Xrm.Page.getAttribute("ber_itemid").getValue();
if (leadphonecall != null && leadphonecall != undefined) {
var leadPhonecallid1 = leadphonecall[0].id;
var leadColumns = ['StatusCode','ber_totaljobvalue'] 
var LeadFilter = "LeadId eq guid'" + leadPhonecallid1 + "'";
var LeadCollection = CrmRestKit.RetrieveMultiple('Lead', leadColumns, LeadFilter);
if (LeadCollection != null && LeadCollection != undefined) {
if (LeadCollection.results != null) {
if (LeadCollection.results.length > 0) {
var collection = LeadCollection.results[0];
var LeadStatus = collection.StatusCode.Value;
}
}
}
// If status is XP, do nothing
if (LeadStatus == 278290010 && Paintingcost != null && ) {

var lead2 = {
// EP Status = XP
ber_totaljobvalue:Paintingcost 
};
//updateRecord exists in JQueryRESTDataOperationFunctions.js
LeadUpdate(leadPhonecallid1, lead2, "LeadSet", updateLeadCompleted, null);


}
}

}
	
	
}
	
	
*/





function setCallCenterFeedBackForIOT() {

    if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category") != undefined) {
        var Category = Xrm.Page.getAttribute("category").getValue();
        if (Category != null && Category == "SR IoT Phone Call") {
            var leadphonecall = Xrm.Page.getAttribute("regardingobjectid").getValue();
            var callcenterfeedback = Xrm.Page.getAttribute("description").getValue();
            if (leadphonecall != null && leadphonecall != undefined) {
                var leadPhonecallid = leadphonecall[0].id;
                //var leadColumns = ['StatusCode', 'ber_totaljobvalue'];
                //var LeadFilter = "LeadId eq guid'" + leadPhonecallid + "'";
            }

            //var incident1 = {
            //    description: { Value: callcenterfeedback }
            //};

            var incident1 = new Object();
            //incident1.ber_CallcenterFeedback = callcenterfeedback;
            incident1.ber_CallCenterFeedback = callcenterfeedback;


            LeadUpdate(leadPhonecallid, incident1, "IncidentSet", updateLeadCompleted, null)

            //var incidentidGuid = Xrm.Page.getAttribute("regardingobjectid").getValue();
            //var callcenterfeedback = Xrm.Page.getAttribute("description").getValue();
            //var entity = new Object();
            //entity.ber_callcenterfeedback = callcenterfeedback;



            /*
            $.ajax({
            type: "POST",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/incidents('" + incidentidGuid + "')",
            data: JSON.stringify(entity),
            beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
            XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
            },
            async: true,
            success: function (data, textStatus, xhr) {
            //Success - No Return Data - Do Something
            },
            error: function (xhr, textStatus, errorThrown)
            {
            Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
            });
            */

        }
    }
}

