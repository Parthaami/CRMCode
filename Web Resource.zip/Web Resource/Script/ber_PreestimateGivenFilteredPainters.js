function filterPreEstimateGivenPainterByDepot() {
    //document.getElementById("ber_masterpainterid").disableViewPicker = 0;
    //  var ItemName = Xrm.Page.data.entity.attributes.get("ber_itemid").getValue()[0].name;
    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        if (_depotId != null) {
            // _depotId = _depotId.replace("{", "");
            //_depotId = _depotId.replace("}", "");
            var view_PaintersByDepotDisplayname = "XP/PXP Painters with Sander";
            //var view_PaintersByDepotId = Xrm.Page.getControl("ber_estimatedpainter").getDefaultView();//GetuniqueGuid();
            var view_PaintersByDepotId = "{00000000-0000-0000-00AA-000010001007}";
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="fullname" width="100" />' +
                    '<cell name="ber_exteriorpainterrating" width="100" />' +
                    '<cell name="ber_epstatus" width="100" />' +
                    '<cell name="ber_painterrating" width="100" />' +
                    '<cell name="ber_havesander" width="100" />' +
                    '<cell name="ber_dealerid" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_preferredlanguage1" width="100" />' +
                    '<cell name="ber_preferredlanguage2" width="100" />' +
              '</row>' +
              '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="contact">' +
                    '<attribute name="fullname" />' +
                    '<attribute name="contactid" />' +
                    '<attribute name="ber_preferredlanguage2" />' +
                    '<attribute name="ber_preferredlanguage1" />' +
                    '<attribute name="ber_painterrating" />' +
                    '<attribute name="ber_exteriorpainterrating" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="ber_dealerid" />' +
                    '<attribute name="ber_epstatus" />' +
                    '<attribute name="mobilephone" />' +
                    '<attribute name="ber_havesander" />' +
                    '<order attribute="fullname" descending="false" />' +
                    '<filter type="and">' +
                      '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                       '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                      '<condition attribute="ber_epstatus" operator="in">' +
                        '<value>278290003</value>' +
                        '<value>278290000</value>' +
                      '</condition>' +
                      ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                      '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                  '</entity>' +
                '</fetch>';
            Xrm.Page.getControl("ber_estimatedpainter").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
            Xrm.Page.getControl("ber_estimatedpainter").setDefaultView(view_PaintersByDepotId);
            //document.getElementById("ber_estimatedpainter").disableViewPicker = 1;
            $("#ber_estimatedpainter").find("img").attr("disableviewpicker", "1");


        }
    }

}







function IsestimateGiven() {

    //  Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);

    if (Xrm.Page.getAttribute("ber_isestimategiven") != undefined || Xrm.Page.getAttribute("ber_isestimategiven") != null) {

        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {

            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

        if (Xrm.Page.getAttribute("statuscode").getValue() != null && Xrm.Page.getAttribute("statuscode") != undefined) {
            var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
        }

        if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
            var estimateGiven = Xrm.Page.getAttribute("ber_isestimategiven").getValue();
            if (estimateGiven == 1 && leadtype == 278290002 && statuscodevalue == 278290032) {
                //estimategiven  = Yes, leadtype = XP, statusreason = CE Assign

                //  Modified by Madhumita, dated on 28th Jan,2019

                Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(false);
                Xrm.Page.getAttribute("ber_estimatedpainter").setRequiredLevel("none");
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("required");
                Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setDisabled(false);
                Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("required");
                Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setDisabled(false);
                Xrm.Page.getAttribute("ber_lbhpserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);


            }

            else if (estimateGiven == 2 && leadtype == 278290002 && statuscodevalue == 278290032) {
                /*
                Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("preliminaryserialnumber").setDisabled(true);
                Xrm.Page.getAttribute("ber_lbhpserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);
                */
                Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
                Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setDisabled(true);
                Xrm.Page.ui.controls.get("ber_estimatedpaintingcost").setDisabled(true);
                Xrm.Page.getAttribute("ber_lbhpserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setVisible(false);
            }


            else if (estimateGiven == 1 && leadtype == 278290001 && statuscodevalue == 278290032) {

                Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
                Xrm.Page.getAttribute("ber_lbhpserialnumber").setRequiredLevel("required");
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setDisabled(false);
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setDisabled(false);
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setDisabled(false);


            }

            else if (estimateGiven == 2 && leadtype == 278290001 && statuscodevalue == 278290032) {

                Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(false);
                Xrm.Page.getAttribute("ber_lbhpserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_lbhpserialnumber").setDisabled(true);
                Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");
                Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setVisible(false);
                Xrm.Page.ui.controls.get("ber_lbhpquotationvalue").setDisabled(false);
                Xrm.Page.ui.controls.get("ber_lbhpquotationserialnumber").setDisabled(false);


            }

            else {

                //   Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
                //   Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("none");
                //   Xrm.Page.ui.controls.get("preliminaryserialnumber").setDisabled(true);



            }
        }

        else {
            Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
        }
    }
}