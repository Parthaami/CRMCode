function CSI() {
    Xrm.Page.ui.tabs.get("tab_5").setVisible(false);

    if (Xrm.Page.getAttribute("category").getValue() != null && Xrm.Page.getAttribute("category").getValue() != undefined && Xrm.Page.getAttribute("subcategory").getValue() != null && Xrm.Page.getAttribute("subcategory").getValue() != undefined) {

        var Category = Xrm.Page.getAttribute("category").getValue();
        var Subcategory = Xrm.Page.getAttribute("subcategory").getValue();

        if (Category == "CSI" && Subcategory == "Pre Painting") {
            Xrm.Page.ui.tabs.get("tab_5").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_1").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_2").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_3").setVisible(false);
            Xrm.Page.getAttribute("ber_csijobdoneontime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csicompletedjobrating").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csicsmsitevisitfrequency").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csibehaviourofapplicator").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csiapplicatiorvisit").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csirespondingtime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csionsiterespondingtime").setRequiredLevel("none");

        }
        else if (Category == "CSI" && Subcategory == "During Painting") {
            Xrm.Page.ui.tabs.get("tab_5").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_1").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_2").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_3").setVisible(false);
            Xrm.Page.getAttribute("ber_csirespondingtime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csionsiterespondingtime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csijobdoneontime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csicompletedjobrating").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csicsmsitevisitfrequency").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csiapplicatiorvisit").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csibehaviourofapplicator").setRequiredLevel("none");

        }
        else if (Category == "CSI" && Subcategory == "Post Painting") {
            Xrm.Page.ui.tabs.get("tab_5").setVisible(true);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_1").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_2").setVisible(false);
            Xrm.Page.ui.tabs.get("tab_5").sections.get("tab_5_section_3").setVisible(true);
            Xrm.Page.getAttribute("ber_csicsmsitevisitfrequency").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csibehaviourofapplicator").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csirespondingtime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csionsiterespondingtime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csiapplicatiorvisit").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csijobdoneontime").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_csicompletedjobrating").setRequiredLevel("none");

        }

    }

}


function warrantydocuments() {
    Xrm.Page.ui.controls.get("ber_csisignedcompletedcertificate").setVisible(false);

    if (Xrm.Page.getAttribute("ber_csireceiptofwarrentcertificate").getValue() != null && Xrm.Page.getAttribute("ber_csireceiptofwarrentcertificate").getValue() != 'undefined') {
        var warrantycertificate = Xrm.Page.getAttribute("ber_csireceiptofwarrentcertificate").getValue();

        if (warrantycertificate == false) {
            Xrm.Page.ui.controls.get("ber_csisignedcompletedcertificate").setVisible(true)
        }
    }
}