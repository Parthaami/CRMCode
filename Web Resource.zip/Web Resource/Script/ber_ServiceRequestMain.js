function OnFormLoad() {
    //Hiding business process flow
    $("#header_process_d").css("display", "none");
    //Ticket # A0969
    var formtype = Xrm.Page.ui.getFormType();
    if (formtype != 1) {
        Xrm.Page.getControl("pcl_resolutiontype").setDisabled(true);
    }
    //Ticket #A1068
    else {
        //debugger;
        if (Xrm.Page.getAttribute("customerid") != null && Xrm.Page.getAttribute("customerid") != 'undefined' && (Xrm.Page.getAttribute("ber_siteid").getValue() == null || Xrm.Page.getAttribute("ber_siteid").getValue() == 'undefined')) {
            var cust = Xrm.Page.getAttribute("customerid").getValue();
            if (Xrm.Page.getAttribute("ber_leadid").getValue() != null && Xrm.Page.getAttribute("ber_leadid") != 'undefined') {
                var lead = Xrm.Page.getAttribute("ber_leadid").getValue();
                var leadid = lead[0].id;
                var leadRecordGuid = leadid.replace("{", "").replace("}", "");
            }

            if (cust != null && cust[0].id != null) {
                var custid = cust[0].id;
                var lookupRecordGuid = custid.replace("{", "").replace("}", "");
                var entitytype = cust[0].entityType;
                var custname = cust[0].name;
                // if SR is against any lead record
                if (lead != null && custname == "Customer Not Found") {
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads?$select=_ber_depotid_value&$filter=leadid eq " + leadRecordGuid, false);
                    req.setRequestHeader("OData-MaxVersion", "4.0");
                    req.setRequestHeader("OData-Version", "4.0");
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                    req.send();

                    if (req.response != null && req.response != "") {
                        var results = JSON.parse(req.response);
                        if (results != null) {
                            if (results.value.length > 0) {
                                var _ber_depotid_value = results.value[0]["_ber_depotid_value"];
                                var _ber_depotid_value_formatted = results.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                                var _ber_depotid_value_lookuplogicalname = results.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                                var depo = new Array();
                                depo[0] = new Object();
                                depo[0].id = _ber_depotid_value;
                                depo[0].name = _ber_depotid_value_formatted;
                                depo[0].entityType = _ber_depotid_value_lookuplogicalname;
                                if (Xrm.Page.getAttribute("ber_depot") != null)
                                    Xrm.Page.getAttribute("ber_depot").setValue(depo);
                            }
                        }
                    }
                }

                else if (lead == null && custname != "Customer Not Found") {
                    if (entitytype == "contact") {

                        var req = new XMLHttpRequest();
                        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid&$filter=contactid eq " + lookupRecordGuid, false);

                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req.send();
                        if (req.response != null && req.response != "") {
                            var result = JSON.parse(req.response);
                            if (result != null) {
                                // alert(result.value.length);
                                if (result.value.length > 0) {
                                    var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                                    var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                    var contactid = result.value[0]["contactid"];
                                    var depo = new Array();
                                    depo[0] = new Object();
                                    depo[0].id = _ber_depotid_value;
                                    depo[0].name = _ber_depotid_value_formatted;
                                    depo[0].entityType = _ber_depotid_value_lookuplogicalname;
                                    //  alert(depo[0].name);
                                    if (Xrm.Page.getAttribute("ber_depot") != null)
                                        Xrm.Page.getAttribute("ber_depot").setValue(depo);
                                }
                            }
                        }
                    }

                    else if (entitytype == "account") {
                        var req = new XMLHttpRequest();
                        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=_ber_depotid_value&$filter=accountid eq " + lookupRecordGuid, false);

                        req.setRequestHeader("OData-MaxVersion", "4.0");
                        req.setRequestHeader("OData-Version", "4.0");
                        req.setRequestHeader("Accept", "application/json");
                        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

                        req.send();
                        if (req.response != null && req.response != "") {
                            var result = JSON.parse(req.response);
                            if (result != null) {
                                alert(result.value.length);
                                if (result.value.length > 0) {
                                    var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                                    var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                    // var contactid = result.value[0]["contactid"];
                                    var depo = new Array();
                                    depo[0] = new Object();
                                    depo[0].id = _ber_depotid_value;
                                    depo[0].name = _ber_depotid_value_formatted;
                                    depo[0].entityType = _ber_depotid_value_lookuplogicalname;
                                    alert(depo[0].name);
                                    if (Xrm.Page.getAttribute("ber_depot") != null)
                                        Xrm.Page.getAttribute("ber_depot").setValue(depo);
                                }
                            }
                        }

                    }
                }
            }
        }

    }
    Xrm.Page.getControl("statecode").setVisible(false);
    onloadlead();
}
function onloadlead() {
    if (Xrm.Page.getAttribute("ber_leadid").getValue() != null) {
        Xrm.Page.getControl("ber_leadid").setVisible(true);
        Xrm.Page.getControl("ber_leadid").setDisabled(true);
    }
}
function IsColorBankRequest() {
    if (Xrm.Page.getAttribute("pcl_srtypeid") != null) {
        var SRType = Xrm.Page.getAttribute("pcl_srtypeid").getValue();
        if (SRType != null) {
            var SRTypeId = SRType[0].id;
            var IsCBRequestCol = ['ber_ColorBankSRType'];
            var SRTypeToFilter = "pcl_srtypeId eq guid'" + SRTypeId + "'";
            var collection = CrmRestKit.RetrieveMultiple('pcl_srtype', IsCBRequestCol, SRTypeToFilter);
            if (collection != null && collection.results != null && collection.results[0].ber_ColorBankSRType != null) {
                if (collection.results[0].ber_ColorBankSRType) {
                    Xrm.Page.getAttribute("ber_colorbankmachine").setRequiredLevel("required");
                    return;
                }
            }
        }
    }
    Xrm.Page.getAttribute("ber_colorbankmachine").setRequiredLevel("none");
}
// Ticket # A1019
function description_checkspecialchar() {
    var iChars = "<>";
    var desc = Xrm.Page.getAttribute("description").getValue();
    for (var i = 0; i < desc.length; i++) {
        if (iChars.indexOf(desc.charAt(i)) != -1) {
            // Remove HTML special characters "<" and ">"
            var updatedDesc = desc.replace(/[<>]/g, "");
            Xrm.Page.getAttribute("description").setValue(updatedDesc);
        }
    }
}