function CSATScore() {
    if (Xrm.Page.getAttribute("category") != null && Xrm.Page.getAttribute("category").getValue() == "XP CSAT") {
        if (Xrm.Page.getAttribute("ber_csatpainterrating").getValue() == 1) {

         //   var CSATRating = Xrm.Page.getAttribute("ber_csatpainterrating").getValue();
            Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setValue(1);
        
        }

    else if (Xrm.Page.getAttribute("ber_csatpainterrating").getValue() == 2) {

        Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setValue(3);
    
        }

else if (Xrm.Page.getAttribute("ber_csatpainterrating").getValue() == 3) {

    Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setValue(5);

        }
    

    else{

        }
    
    }

    else {

        setVisibleSection("phonecall", "CSAT_Survey", false);
        Xrm.Page.getAttribute("ber_pleaserateyouroverallsatisfaction1to5").setValue(null);
     
    }
}