function MeetPlanningOnSave(context) {
    var event = context.getEventArgs();
    if (Xrm.Page.getAttribute("ber_meet").getValue() != null) {
        var meettypeid = new Array();
        meettypeid[0] = new Object();
        var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;
        var depotId = Xrm.Page.getAttribute("ber_depot").getValue()[0].id;
        var Meetguid = MeetId.replace("{", "").replace("}", "");
        var Depotguid = depotId.replace("{", "").replace("}", "");
        // var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id.replace("{", "").replace("}", "");
        //  var depotId = Xrm.Page.getAttribute("ber_depot").getValue()[0].id.replace("{", "").replace("}", "");

        // Retrieve meet data
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meets?$select=ber_lastplanningdate,ber_type&$filter=ber_meetid eq " + Meetguid, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads?$select=ber_totaljobvalue,statuscode&$filter=leadid eq " + leadPhonecallid, true);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var ber_lastplanningdate = result.value[0]["ber_lastplanningdate"];
                var ber_type = result.value[0]["ber_type"];
                var ber_type_formatted = result.value[0]["ber_type@OData.Community.Display.V1.FormattedValue"];
            }
        }


        // Retrieve meet planning data 

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_meetdepotses?$select=ber_maxbudgetperpainter,ber_maxpainters&$filter=_ber_depotid_value eq " + Depotguid + " and  _ber_meetid_value eq " + Meetguid, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result1 = JSON.parse(req.response);
            if (result1 != null) {
                var ber_maxbudgetperpainter = result1.value[0]["ber_maxbudgetperpainter"];
                var ber_maxbudgetperpainter_formatted = result1.value[0]["ber_maxbudgetperpainter@OData.Community.Display.V1.FormattedValue"];
                var ber_maxpainters = result1.value[0]["ber_maxpainters"];
                var ber_maxpainters_formatted = result1.value[0]["ber_maxpainters@OData.Community.Display.V1.FormattedValue"];
            }
        }

        //       alert(ber_maxbudgetperpainter_formatted);
        //      alert(ber_maxpainters_formatted);
        if (!UserHasRole("HO User")) {
            if (Xrm.Page.getAttribute("ber_noofapplicators").getValue() != null) {
                if (Xrm.Page.getAttribute("ber_noofapplicators").getValue() > ber_maxpainters_formatted) {
                    alert('Cannot plan this meet for more than ' + ber_maxpainters_formatted + ' painters.');
                    //event.returnValue = false;
                    event.preventDefault();
                }

            }

            if (Xrm.Page.getAttribute("ber_costperhead").getValue() != null) {
                if (Xrm.Page.getAttribute("ber_costperhead").getValue() > ber_maxbudgetperpainter) {
                    alert('Budget per painter should not exceed Rs.' + ber_maxbudgetperpainter);
                    //event.returnValue = false;
                    event.preventDefault();
                }
            }
        }

    }
}





function Calculate() {
    Xrm.Page.getAttribute("ber_noofapplicators").getValue();
    Xrm.Page.getAttribute("ber_costperhead").getValue();
    if (Xrm.Page.getAttribute("ber_noofapplicators").getValue() != null && Xrm.Page.getAttribute("ber_costperhead").getValue() != null) {
        var applicants = Xrm.Page.getAttribute("ber_noofapplicators").getValue();
        var cost = Xrm.Page.getAttribute("ber_costperhead").getValue();

        var total = applicants * cost;

        Xrm.Page.getAttribute("ber_totalexpenditure").setValue(total);
        Xrm.Page.data.entity.attributes.get("ber_totalexpenditure").setSubmitMode("always");

    }
    else {
        Xrm.Page.getAttribute("ber_totalexpenditure").setValue(null);
        Xrm.Page.data.entity.attributes.get("ber_totalexpenditure").setSubmitMode("always");

    }
}

function CaluculatePoints() {
    var volumebonus = 0;
    var groupbonus = 0;
    var beniftbous = 0;
    var totalpoints = 0;

    if (Xrm.Page.getAttribute("ber_benefitpoints").getValue() != null) {
        if (Xrm.Page.getAttribute("ber_volumebonus").getValue() != null) {
            volumebonus = Xrm.Page.getAttribute("ber_volumebonus").getValue();
        }
        if (Xrm.Page.getAttribute("ber_groupbonus").getValue() != null) {
            groupbonus = Xrm.Page.getAttribute("ber_groupbonus").getValue();
        }

        beniftbous = Xrm.Page.getAttribute("ber_benefitpoints").getValue();
    }

    total = volumebonus + groupbonus + beniftbous;

    Xrm.Page.getAttribute("ber_totalpointmeet").setValue(total);
}