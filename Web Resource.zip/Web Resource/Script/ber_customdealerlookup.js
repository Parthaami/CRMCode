var _url = "http://10.150.80.11:7035";

function clientmap() {
    var setlabel = document.getElementById("IFRAME_dealer_c");
    setlabel.innerHTML = "<LABEL for=IFRAME_dealer>Dealer<IMG alt=Required src='/_imgs/frm_required.gif'></LABEL>";


    var map = true;
    var orgName = Xrm.Page.context.getOrgUniqueName();
    var meetplanningid = Xrm.Page.getAttribute("ber_paintermeetid").getValue();
    if (meetplanningid == null) {
        meetplanningid = "0000";
    }
    else {
        meetplanningid = meetplanningid[0].id;
    }

    var PainterId = Xrm.Page.getAttribute("ber_contactid").getValue();
    if (PainterId != null)
        PainterId = PainterId[0].id;
    else
        PainterId = "00000000-0000-0000-0000-000000000000";

    var Title = Xrm.Page.getAttribute("ber_dealerid").getValue();
    if (Title == null) {
        Title = '';
        map = false;
    }
    else {
        Title = Title[0].name;
    }
    while (Title.search('&') != -1) {
        Title = Title.replace("&", "@");
    }

    //var URI = "/ISV/" + orgName + "/PainterMeetLeadCustomApp/Lookupbox.aspx?title=" + Title + "&map=" + map + "&PainterId=" + PainterId + " &lookfor=client";
    var URI = _url + "/Lookupbox.aspx?title=" + Title + "&map=" + map + "&PainterId=" + PainterId + " &lookfor=client";

    document.all.IFRAME_dealer.src = URI;
}



function clientmaponsave(ExecutionObj) {

    //***************Submit ClientMap iframe for save*******************//
    if (Xrm.Page.ui.getFormType() == 1) {
        var dealer = Xrm.Page.getAttribute("ber_dealerid").getValue();
        if (dealer == null) {
            alert("You must provide a value for Dealer.");
            event.returnValue = false;
        }
    }
    if (document.getElementById('IFRAME_dealer') != null && document.getElementById('IFRAME_dealer') != 'undefined') {
        var iframe = document.getElementById('IFRAME_dealer');
        var iframeDoc = iframe.Document;
        var ClientId = "";
        var ClientName = "";
        var IsUparent = "";
        if (iframeDoc.getElementById('HiddenId') != null && document.getElementById('HiddenId') != 'undefined') {
            ClientId = iframeDoc.getElementById('HiddenId').value;
        }
        if (iframeDoc.getElementById('HiddenName') != null && document.getElementById('HiddenName') != 'undefined') {
            ClientName = iframeDoc.getElementById('HiddenName').value;
        }

        var name = iframeDoc.getElementById('MainTextBox1').value;

        if (ClientId != "" && ClientId != null && ClientId != 'undefined' && ClientName != "" && ClientName != null && ClientName != 'undefined') {
            var lookupvalue = new Array();
            lookupvalue[0] = new Object();
            lookupvalue[0].id = ClientId;
            lookupvalue[0].name = ClientName;
            lookupvalue[0].entityType = "account";
            Xrm.Page.getAttribute("ber_dealerid").setValue(lookupvalue);
            // Xrm.Page.getAttribute("ber_dealername").setValue(ClientName);        
        }

    }

}