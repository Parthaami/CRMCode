function filteredInfluencer() {
    if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode") != undefined) {

        var Leadsource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        var Leadsourcename = Xrm.Page.getAttribute("leadsourcecode").getText();
        if (Leadsourcename == 'Architect' || Leadsourcename == 'Interior Decorator' || Leadsourcename == 'Builders/ Promoters' || Leadsourcename == 'Engineer' || Leadsourcename == 'Competition Painter') {
            var view_PaintersByDepotDisplayname = "Filtered Influencer List";
            // var view_PaintersByDepotId = GetuniqueGuid();
            var view_PaintersByDepotId = "{20A043D1-EAFF-47FD-96BB-96C0FA1C6598}";
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="ber_name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="ber_influencerid">' +
                    '<cell name="ber_name" width="100" />' +
                     '<cell name="ber_influencername" width="100" />' +
                    '<cell name="ber_influencertype" width="100" />' +
                    '<cell name="ber_mobilenumber" width="100" />' +
              '</row>' +
              '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                                       '<entity name="ber_influencer">' +
                                       '<attribute name="ber_influencerid" />' +
                                       '<attribute name="ber_name" />' +
                                       '<attribute name="ber_influencername" />' +
                                       '<attribute name="createdon" />' +
                                       '<attribute name="ber_mobilenumber" />' +
                                       '<attribute name="ber_influencertype" />' +
                                       '<order attribute="ber_name" descending="false" />' +
                                       '<filter type="and">' +
                                      '<condition attribute="ber_influencertype" operator="eq" value="' + Leadsource + '" />' +
                                       '<condition attribute="statecode" operator="eq" value="0" />' +
                                       '<condition attribute="ber_mobilenumber" operator="not-null" />' +
                                       '</filter>' +
                                       '</entity>' +
                                       '</fetch>';

            var fetchData = XrmServiceToolkit.Soap.Fetch(fetchxml_PaintersByDepot);

            Xrm.Page.getControl("ber_influencer").addCustomView(view_PaintersByDepotId, "ber_influencer", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
            Xrm.Page.getControl("ber_influencer").setDefaultView(view_PaintersByDepotId);
            document.getElementById("ber_influencer").disableViewPicker = 1;


        }

        else {

        }


    }

    // leadsourcehide_visible();

}


/////////////////Modified by Madhumita, 30th May//////////////////////


function leadsourcehide_visible() {

    if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode") != undefined) {
        var Leadsource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        if (Leadsource == '278290042' || Leadsource == '278290043' || Leadsource == '278290044' || Leadsource == '278290045' || Leadsource == '278290046') {
            // Xrm.Page.getAttrbute("description").setValue(Leadsource + "\r\n" +  Leadsource +  "\r\n\");
            Xrm.Page.ui.controls.get("ber_influencer").setVisible(true);
            Xrm.Page.getAttribute("ber_influencer").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_influencer").setSubmitMode("always");
        }

        else {

            Xrm.Page.ui.controls.get("ber_influencer").setVisible(false);
            Xrm.Page.getAttribute("ber_influencer").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_influencer").setValue(null);
            Xrm.Page.getAttribute("ber_influencer").setSubmitMode("always");
        }

    }
}

function InfluencerVisible() {
    if (Xrm.Page.getAttribute("ber_aidorganisation").getValue() != null && Xrm.Page.getAttribute("ber_aidorganisation") != undefined) {

        Xrm.Page.ui.controls.get("ber_influencer").setVisible(true);
        Xrm.Page.getAttribute("ber_influencer").setRequiredLevel("required");
        Xrm.Page.getAttribute("ber_influencer").setSubmitMode("always");

    }

function getDGMobileNumber() {
    if (Xrm.Page.getAttribute("ber_dgcontact") != undefined && Xrm.Page.getAttribute("ber_dgcontact").getValue() != null) {
        var DGContact = Xrm.Page.getAttribute("ber_dgcontact").getValue();

        var DGContactid = DGContact[0].id;
        //  alert(Customerid);
        var DGContactColumns = ['ContactId', 'MobilePhone'];
        //   alert(CustomerColumns);
        var DGContactFilter = "ContactId eq guid'" + DGContactid + "'";
        //    alert(CustomerFilter);
        var DGContactCollection = CrmRestKit.RetrieveMultiple('Contact', DGContactColumns, DGContactFilter);
        if (DGContactCollection != null && DGContactCollection != undefined) {
            if (DGContactCollection.results != null) {
                if (DGContactCollection.results.length > 0) {
                    var collection = DGContactCollection.results[0];
                    var phone = collection.MobilePhone;
                    //  alert(phone);
                    Xrm.Page.getAttribute("ber_dgmobilenumber").setValue(phone);
                    Xrm.Page.getAttribute("ber_dgmobilenumber").setSubmitMode("always");
                }
            }
        }
    }
}