function StValidation() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")
    if (Xrm.Page.getAttribute("ber_startdate").getValue() != null && Xrm.Page.getAttribute("ber_startdate").getValue() != undefined && Xrm.Page.getAttribute("ber_enddate").getValue() != null && Xrm.Page.getAttribute("ber_enddate").getValue() != undefined) {
        var a = Xrm.Page.getAttribute("ber_startdate").getValue();
        var b = Xrm.Page.getAttribute("ber_enddate").getValue();
        var c = calculateDays(a, b);
        if (b < a) {
            alert("start date must lesser than end date");
            Xrm.Page.getAttribute("ber_startdate").setValue(null);
        }
        else if (c < 7) {
            alert("Duration between start date and end date must be greater than 7 days");
            if (!isCrmForMobile)
                Xrm.Page.getAttribute("ber_startdate").setValue(null);

        }
    }
}

function calculateDays(datetime1, datetime2) {
    var oneDay = 1000 * 60 * 60 * 24;        // The number of milliseconds in a day
    //Convert the datetime1 and datetime2 to Date object and get Time in milliseconds

    var dt1 = new Date(datetime1).getTime();
    var dt2 = new Date(datetime2).getTime();

    // Calculate the difference in milliseconds
    var diff = Math.abs(dt1 - dt2); // Difference of Days

    return Math.round(diff / oneDay);
}





/////////////////////



function ValidatePreferredtime(executionObj) {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")
    if (Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != null && Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != undefined) {
        var preferreddate = Xrm.Page.getAttribute("ber_preferreddatetime").getValue();
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        //  status == 278290032
        if (status == 1 || status == 278290032) {
            var today = new Date();

            var StartingTime = parseFloat("9");

            var EndingTime = parseFloat("21");

            var TimeinHour = parseFloat(preferreddate.getHours()) + parseFloat(preferreddate.getMinutes()) / 60;

            if ((TimeinHour > StartingTime) && (TimeinHour < EndingTime)) {

            }
            else {
                alert("Please ensure preferred time must be between 9:00 A.M to 9:00 P.M");

                if (!isCrmForMobile)
                    Xrm.Page.getAttribute("ber_preferreddatetime").setValue(null);

                executionObj.getEventArgs().preventDefault();

            }

        }


    }

}


function PreferredDateValidation() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")
    if (Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != null && Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != undefined) {
        var a = Xrm.Page.getAttribute("ber_preferreddatetime").getValue();
        var x = new Date((a.getMonth() + 1) + "/" + a.getDate() + "/" + a.getFullYear()).setHours(0, 0, 0, 0);
        var b = new Date();
        var c = new Date((b.getMonth() + 1).toString() + "/" + b.getDate() + "/" + b.getFullYear()).setHours(0, 0, 0, 0);
        if (a != null && x <= c) {
            alert("Date Should be greater than Today's Date.");
            if (!isCrmForMobile)
                Xrm.Page.getAttribute("ber_preferreddatetime").setValue(null);

        }
    }
}

///////  Validation for Next Visit Date


function ValidateNextVisitdateTime(executionObj) {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")
    if (Xrm.Page.getAttribute("ber_nextvisitdate").getValue() != null && Xrm.Page.getAttribute("ber_nextvisitdate").getValue() != undefined) {
        var preferreddate = Xrm.Page.getAttribute("ber_nextvisitdate").getValue();
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        //  status == 278290032
        if (status == 278290032) {
            var today = new Date();

            var StartingTime = parseFloat("9");

            var EndingTime = parseFloat("21");

            var TimeinHour = parseFloat(preferreddate.getHours()) + parseFloat(preferreddate.getMinutes()) / 60;

            if ((TimeinHour > StartingTime) && (TimeinHour < EndingTime)) {

            }
            else {
                alert("Please ensure Next Visit time must be between 9:00 A.M to 9:00 P.M");
                if (!isCrmForMobile)
                    Xrm.Page.getAttribute("ber_nextvisitdate").setValue(null);

                executionObj.getEventArgs().preventDefault();

            }

        }


    }

}


function NextVisitDateValidation() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile")
    if (Xrm.Page.getAttribute("ber_nextvisitdate").getValue() != null && Xrm.Page.getAttribute("ber_nextvisitdate").getValue() != undefined) {
        var a = Xrm.Page.getAttribute("ber_nextvisitdate").getValue();
        var x = new Date((a.getMonth() + 1) + "/" + a.getDate() + "/" + a.getFullYear()).setHours(0, 0, 0, 0);
        var b = new Date();
        var c = new Date((b.getMonth() + 1).toString() + "/" + b.getDate() + "/" + b.getFullYear()).setHours(0, 0, 0, 0);

        if (a != null && x <= c) {
            alert("Date Should be greater than Today's Date. ");
            if (!isCrmForMobile)
                Xrm.Page.getAttribute("ber_nextvisitdate").setValue(null);

        }
    }
}