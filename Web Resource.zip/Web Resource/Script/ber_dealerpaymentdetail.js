function populateNameField(){

Xrm.Page.getAttribute("ber_name").setValue((Xrm.Page.getAttribute("ber_billnumber").getValue().toString() + '\\'+Xrm.Page.getAttribute("ber_bank").getValue().toString() + '\\'+ Xrm.Page.getAttribute("ber_chequeno").getValue().toString()) + '\\'+ Xrm.Page.getAttribute("ber_amount").getValue().toString())  ;

Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 
}


function ValidatePaymentAmt() {
    if (Xrm.Page.getAttribute("ber_totalpendingamount").getValue() != null && Xrm.Page.getAttribute("ber_amount").getValue() != null) {
        if (Xrm.Page.getAttribute("ber_amount").getValue() > Xrm.Page.getAttribute("ber_totalpendingamount").getValue()) {
            alert('Please enter valid amount.Pending bill amount is ' + Xrm.Page.getAttribute("ber_totalpendingamount").getValue());
            Xrm.Page.getAttribute("ber_amount").setValue(null);
            Xrm.Page.getControl("ber_amount").setFocus();
        }
    }
    else {
        alert('Please enter valid amount.Pending bill amount is ' + Xrm.Page.getAttribute("ber_totalpendingamount").getValue());
    }
}