function DifferedStatus() {

    var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();

    if (statuscodevalue == 1) {

        Xrm.Page.getAttribute("ber_differedstatus").setRequiredLevel("required");
        
    }

    else {

    // Do Nothing

    }

}