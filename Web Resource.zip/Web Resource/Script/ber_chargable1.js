// JScript source code
function Chargable1(utc) {
    if (Xrm.Page.getAttribute("ber_paintexpressitem") != undefined && Xrm.Page.getAttribute("ber_paintexpressitem").getValue() != null) {
        // alert("1");
        var painterExpressItem = Xrm.Page.getAttribute("ber_paintexpressitem").getValue();
        var painterExpressItemid = painterExpressItem[0].id;
        var painterExpressItemGUID = painterExpressItemid.replace("{", "").replace("}", "");

        // alert("2");
        var req = new XMLHttpRequest();
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statecode&$filter=_ber_itemid_value eq " + painterExpressItemGUID, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statecode&$filter=ber_paintexpressitemid eq" + painterExpressItemGUID, false);
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statuscode&$filter=ber_paintexpressitemid eq " + painterExpressItemGUID, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var _ber_itemid_value = result.value[0]["_ber_itemid_value"];
                var _ber_itemid_value_formatted = result.value[0]["_ber_itemid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_itemid_value_lookuplogicalname = result.value[0]["_ber_itemid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_name = result.value[0]["ber_name"];
                var _ber_painterid_value = result.value[0]["_ber_painterid_value"];
                var painteridGUID = _ber_painterid_value.replace("{", "").replace("}", "");
                var _ber_painterid_value_formatted = result.value[0]["_ber_painterid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_painterid_value_lookuplogicalname = result.value[0]["_ber_painterid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_toolapprovaldate = result.value[0]["ber_toolapprovaldate"];
                var statuscode = result.value[0]["statuscode"];
                // var statecode_formatted = result.value[0]["statecode@OData.Community.Display.V1.FormattedValue"];

                //alert("3");


                if (_ber_itemid_value_formatted != null) {
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(_ber_itemid_value_formatted);
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
                }
                else if (_ber_itemid_value_formatted == null) {
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
                    Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
                }
            }
        }
    }

    if (_ber_painterid_value != undefined || _ber_painterid_value != null) {
        if (statuscode == 278290000 && ber_toolapprovaldate != null) {
            var req1 = new XMLHttpRequest();
            req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.0/contacts(" + painteridGUID + ")?$select=ber_customertype,ber_toolwiseactivated", false);
            req1.setRequestHeader("OData-MaxVersion", "4.0");
            req1.setRequestHeader("OData-Version", "4.0");
            req1.setRequestHeader("Accept", "application/json");
            req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req1.setRequestHeader("Prefer", "odata.include-annotations=\"OData.Community.Display.V1.FormattedValue\"");
            req1.send();

            if (req1.response != null && req1.response != "") {
                var result1 = JSON.parse(req1.response);
                if (result1 != null) {
                    var CustomerType = result1["ber_customertype"];
                    var Activated = result1["ber_toolwiseactivated"];

                    var laterdate = new Date();

                    var prevdate = HandleODataDate(ber_toolapprovaldate);
                    if (statuscode == 278290000 && ber_toolapprovaldate != null) {
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(prevdate);
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(prevdate);
                        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");

                    }

                    var prevdateday = prevdate.getDate();
                    var prevdatemonth = prevdate.getMonth() + 1;
                    var prevdateyear = prevdate.getFullYear();

                    var laterdateday = laterdate.getDate();
                    var laterdatemonth = laterdate.getMonth() + 1;
                    var laterdateyear = laterdate.getFullYear();

                    var month, year, totaldays, totalmonth;

                    totalmonth = 0;

                    if (prevdatemonth == laterdatemonth && prevdateyear == laterdateyear) {
                        totaldays = laterdateday - prevdateday;
                        //  alert(totaldays);
                    }
                    else {
                        for (month = prevdatemonth, year = prevdateyear; year <= laterdateyear; month++) {
                            if (month == prevdatemonth && year == prevdateyear) {
                                totaldays = new Date(prevdateyear, prevdatemonth, 0).getDate() - prevdateday;
                            }
                            else if (month == laterdatemonth && year == laterdateyear) {
                                totaldays = totaldays + laterdateday;
                            }
                            else {
                                totaldays = totaldays + new Date(year, month, 0).getDate()
                            }
                            if (month == 12) {
                                month = 0;
                                year = year + 1;
                            }
                            if (month == laterdatemonth && year == laterdateyear) {
                                // alert(totaldays);
                                break;
                            }
                        }
                    }

                    // Logic for tool warranty
                    //Activated =1 => yes | Activated =2 => NO
                    //Under warranty    => 278290000
                    //under warranty   = > 278290001

                    if (ber_toolapprovaldate != null) {
                        if (totaldays <= 180)   //Under warranty for all cases  =>27,82,90,000
                        {
                            Xrm.Page.getAttribute("ber_chargable").setValue(278290000);                         // Under Warranty
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                        else if (totaldays > 365) //  Not under warranty for all cases => 27,82,90,001
                        {
                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                        else if (Activated == 1 && (totaldays > 180 && totaldays <= 365)) //Under warranty 
                        {
                            Xrm.Page.getAttribute("ber_chargable").setValue(278290000);                         // Under Warranty
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                        else if ((Activated == 2 || Activated == null) && (totaldays > 180 && totaldays <= 365)) //Not under warranty
                        {
                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                    }



                    /*
                    //   if (Activated != null && totaldays != null && ber_toolapprovaldate != null) {
                    if (ber_toolapprovaldate != null) {
                        if (Activated == 1 && totaldays <= 365) {

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290000);                         // Under Warranty
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                        else if (Activated == 2 && totaldays <= 365) {                                          // Not Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        else if (Activated == null && totaldays <= 365) {                                       // Not Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        else if (totaldays > 365) {                                                             // Not Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        if (totaldays <= 180) {

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290000);                         // Always Under Warranty
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        else if (Activated == 1 && totaldays > 180) {                                           // Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290000);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        else if (Activated == 2 && totaldays > 180) {                                          // Not Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }

                        else if (Activated == null && totaldays > 180) {                                        // Not Under Warranty

                            Xrm.Page.getAttribute("ber_chargable").setValue(278290001);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                        else if (totaldays == null) {
                            Xrm.Page.getAttribute("ber_chargable").setValue(null);
                            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                        }
                    }
                    else {
                        Xrm.Page.getAttribute("ber_chargable").setValue(null);
                        Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
                    }

                    */


                }
            }
        }
        else if (statuscode == 1 || ber_toolapprovaldate == null) {
            Xrm.Page.getAttribute("ber_chargable").setValue(null);
            Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
            Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");

        }


    }

    else {
        Xrm.Page.getAttribute("ber_chargable").setValue(null);
        Xrm.Page.getAttribute("ber_chargable").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_toolapprovaldate").setValue(null);
        Xrm.Page.getAttribute("ber_toolapprovaldate").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_expresstoolname").setValue(null);
        Xrm.Page.getAttribute("ber_expresstoolname").setSubmitMode("always");

    }


}


/**
 * HandleODataDate  
 * @param {type} dateValue
 * @returns {type} 
 */
function HandleODataDate(dateValue) {
    var returnValue = null;
    try {
        dateValue = dateValue == null ? "" : dateValue.toString();
        if (dateValue != "") {

            //dateValue = dateValue.replace("/", "");
            //dateValue = dateValue.replace("Date(", "");
            //dateValue = dateValue.replace(")", "");
            //dateValue = dateValue.replace("/", "");
            //var returnValue = new Date(parseInt(dateValue));
            //returnValue = isNaN(returnValue) ? null : returnValue;
            var dateValue = new Date(dateValue.substring(0, 10));
            return dateValue;
        }

    }
    catch (Exception) {
    }

    return returnValue;

}


/*

function SetItemName_ApprovalDate() {

    if (Xrm.Page.getAttribute("ber_paintexpressitem") != undefined && Xrm.Page.getAttribute("ber_paintexpressitem").getValue() != null) {

        var painterExpressItem = Xrm.Page.getAttribute("ber_paintexpressitem").getValue();

        var painterExpressItemid = painterExpressItem[0].id;
        var painterExpressItemguid = painterExpressItemid.replace("{", "").replace("}", "");

        /*

        var painterExpressItemColumns = ['ber_name', 'ber_painterid', 'ber_toolapprovaldate', 'statuscode', 'ber_ItemId'];

        var painterExpressItemFilter = "ber_paintexpressitemId eq guid'" + painterExpressItemid + "'";

        var painterExpressItemCollection = CrmRestKit.RetrieveMultiple('ber_paintexpressitem', painterExpressItemColumns, painterExpressItemFilter);
        if (painterExpressItemCollection != null && painterExpressItemCollection != undefined) {
        if (painterExpressItemCollection.results != null) {
        if (painterExpressItemCollection.results.length > 0) {
        var collection = painterExpressItemCollection.results[0];
        var PainterId = collection.ber_painterid.Id;

        var AproovedDate = collection.ber_toolapprovaldate;
        var Status = collection.statuscode.Value;
        
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_paintexpressitems?$select=_ber_itemid_value,ber_name,_ber_painterid_value,ber_toolapprovaldate,statecode&$filter=_ber_itemid_value eq " + painterExpressItemguid, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var _ber_itemid_value = result.value[0]["_ber_itemid_value"];
                var _ber_itemid_value_formatted = result.value[0]["_ber_itemid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_itemid_value_lookuplogicalname = result.value[0]["_ber_itemid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_name = result.value[0]["ber_name"];
                var _ber_painterid_value = result.value[0]["_ber_painterid_value"];
                var _ber_painterid_value_formatted = result.value[0]["_ber_painterid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_painterid_value_lookuplogicalname = result.value[0]["_ber_painterid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var ber_toolapprovaldate = result.value[0]["ber_toolapprovaldate"];
                var statecode = result.value[0]["statecode"];
                var statecode_formatted = result.value[0]["statecode@OData.Community.Display.V1.FormattedValue"];
            }
        }

    n}

        if (_ber_itemid_value != null) {
            //var ItemName = collection.ber_ItemId.Name;
            Xrm.Page.getAttribute("ber_expresstoolname").setValue(_ber_itemid_value_formatted);
            Xrm.Page.getAttribute("ber_expresstoolname").setSubmitMode("always");
        }

        else if (_ber_itemid_value == null) {
            //  var ItemName = collection.ber_ItemId.Name;
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
            Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
        }
    }




    else {
        Xrm.Page.getAttribute("ber_paintexpresstoolname").setValue(null);
        Xrm.Page.getAttribute("ber_paintexpresstoolname").setSubmitMode("always");
    }
}


*/