var buttonid="";
function callDialog(types,recordId)
{ 
 //Load modal
 var serverUri = Mscrm.CrmUri.create('/cs/dialog/rundialog.aspx');

 var para =new Array;
 para=types.split(',');
 var dialogId= para[0];
 var typename=para[1];

 window.showModalDialog(serverUri +'?DialogId=' + dialogId +'&EntityName=' + typename + "&ObjectId=" + recordId,  null , 'width=615, height=480, resizable=1, status=1, scrollbars=1');

 //Reload form
 window.location.reload(true);
}
function Field(field)
{ 
 var para=new Array;
 para=field.split(','); 
 buttonid=field;
 var field=para[1];
 var value=parseInt(para[2]);
 var fieldvalue=Xrm.Page.getAttribute(field).getValue();
 if(fieldvalue==value)
 {
  return true;
 }
 else
 {
  return false;
 }
}

function OnChange()
{
Xrm.Page.ui.refreshRibbon();
}
function UserHasRole(roleName)
{ 

//get Current User Roles, oXml is an object 
var oXml = GetCurrentUserRoles();
if(oXml != null)
{  
 //select the node text  
 var roles = oXml.selectNodes("//BusinessEntity/q1:name"); 
 var pararoles=new Array;
 pararoles=roleName.split(','); 
 if(roles != null)  
 {   
  for( i = 0; i < roles.length; i++) 
  {
   for(j=0;j<pararoles.length;j++)
   {     
    if(roles[i].text == pararoles[j]) 
    {    
     //return false if user has this role 
     return false;  
    }
   }  
  }  
 } 
}
 //otherwise return true
 return true;
}
function GetCurrentUserRoles()
{
  var xml = "" +
 "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
 "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
 " xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">" +
 GenerateAuthenticationHeader() +
 " <soap:Body>" +
 " <RetrieveMultiple xmlns=\"http://schemas.microsoft.com/crm/2007/WebServices\">" +
 " <query xmlns:q1=\"http://schemas.microsoft.com/crm/2006/Query\" xsi:type=\"q1:QueryExpression\">" +
 " <q1:EntityName>role</q1:EntityName>" +
 " <q1:ColumnSet xsi:type=\"q1:ColumnSet\">" +
 " <q1:Attributes>" +
 " <q1:Attribute>name</q1:Attribute>" +
 " </q1:Attributes>" +
 " </q1:ColumnSet>" +
 " <q1:Distinct>false</q1:Distinct>" +
 " <q1:LinkEntities>" +
 " <q1:LinkEntity>" +
 " <q1:LinkFromAttributeName>roleid</q1:LinkFromAttributeName>" +
 " <q1:LinkFromEntityName>role</q1:LinkFromEntityName>" +
 " <q1:LinkToEntityName>systemuserroles</q1:LinkToEntityName>" +
 " <q1:LinkToAttributeName>roleid</q1:LinkToAttributeName>" +
 " <q1:JoinOperator>Inner</q1:JoinOperator>" +
 " <q1:LinkEntities>" +
 " <q1:LinkEntity>" +
 " <q1:LinkFromAttributeName>systemuserid</q1:LinkFromAttributeName>" +
 " <q1:LinkFromEntityName>systemuserroles</q1:LinkFromEntityName>" +
 " <q1:LinkToEntityName>systemuser</q1:LinkToEntityName>" +
 " <q1:LinkToAttributeName>systemuserid</q1:LinkToAttributeName>" +
 " <q1:JoinOperator>Inner</q1:JoinOperator>" +
 " <q1:LinkCriteria>" +
 " <q1:FilterOperator>And</q1:FilterOperator>" +
 " <q1:Conditions>" +
 " <q1:Condition>" +
 " <q1:AttributeName>systemuserid</q1:AttributeName>" +
 " <q1:Operator>EqualUserId</q1:Operator>" +
 " </q1:Condition>" +
 " </q1:Conditions>" +
 " </q1:LinkCriteria>" +
 " </q1:LinkEntity>" +
 " </q1:LinkEntities>" +
 " </q1:LinkEntity>" +
 " </q1:LinkEntities>" +
 " </query>" +
 " </RetrieveMultiple>" +
 " </soap:Body>" +
 "</soap:Envelope>" +
 "";

        var xmlHttpRequest = new ActiveXObject("Msxml2.XMLHTTP");
        xmlHttpRequest.Open("POST", "/mscrmservices/2007/CrmService.asmx", false);
        xmlHttpRequest.setRequestHeader("SOAPAction", " http://schemas.microsoft.com/crm/2007/WebServices/RetrieveMultiple");
        xmlHttpRequest.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
        xmlHttpRequest.setRequestHeader("Content-Length", xml.length);
        xmlHttpRequest.send(xml);

        var resultXml = xmlHttpRequest.responseXML;
        return (resultXml);
}