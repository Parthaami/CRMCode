function setFormAsReadOnly() {
    //Write you conditions here.
    if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();

        if (Xrm.Page.getAttribute("leadsourcecode").getValue() != null && Xrm.Page.getAttribute("leadsourcecode") != undefined) {
            var leadSource = Xrm.Page.getAttribute("leadsourcecode").getValue();
        }
         var StatusReason = Xrm.Page.getAttribute("statuscode").getValue();
         if (leadtype == 278290002 && (leadSource == 278290033 || leadSource == 278290034 || leadSource == 278290035)) {
             if (StatusReason == 278290009 || StatusReason == 278290026) {

                    // if (UserHasRole("Depot User") || ("Depot Home Decor User")) {
                       if (UserHasRole("System Administrator")) {
                          disableFormFields(false);
                      }

                 //  else if (UserHasRole("System Administrator")) {
                   else if (UserHasRole("Depot User") || ("Depot Home Decor User")) {
                     disableFormFields(true);
                    }
             }
         }
    }
    

}

function doesControlHaveAttribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}

function disableFormFields(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveAttribute(control)) {
            control.setDisabled(onOff);
        }
    });
}
















function WarrantyRequired() {
    if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (Xrm.Page.getAttribute("statuscode").getValue() != null) {
            var Status = Xrm.Page.getAttribute("statuscode").getValue();
            if (leadtype == 278290002) {
                if (Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290034' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '    278290035' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290033') {
                    if (Status == 278290010 || Status == 278290006) {
                        //Xrm.Page.ui.controls.get("ber_warrantyrequired").setVisible(true);
                        Xrm.Page.ui.controls.get("ber_warrantyrequired").setDisabled(false);

                    }
                    else {
                        Xrm.Page.ui.controls.get("ber_warrantyrequired").setDisabled(true);
                        Xrm.Page.ui.controls.get("ber_capturewarrantydate").setDisabled(true);
                    }
                }
                else {
                    Xrm.Page.ui.controls.get("ber_warrantyrequired").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_capturewarrantydate").setDisabled(true);
                }
            }

            else {
                Xrm.Page.ui.controls.get("ber_warrantyrequired").setDisabled(true);
                Xrm.Page.ui.controls.get("ber_capturewarrantydate").setDisabled(true);
            }

        }

    }
}





function SaveAndClose() {
    Xrm.Page.data.entity.save();
}





///////////////////////////////


function CaptureWarrantyDate() {
    if (Xrm.Page.getAttribute("ber_warrantyrequired").getValue() != null && Xrm.Page.getAttribute("ber_warrantyrequired") != undefined) {
        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
            var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
            var statuscodevalue = Xrm.Page.getAttribute("ber_warrantyrequired").getValue();
            var today = new Date();
            if (leadtype == 278290002) {
                //if (ber_warrantyrequired == 278290004) {
                if (Xrm.Page.getAttribute("ber_capturewarrantydate") != undefined && Xrm.Page.getAttribute("ber_capturewarrantydate").getValue() == null) {

                    var CaptureDate = Xrm.Page.getAttribute("ber_capturewarrantydate").setValue(today);

                    Xrm.Page.getAttribute("ber_capturewarrantydate").setSubmitMode("always");

                }

            }
        }
    }
}