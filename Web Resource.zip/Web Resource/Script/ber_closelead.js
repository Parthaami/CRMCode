var _url = "http://10.150.80.18:7035";          // Change IP and Port as per the server where it is deployed

function onSendForApprovalButtonClick() {

    if (Xrm.Page.data.entity.getIsDirty()) {
        alert("Please save the changes.");
    }
    else {
        var context;
        var objectId;
        var orgName;
        var userId;
        var hostName;
        var serverURL = window.location.protocol + "//" + window.location.host;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        //var product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=0&etn=lead&chkboxvisible=false&Exclude=New,Verified,Approved";
        var product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=0&etn=lead&chkboxvisible=false&Exclude=New,Verified,Approved";

        //Window.open(product, "_blank", "width=900px,height=600px,resizable=1");
        var state = "help:no;status:no;scroll:no;resize:no;dialogHeight:220px;dialogWidth:360px";
        var title = "Lead";
        window.showModalDialog(product, "Change Lead Stauts", state);
        Xrm.Page.ui.close();
    }

}
function onApproveButtonClick() {

    if (Xrm.Page.data.entity.getIsDirty()) {
        alert("Please save the changes.");
    }
    else {
        var context;
        var objectId;
        var orgName;
        var userId;
        var hostName;
        var serverURL = window.location.protocol + "//" + window.location.host;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        //var product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=0&etn=lead&chkboxvisible=false&Exclude=New,Verified,Sent for Approval";
        var product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=0&etn=lead&chkboxvisible=false&Exclude=New,Verified,Sent for Approval";

        //Window.open(product, "_blank", "width=900px,height=600px,resizable=1");
        var state = "help:no;status:no;scroll:no;resize:no;dialogHeight:220px;dialogWidth:360px";
        var title = "Lead";
        window.showModalDialog(product, "Change Lead Stauts", state);
        Xrm.Page.ui.close();
    }
}


function closelead() {


    var context;
    var objectId;
    var orgName;
    var userId;
    var hostName;
    var serverURL = window.location.protocol + "//" + window.location.host;
    var product;

    context = Xrm.Page.context;
    objectId = Xrm.Page.data.entity.getId();
    orgName = context.getOrgUniqueName();
    hostName = window.location.hostname;

    objectId = objectId.replace("{", "");
    objectId = objectId.replace("}", "");

    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
    if (leadtype == 278290000) // If Lead Type is BDM
    {
        //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&leadtype=bdm&Exclude=Qualified,Estimate Approved";
        product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&leadtype=bdm&Exclude=Qualified,Estimate Approved";
    }
    else if (leadtype == 278290001) // If Lead Type is Home Decor
    {
        if (Xrm.Page.getAttribute("ber_hdemployeeid").getValue() != null) {
            //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&leadtype=hd&Exclude=Deal Closed,Estimate Approved";
            product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&leadtype=hd&Exclude=Deal Closed,Estimate Approved";
        }
        else {
            alert('You should enter HD Employee first!');
            product = "";
            var control = Xrm.Page.ui.controls.get("ber_hdemployeeid");
            control.setFocus();
        }
    }
    else {
        //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&Exclude=Estimate Approved";
        product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&chkboxvisible=false&StateCode=1&etn=lead&Exclude=Estimate Approved";
    }

    //Window.open(product, "_blank", "width=900px,height=600px,resizable=1");
    if (product != "") {
        var state = "help:no;status:no;scroll:no;resize:no;dialogHeight:270px;dialogWidth:360px";
        window.showModalDialog(product, "Change Lead Status", state);
        Xrm.Page.ui.close();
    }

}

function lostlead() {
    RemoveItem();
    var context;
    var objectId;
    var orgName;
    var userId;
    var hostName;
    var serverURL = window.location.protocol + "//" + window.location.host;
    var product;
    context = Xrm.Page.context;
    objectId = Xrm.Page.data.entity.getId();
    orgName = context.getOrgUniqueName();
    hostName = window.location.hostname;

    objectId = objectId.replace("{", "");
    objectId = objectId.replace("}", "");

    if (Xrm.Page.getAttribute("ber_leadtype") != null && Xrm.Page.getAttribute("ber_leadtype") != undefined) {
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (leadtype != null) {
            if (leadtype == 278290001)  // If Lead Type is Home Decor
            {

                //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=hd&Exclude=none";
                product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=hd&Exclude=none";
            }
            else if (leadtype == 278290002)  // If Lead Type is XP
            {
                //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=xp&Exclude=none";
                product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=xp&Exclude=none";
            }
        }
        else {

            //product = serverURL + "/ISV/" + orgName + "/PainterMeetLeadCustomApp/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=xp&Exclude=none";
            product = _url + "/LeadStatus.aspx?EntityId=" + objectId + "&ObjectTypeCode=4&StateCode=2&etn=lead&chkboxvisible=false&leadtype=xp&Exclude=none";
        }
        //Window.open(product, "_blank", "width=900px,height=600px,resizable=1");
        if (product != "") {
            var state = "help:no;status:no;scroll:no;resize:no;dialogHeight:270px;dialogWidth:360px";
            var title = "Lead";
            window.showModalDialog(product, "Change Lead Stauts", state);
            Xrm.Page.ui.close();
        }
    }



}











function RemoveItem() {

    var leadType = Xrm.Page.getAttribute("ber_leadtype").getValue();

    if (leadType == 278290002) {
        var PickListControl = Xrm.Page.getControl("statuscode");
        PickListControl.removeOption(278290013);
    }

}