function enableFields() {

    if (UserHasRole("Call Center User Additional Functionalities")) {
  //  if (UserHasRole("System Administrator")) {
     //   var status = Xrm.Page.getAttribute("statuscode").getValue();
        var recordOwner = Xrm.Page.getAttribute("ownerid").getValue()[0].id;
        var currentUserId = Xrm.Page.context.getUserId();

        if (currentUserId != recordOwner) {

            formdisable(true);
            sectiondisable("dealerinfo", true);

           //  var Painter = Xrm.Page.ui.controls.get("ber_masterpainterid");
           //  Painter.setDisabled(true);

        }
            
   }

    
    else if (UserHasRole("System Administrator")) {

     //   alert("B");

    }
    
}


function formdisable(disablestatus) {
    var allAttributes = Xrm.Page.data.entity.attributes.get();
    for (var i in allAttributes) {
        var myattribute = Xrm.Page.data.entity.attributes.get(allAttributes[i].getName());
        var myname = myattribute.getName();
        Xrm.Page.getControl(myname).setDisabled(disablestatus);
    }
} // formdisable



function sectiondisable(sectionname, disablestatus) {
    var ctrlName = Xrm.Page.ui.controls.get();
    for (var i in ctrlName) {
        var ctrl = ctrlName[i];
        var ctrlSection = ctrl.getParent().getName();
        if (ctrlSection == sectionname) {
            ctrl.setDisabled(disablestatus);
        }
    }
}  // sectiondisable



















/*

function stopModify(executionObj) {
    if (UserHasRole("Call Center User Additional Functionalities")) {

        // var recordOwner = Xrm.Page.getAttribute("ownerid").getValue()[0].name;
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        var recordOwner = Xrm.Page.getAttribute("ownerid").getValue()[0].id

       // alert(recordOwner);

        var currentUserId = Xrm.Page.context.getUserId();
      //  alert(currentUserId);
        //if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User"))
        if (status == 1 && currentUserId != recordOwner) {
            //executionObj.getEventArgs().preventDefault();
            alert("Cannot edit the record");
            executionObj.getEventArgs().preventDefault();
        }

    }

    else if (UserHasRole("System Administrator")) {

        alert("B");

    }
}


*/