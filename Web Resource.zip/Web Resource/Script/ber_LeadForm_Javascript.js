// JavaScript source code
//debugger;

function OnChangeStatus() {

    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null || Xrm.Page.getAttribute("ber_leadtype").getValue() != undefined || Xrm.Page.getAttribute("ber_leadtype").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (Xrm.Page.getAttribute("ber_leadtype") != null) {
            var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
            if (b != null) {
                if (b == 278290002) {
                    if (Xrm.Page.getAttribute("ber_dealertype") != null)
                        Xrm.Page.getAttribute("ber_dealertype").setRequiredLevel("required");

                    if (UserHasRole("Call Center User") || UserHasRole("Call Center User Additional Functionalities")) {
                        if (Xrm.Page.getAttribute("ber_whowill") != null)
                            Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("none");
                    }
                }
                else if (b == 278290001) {
                    setVisibleSection("general", "dealerinfo", false);
                    setVisibleSection("general", "productdetails", true);
                    setVisibleSection("general", "Job_Value", false);
                    setVisibleSection("general", "CC_WC", false);
                }
            }
        }
        //break;



        switch (status) {

            case 2:
            case 278290001:
            case 278290002:
            case 278290004:
            case 278290009:
                if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                    Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("industrycode") != null)
                    Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("address2_addresstypecode") != null)
                    Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_salutation") != null)
                    Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");


                if (Xrm.Page.getAttribute("firstname") != null)
                    Xrm.Page.getAttribute("firstname").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("lastname") != null)
                    Xrm.Page.getAttribute("lastname").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_callinfo") != null)
                    Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_leadtype") != null)
                    Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null)
                    Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null)
                    Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                    Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");


                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }

                if (Xrm.Page.getAttribute("address1_line1") != null)
                    Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_stateid") != null)
                    Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_cityid") != null)
                    Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("telephone1") != null)
                    Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_pincodeid") != null)
                    Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                    Xrm.Page.getControl("ber_masterpainterid").setDisabled(false); // changed on 10/12/2015

                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {

                            if (Xrm.Page.getAttribute("ber_startdate") != null)
                                Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                        }
                    }
                }
                break;

            case 278290032:

                Xrm.Page.getAttribute("statuscode").setValue(278290032);
                if (UserHasRole("System Administrator") || ("Depot User") || ("Depot Home Decor User")) {
                    if (Xrm.Page.getAttribute("ber_isestimategiven") != null)
                        Xrm.Page.getAttribute("ber_isestimategiven").setRequiredLevel("required");

                    if (Xrm.Page.getAttribute("ber_preliminaryserialnumber") != null)
                        Xrm.Page.getAttribute("ber_preliminaryserialnumber").setRequiredLevel("required");

                }

                else {
                    Xrm.Page.getControl("ber_isestimategiven").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);
                    Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setDisabled(true);

                    if (Xrm.Page.getAttribute("ber_isestimategiven") != null)
                        Xrm.Page.getControl("ber_isestimategiven").setDisabled(true);

                    if (Xrm.Page.getAttribute("ber_estimatedpainter") != null)
                        Xrm.Page.ui.controls.get("ber_estimatedpainter").setDisabled(true);

                    if (Xrm.Page.getAttribute("ber_preliminaryserialnumber") != null)
                        Xrm.Page.ui.controls.get("ber_preliminaryserialnumber").setDisabled(true);


                }
                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_nextvisitdate") != null) Xrm.Page.getAttribute("ber_nextvisitdate").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none"); //---- changed on 04122015
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");

                if (Xrm.Page.getControl("ber_leadtype") != null) Xrm.Page.getControl("ber_leadtype").setDisabled(false);
                if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_painterallocationdate") != null) Xrm.Page.getControl("ber_painterallocationdate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_wondate") != null) Xrm.Page.getControl("ber_wondate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_tsiid") != null) Xrm.Page.getControl("ber_tsiid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_capturedealerallocateddate") != null) Xrm.Page.getControl("ber_capturedealerallocateddate").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {
                            if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                        }
                    }
                }

                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }


                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b != 278290002) {
                            setVisibleSection("general", "dealerinfo", false);
                            setVisibleSection("general", "productdetails", true);
                            setVisibleSection("general", "Job_Value", false);
                            setVisibleSection("general", "CC_WC", false);
                        }
                    }
                }

                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {

                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");


                        }
                    }
                }
                break;

            case 1:
                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");

                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_dealerid") != null) {
                    Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none"); //---- changed on 04122015
                }

                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
                if (Xrm.Page.getControl("ber_leadtype") != null) Xrm.Page.getControl("ber_leadtype").setDisabled(false);

                if (Xrm.Page.getControl("ber_masterpainterid") != null)
                    Xrm.Page.getControl("ber_masterpainterid").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getControl("ber_painterallocationdate") != null)
                    Xrm.Page.getControl("ber_painterallocationdate").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getControl("ber_wondate") != null)
                    Xrm.Page.getControl("ber_wondate").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getControl("ber_tsiid") != null)
                    Xrm.Page.getControl("ber_tsiid").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getControl("ber_capturedealerallocateddate") != null)
                    Xrm.Page.getControl("ber_capturedealerallocateddate").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {
                            if (Xrm.Page.getAttribute("ber_carpetarea") != null)
                                Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");

                            if (UserHasRole("Call Center User") || ("Call Center User Additional Functionalities")) {
                                if (Xrm.Page.getAttribute("ber_startdate") != null)
                                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
                            }


                            else {
                                if (Xrm.Page.getAttribute("ber_startdate") != null)
                                    Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                            }

                        }
                    }
                }

                if (Xrm.Page.getAttribute("industrycode") != null)
                    Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null)
                    Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null)
                    Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_masterpainterid") != null)
                    Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }


                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b != 278290002) {
                            setVisibleSection("general", "dealerinfo", false);
                            setVisibleSection("general", "productdetails", true);
                            setVisibleSection("general", "Job_Value", false);
                            setVisibleSection("general", "CC_WC", false);
                        }
                    }
                }

                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {

                            if (Xrm.Page.getAttribute("ber_startdate") != null)
                                Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");


                        }
                    }
                }
                break;

            case 278290005:
                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none"); //---- changed on 04122015
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
                if (Xrm.Page.getControl("ber_leadtype") != null) Xrm.Page.getControl("ber_leadtype").setDisabled(false);
                if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_painterallocationdate") != null) Xrm.Page.getControl("ber_painterallocationdate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_wondate") != null) Xrm.Page.getControl("ber_wondate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_tsiid") != null) Xrm.Page.getControl("ber_tsiid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_capturedealerallocateddate") != null) Xrm.Page.getControl("ber_capturedealerallocateddate").setDisabled(true); // changed on 10/12/2015

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {
                            if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

                        }
                    }
                }

                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");


                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }


                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b != 278290002) {
                            setVisibleSection("general", "dealerinfo", false);
                            setVisibleSection("general", "productdetails", true);
                            setVisibleSection("general", "Job_Value", false);
                            setVisibleSection("general", "CC_WC", false);
                        }
                    }
                }

                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {


                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");


                        }
                    }
                }
                break;


            case 278290005:

                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
                //  Xrm.Page.getAttribute("ber_whowill").setRequiredLevel("required");

                Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");

                if (b == 278290002) {
                    if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                        Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");
                    }
                    if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("required");
                    if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("required");

                }

                else {
                    if (Xrm.Page.getAttribute("ber_enddate") != null) Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                    if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                    if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");

                }




                if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
                    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (leadtype !== null) {
                        if (leadtype == 278290002) {
                            if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                                Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("required");
                            }
                        }
                    }
                }


                if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
                    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (leadtype !== null) {
                        if (leadtype == 278290002) {
                            if (Xrm.Page.getAttribute("ber_masterpainterid") != null && Xrm.Page.getAttribute("ber_masterpainterid") != undefined && Xrm.Page.getAttribute("ber_dealerid") != null && Xrm.Page.getAttribute("ber_dealerid") != undefined) {
                                Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("required");
                                Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
                            }
                        }
                    }
                }

                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");
                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(false); // changed on 10/12/2015
                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_ilabourcost") != null) Xrm.Page.getAttribute("ber_ilabourcost").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_imaterialcost") != null) Xrm.Page.getAttribute("ber_imaterialcost").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_ematerialcost") != null) Xrm.Page.getAttribute("ber_ematerialcost").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_elabourcost") != null) Xrm.Page.getAttribute("ber_elabourcost").setRequiredLevel("required");


                break;

            case 278290006:


                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");

                setVisibleSection("general", "leadproduct", true);


                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }


                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");

                Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {

                            if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");
                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                            if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(false); // changed on 10/12/2015
                            if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                            if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                                Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("required");
                            }

                        }
                    }
                }
                break;

            case 278290007: // For Enquiry

                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("leadsourcecode") != null) Xrm.Page.getAttribute("leadsourcecode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required"); // 03/12/2015
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("none");
                if (Xrm.Page.getControl("ber_leadtype") != null) Xrm.Page.getControl("ber_leadtype").setDisabled(false);
                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");

                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }

                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required"); // 03/12/2015
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("none");
                if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_painterallocationdate") != null) Xrm.Page.getControl("ber_painterallocationdate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_wondate") != null) Xrm.Page.getControl("ber_wondate").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_tsiid") != null) Xrm.Page.getControl("ber_tsiid").setDisabled(true); // changed on 10/12/2015
                if (Xrm.Page.getControl("ber_capturedealerallocateddate") != null) Xrm.Page.getControl("ber_capturedealerallocateddate").setDisabled(true); // changed on 10/12/2015

                setVisibleSection("general", "leadproduct", false);
                break;


            case 278290008:
            case 278290026:



                if (Xrm.Page.getAttribute("industrycode") != null) Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("address2_addresstypecode") != null) Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_salutation") != null) Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("firstname") != null) Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("lastname") != null) Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_callinfo") != null) Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_leadtype") != null) Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null) Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");

                Xrm.Page.getAttribute("industrycode").setRequiredLevel("none");
                Xrm.Page.getAttribute("address2_addresstypecode").setRequiredLevel("required");
                //        Xrm.Page.getAttribute("leadsourcecode").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");
                Xrm.Page.getAttribute("firstname").setRequiredLevel("required");
                Xrm.Page.getAttribute("lastname").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_callinfo").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_leadtype").setRequiredLevel("required");
                Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("none");
                Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined) {
                    Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("none");
                }
                if (Xrm.Page.getAttribute("ber_estimatedpaintingcost") != null && Xrm.Page.getAttribute("ber_estimatedpaintingcost") != undefined) {
                    Xrm.Page.getAttribute("ber_estimatedpaintingcost").setRequiredLevel("none");
                }


                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b != 278290002) {
                            setVisibleSection("general", "dealerinfo", false);
                            setVisibleSection("general", "productdetails", true);
                            setVisibleSection("general", "Job_Value", false);
                            setVisibleSection("general", "CC_WC", false);
                            // Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("none");
                            // Xrm.Page.getAttribute("ber_appointmentdate").setValue(null);
                            //Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
                            //  Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
                            //   Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false);


                        }
                    }
                }


                if (Xrm.Page.getAttribute("ber_carpetarea") != null) Xrm.Page.getAttribute("ber_carpetarea").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("address1_line1") != null) Xrm.Page.getAttribute("address1_line1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_stateid") != null) Xrm.Page.getAttribute("ber_stateid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_cityid") != null) Xrm.Page.getAttribute("ber_cityid").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("telephone1") != null) Xrm.Page.getAttribute("telephone1").setRequiredLevel("required");
                if (Xrm.Page.getAttribute("ber_pincodeid") != null) Xrm.Page.getAttribute("ber_pincodeid").setRequiredLevel("required");

                setVisibleSection("general", "leadproduct", false);

                if (Xrm.Page.getControl("ber_masterpainterid") != null) Xrm.Page.getControl("ber_masterpainterid").setDisabled(false); // changed on 10/12/2015

                if (Xrm.Page.getAttribute("ber_leadtype") != null) {
                    var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (b != null) {
                        if (b == 278290002) {


                            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
                            if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("required");
                            if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("required");

                        }
                    }
                }







            case 278290030:
                setVisibleSection("general", "dealerinfo", false);
                setVisibleSection("general", "productdetails", false);
                setVisibleSection("general", "Job_Value", false);
                setVisibleSection("general", "CC_WC", false);
                break;

        }




    }



}





function Copyandretrivemonth() {
    if (Xrm.Page.getAttribute("createdon") != null && Xrm.Page.getAttribute("createdon") != undefined) {
        var createdon = Xrm.Page.getAttribute("createdon").getValue();
        if (createdon != null && createdon != undefined) {
            var month = createdon.getMonth() + 1;
            if (month != null && month != undefined) {
                if (Xrm.Page.getAttribute("ber_createdmonth") != null) Xrm.Page.getAttribute("ber_createdmonth").setValue(month);
                if (Xrm.Page.getAttribute("ber_createdmonth") != null) Xrm.Page.getAttribute("ber_createdmonth").setSubmitMode("always");
            }
        }
    }
}

function StartDateValidation() {
    if (Xrm.Page.getAttribute("ber_startdate").getValue() == null) {
        // alert("Please enter the start date first. ");
        if (Xrm.Page.getAttribute("ber_enddate") != null) Xrm.Page.getAttribute("ber_enddate").setValue(null);
    }
    if (Xrm.Page.getAttribute("ber_startdate") != null && Xrm.Page.getAttribute("ber_startdate") != undefined)

        if (Xrm.Page.getAttribute("ber_startdate").getValue() != null && Xrm.Page.getAttribute("ber_startdate").getValue() != undefined) {
            var a = Xrm.Page.getAttribute("ber_startdate").getValue();
            var b = new Date();
            var c = new Date((b.getMonth() + 1).toString() + "/" + b.getDate() + "/" + b.getFullYear().toString());
            if (a != null && a <= c) {
                alert("Start Date Should be greater than Today's Date. ");
                if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setValue(null);
            }
        }
}

function EndDateValidation() {
    if (Xrm.Page.getAttribute("ber_enddate") != null && Xrm.Page.getAttribute("ber_enddate") != undefined)
        if (Xrm.Page.getAttribute("ber_enddate").getValue() != null && Xrm.Page.getAttribute("ber_enddate").getValue() != undefined) {
            var b = Xrm.Page.getAttribute("ber_enddate").getValue();
            if (Xrm.Page.getAttribute("ber_startdate").getValue() == null) {
                alert("Please enter the start date first. ");
                Xrm.Page.getAttribute("ber_enddate").setValue(null);
            }
            // var b = Xrm.Page.getAttribute("ber_enddate").getValue();
            if (Xrm.Page.getAttribute("ber_startdate").getValue() != null && Xrm.Page.getAttribute("ber_startdate").getValue() != undefined) {
                var c = Xrm.Page.getAttribute("ber_startdate").getValue();

                var d = calculateDays1(c, b);
                if (b < c) {
                    alert("End Date Should be greater than Start Date. ");
                    Xrm.Page.getAttribute("ber_enddate").setValue(null);
                }

                else if (d < 7) {
                    alert("End Date Should be atleast 7 days ahead of Start Date. ");
                    Xrm.Page.getAttribute("ber_enddate").setValue(null);
                }
            }
        }
}


function calculateDays1(datetime1, datetime2) {
    var oneDay = 1000 * 60 * 60 * 24;        // The number of milliseconds in a day
    //Convert the datetime1 and datetime2 to Date object and get Time in milliseconds

    var dt1 = new Date(datetime1).getTime();
    var dt2 = new Date(datetime2).getTime();

    // Calculate the difference in milliseconds
    var diff = Math.abs(dt1 - dt2); // Difference of Days

    return Math.round(diff / oneDay);
}


function AppointmentDateValidation() {
    if (Xrm.Page.getAttribute("ber_appointmentdate") != null && Xrm.Page.getAttribute("ber_appointmentdate") != undefined) {
        if (Xrm.Page.getAttribute("ber_appointmentdate").getValue() != null && Xrm.Page.getAttribute("ber_appointmentdate").getValue() != undefined) {
            var a = Xrm.Page.getAttribute("ber_appointmentdate").getValue();
            var b = new Date();
            var c = new Date((b.getMonth() + 1).toString() + "/" + b.getDate() + "/" + b.getFullYear().toString());
            if (a != null && a <= c) {
                alert("Appointment Date Should be greater than Today's Date. ");
                Xrm.Page.getAttribute("ber_startdate").setValue(null);
            }
        }
    }
}

// Function Work Retail Project Dealer View  Visibility Control


function filterDealerLookupOnDealerSelectionCriteria() {
    if (Xrm.Page.getAttribute("ber_dealerselectioncriteria") != null && Xrm.Page.getAttribute("ber_dealerselectioncriteria") != undefined) {

        var dealerselectioncriteria = Xrm.Page.getAttribute("ber_dealerselectioncriteria").getValue();
        //278290034 -Retail Projects - Cold Call ,278290035-Retail Projects - Dealers,278290033-Retail Projects - Others,278290055-Referral - AID,278290057-Retail Projects - Painter Referral
        if (dealerselectioncriteria == '278290000') {
            if (Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290034' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290035' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290033' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290055') {
                filterDealerLookupForPincode();
            }

            else {
                filterDealerForRetailsProject();
            }
            // filterDealerLookupForPincode();
        }
            //278290034 -Retail Projects - Cold Call ,278290035-Retail Projects - Dealers,278290033-Retail Projects - Others,278290055-Referral - AID,278290057-Retail Projects - Painter Referral
        else if (dealerselectioncriteria == '278290001' || dealerselectioncriteria == '278290002') {
            if (Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290034' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290035' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290033' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290055') {
                filterDealerForDepot();
            }

            else {

                filterDealerForRetailsProject();
            }
        }
    }
}


var TerritoryType;
var lockedforAD;

function filterDealerLookupOnDealerSelectionCriteria_AccelaratedDealer() {

    if (Xrm.Page.getAttribute("ber_dealerselectioncriteria") != null && Xrm.Page.getAttribute("ber_dealerselectioncriteria") != undefined) {

        if (TerritoryType == 'Urban' && lockedforAD == 'Yes') {
            //  alert("1");
            var dealerselectioncriteria = Xrm.Page.getAttribute("ber_dealerselectioncriteria").getValue();
            //278290034 -Retail Projects - Cold Call ,278290035-Retail Projects - Dealers,278290033-Retail Projects - Others,278290055-Referral - AID,278290057-Retail Projects - Painter Referral
            if (dealerselectioncriteria == '278290000') {
                if (Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290034' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290035' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290033' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290055' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290057' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290045') {
                    // filterDealerLookupForPincode();
                    filterDealerLookupForPincode_AccelaratedDealers();
                }

                else if (Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290034' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290033' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290045') {
                    // filterDealerForRetailsProject();
                    filterDealerForRetailsProject_AccelaratedDealers();
                }

                else if (Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290035' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290055' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290057') {
                    filterDealerForRetailsProject();
                }


                // filterDealerLookupForPincode();
            }
                //278290034 -Retail Projects - Cold Call ,278290035-Retail Projects - Dealers,278290033-Retail Projects - Others,278290055-Referral - AID,278290057-Retail Projects - Painter Referral
            else if (dealerselectioncriteria == '278290001' || dealerselectioncriteria == '278290002') {
                if (Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290034' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290035' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290033' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290055' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290057' && Xrm.Page.getAttribute("leadsourcecode").getValue() != '278290045') {
                    //filterDealerForDepot3();
                    filterDealerForDepot_AccelaratedDealer();
                }

                else if (Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290034' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290033' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290045') {
                    // filterDealerForRetailsProject();
                    filterDealerForRetailsProject_AccelaratedDealers();
                }

                else if (Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290035' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290055' || Xrm.Page.getAttribute("leadsourcecode").getValue() == '278290057') {
                    filterDealerForRetailsProject();
                }
            }
        }
    }
}



//Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018

function filterDealerLookupOnDealerSelectionCriteriaRetails() {
    filterDealerForRetailsProject();
}

function filterDealerLookupForPincode() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {


        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
        if (Xrm.Page.getAttribute("ber_pincodeid").getValue() != null && Xrm.Page.getAttribute("ber_pincodeid").getValue() != undefined) {
            var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
            if (pinCodeId != null) {
                var _pinCode = pinCodeId[0].id;
                if (_pinCode != null) {
                    _pinCode = _pinCode.replace("{", "");
                    _pinCode = _pinCode.replace("}", "");

                    var viewDisplayName = 'Dealers Specific To PinCode';
                    //var viewId = GetuniqueGuid();
                    var viewId = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var dealerViewId = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    //   viewDisplayName = null;
                    // viewId = null;
                    var isDefaultView = true;
                    layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
					'<cell name="ber_dealerrating" width="100" />' +

					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +

                    '<attribute name="ber_dealerrating" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                    '<order attribute="name" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_postalcode" operator="eq" uitype="ber_pincode" value="' + _pinCode + '" />' +
                    '</filter>' +
					'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                   '<condition attribute="accountcategorycode" operator="eq" value="278290010" />' +
                   '<condition attribute="accountcategorycode" operator="eq" value="278290011" />' +
                    '</filter>' +
                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(dealerViewId, "account", viewDisplayName, fetchxml, layoutxml, isDefaultView);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(dealerViewId);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");

                }
            }
        }
    }
    else {
        filterDealerLookupForPincode_Ultratech();
    }
}


function filterDealerForDepot() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");

        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
                    '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    /*'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                    '</filter>' +
                    '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}


function filterDealerForRetailsProject() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                var _depotName = depotId[0].name;


                if (_depotId != null) {
                    /*
                    //if (_depotName == '006:Kolkata-2' || _depotName == '108:Kolkata-4' || _depotName == '110:Kolkata-5' || _depotName == '004:Bhubaneswar' || _depotName == '038:Vijaywada' || _depotName == '104:Gurgaon' || _depotName == '020:Delhi-Okhla' || _depotName == '085:Delhi-Mandoli' || _depotName == '086:Delhi-Janakpuri' || _depotName == '041:Delhi-Punjabibagh' || _depotName == '113:Delhi-Rohini' || _depotName == '002:Guwahati' || _depotName == '126:Durgapur' || _depotName == '005:Siliguri' || _depotName == '118:Guwahati-2' || _depotName == '062:Shillong' || _depotName == '061:Agartala') {
                    if (_depotName == '006:Kolkata-2' || _depotName == '108:Kolkata-4' || _depotName == '110:Kolkata-5' || _depotName == '004:Bhubaneswar' || _depotName == '038:Vijaywada' || _depotName == '104:Gurgaon' || _depotName == '002:Guwahati' || _depotName == '126:Durgapur' || _depotName == '005:Siliguri' || _depotName == '118:Guwahati-2' || _depotName == '062:Shillong') {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = 'Dealers for Retails Project specific to code 65';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="territoryid" width="100" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="territoryid" />' +
                    '<attribute name="accountid" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="customertypecode" value="278290023" operator="eq"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="not-null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    '<link-entity name="account" alias="a_57511732b5534cfbbcf2d280f9f8c6f1" link-type="outer" visible="false" to="parentaccountid" from="accountid">' +
                    '<attribute name="accountnumber"/>' +
                    '</link-entity>' +
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                    }

                    */

                    // else {

                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = 'Dealers for Retails Project specific to code 55 ';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
					'<cell name="territoryid" width="100" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="territoryid" />' +
                    '<attribute name="accountid" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<filter type="or">' +
                     '<condition attribute="customertypecode" value="278290019" operator="eq"/>' +
                       '<condition attribute="customertypecode" value="278290023" operator="eq"/>' +
                         '</filter>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="not-null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    '<link-entity name="account" alias="a_57511732b5534cfbbcf2d280f9f8c6f1" link-type="outer" visible="false" to="parentaccountid" from="accountid">' +
                    '<attribute name="accountnumber"/>' +
                    '</link-entity>' +
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");


                    //  }
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}


//////////    Retails view for Dealer code 65    ////////////////////////

function filterDealerForRetailsProject_code65() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot for Retails Project Specific to code 65';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
					'<cell name="territoryid" width="100" />' +
                    '<cell name="accountid" width="100" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="territoryid" />' +
                    '<attribute name="accountid" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="customertypecode" value="278290023" operator="eq"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="not-null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    '<link-entity name="account" alias="a_57511732b5534cfbbcf2d280f9f8c6f1" link-type="outer" visible="false" to="parentaccountid" from="accountid">' +
                    '<attribute name="accountnumber"/>' +
                    '</link-entity>' +
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");

                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}







function GetuniqueGuid() {
    var a = function () {
        return (65536 * (1 + Math.random()) | 0).toString(16).substring(1);
    };
    return "{" + (a() + a() + "-" + a() + "-" + a() + "-" + a() + "-" + a() + a() + a()) + "}";
}



function TotalJobValueValidation() {
    if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != null && Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue") != undefined) {
        if (Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").getValue() != null && Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").getValue() != undefined) {
            var b = Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").getValue();
            if (Xrm.Page.getAttribute("ber_totaljobvalue").getValue() != null && Xrm.Page.getAttribute("ber_totaljobvalue").getValue() != undefined) {
                var c = Xrm.Page.getAttribute("ber_totaljobvalue").getValue();
                if (c <= b) {
                    alert("Total Material Consumed Should be less than Total Job Value. ");
                    Xrm.Page.getAttribute("ber_totalmaterialconsumedvalue").setValue(null);
                }
            }
        }
    }
}































///////////////////////////////////////////////////////////////////////////



/*
function HideShowTab(tabName, visible) {
try {
Xrm.Page.ui.tabs.get(tabName).setVisible(visible);
}
catch (err) { }
}

//HideShowTab("general", false);   // "false" = invisible


*/



function OnchangeLBHP() {

    if (Xrm.Page.getAttribute("statuscode").getValue() != undefined || Xrm.Page.getAttribute("statuscode").getValue() != null) {
        var status = Xrm.Page.getAttribute("statuscode").getValue();
        var PickListControl = Xrm.Page.ui.controls.get("statuscode");
        var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();


        /*

        if (leadtype == 278290001 && status == 278290029) {

        Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);
        Xrm.Page.ui.controls.get("ber_appointmentdate").setVisible(true);
        Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("required");
        // Xrm.Page.getControl("ber_appointmentdate").setDisabled(false);           
        Xrm.Page.ui.controls.get("statuscode").setDisabled(false);
        // Xrm.Page.getAttribute("ber_salutation").setRequiredLevel("required");



        }

        else if (leadtype == 278290001 && status == 278290024) {

        Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
        Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);

        Xrm.Page.ui.controls.get("ber_appointmentdate").setVisible(true);
        Xrm.Page.getAttribute("ber_appointmentdate").setRequiredLevel("required");
        Xrm.Page.ui.controls.get("statuscode").setDisabled(false);

        // PickListControl.removeOption("278290005");
        PickListControl.removeOption("1");
        // PickListControl.removeOption("278290025");
        //  PickListControl.removeOption("278290026");
        //  PickListControl.removeOption("278290027");
        //  PickListControl.removeOption("278290028");
        PickListControl.removeOption("278290029");

        }

        */

        if (leadtype == 278290001 && status == 278290005) {



            PickListControl.removeOption("278290007");
            PickListControl.removeOption("1");
            PickListControl.removeOption("278290008");
            PickListControl.removeOption("278290004");
            PickListControl.removeOption("2");
            PickListControl.removeOption("278290001");
            PickListControl.removeOption("278290002");
            PickListControl.removeOption("278290029");
            PickListControl.removeOption("278290028");
            PickListControl.removeOption("278290030");
            PickListControl.removeOption("278290024");
            PickListControl.removeOption("278290025");
            PickListControl.removeOption("278290027");
            if (Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
            if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null) Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(false); //leadproduct
            if (Xrm.Page.ui.tabs.get("general").sections.get("CC_WC") != null) Xrm.Page.ui.tabs.get("general").sections.get("CC_WC").setVisible(false);
            if (Xrm.Page.ui.tabs.get("general").sections.get("leadproduct") != null) Xrm.Page.ui.tabs.get("general").sections.get("leadproduct").setVisible(true);
            if (Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null) Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);


            Xrm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
            Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);


            Xrm.Page.ui.controls.get("ber_startdate").setVisible(true);
            Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");

            Xrm.Page.ui.controls.get("ber_enddate").setVisible(true);
            Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");

            Xrm.Page.ui.controls.get("ber_totaljobvalue").setVisible(true);
            Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("required");

            if (Xrm.Page.ui.tabs.get("general").sections.get("productdetails") != null) rm.Page.ui.tabs.get("general").sections.get("productdetails").setVisible(true);
            if (Xrm.Page.ui.tabs.get("general").sections.get("Job_Value") != null) Xrm.Page.ui.tabs.get("general").sections.get("Job_Value").setVisible(true);


            if (Xrm.Page.ui.controls.get("ber_startdate") != null) Xrm.Page.ui.controls.get("ber_startdate").setVisible(true);
            if (Xrm.Page.getAttribute("ber_startdate") != null) Xrm.Page.getAttribute("ber_startdate").setRequiredLevel("required");
            if (Xrm.Page.ui.controls.get("ber_enddate") != null) Xrm.Page.ui.controls.get("ber_enddate").setVisible(true);
            if (Xrm.Page.getAttribute("ber_enddate") != null) Xrm.Page.getAttribute("ber_enddate").setRequiredLevel("required");
            if (Xrm.Page.ui.controls.get("ber_totaljobvalue") != null) Xrm.Page.ui.controls.get("ber_totaljobvalue").setVisible(true);
            if (Xrm.Page.getAttribute("ber_totaljobvalue") != null) Xrm.Page.getAttribute("ber_totaljobvalue").setRequiredLevel("required");



        }

        else {

            // Do Nothing

        }
    }
}





function OnloadHomeDecor() {
    if (Xrm.Page.getAttribute("ber_leadtype") != null) {
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (b != null) {
            if (b == 278290001) {
                if (Xrm.Page.getAttribute("ber_masterpainterid") != null) Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
                if (Xrm.Page.getAttribute("ber_dealerid") != null) Xrm.Page.getAttribute("ber_dealerid").setRequiredLevel("none");
                if (Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo") != null) Xrm.Page.ui.tabs.get("general").sections.get("dealerinfo").setVisible(false);
            }

            else {

            }
        }

    }


}









function Appointmenttimecount() {



    if ((Xrm.Page.data.entity.attributes.get("ber_appointmentdate") != null) || (Xrm.Page.data.entity.attributes.get("ber_appointmentdate") != undefined)) {


        var today = new Date();

        // var Count = 0;
        var dateFormate_capturueddate;

        var Year1 = today.getFullYear();

        var Month1 = today.getMonth() + 1;

        var Day1 = today.getDate();

        // var dateFormate_today = Day1 + "-" + Month1 + "-" + Year1;
        //var dateOnly = new Date(year,month,day);
        dateFormate_today = new Date(Year1, Month1, Day1);
        var StatusReason = Xrm.Page.data.entity.attributes.get("statuscode").getValue();
        var LeadType = Xrm.Page.data.entity.attributes.get("ber_leadtype").getValue();
        var DateCapture = Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").getValue();


        if ((Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").getValue() != null) || (Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").getValue() != undefined)) {


            var Year = DateCapture.getFullYear();


            var Month = DateCapture.getMonth() + 1;

            var Day = DateCapture.getDate();

            //  dateFormate_capturueddate = Day + "-" + Month + "-" + Year;
            dateFormate_capturueddate = new Date(Year, Month, Day);


        }

        var Count = Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").getValue();
        //alert(dateFormate_capturueddate);


        if ((LeadType == 278290001) && (DateCapture == null) && (Count == null)) {

            Count = 1;

            Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setValue(Count);
            Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setValue(new Date());
            Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setSubmitMode("always");
            Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setSubmitMode("always");

        }


        else if ((LeadType == 278290001) && (Count != null) && (DateCapture != null)) {
            if (dateFormate_today > dateFormate_capturueddate) {
                Count++;
                Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setValue(Count);
                Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setValue(new Date());
                Xrm.Page.data.entity.attributes.get("ber_lbhpappointmentcount").setSubmitMode("always");
                Xrm.Page.data.entity.attributes.get("ber_lbhpappointdatecapture").setSubmitMode("always");


            }
        }

        else {

        }

    }

}











function filterDealerLookupForPincode_Ultratech() {

    //document.getElementById("ber_dealerid").disableViewPicker = 0;
    $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
    if (Xrm.Page.getAttribute("ber_pincodeid").getValue() != null && Xrm.Page.getAttribute("ber_pincodeid").getValue() != undefined) {
        var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
        if (pinCodeId != null) {
            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {
                _pinCode = _pinCode.replace("{", "");
                _pinCode = _pinCode.replace("}", "");

                var viewDisplayName = 'Dealers Specific To Ultratech';
                //var viewId = GetuniqueGuid();
                // var viewId = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                var viewId = "{00000000-0000-0000-00AA-000010001009}";

                //   viewDisplayName = null;
                // viewId = null;
                var isDefaultView = true;
                layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
					'<cell name="ber_dealerrating" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '<cell name="customertypecode" width="150" />' +
                    '</row>' +
                    '</grid>';
                fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                     '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                    '<attribute name="customertypecode" />' +
                    '<order attribute="ber_accelerateddealersad" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_postalcode" operator="eq" uitype="ber_pincode" value="' + _pinCode + '" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="customertypecode" operator="eq" value="9"/>' +
                    '</filter>' +
					'<filter type="and">' +

                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                Xrm.Page.getControl("ber_dealerid").addCustomView(viewId, "account", viewDisplayName, fetchxml, layoutxml, isDefaultView);
                Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId);
                //document.getElementById("ber_dealerid").disableViewPicker = 1;
                $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
            }
        }
    }
}





function filterDealerForDepot_Ultratech() {

    // if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

    //document.getElementById("ber_dealerid").disableViewPicker = 0;
    $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
        if (depotId != null) {
            var _depotId = depotId[0].id;
            if (_depotId != null) {
                _depotId = _depotId.replace("{", "");
                _depotId = _depotId.replace("}", "");
                var viewDisplayName2 = 'Dealers Specific To Depot Based on Ultratech';
                //var viewId2 = GetuniqueGuid();
                // var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                var viewId2 = "{00000000-0000-0000-00AA-000010001009}";
                var isDefaultView2 = true;
                layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="ber_accelerateddealersad" width="100" />' +
                    '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '<cell name="customertypecode" width="150" />' +
                    '</row>' +
                    '</grid>';
                fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                     '<attribute name="customertypecode" />' +
                    '<order attribute="ber_accelerateddealersad" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="customertypecode" operator="eq" value="9"/>' +
                    '</filter>' +
                /*'<filter type="and">' +
                '<filter type="or">' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                '</filter>' +
                '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                //document.getElementById("ber_dealerid").disableViewPicker = 1;
                $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
            }
        }
    }
    // }


}


/////////////added by Madhumita, Dated 28th for altenate Dealer addition /////////////////


function callsetDealer() {
    if ((Xrm.Page.data.entity.attributes.get("ber_leadtype").getValue() != null) || (Xrm.Page.data.entity.attributes.get("ber_leadtype") != undefined)) {
        if ((Xrm.Page.data.entity.attributes.get("ber_dealerid").getValue() != null) || (Xrm.Page.data.entity.attributes.get("ber_dealerid") != undefined)) {

            var leadType = Xrm.Page.getAttribute("ber_leadtype").getValue();
            var StatusReason = Xrm.Page.getAttribute("statuscode").getValue();
            // lead type = XP
            if (leadType == 278290002) {
                // 278290004 = Dealer allocated, 278290009 = Painter allocated , 278290026 = Quotation Given , 278290005 = Won
                if (StatusReason == 278290004 || StatusReason == 278290009 || StatusReason == 278290026 || StatusReason == 278290005) {
                    setOtherDealer();
                }
            }

            else {

            }
        }
    }
}








/////////////added by Madhumita, Dated 28th for altenate Dealer addition /////////////////


function setOtherDealer() {
    if (Xrm.Page.getAttribute("ber_dealerid").getValue() != null && Xrm.Page.getAttribute("ber_dealerid").getValue() != undefined) {
        if ((Xrm.Page.data.entity.attributes.get("ber_dealercode").getValue() != null) || (Xrm.Page.data.entity.attributes.get("ber_dealercode") != undefined)) {
            var dealercode = Xrm.Page.getAttribute("ber_dealercode").getValue();
            if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
                var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
                if (depotId != null) {
                    var _depotId = depotId[0].id;
                    if (_depotId != null && dealercode != null) {

                        var fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                       '<entity name="account">' +
                       '<attribute name="name" />' +
                       '<attribute name="accountnumber" />' +
                       '<attribute name="customertypecode" />' +
                       '<attribute name="ber_creditdays" />' +
                       '<attribute name="donotfax" />' +
                       '<attribute name="ber_taxcategory" />' +
                       '<attribute name="ber_depotid" />' +
                       '<attribute name="territoryid" />' +
                       '<attribute name="ber_associatedtsiid" />' +
                       '<attribute name="accountid" />' +
                       '<order attribute="name" descending="false" />' +
                       '<filter type="and">' +
                       '<condition attribute="accountnumber" operator="eq" value="' + dealercode + '" />' +
                       '<condition attribute="parentaccountid" operator="null" />' +
                       '<condition attribute="statecode" operator="eq" value="0" />' +
                       '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                       '</filter>' +
                       '<link-entity name="account" from="accountid" to="parentaccountid" visible="false" link-type="outer" alias="a_57511732b5534cfbbcf2d280f9f8c6f1">' +
                       '<attribute name="accountnumber" />' +
                       '</link-entity>' +
                       '</entity>' +
                       '</fetch>';

                        var retrievedDealer = XrmServiceToolkit.Soap.Fetch(fetchxml);
                        if (retrievedDealer.length > 0) {
                            //   alert(retrievedDealer.length);

                            var DealerArray = new Array();
                            DealerArray[0] = new Object();
                            DealerArray[0].id = retrievedDealer[0].attributes.accountid.value;
                            if (retrievedDealer[0].attributes.name != null || retrievedDealer[0].attributes.name != undefined) {
                                DealerArray[0].name = retrievedDealer[0].attributes.name.value;
                            }
                            else {

                            }
                            DealerArray[0].entityType = retrievedDealer[0].logicalName;

                            if (Xrm.Page.getAttribute("ber_dealer1").getValue() == null && Xrm.Page.getAttribute("ber_dealer2").getValue() == null && Xrm.Page.getAttribute("ber_dealer3").getValue() == null) {

                                Xrm.Page.getAttribute("ber_dealer1").setValue(DealerArray);
                                Xrm.Page.getAttribute("ber_dealer1").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_dealercode").setValue(null);
                                Xrm.Page.getAttribute("ber_dealercode").setSubmitMode("always");
                            }

                            else if (Xrm.Page.getAttribute("ber_dealer1").getValue() != null && Xrm.Page.getAttribute("ber_dealer2").getValue() == null && Xrm.Page.getAttribute("ber_dealer3").getValue() == null) {
                                Xrm.Page.getAttribute("ber_dealer2").setValue(DealerArray);
                                Xrm.Page.getAttribute("ber_dealer2").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_dealercode").setValue(null);
                                Xrm.Page.getAttribute("ber_dealercode").setSubmitMode("always");

                            }

                            else if (Xrm.Page.getAttribute("ber_dealer1").getValue() != null && Xrm.Page.getAttribute("ber_dealer2").getValue() != null && Xrm.Page.getAttribute("ber_dealer3").getValue() == null) {
                                Xrm.Page.getAttribute("ber_dealer3").setValue(DealerArray);
                                Xrm.Page.getAttribute("ber_dealer3").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_dealercode").setValue(null);
                                Xrm.Page.getAttribute("ber_dealercode").setSubmitMode("always");

                            }

                            else {

                            }
                        }

                    }
                }
            }
        }
    }
}




function filterDealerForDepot1() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");

        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    // var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90277}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
                    '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    /*'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                    '</filter>' +
                    '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}



function filterDealerForDepot3() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");

        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var currentUser = Xrm.Page.context.getUserId();
                    var modifiedcurrentUser = currentUser.replace("{", "").replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    //  var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90279}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
                    //  '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                   '<cell name="ber_depotid" width="100" />' +
                    //  '<cell name="address1_city" width="100" />' +
                    // '<cell name="address1_line2" width="150" />' +
                    //  '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    //  '<attribute name="ber_dealerrating" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                       '<attribute name="ownerid" />' +
                    // '<attribute name="address1_line2" />' +
                    //  '<attribute name="address1_line3" />' +
                    //  '<attribute name="address1_city" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ownerid" operator="eq" uitype="systemuser" value="' + modifiedcurrentUser + '" />' +
                    '</filter>' +
                    /*'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                    '</filter>' +
                    '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}





function filterDealerForDepot3() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");

        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var currentUser = Xrm.Page.context.getUserId();
                    var modifiedcurrentUser = currentUser.replace("{", "").replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    //  var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90279}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
                    //  '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                   '<cell name="ber_depotid" width="100" />' +
                    //  '<cell name="address1_city" width="100" />' +
                    // '<cell name="address1_line2" width="150" />' +
                    //  '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    //  '<attribute name="ber_dealerrating" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                       '<attribute name="ownerid" />' +
                    // '<attribute name="address1_line2" />' +
                    //  '<attribute name="address1_line3" />' +
                    //  '<attribute name="address1_city" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ownerid" operator="eq" uitype="systemuser" value="' + modifiedcurrentUser + '" />' +
                    '</filter>' +
                    /*'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                    '</filter>' +
                    '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}

//////////////////////////////////////////// Accelarated Dealer views   /////////////////////////////////////////////////////



function filterDealerForDepot_AccelaratedDealer() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");

        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                if (_depotId != null) {
                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var currentUser = Xrm.Page.context.getUserId();
                    var modifiedcurrentUser = currentUser.replace("{", "").replace("}", "");
                    var viewDisplayName2 = 'Dealers Specific To Depot AD View';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    //  var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90279}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
                    //  '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                   '<cell name="ber_depotid" width="100" />' +
                    //  '<cell name="address1_city" width="100" />' +
                    // '<cell name="address1_line2" width="150" />' +
                    //  '<cell name="address1_line3" width="150" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    //  '<attribute name="ber_dealerrating" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                       '<attribute name="ownerid" />' +
                    // '<attribute name="address1_line2" />' +
                    //  '<attribute name="address1_line3" />' +
                    //  '<attribute name="address1_city" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ownerid" operator="eq" uitype="systemuser" value="' + modifiedcurrentUser + '" />' +
                    '<condition attribute="ber_accelerateddealersad" operator="eq" value="1" />' +
                    '</filter>' +
                    /*'<filter type="and">' +
                    '<filter type="or">' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                    '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                    '</filter>' +
                    '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}




function filterDealerForDepot_Ultratech_AccelaratedDealers() {

    // if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

    //document.getElementById("ber_dealerid").disableViewPicker = 0;
    $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
    if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
        var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
        if (depotId != null) {
            var _depotId = depotId[0].id;
            if (_depotId != null) {
                _depotId = _depotId.replace("{", "");
                _depotId = _depotId.replace("}", "");
                var viewDisplayName2 = 'Ultratech Dealers AD View w.r.t Depot';
                //var viewId2 = GetuniqueGuid();
                // var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                var viewId2 = "{00000000-0000-0000-00AA-000010001009}";
                var isDefaultView2 = true;
                layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="ber_accelerateddealersad" width="100" />' +
                    '<cell name="ber_dealerrating" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '<cell name="customertypecode" width="150" />' +
                    '</row>' +
                    '</grid>';
                fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                     '<attribute name="customertypecode" />' +
                    '<order attribute="ber_accelerateddealersad" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '<condition attribute="ber_accelerateddealersad" operator="eq" value="1" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="customertypecode" operator="eq" value="9"/>' +
                    '</filter>' +
                /*'<filter type="and">' +
                '<filter type="or">' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290009" />  ' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290008" /> ' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290005" />' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290007" />' +
                '<condition attribute="accountcategorycode" operator="eq" value="278290006" />' +
                '</filter>' +
                '</filter>' +*/
                    '</entity>' +
                    '</fetch>';
                Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                //document.getElementById("ber_dealerid").disableViewPicker = 1;
                $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
            }
        }
    }
    // }


}



function filterDealerLookupForPincode_Ultratech_AccelaratedDealers() {

    //document.getElementById("ber_dealerid").disableViewPicker = 0;
    $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
    if (Xrm.Page.getAttribute("ber_pincodeid").getValue() != null && Xrm.Page.getAttribute("ber_pincodeid").getValue() != undefined) {
        var pinCodeId = Xrm.Page.getAttribute("ber_pincodeid").getValue();
        if (pinCodeId != null) {
            var _pinCode = pinCodeId[0].id;
            if (_pinCode != null) {
                _pinCode = _pinCode.replace("{", "");
                _pinCode = _pinCode.replace("}", "");

                var viewDisplayName = 'Ultratech Dealers AD View w.r.t Pincode';
                //var viewId = GetuniqueGuid();
                // var viewId = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                // var viewId = "{00000000-0000-0000-00AA-000010001009}";
                var viewId = "{4B4028B8-8DEA-4AE0-80EA-fBC0F55AE6D7}";

                //   viewDisplayName = null;
                // viewId = null;
                var isDefaultView = true;
                layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
					'<cell name="ber_dealerrating" width="100" />' +
                     '<cell name="ber_accelerateddealersad" width="100" />' +
					'<cell name="ber_postalcode" width="100" />' +
					'<cell name="accountcategorycode" width="100" /> ' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="telephone1" width="100" />' +
                    '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="address1_city" width="100" />' +
                    '<cell name="address1_line2" width="150" />' +
                    '<cell name="address1_line3" width="150" />' +
                    '<cell name="customertypecode" width="150" />' +
                    '</row>' +
                    '</grid>';
                fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_dealerrating" />' +
                     '<attribute name="ber_accelerateddealersad" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="telephone1" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountid" />' +
                    '<attribute name="address1_line2" />' +
                    '<attribute name="address1_line3" />' +
                    '<attribute name="address1_city" />' +
                    '<attribute name="customertypecode" />' +
                    '<order attribute="ber_accelerateddealersad" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_postalcode" operator="eq" uitype="ber_pincode" value="' + _pinCode + '" />' +
                    '<condition attribute="ber_accelerateddealersad" operator="eq" value="1" />' +
                    '</filter>' +
                    '<filter type="and">' +
                //Dealer Status = Active
                    '<condition attribute="customertypecode" operator="eq" value="9"/>' +
                    '</filter>' +
					'<filter type="and">' +

                    '</filter>' +
                    '</entity>' +
                    '</fetch>';
                Xrm.Page.getControl("ber_dealerid").addCustomView(viewId, "account", viewDisplayName, fetchxml, layoutxml, isDefaultView);
                Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId);
                //document.getElementById("ber_dealerid").disableViewPicker = 1;
                $("#ber_dealerid").find("img").attr("disableviewpicker", "1");
            }
        }
    }
}



function filterDealerForRetailsProject_AccelaratedDealers() {

    if (Xrm.Page.getAttribute("leadsourcecode") != null && Xrm.Page.getAttribute("leadsourcecode").getValue() != 278290018) {

        //document.getElementById("ber_dealerid").disableViewPicker = 0;
        $("#ber_dealerid").find("img").attr("disableviewpicker", "0");
        if (Xrm.Page.getAttribute("ber_depotid").getValue() != null && Xrm.Page.getAttribute("ber_depotid").getValue() != undefined) {
            var depotId = Xrm.Page.getAttribute("ber_depotid").getValue();
            if (depotId != null) {
                var _depotId = depotId[0].id;
                var _depotName = depotId[0].name;


                if (_depotId != null) {

                    // else {

                    _depotId = _depotId.replace("{", "");
                    _depotId = _depotId.replace("}", "");
                    var viewDisplayName2 = ' Retails Project AD Dealers for code 55';
                    //var viewId2 = GetuniqueGuid();
                    //var viewId2 = Xrm.Page.getControl("ber_dealerid").getDefaultView();
                    // var viewId2 = "{15C63745-0A6E-4322-8416-A62C84D90278}";
                    var viewId2 = "{B82428AC-C0DE-4ACE-8993-58953945430F}";
                    var isDefaultView2 = true;
                    layoutxml2 = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="200" />' +
                    '<cell name="accountnumber" width="100" />' +
                     '<cell name="customertypecode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
					'<cell name="territoryid" width="100" />' +
                    '</row>' +
                    '</grid>';
                    fetchxml2 = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                    '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="customertypecode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="territoryid" />' +
                    '<attribute name="accountid" />' +
                    '<order descending="false" attribute="accountnumber"/>' +
                    '<filter type="and">' +
                    '<filter type="or">' +
                     '<condition attribute="customertypecode" value="278290019" operator="eq"/>' +
                       '<condition attribute="customertypecode" value="278290023" operator="eq"/>' +
                         '</filter>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="parentaccountid" operator="not-null" />' +
                    '</filter>' +
                    '<filter type="and">' +
                    //Dealer Status = Active
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                    '</filter>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                    '<link-entity name="account" alias="a_57511732b5534cfbbcf2d280f9f8c6f1" to="parentaccountid" from="accountid">' +
                    '<attribute name="accountnumber"/>' +
                    '<filter type="and">' +
                    '<condition attribute="ber_accelerateddealersad" value="1" operator="eq"/>' +
                    '</filter>' +
                    '</link-entity>' +
                    '</entity>' +
                    '</fetch>';
                    Xrm.Page.getControl("ber_dealerid").addCustomView(viewId2, "account", viewDisplayName2, fetchxml2, layoutxml2, isDefaultView2);
                    Xrm.Page.getControl('ber_dealerid').setDefaultView(viewId2);
                    //document.getElementById("ber_dealerid").disableViewPicker = 1;
                    $("#ber_dealerid").find("img").attr("disableviewpicker", "1");


                    //  }
                }
            }
        }
    }

    else {
        filterDealerForDepot_Ultratech();

    }
}

                    }
                }
            }
        }
    }
}


