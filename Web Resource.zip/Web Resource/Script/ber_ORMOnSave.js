// JavaScript source code
function OnSaveORMLead() {

    /*
	-----------------------------------------------------------------------
	Lead                                                 ORM
	-----------------------------------------------------------------------
	First name                                          First name
	Last name                                           Last Name
	Call info                                           based on Basket
	Lead source                                         based on Basket
	Pin code                                            pincode
	City                                                city
	State                                               state
	Primary Contact Number              				Mobile number
	Status Reason                                   	based on data
	ORM                                                 reference ORM guid
	-------------------------------------------------------------------------
    */

    /*
	------------------------------------------------------------------------
		ber_basket
	------------------------------------------------------------------------
		Amazon
		Amazon-Banner
		Amazon-Video
		AnandaBazar
		BERGER
		Bhaskar
		bing
		Business Enquiry
		CricNXT
		Dailyhunt
		EASY
		emailmkt
		Facebook
		Facebook-Lead
		FB-PPS
		GDN-GSP
		Google
		Google-OTP
		google-SEM
		google-SEM-OTP
		google-Youtube
		Hindu
		HotStar
		IMAGINE
		India-today
		Industrial Users Product Enquiry
		Inshorts-App
		Instagram
		Jagran
		Landing Page
		Linkedin
		mCanvas
		Microsite
		Microsite-emailmkt
		Microsite-GDN-GSP
		Microsite-Google
		Microsite-Google-OTP
		Microsite-google-SEM
		Microsite-google-SEM-OTP
		Microsite-Twitter-website-card
		MoneyControl
		News18
		PAINT
		Paint Calculator
		PAINTS
		Product Enquiry
		programmatic-Native
		Quikr
		Quint
		Republic
		SILK
		Sizmek
		SMS
		thehindu
		Times_Of_India
		Truecaller
		Twitter-PT
		Twitter-website-card
		Virtual Painter
		Website
		WhatsApp
		XP
	---------------------------------------------------------------------------------------	
	*/

    if (Xrm.Page.getAttribute("ber_identitytype").getValue() == null || Xrm.Page.getAttribute("ber_identitytype").getValue() == 'undefined' || Xrm.Page.getAttribute("ber_identitytype").getValue() == "278290001") {
        return;
    }



    var ber_firstname = "";
    var ber_lastname = "";
    var ber_basket = "";
    var ber_pincode = "";
    var ber_city = "";
    var ber_state = "";
    var ber_mobilenumber = "";
    var ber_orm = "";
    var ber_callinfo = "";
    var ber_leadsourceid = "";
    var regardingleadID = "";
    var ber_targetsource = "";
    var DepotId = "";
    var StateId = "";
    var CityId = "";
    var PincodeId = "";
    var ber_leadtype = "";
    var ber_rating = "";
    var ber_leadconversionrequired = "";
    var ber_Exterior = "";
    var ber_interior = "";
    var ber_preferreddatetime = "";
    var ber_paintertype = "";
    var ber_leadopportunity = "";
    var ber_street1 = "";
    var ber_carpetareaapprox = "";

    var ber_salutation = "";
    var ber_paintingtype = "";

    try {

        //Fetch Data From Lead (Same entity) 	
        if (Xrm.Page.getAttribute("ber_firstname").getValue() != null && Xrm.Page.getAttribute("ber_firstname") != 'undefined') {
            ber_firstname = Xrm.Page.getAttribute("ber_firstname").getValue();
        }
        if (Xrm.Page.getAttribute("ber_lastname").getValue() != null && Xrm.Page.getAttribute("ber_lastname") != 'undefined') {
            ber_lastname = Xrm.Page.getAttribute("ber_lastname").getValue();
        }

        if (Xrm.Page.getAttribute("ber_basket").getValue() != null && Xrm.Page.getAttribute("ber_basket") != 'undefined') {
            ber_basket = Xrm.Page.getAttribute("ber_basket").getValue();
        }

        if (Xrm.Page.getAttribute("ber_pincode").getValue() != null && Xrm.Page.getAttribute("ber_pincode") != 'undefined') {
            ber_pincode = Xrm.Page.getAttribute("ber_pincode").getValue();
        }
        if (Xrm.Page.getAttribute("ber_city").getValue() != null && Xrm.Page.getAttribute("ber_city") != 'undefined') {
            ber_city = Xrm.Page.getAttribute("ber_city").getValue();
        }

        if (Xrm.Page.getAttribute("ber_state").getValue() != null && Xrm.Page.getAttribute("ber_state") != 'undefined') {
            ber_state = Xrm.Page.getAttribute("ber_state").getValue();
        }
        if (Xrm.Page.getAttribute("ber_mobilenumber").getValue() != null && Xrm.Page.getAttribute("ber_mobilenumber") != 'undefined') {
            ber_mobilenumber = Xrm.Page.getAttribute("ber_mobilenumber").getValue();
        }

        // ber_leadtype
        if (Xrm.Page.getAttribute("ber_leadtype").getValue() != null && Xrm.Page.getAttribute("ber_leadtype") != 'undefined') {
            ber_leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
        }

        if (Xrm.Page.getAttribute("ber_rating").getValue() != null && Xrm.Page.getAttribute("ber_rating") != 'undefined') {
            ber_rating = Xrm.Page.getAttribute("ber_rating").getValue();
        }

        if (Xrm.Page.getAttribute("ber_leadconversionrequired").getValue() != null && Xrm.Page.getAttribute("ber_leadconversionrequired") != 'undefined') {
            ber_leadconversionrequired = Xrm.Page.getAttribute("ber_leadconversionrequired").getValue();
        }

        if (Xrm.Page.getAttribute("ber_exterior").getValue() != null && Xrm.Page.getAttribute("ber_exterior") != 'undefined') {
            ber_Exterior = Xrm.Page.getAttribute("ber_exterior").getValue();
        }

        if (Xrm.Page.getAttribute("ber_interior").getValue() != null && Xrm.Page.getAttribute("ber_interior") != 'undefined') {
            ber_interior = Xrm.Page.getAttribute("ber_interior").getValue();
        }
        if (Xrm.Page.getAttribute("ber_preferreddatetime").getValue() != null && Xrm.Page.getAttribute("ber_preferreddatetime") != 'undefined') {
            ber_preferreddatetime = Xrm.Page.getAttribute("ber_preferreddatetime").getValue();
        }

        if (Xrm.Page.getAttribute("ber_paintingtype").getValue() != null && Xrm.Page.getAttribute("ber_paintingtype") != 'undefined') {
            ber_paintertype = Xrm.Page.getAttribute("ber_paintingtype").getValue();
        }
        if (Xrm.Page.getAttribute("ber_leadopportunity").getValue() != null && Xrm.Page.getAttribute("ber_leadopportunity") != 'undefined') {
            ber_leadopportunity = Xrm.Page.getAttribute("ber_leadopportunity").getValue();
        }

        if (Xrm.Page.getAttribute("ber_street1").getValue() != null && Xrm.Page.getAttribute("ber_street1") != 'undefined') {
            ber_street1 = Xrm.Page.getAttribute("ber_street1").getValue();
        }

        if (Xrm.Page.getAttribute("ber_salutation").getValue() != null && Xrm.Page.getAttribute("ber_salutation") != 'undefined') {
            ber_salutation = Xrm.Page.getAttribute("ber_salutation").getValue();
        }

        if (Xrm.Page.getAttribute("ber_paintingtype").getValue() != null && Xrm.Page.getAttribute("ber_paintingtype") != 'undefined') {
            ber_paintingtype = Xrm.Page.getAttribute("ber_paintingtype").getValue();
        }

        //if (Xrm.Page.getAttribute("ber_carpetareaapprox").getValue() != null && Xrm.Page.getAttribute("ber_carpetareaapprox") != 'undefined') {
        //    ber_carpetareaapprox = Xrm.Page.getAttribute("ber_carpetareaapprox").getValue();
        //}


        // Fetch City,State,Depot w.r.t PinCode  	
        if (ber_pincode != null) {
            var dpeotStCty = fetchDepotStateCity(ber_pincode);
            DepotId = dpeotStCty.DepotId;
            StateId = dpeotStCty.StateId;
            CityId = dpeotStCty.CityId;
            PincodeId = dpeotStCty.PincodeId;
        }

        // retrive Data from call info and Source Mapping  if Provided KeyWord not null ber_basket i.e Facebook/Amazon etc.
        if (ber_basket != null) {
            //Calling Ajax....
            $.ajax({
                type: "GET",
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_leadsources?$select=ber_callinfo,ber_targetsource&$filter=ber_name eq '" + ber_basket + "'",
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                    XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                    XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                },
                async: false,
                success: function (data, textStatus, xhr) {
                    var results = data;

                    if (results.value.length > 0) {
                        ber_callinfo = results.value[0]["ber_callinfo"];
                        var ber_callinfo_formatted = results.value[0]["ber_callinfo@OData.Community.Display.V1.FormattedValue"];
                        //ber_leadsourceid = results.value[0]["ber_leadsourceid"];

                        ber_targetsource = results.value[0]["ber_targetsource"];
                        var ber_targetsource_formatted = results.value[0]["ber_targetsource@OData.Community.Display.V1.FormattedValue"];
                    }

                },
                error: function (xhr, textStatus, errorThrown) {
                    Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
                }
            });

        }


        if (Xrm.Page.getAttribute("ber_identitytype").getValue() == 278290000)  // If type Lead 
        {
            if ((Xrm.Page.getAttribute("ber_regardinglead").getValue() == null && Xrm.Page.getAttribute("ber_regardinglead").getValue() != 'undefined') && (Xrm.Page.getAttribute("statuscode").getValue() != null && Xrm.Page.getAttribute("statuscode").getValue() != 'undefined' && Xrm.Page.getAttribute("statuscode").getValue() == 278290000)) {
                regardingleadID = CreatingRefLead(ber_firstname, ber_lastname, ber_callinfo, ber_targetsource, PincodeId, DepotId, StateId, CityId, ber_mobilenumber, ber_leadtype, ber_rating, ber_leadconversionrequired, ber_Exterior, ber_interior, ber_preferreddatetime, ber_paintertype, ber_street1, ber_leadopportunity, ber_salutation, ber_paintingtype);
                //setLookupValue(lookUpSchemaName, entitySchemaName, recordId, recordName);
                //var recordName = "ORM_Lead_" + Math.random();
                setLookupValue("ber_regardinglead", "lead", regardingleadID, "");
            }
        }

    }
    catch (e) {
        //return onSave;
    }

}

/**
 * Creating New Lead for ORM enity based on provided below Parameter
 * @param {type} ber_firstname
 * @param {type} ber_lastname
 * @param {type} ber_callinfo
 * @param {type} ber_targetsource
 * @param {type} PincodeId
 * @param {type} DepotId
 * @param {type} StateId
 * @param {type} CityId
 * @param {type} ber_mobilenumber
 * @param {type} ber_leadtype
 * @param {type} ber_rating
 * @param {type} ber_leadconversionrequired
 * @param {type} ber_Exterior
 * @param {type} ber_interior
 * @param {type} ber_preferreddatetime
 * @param {type} ber_paintertype
 * @param {type} ber_street1
 * @param {type} ber_leadopportunity
 * @param {type} ber_carpetareaapprox
 * @returns {type} 
 */
function CreatingRefLead(ber_firstname, ber_lastname, ber_callinfo, ber_targetsource, PincodeId, DepotId, StateId, CityId, ber_mobilenumber, ber_leadtype, ber_rating, ber_leadconversionrequired, ber_Exterior, ber_interior, ber_preferreddatetime, ber_paintertype, ber_street1, ber_leadopportunity, ber_salutation, ber_paintingtype) {

    var leadID = "";
    var CurrentEntityId = Xrm.Page.data.entity.getId().replace("{", '').replace("}", '');
    var entity = {};

    //String Value
    entity["firstname"] = ber_firstname;
    entity["lastname"] = ber_lastname;

    //optionset
    entity["ber_callinfo"] = ber_callinfo; //website facebook //ber_callinfo; 
    entity["leadsourcecode"] = ber_targetsource; //ber_leadsourceid;//278290012; //leadsoure social media

    entity["ber_salutation"] = ber_salutation;
    entity["address2_addresstypecode"] = ber_paintingtype;

    /*
    //Entity Reference  
    entity["ber_pincodeid@odata.bind"]  = "/ber_pincodes("+PincodeId+")";
    entity["ber_cityid@odata.bind"]     = "/ber_cities("+CityId+")";
    entity["ber_stateid@odata.bind"]    = "/ber_states("+StateId+")";   
    entity["ber_orm@odata.bind"]        = "/ber_ormidentities("+CurrentEntityId+")";
    */

    entity["ber_pincodeid@odata.bind"] = "/ber_pincodes(" + PincodeId + ")";
    entity["ber_cityid@odata.bind"] = "/ber_cities(" + CityId + ")";
    entity["ber_stateid@odata.bind"] = "/ber_states(" + StateId + ")";
    //entity["ber_orm@odata.bind"] = "/ber_ormidentities(" + CurrentEntityId + ")";

    if (ber_pincode != null) {
        entity["statuscode"] = 1;              //  As New Status
    }
    else {
        entity["statuscode"] = 278290007;      //  As Enqury Status
    }

    entity["ber_depotid@odata.bind"] = "/ber_depots(" + DepotId + ")";

    //var ber_leadtype = "";
    //var ber_leadconversionrequired = "";
    //var ber_Exterior = "";
    //var ber_interior = "";
    //var ber_preferreddatetime = "";


    //  Home Decor  => 278290001
    //  XP          => 278290002


    entity["telephone1"] = ber_mobilenumber;
    entity["ber_leadtype"] = ber_leadtype;
    entity["leadqualitycode"] = ber_rating;
    entity["address1_line1"] = ber_street1;
    entity["industrycode"] = ber_leadopportunity;
    //enity["ber_carpetarea"] = parseFloat(ber_carpetareaapprox.toFixed(0));
    entity["ber_leadconversionrequired"] = ber_leadconversionrequired;
    entity["ber_exterior"] = ber_Exterior;
    entity["ber_interior"] = ber_interior;

    var date = new Date(ber_preferreddatetime);
    entity["ber_preferreddatetime"] = ber_preferreddatetime;  //CRM Date time

    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads",
        data: JSON.stringify(entity),
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
            XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
        },
        async: false,
        success: function (data, textStatus, xhr) {
            var uri = xhr.getResponseHeader("OData-EntityId");
            var regExp = /\(([^)]+)\)/;
            var matches = regExp.exec(uri);
            var newEntityId = matches[1];
            leadID = newEntityId;

            //alert(uri);
            //alert(leadID);
        },
        error: function (xhr, textStatus, errorThrown) {
            Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
        }
    });



    //setLookupValue("ber_pincodeid", "ber_pincode", PincodeId, "");
    //setLookupValue("ber_cityid", "ber_city", CityId, "");
    //setLookupValue("ber_stateid", "ber_state", StateId, "");
    //setLookupValue("ber_orm", "ber_ormidentity", CurrentEntityId, "");

    // Assign Record 
    if (ber_pincode != null) {
        AssignRecordToCurrentUser(leadID, DepotId);
    }
    else {
        var currentUserId = "AB4099F8-FF8F-E411-AF59-5CF3FC98CFEC";      //GUID Of Shekhar
        AssignRecordToCurrentUser(leadID, currentUserId);
    }

    return leadID;
}

/*
function setLookupValue(lookUpSchemaName, entitySchemaName, recordId, recordName) {
    Xrm.Page.getAttribute(lookUpSchemaName).setValue([{
        entityType: entitySchemaName,
        id: recordId,
        name: recordName
    }]);
}
*/

/**
 *  Setting Lead of respective ORM enity
 * @param {type} lookUpSchemaName
 * @param {type} entitySchemaName
 * @param {type} recordId
 * @param {type} recordName
 */
function setLookupValue(lookUpSchemaName, entitySchemaName, recordId, recordName) {
    var lookUpObj = [];
    lookUpObj[0] = {};
    lookUpObj[0].id = recordId;
    lookUpObj[0].entityType = entitySchemaName;
    lookUpObj[0].name = recordName;
    if (Xrm.Page.getAttribute(lookUpSchemaName) != null) {
        Xrm.Page.getAttribute(lookUpSchemaName).setValue(lookUpObj);
        Xrm.Page.getAttribute(lookUpSchemaName).setSubmitMode("always");
    }
}

/**
 *  Assigning Record To Depot User if pincode Code exist Otherwise assign Shekhar Rana as owner  
 * @param {type} currentRecordId
 */
function AssignRecordToCurrentUser(currentRecordId, currentUserId) {
    //var currentRecordId = Xrm.Page.data.entity.getId().replace("{", '').replace("}", '');
    //var currentUserId = Xrm.Page.context.getUserId().replace("{", '').replace("}", '');

    /*
    var currentUserId = "AB4099F8-FF8F-E411-AF59-5CF3FC98CFEC";      //GUID Of Shekhar
    var entity = {};
    entity["ownerid@odata.bind"] = "/systemusers(" + currentUserId + ")";
    var impersonateUserId = "DE211861-F9DB-E111-8D9A-5EF3FC9CC7BB";   // GUID of the system administrator
    var req = new XMLHttpRequest();
    req.open("POST", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/leads(" + currentRecordId + ")", false);// my entity name is leads
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("MSCRMCallerID", impersonateUserId);
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            debugger;
            req.onreadystatechange = null;
            if (this.status === 204) {
                //Success - No Return Data - Do Something
            } else {
                // Xrm.Utility.alertDialog(this.statusText);
            }
        }
    };
    req.send(JSON.stringify(entity));
    */
}

/**
 *  Fetching Corresponding Depot / State/City Corresponding Pincode
 * @param {type} ber_pincode
 * @returns {type} 
 */
function fetchDepotStateCity(ber_pincode) {

    if (ber_pincode != null && ber_pincode != 'undefined') {
        var pincode = ber_pincode;
        if (pincode != null && pincode != undefined) {

            var ber_pincodeid = "";
            var ber_name = "";
            var req = new XMLHttpRequest();
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_pincodes?$select=_ber_cityid_value,ber_name,ber_pincodeid&$filter=ber_name eq '" + pincode + "' and  statecode eq 0 ", false);
            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();
            if (req.response != null && req.response != "") {
                var results = JSON.parse(req.response);
                try {
                    if (results != null) {
                        //no duplicate record should be allowed
                        if (results.value.length > 0) {
                            var _ber_cityid_value = results.value[0]["_ber_cityid_value"];
                            var _ber_cityid_value_formatted = results.value[0]["_ber_cityid_value@OData.Community.Display.V1.FormattedValue"];
                            var _ber_cityid_value_lookuplogicalname = results.value[0]["_ber_cityid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                            ber_name = results.value[0]["ber_name"];
                            ber_pincodeid = results.value[0]["ber_pincodeid"];

                        }


                        var req1 = new XMLHttpRequest();
                        //  req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_cities?$select=ber_cityid,_ber_defaultdepotid_value&$filter=ber_cityid eq " + _ber_cityid_value, false);
                        req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_cities?$select=ber_cityid,_ber_stateid_value,_ber_defaultdepotid_value&$filter=ber_cityid eq " + _ber_cityid_value, false);
                        req1.setRequestHeader("OData-MaxVersion", "4.0");
                        req1.setRequestHeader("OData-Version", "4.0");
                        req1.setRequestHeader("Accept", "application/json");
                        req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                        req1.send();

                        if (req1.response != null && req1.response != "") {
                            var results2 = JSON.parse(req1.response);

                            if (results2 != null) {
                                //no duplicate record should be allowed
                                if (results2.value.length > 0) {
                                    //  alert(results2.value.length);

                                    var ber_cityid = results2.value[0]["ber_cityid"];
                                    var _ber_stateid_value = results2.value[0]["_ber_stateid_value"];
                                    var _ber_stateid_value_formatted = results2.value[0]["_ber_stateid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_stateid_value_lookuplogicalname = results2.value[0]["_ber_stateid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                                    var _ber_defaultdepotid_value = results2.value[0]["_ber_defaultdepotid_value"];
                                    var _ber_defaultdepotid_value_formatted = results2.value[0]["_ber_defaultdepotid_value@OData.Community.Display.V1.FormattedValue"];
                                    var _ber_defaultdepotid_value_lookuplogicalname = results2.value[0]["_ber_defaultdepotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                                    // alert(_ber_defaultdepotid_value_formatted);


                                    var IDs = new Object();
                                    IDs["PincodeId"] = ber_pincodeid;
                                    //IDs["PincodeName"] = ber_name;
                                    IDs["DepotId"] = _ber_defaultdepotid_value;
                                    IDs["StateId"] = _ber_stateid_value;
                                    IDs["CityId"] = ber_cityid;
                                    return IDs;

                                }
                            }
                        }

                    }
                }
                catch (err) {
                    alert("Please communicate system administrator in HO for error: " + err);
                }
            }
        }
    }

}






/****************************
Developer : Madhumita
Dated : 1st July, 2019
Method: OnSaveValidation
Functionality : A method to check that before saving the lead form
                either interior or exterior must be selected
****************************/


function OnSaveValidation(executionObj) {

    if (Xrm.Page.getAttribute("ber_identitytype") != null && Xrm.Page.getAttribute("ber_identitytype") != undefined) {

        var IdentityType = Xrm.Page.getAttribute("ber_identitytype").getValue();
        if (IdentityType == 278290000) {
            var interior = Xrm.Page.getAttribute("ber_interior").getValue();
            var exterior = Xrm.Page.getAttribute("ber_exterior").getValue();

            if (interior == 0 && exterior == 0) {
                if (Xrm.Page.getAttribute("ber_leadtype") !== null) {
                    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
                    if (leadtype !== null) {
                        if (leadtype == 278290002) {
                            var event = executionObj.getEventArgs();
                            alert("Unable to save because neither interior nor exterior is selected.");
                            Xrm.Page.ui.controls.get("ber_interior").setFocus();
                            //executionObj.getEventArgs().preventDefault();
                            event.preventDefault();
                        }
                    }
                }

            }

        }
    }
}