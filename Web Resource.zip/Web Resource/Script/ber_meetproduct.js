
function Apply_MeetProductLookupFilter() 
{
debugger;
    if (Xrm.Page.getAttribute("ber_paintermeet").getValue() != null && Xrm.Page.getAttribute("ber_paintermeet").getValue() != undefined) {
        var contact = Xrm.Page.getAttribute("ber_paintermeet").getValue();
        var columns = ['ber_product'];
        var filter = "ber_PainterMeet/Id eq guid'" + PainterMeet[0].id + "'";
        var collection = CrmRestKit.RetrieveMultiple('ber_product', columns, filter);
        if (collection != null && collection.results != null && collection.results[0] != null) {
            var Product = collection.results[0].ber_Product;
            var value = new Array();
            value[0] = new Object();
            value[0].id = Product.Id;
            value[0].name = Product.Name;
            value[0].entityType = "ber_product";
               var product= product[0].id,
                productType =product[0].entityType,
                viewDisplayName = null,
                viewId = null,
                isDefaultView = true,
               layoutxml = '<grid name="resultset" object="10032" jump="ber_name" select="1" icon="1" preview="1">'
                                    + '<row name="result" id="ber_productid">'
                                    + '<cell name="ber_name" width="300" />'
                                    + '<cell name="createdon" width="125" />'
                                    + '</row>'
                                    + '</grid>';

        fetchxml ='<?xml version="1.0"?>' +
'<fetch distinct="true" mapping="logical" output-format="xml-platform" version="1.0"> ' +
'<entity name="product"> ' +
'<attribute name="name"/> ' +
'<attribute name="productnumber"/> ' +
'<attribute name="productid"/>' +
'<attribute name="defaultuomid"/> ' +
'<attribute name="ber_shadeid"/>' +
'<order descending="false" attribute="name"/>' +
'<link-entity name="ber_meetproduct" alias="aa" to="productid" from="ber_product"> ' +
'<filter type="and">' +
' <condition attribute="ber_paintermeet" value="{CCC4B28A-6DFE-E111-AEAA-18A90548E1D3}" uitype="ber_paintermeet" uiname="Painter Meet For Roof Paints" operator="eq"/> ' +
'</filter>' +
'</link-entity> ' +
'</entity>' +
'</fetch>';     
}
 if (productType == "product") {

            viewDisplayName = 'Related PainterMeet (Contact-PainterMeet-Connection)';
            viewId = GetuniqueGuid();

            Xrm.Page.getControl('ber_productid).addCustomView(viewId, 'ber_product, viewDisplayName, fetchxml, layoutxml,   isDefaultView);
            Xrm.Page.getControl('ber_productid).setDefaultView(viewId);

        }
}
}

function GetuniqueGuid() {

    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };

    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';

};