function validateInvoiceDate()
{
    var date = Xrm.Page.getAttribute("ber_dateoflifting").getValue();
    var currentDate = new Date();
    if (date > currentDate) {
        alert("Invoice Date can't be future date");
        Xrm.Page.getAttribute("ber_dateoflifting").setValue("");
    }

}