function filterTokenMasterLookup()
{
    

    fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                     '<entity name="ber_tokenmaster">' +
                     '<attribute name="ber_tokenmasterid" /> ' +
                     '<attribute name="ber_product"/>' +
                     '<attribute name="createdon"/>' +
                     '<order attribute="ber_product" descending="false" />' ;

                     if (Xrm.Page.getAttribute("ber_painter").getValue() != null && Xrm.Page.getAttribute("ber_painter").getValue() != undefined)
                    {
                         fetchxml += '<link-entity name="ber_tokentypemaster" from="ber_tokentypemasterid" to="ber_tokentype" alias="aa">' +
                        '<filter type="and">' +
                        '<condition attribute="ber_customertype" operator="eq" value="2" /> ' +
                        '</filter>' +
                        '</link-entity>' ;
                     }
                     else if((Xrm.Page.getAttribute("ber_dealer").getValue() != null && Xrm.Page.getAttribute("ber_dealer").getValue() != undefined))
                     {
                         fetchxml += '<link-entity name="ber_tokentypemaster" from="ber_tokentypemasterid" to="ber_tokentype" alias="aa">' +
                            '<filter type="and">' +
                            '<condition attribute="ber_customertype" operator="eq" value="1" /> ' +
                            '</filter>' +
                            '</link-entity>';
                     }
                     

                     fetchxml += '</entity>' +
                    '</fetch>';
  


    var viewDisplayName = null;
    var viewId = null;
    var isDefaultView = true;
    var layoutxml = '<grid name="resultset" object="10098" jump="ber_product" select="1" icon="1" preview="1">' +
                '<row name="result" id="ber_tokenmasterid">' +
                '<cell name="ber_product" width="100"/>' +
                '<cell name="ber_denomination" width="100"/>' +
                '<cell name="ber_packsize" width="100"/>' +
                '<cell name="ber_srlno" width="100"/>' +
                '<cell name="ber_tokenkeyno" width="100"/>' +
                '<cell name="ber_tokenmonth" width="100"/>' +
                '<cell name="ber_tokentype" width="100"/>' +
                '<cell name="ber_tokenyear" width="100"/>' +
                '<cell name="ber_tokenmonth" width="100"/>' +
                '</row></grid>';



    viewDisplayName = 'Token Master';
    //viewId = "D7A37438-EE11-48E2-A9FD-753B170A0C09";   
       viewId= Xrm.Page.getControl('ber_token').getDefaultView();
    Xrm.Page.getControl('ber_token').addCustomView(viewId, 'ber_tokenmaster', viewDisplayName, fetchxml, layoutxml, isDefaultView);
      document.getElementById('ber_token').disableViewPicker = 1;
     Xrm.Page.getControl("ber_token").setDisabled(false);

           var control = Xrm.Page.ui.controls.get("ber_token");
           control.setFocus();     


}


function GetuniqueGuid() {
    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };
    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';
};