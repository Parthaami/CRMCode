function ValidateSlipNo() {
    var slipNo = Xrm.Page.getAttribute("ber_slipno").getValue();

    if (slipNo != "") {
        var splitArray = slipNo.split("/");
        if (splitArray.length > 1)
        {
            var depoCode = splitArray[0];
            if (depoCode.length > 3)
            {
                alert("Invalid Depot Number in Slip No.");
                Xrm.Page.getAttribute("ber_slipno").setValue("");
                return;
            }
            GetRoleName(depoCode);                      
        }
        else {
            alert("Invalid Depot Number in Slip No.");
            Xrm.Page.getAttribute("ber_slipno").setValue("");
        }
    }
}


function GetRoleName(depoCode) {

    var serverUrl = location.protocol + "//" + location.host + "/" + parent.Xrm.Page.context.getOrgUniqueName();
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_depotSet?$select=ber_DepotNumber&$filter=ber_DepotNumber eq '" + depoCode + "'";

    $.ajax(
        {
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest)
            {
                if (data.d.results.length > 0) {
                    if (data.d.results[0].ber_DepotNumber != null) {
                        return;
                    }
                    else {
                        alert("Invalid Depot Number in Slip No.");
                        Xrm.Page.getAttribute("ber_slipno").setValue("");
                    }
                }
                else {
                    alert("Invalid Depot Number in Slip No.");
                    Xrm.Page.getAttribute("ber_slipno").setValue("");
                }

            },
            error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
        }
    );

}