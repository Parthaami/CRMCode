var ajax_request;

function SubmitRequest(strStatus)
{
    Xrm.Page.getAttribute("ber_bookingstatus").setValue(strStatus);
    Xrm.Page.data.entity.save();
}

function showLoadingMessage(msg)
{
    tdAreas.style.display = 'none';
    var newdiv = document.createElement('div');
    newdiv.setAttribute('id', "msgDiv");
    newdiv.valign = "middle";
    newdiv.align = "center";
    var divInnerHTML = "<table height='100%' width='100%' style='background-color:#f6f8fa; cursor:wait'>";
    divInnerHTML += "<tr>";
    divInnerHTML += "<td valign='middle' align='center'>";
    divInnerHTML += "<img alt='' src='/_imgs/AdvFind/progress.gif'/>";
    divInnerHTML += "<div/><b>" + msg + "</b>";
    divInnerHTML += "</td></tr></table>";
    newdiv.innerHTML = divInnerHTML;
    newdiv.style.background = '#FFFFFF';
    newdiv.style.fontSize = "15px";
    newdiv.style.zIndex = "1010";
    newdiv.style.width = document.body.clientWidth;
    newdiv.style.height = document.body.clientHeight;
    newdiv.style.position = 'absolute';
    document.body.insertBefore(newdiv, document.body.firstChild);
    document.all.msgDiv.style.visibility = 'visible';
}

function GeneratePDC()
{
    showLoadingMessage("Generating PDCs...");
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();
    var BR = Xrm.Page.getAttribute('ber_bookingrequest').getValue();
    var ObjId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    var webServiceURL = serverURL + "/ISV/" + _orgName + "/ColorBankService/Service.asmx?";

    if (BR != null)
    {
        var BRId = BR[0].id;
        BRId = BRId.replace("{", "").replace("}", "");
        var req_params = '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><CreatePDCNew xmlns="http://tempuri.org/"><strBookingRequestId>' + BRId + '</strBookingRequestId><strChequeId>' + ObjId + '</strChequeId></CreatePDCNew></soap:Body></soap:Envelope>';
        window.XMLHttpRequest = new XMLHttpRequest();

        try
        {
            if (window.XMLHttpRequest)
            {
                ajax_request = new XMLHttpRequest();
            }
            //ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
        }
        catch (trymicrosoft)
        {
            try
            {
                ajax_request = new ActiveXObject("Msxml2.XMLHTTP");
            }
            catch (othermicrosoft)
            {
                try
                {
                    ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
                }
                catch (failed)
                {
                    ajax_request = false;
                }
            }
        }

        ajax_request.open("POST", webServiceURL, true);
        ajax_request.setRequestHeader("Content-Type", "text/xml;charset=utf-8");
        ajax_request.onreadystatechange = receiveXML_SOAPDataItem;
        ajax_request.send(req_params);
    }
}

function receiveXML_SOAPDataItem()
{
    if (ajax_request.readyState == 4)
    {
        if (ajax_request.status == 200)
        {
            var xmldata = ajax_request.responseXML
            var result = xmldata.getElementsByTagName("CreatePDCNewResult");
            if (result.length > 0)
            {
                document.all.msgDiv.style.visibility = 'hidden';
                alert(result[0].nodeTypedValue);
            }
            window.parent.close();
        }
        if (ajax_request.status == 400)
        {
            document.all.msgDiv.style.visibility = 'hidden';
            window.parent.close();
        }
    }
}

function openNewColorBankForm()
{

    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    var ObjId = Xrm.Page.data.entity.getId();
    var errorMessage = "Context to retrieve the Server URL is not available.";

    var recordUrl = serverURL + "/" + _orgName + "/main.aspx?";
    var params = "etc=10072";
    params += "&pagetype=entityrecord";
    params += "&extraqs=" + encodeURIComponent("_CreateFromId=" + ObjId + "&_CreateFromType=10023&etc=10072&pagemode=iframe");

    var accountURL = recordUrl + params;
    window.open(accountURL, "_blank", "width=900px,height=600px,resizable=1");
}

function ForwardStock()
{
    showLoadingMessage("Creating Forward Stock Transfer Record...");
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();
    var ObjId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    var webServiceURL = serverURL + "/ISV/" + _orgName + "/ColorBankService/Service.asmx?";

    var req_params = '<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><ForwardStock xmlns="http://tempuri.org/"><strGuid>' + ObjId + '</strGuid></ForwardStock></soap:Body></soap:Envelope>';

    window.XMLHttpRequest = new XMLHttpRequest();

    try
    {
        if (window.XMLHttpRequest)
        {
            ajax_request = new XMLHttpRequest();
        }
        //ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
    }
    catch (trymicrosoft)
    {
        try
        {
            ajax_request = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (othermicrosoft)
        {
            try
            {
                ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (failed)
            {
                ajax_request = false;
            }
        }
    }
    ajax_request.open("POST", webServiceURL, true);
    ajax_request.setRequestHeader("Content-Type", "text/xml;charset=utf-8");
    ajax_request.onreadystatechange = receiveXML_SOAPDataItem1;
    ajax_request.send(req_params);
}

function receiveXML_SOAPDataItem1()
{
    if (ajax_request.readyState == 4)
    {
        if (ajax_request.status == 200)
        {
            var xmldata = ajax_request.responseXML
            var result = xmldata.getElementsByTagName("ForwardStockResult");
            if (result.length > 0)
            {
                var msgdv = document.getElementById('msgDiv');
                if (msgdv != null)
                {
                    msgdv.visibility = 'hidden';
                }

                if (result[0].nodeTypedValue == '1')
                {
                    alert('Installation Request not found.');
                    location.reload();
                }
                else if (result[0].nodeTypedValue == '2')
                {
                    alert("Depot's Inventory Location not found");
                    location.reload();
                }
                else if (result[0].nodeTypedValue == '3')
                {
                    alert("Dealer's Inventory Location Not Found");
                    location.reload();
                }
                else
                {
                    var ObjId = result[0].nodeTypedValue;

                    var serverURL = window.location.protocol + "//" + window.location.host;
                    var _orgName = Xrm.Page.context.getOrgUniqueName();
                    var errorMessage = "Context to retrieve the Server URL is not available.";

                    var recordUrl = serverURL + "/" + _orgName + "/main.aspx?";
                    var params = "etc=10039";
                    params += "&pagetype=entityrecord";
                    params += "&extraqs=" + encodeURIComponent("etc=10039&id=" + ObjId + "&pagemode=iframe");

                    var accountURL = recordUrl + params;

                    window.parent.location.href = accountURL;
                }
            }
        }
    }
}

function UpdatePDCDate()
{
    var startDate = Xrm.Page.getAttribute('ber_rentalstartdate').getValue();
    if (startDate == null)
    {
        return;
    }


    showLoadingMessage("Upating PDCs...");

    //var startDate = Xrm.Page.getAttribute('ber_rentalstartdate').getValue();
    var Day = startDate.getDate();
    var Month = startDate.getMonth();
    var Year = startDate.getFullYear();
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();
    var ObjId = Xrm.Page.getAttribute('ber_installationrequest');
    if (ObjId == null)
    {
        return;
    }
    var webServiceURL = serverURL + "/ISV/" + _orgName + "/ColorBankService/Service.asmx?";

    //var req_params = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><UpdatePDCDate xmlns="http://tempuri.org/"><strGuid>' + ObjId + '</strGuid></UpdatePDCDate></soap:Body></soap:Envelope>';
    var req_params = '<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><UpdatePDCDate xmlns="http://tempuri.org/"><strGuid>' + ObjId.getValue()[0].id.replace("{", "").replace("}", "") + '</strGuid><nDay>' + Day + '</nDay><nMonth>' + Month + '</nMonth><nYear>' + Year + '</nYear></UpdatePDCDate></soap:Body></soap:Envelope>';
    window.XMLHttpRequest = new XMLHttpRequest();

    try
    {
        if (window.XMLHttpRequest)
        {
            ajax_request = new XMLHttpRequest();
        }
    }
    catch (trymicrosoft)
    {
        try
        {
            ajax_request = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (othermicrosoft)
        {
            try
            {
                ajax_request = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (failed)
            {
                ajax_request = false;
            }
        }
    }

    ajax_request.open("POST", webServiceURL, true);
    ajax_request.setRequestHeader("Content-Type", "text/xml;charset=utf-8");
    ajax_request.onreadystatechange = receiveXML_SOAPDataItem2;
    ajax_request.send(req_params);
}

function receiveXML_SOAPDataItem2()
{
    if (ajax_request.readyState == 4)
    {
        if (ajax_request.status == 200)
        {
            var xmldata = ajax_request.responseXML
            var result = xmldata.getElementsByTagName("UpdatePDCDateResult");
            if (result.length > 0)
            {
                document.all.msgDiv.style.visibility = 'hidden';
            }
            else
            {
                window.location.reload(true);
            }
        }
    }
}

function PendingVerification()
{
    Xrm.Page.getAttribute("ber_status").setValue("278290001");
    Xrm.Page.data.entity.save();
}

function Installed()
{
    Xrm.Page.getAttribute("ber_status").setValue("278290002");
    Xrm.Page.data.entity.save();
    UpdatePDCDate();
}

function OpenPDCForm()
{
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    var ObjId = Xrm.Page.data.entity.getId();
    var errorMessage = "Context to retrieve the Server URL is not available.";

    var recordUrl = serverURL + "/" + _orgName + "/main.aspx?";
    var params = "etc=10092";
    params += "&pagetype=entityrecord";
    params += "&extraqs=" + encodeURIComponent("_CreateFromId=" + ObjId + "&_CreateFromType=10023&etc=10092&pagemode=iframe");

    var accountURL = recordUrl + params;
    window.open(accountURL, "_blank", "width=750px,height=450px,resizable=0");
}

function Approve()
{
    Xrm.Page.getAttribute("ber_bookingstatus").setValue("3");
    Xrm.Page.data.entity.save();
}

function Reject()
{
    Xrm.Page.getAttribute("ber_bookingstatus").setValue("11");
    Xrm.Page.data.entity.save();
}