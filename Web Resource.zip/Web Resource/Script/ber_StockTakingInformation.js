function getStockTakingDetail() {
    if (Xrm.Page.ui.getFormType() == 1) {
        var _ber_depotid;
        var _ber_stocktaking;

        var BillToId = Xrm.Page.getAttribute("ber_billto").getValue()[0].id;
        BillToId = BillToId.replace("{", "").replace("}", "");

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + BillToId + ")?$select=_ber_associatedtsiid_value,_ber_depotid_value,customertypecode,paymenttermscode", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();

        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                //var _ber_associatedtsiid_value = result["_ber_associatedtsiid_value"];
                //var _ber_associatedtsiid_value_formatted = result["_ber_associatedtsiid_value@OData.Community.Display.V1.FormattedValue"];
                //var _ber_associatedtsiid_value_lookuplogicalname = result["_ber_associatedtsiid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var _ber_depotid = result["_ber_depotid_value"];
                _ber_depotid = _ber_depotid.replace("{", "").replace("}", "");
                //var _ber_depotid_value_formatted = result["_ber_depotid@OData.Community.Display.V1.FormattedValue"];
                //var _ber_depotid_value_lookuplogicalname = result["_ber_depotid@Microsoft.Dynamics.CRM.lookuplogicalname"];
                //var customertypecode = result["customertypecode"];
                //var customertypecode_formatted = result["customertypecode@OData.Community.Display.V1.FormattedValue"];
                //var paymenttermscode = result["paymenttermscode"];
                //var paymenttermscode_formatted = result["paymenttermscode@OData.Community.Display.V1.FormattedValue"];
            }
        }

        var req1 = new XMLHttpRequest();
        req1.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_depots(" + _ber_depotid + ")?$select=ber_stocktaking", false);
        req1.setRequestHeader("OData-MaxVersion", "4.0");
        req1.setRequestHeader("OData-Version", "4.0");
        req1.setRequestHeader("Accept", "application/json");
        req1.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req1.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req1.send();

        if (req1.response != null && req.response != "") {
            var result1 = JSON.parse(req1.response);
            if (result1 != null) {
                _ber_stocktaking = result["ber_stocktaking"];
                //var ber_stocktaking_formatted = result["_ber_stocktaking@OData.Community.Display.V1.FormattedValue"];
            }
        }

        if (_ber_stocktaking)
            alert("Currently Stock taking Activity is going on for this depot, order will be assigned to Depot.");
    }
}