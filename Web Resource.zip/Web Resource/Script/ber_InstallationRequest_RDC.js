function RDC_OnChange()
{
     var lookupItem = new Array(); 
     lookupItem = Xrm.Page.getAttribute("ber_rdcid").getValue();
     if (lookupItem != null) 
     {
            HideShowItemGridIFrame(true);
     }
     else
     {
            HideShowItemGridIFrame(false);
     }
}