function DisableEstimatetab() {

    if (Xrm.Page.getAttribute("ber_leadtype") != undefined && Xrm.Page.getAttribute("ber_leadtype").getValue() != null) {
        var statuscodevalue = Xrm.Page.getAttribute("statuscode").getValue();
        var b = Xrm.Page.getAttribute("ber_leadtype").getValue();
        if (b != null) {
            if (b == 278290001) {
                if (statuscodevalue == 278290005) {
                   // Xrm.Page.ui.tabs.get("general").sections.get("estimates").setDisable(true);

                    disableSubgrid("leadestimates"); 

                }

                else {

                }
            }


        }
    }
}



function disableSubgrid(subgridName) {
    document.getElementById(subgridName + "_span").disabled = "true";
}