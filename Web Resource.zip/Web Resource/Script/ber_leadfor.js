function leadfor() {
    //debugger;

    var leadtype = Xrm.Page.getAttribute("ber_leadtype").getValue();
    if (leadtype == 278290002) {
        if (Xrm.Page.getAttribute("ber_leadforid").getValue() != null) {
            Xrm.Page.getControl("ber_bdodgid").setVisible(true);
            Xrm.Page.getControl("ber_bdoid").setVisible(true);
            Xrm.Page.getControl("ber_masterpainterid").setVisible(true);
            Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("required");
        }
        else {
            //Xrm.Page.getControl("ber_bdodgid").setVisible(false);
            //Xrm.Page.getControl("ber_bdoid").setVisible(false);
            Xrm.Page.getControl("ber_masterpainterid").setVisible(false);
            Xrm.Page.getAttribute("ber_masterpainterid").setRequiredLevel("none");
        }

    }

}