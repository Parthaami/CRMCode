function populateNameField()
{
Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_customerid").getValue()[0].name + '\\'+ Xrm.Page.getAttribute("ber_contractorid").getValue()[0].name );
Xrm.Page.getAttribute("ber_name").setSubmitMode("always"); 

}