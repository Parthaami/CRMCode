function checklookupvalue(executionObj)
{
var Iscc =UserHasRole("Call Center User");
if (Iscc) {
            //Nothing
        }
		
		else {
            // Form
				var leadtype = Xrm.Page.getAttribute("ber_leadtype").getSelectedOption().text;
					if (leadtype == "BDM" ) 
					{
					var dgid = new Array(); 
					dgid = Xrm.Page.getAttribute("ber_bdodgid").getValue();
					var bdoid = new Array(); 
					bdoid = Xrm.Page.getAttribute("ber_bdoid").getValue();
	
					if (dgid == null && bdoid==null)
						{
			alert("Unable to save because DG  and BDO is not Selected.");
            			executionObj.getEventArgs().preventDefault();
			
						}
					}
        } 


}