// JavaScript source code
FilteredTSI()
{
    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined) {
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
    }
    if (Xrm.Page.getAttribute("ber_cityid") != null && Xrm.Page.getAttribute("ber_cityid") != undefined) {
        var submitMode = "always";
        var city = Xrm.Page.getAttribute("ber_cityid").getValue();
        if (city != null && city != undefined) {
            var cityId = city[0].id;
            var d = "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            d += "<entity name = 'ber_city'>";
            d += "<attribute name = 'ber_citytype'/>";
            d += "<attribute name = 'ber_defaultdepotid'/>";
            d += "<attribute name = 'ber_openjobs'/>";
            d += "<attribute name = 'ber_maxjobs'/>";
            d += "<filter type = 'and'>";
            d += "<condition attribute='ber_cityid' value ='";
            d += cityId;
            d += "' operator = 'eq'/>";
            d += "</filter>";
            d += "</entity>";
            d += "</fetch>";
            var fetchData = XrmServiceToolkit.Soap.Fetch(d);
            if (fetchData[0].attributes['ber_defaultdepotid'] !== null && fetchData[0].attributes['ber_defaultdepotid'] !== undefined) {
                var defaultdepotname = fetchData[0].attributes["ber_defaultdepotid"].name;
                var defaultdepotid = fetchData[0].attributes["ber_defaultdepotid"].id;
                var defaultdepotlogicalname = fetchData[0].attributes["ber_defaultdepotid"].logicalName;
                Xrm.Page.getAttribute("ber_depotid").setValue([{
                    id: defaultdepotid,
                    name: defaultdepotname,
                    entityType: defaultdepotlogicalname
                }]);

            }


        }
    }


    if (Xrm.Page.getAttribute("ber_dgcontact") != null && Xrm.Page.getAttribute("ber_dgcontact") != undefined) {
        //document.getElementById("ber_dgcontact").disableViewPicker = 0;
        $("#ber_dgcontact").find("img").attr("disableviewpicker", "0");
    }
    if (Xrm.Page.getAttribute("ber_depotid") != null && Xrm.Page.getAttribute("ber_depotid") != undefined && Xrm.Page.getAttribute("ber_depotid").getValue() != null) {
        var _depotId = (Xrm.Page.getAttribute("ber_depotid").getValue())[0].id;
        if (_depotId != null) {
            // _depotId = _depotId.replace("{", "");
            //_depotId = _depotId.replace("}", "");
            var view_DGdisplayname = "Filtered DG and HD employee by Default depot";
            //var view_DGId = GetuniqueGuid();
            var tsiViewId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}";
            // var view_DGId = Xrm.Page.getControl("ber_dgcontact").getDefaultView();
            var IsDefaultView = true;

            layoutxml_DG = '<grid name="resultset" object="1" jump="contactid" select="1" icon="2" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="ber_name" width="100" />' +
                    '<cell name="ber_depotname" width="100" />' +
                    '<cell name="ber_mobilenumber" width="100" />' +
                    '<cell name="ber_customertype" width="100" />' +
                    '<cell name="ownerid" width="150" />' +
              '</row>' +
              '</grid>';

            fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="ber_tsi">' +
                    '<attribute name="ber_tsiid" />' +
                    '<attribute name="ber_name" />' +
                    '<attribute name="ber_depotname" />' +
                    '<attribute name="ber_mobilenumber" />' +
                    '<attribute name="ber_customertype" />' +
                    '<order attribute="ber_name" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="statecode" operator="eq" value="0"/>' +
                      '<condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="' + defaultdepotid + '" />' +
                    '</filter>' +
                  '</entity>' +
                '</fetch>';
            Xrm.Page.getControl("ber_dgcontact").addCustomView(tsiViewId, "contact", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
            Xrm.Page.getControl("ber_dgcontact").setDefaultView(tsiViewId);
            //document.getElementById("ber_dgcontact").disableViewPicker = 1;
            $("#ber_dgcontact").find("img").attr("disableviewpicker", "1");

        }
    }


}