function GetCE() {

    if (Xrm.Page.getAttribute("ber_leadid") != undefined && Xrm.Page.getAttribute("ber_leadid").getValue() != null) {
        Xrm.Page.ui.controls.get("ber_ceassigned").setVisible(true);
        var lead = Xrm.Page.getAttribute("ber_leadid").getValue();
        var leadid = lead[0].id;
        var LeadColumns = ['ber_DGcontact'];
        var LeadFilter = "LeadId eq guid'" + leadid + "'";
        var LeadCollection = CrmRestKit.RetrieveMultiple('Lead', LeadColumns, LeadFilter);
        if (LeadCollection != null && LeadCollection != undefined) {
            if (LeadCollection.results != null) {
                if (LeadCollection.results.length > 0) {
                    var collection = LeadCollection.results[0];
                    var CE1 = new Array();
                    CE1[0] = new Object();
                    CE1[0].id = collection.ber_DGcontact.Id
                    CE1[0].name = collection.ber_DGcontact.Name;
                    CE1[0].entityType = "contact";
                    Xrm.Page.getAttribute("ber_ceassigned").setValue(CE1);
                    Xrm.Page.getAttribute("ber_ceassigned").setSubmitMode("always");
                    var CEValue = Xrm.Page.getAttribute("ber_ceassigned").getValue();
                }
            }
        }
    }

    else {

        if (Xrm.Page.ui.controls.get("ber_ceassigned") != null) Xrm.Page.ui.controls.get("ber_ceassigned").setVisible(false);

    }
}

function SetDealers() {

    if (Xrm.Page.getAttribute("customerid") != undefined && Xrm.Page.getAttribute("customerid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid") != undefined && Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'Painter - Express Painting') {
        var SRType = Xrm.Page.getAttribute("pcl_srtypeid").getValue();
        if (Xrm.Page.ui.controls.get("ber_dealer") != null) Xrm.Page.ui.controls.get("ber_dealer").setVisible(true);
        if (Xrm.Page.ui.controls.get("ber_chargable") != null) Xrm.Page.ui.controls.get("ber_chargable").setVisible(true);
        if (Xrm.Page.ui.controls.get("ber_paintexpressitem") != null) Xrm.Page.ui.controls.get("ber_paintexpressitem").setVisible(true);
        if (Xrm.Page.ui.controls.get("ber_paintexpresstoolname") != null) Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(true);
        if (Xrm.Page.ui.controls.get("ber_toolapprovaldate") != null) Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(true);
        if (Xrm.Page.getAttribute("ber_paintexpressitem") != null) Xrm.Page.getAttribute("ber_paintexpressitem").setRequiredLevel("required");

        var Customer = Xrm.Page.getAttribute("customerid").getValue();
        var Customerid = Customer[0].id;
        var lookupRecordGuid = Customerid.replace("{", "").replace("}", "");
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts(" + lookupRecordGuid + ")?$select=_ber_dealerid_value", false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();

        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            if (result != null) {
                var _ber_dealerid_value = result["_ber_dealerid_value"];
                var _ber_dealerid_value_formatted = result["_ber_dealerid_value@OData.Community.Display.V1.FormattedValue"];
                var _ber_dealerid_value_lookuplogicalname = result["_ber_dealerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                var Dealer1 = new Array();
                Dealer1[0] = new Object();
                Dealer1[0].id = _ber_dealerid_value;
                Dealer1[0].name = _ber_dealerid_value_formatted;
                Dealer1[0].entityType = _ber_dealerid_value_lookuplogicalname;
                if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setValue(Dealer1);
                if (Xrm.Page.getAttribute("ber_dealer") != null) Xrm.Page.getAttribute("ber_dealer").setSubmitMode("always");
                    //    alert(DealerValue);

            }
        }
    }
    else {
        Xrm.Page.ui.controls.get("ber_dealer").setVisible(false);
        Xrm.Page.ui.controls.get("ber_chargable").setVisible(false);
        Xrm.Page.ui.controls.get("ber_paintexpressitem").setVisible(false);
        Xrm.Page.ui.controls.get("ber_paintexpresstoolname").setVisible(false);
        Xrm.Page.ui.controls.get("ber_toolapprovaldate").setVisible(false);
        Xrm.Page.getAttribute("ber_paintexpressitem").setRequiredLevel("none");
    }
}


function FilteredDealers_Painters() {
    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (Xrm.Page.getAttribute("ber_dealer") != null && Xrm.Page.getAttribute("ber_dealer") != undefined) {
        document.getElementById("ber_dealer").disableViewPicker = 0;

        if (!isCrmForMobile) {
            document.getElementById("ber_dealer").disableViewPicker = 0;
        }
        else {
            $("#ber_dealer").find("img").attr("disableviewpicker", "0");
        }

        if (Xrm.Page.getAttribute("ber_depot") != null && Xrm.Page.getAttribute("ber_depot").getValue() != null) {
            var Depot = Xrm.Page.getAttribute("ber_depot").getValue();
            var DepotId = Depot[0].id;
            // alert("2");
        }

        if (Xrm.Page.getAttribute("customerid").getValue() != null && Xrm.Page.getAttribute("customerid") != undefined) {
            var Painter = (Xrm.Page.getAttribute("customerid").getValue())[0].id;
            if (Painter != null) {
                // _depotId = _depotId.replace("{", "");
                //_depotId = _depotId.replace("}", "");
                var view_DGdisplayname = "Filtered Dealers";
                var view_DGId = "{15C63745-0A6E-4322-8416-A62C84D90271}";
                var IsDefaultView = true;

                layoutxml_DG = '<grid name="resultset" object="1" jump="accountid" select="1" icon="2" preview="1">' +
                    '<row name="result" id="accountid">' +
                    '<cell name="name" width="100" />' +
                    '<cell name="accountnumber" width="100" />' +
                    '<cell name="accountcategorycode" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
              '</row>' +
              '</grid>';

                fetchxml_DG = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="account">' +
                    '<attribute name="name" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="accountnumber" />' +
                    '<attribute name="accountcategorycode" />' +
                    '<attribute name="ber_depotid" />' +
                    '<order attribute="name" descending="false" />' +
                    '<filter type="and">' +
                     '<condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="' + DepotId + '" />' +
                     '<condition attribute="statecode" value="0" operator="eq"/>' +
                // '<condition attribute="accountcategorycode" value="278290008" operator="eq"/>' +
               '<condition attribute="accountcategorycode" operator="in">' +
                     '<value>278290008</value>' +
                     '<value>278290006</value>' +
                      '<value>278290009</value>' +
                       '<value>278290005</value>' +
                       '<value>278290010</value>' +
                       '<value>278290007</value>' +
                     '</condition>' +
                     '<condition attribute="parentaccountid" operator="null"/>' +
                    '</filter>' +
                      '<link-entity name="account" link-type="outer" visible="false" to="parentaccountid" from="accountid">' +
                     '<attribute name="accountnumber"/>' +
                     '</link-entity>' +
                  '</entity>' +
                '</fetch>';
                Xrm.Page.getControl("ber_dealer").addCustomView(view_DGId, "account", view_DGdisplayname, fetchxml_DG, layoutxml_DG, IsDefaultView);
                Xrm.Page.getControl("ber_dealer").setDefaultView(view_DGId);
                if (!isCrmForMobile) {
                    document.getElementById("ber_dealer").disableViewPicker = 1;
                }
                else {
                    $("#ber_dealer").find("img").attr("disableviewpicker", "1");
                }

            }
        }
    }
}

///////////////////////////////  set MobilePhone //////////////////////////////

function setMobilePhone1() {
    if (Xrm.Page.getAttribute("customerid") != undefined && Xrm.Page.getAttribute("customerid").getValue() != null) {
        alert("7");
        var painter = Xrm.Page.getAttribute("customerid").getValue();
        alert("1");
        var painterid = painter[0].id;
        alert("2");
        var painterColumns = ['ber_CustomerType', 'MobilePhone'];
        alert("3");
        var painterFilter = "ContactId eq guid'" + painterid + "'";
        alert("4");
        var painterCollection = CrmRestKit.RetrieveMultiple('Contact', painterColumns, painterFilter);
        if (painterCollection != null && painterCollection != undefined) {
            alert("5");

            if (painterCollection.results != null) {
                if (painterCollection.results.length > 0) {
                    alert("6");
                    var collection = painterCollection.results[0];
                    var Phone = collection.MobilePhone;
                    // var AproovedDate = collection.ber_toolapprovaldate;
                    // var Status = collection.statuscode.Value;
                }
            }
        }
    }
}


function IoT() {
    if (Xrm.Page.getAttribute("customerid") != undefined && Xrm.Page.getAttribute("customerid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid") != undefined && Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'IoT') {

        if (Xrm.Page.ui.controls.get("ber_iotserialkey") != null) Xrm.Page.ui.controls.get("ber_iotserialkey").setVisible(true);
        if (Xrm.Page.getAttribute("ber_iotserialkey") != null) Xrm.Page.getAttribute("ber_iotserialkey").setRequiredLevel("required");
    }
    else {
        if (Xrm.Page.ui.controls.get("ber_iotserialkey") != null) Xrm.Page.ui.controls.get("ber_iotserialkey").setVisible(false);
        if (Xrm.Page.getAttribute("ber_iotserialkey") != null) Xrm.Page.getAttribute("ber_iotserialkey").setRequiredLevel("none");
    }
}