function RemoveStatus() {
    if (Xrm.Page.ui.getFormType() != 1) {
        Xrm.Page.getControl("statuscode").setDisabled(false);
        var SchemeStatus = Xrm.Page.getControl("statuscode");
        var STATUS = Xrm.Page.getAttribute("statuscode").getValue();

        if (STATUS != 0)
            SchemeStatus.removeOption(0);
        if (STATUS != 2)
            SchemeStatus.removeOption(2);
        if (STATUS != 3)
            SchemeStatus.removeOption(3);
        if (STATUS != 4)
            SchemeStatus.removeOption(4);
    }   
}