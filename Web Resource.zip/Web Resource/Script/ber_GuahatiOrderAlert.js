function Orderalert() {

    if (Xrm.Page.getAttribute("ber_depotid") != undefined && Xrm.Page.getAttribute("ber_depotid").getValue() != null) {

        var depot = Xrm.Page.getAttribute("ber_depotid").getValue();
        if (depot != null) {
            var _depotId = depot[0].id;
            var _depotName = depot[0].name;
            if(_depotName == "002:Guwahati") {
                alert("ALERT!! LITRES (L) AND KGS (K) ARE TO BE BILLED IN SEPARATE ORDERS!!");
                    
          }
        }

       
    }

    

}