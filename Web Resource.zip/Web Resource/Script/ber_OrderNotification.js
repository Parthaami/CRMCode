function orderLimitAlert() {

    addNotification("Order amount (without tax) should not exceed  1.73 lacs", 1);

}



function addNotification(message, level) {
    //var notificationsArea = document.getElementById('crmNotifications');
    //if (notificationsArea == null) {
    //    return;
    //}

    if (level == 1) { //critical 
        Xrm.Page.ui.setFormNotification(message, 'ERROR', '1');
        //notificationsArea.AddNotification('mep1', 1, 'source', message);
    }
    if (level == 2) { //Info 
        Xrm.Page.ui.setFormNotification(message, 'INFORMATION', '3');
        //notificationsArea.AddNotification('mep3', 3, 'source', message);
    }
    if (level == 3) { //Warning 
        Xrm.Page.ui.setFormNotification(message, 'WARNING', '2');
        //notificationsArea.AddNotification('mep2', 2, 'source', message);
    }
    if (message == "") {
        Xrm.Page.ui.setFormNotification(null, null, null);
    }
}