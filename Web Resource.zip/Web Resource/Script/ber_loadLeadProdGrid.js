function loadLeadProdGrid() {
    //debugger;         
    if (Xrm.Page.ui.tabs.get("leadproduct") != null) {
        Xrm.Page.ui.tabs.get("leadproduct").add_tabStateChange(function () {
            if (Xrm.Page.ui.tabs.get("leadproduct").getDisplayState() == "expanded") {
                if (Xrm.Page.ui.getFormType() != 1) {
                    setiframeurl(1);

                }
            }
        })
    }
}

function setiframeurl(gridnum) {
    //debugger;
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    if (Xrm.Page.ui.getFormType() != 1 && Xrm.Page.getAttribute("statuscode").getValue() != 1) {
        var context;
        var objectId;
        var orgName;
        var userId;
        var hostName;

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        userId = context.getUserId();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        var product = "http://10.150.80.11:7035/LeadProduct.aspx?LeadId=" + objectId + "&UserId=" + userId;

        var estimateproduct = serverURL + "/ISV/" + _orgName + "/LeadEstimatedProduct/EstimatedLeadProduct.aspx?LeadId=" + objectId + "&UserId=" + userId;

        var status = Xrm.Page.getAttribute("statecode").getValue();

        if (status != 0) {
            product += "&ROG=true";
            estimateproduct += "&ROG=true";
        }

        if (document.all.IFRAME_leadproductgrid != null && gridnum == 1) {
            if (document.all.IFRAME_leadproductgrid.src == null || document.all.IFRAME_leadproductgrid.src == "about:blank") {
                document.all.IFRAME_leadproductgrid.src = product;
            }
        }
        if (document.all.IFRAME_leadproductgrid != null && gridnum == 2) {
            if (document.all.IFRAME_leadestimateproduct.src == null || document.all.IFRAME_leadestimateproduct.src == "about:blank") {
                document.all.IFRAME_leadestimateproduct.src = estimateproduct;
            }
        }
    }
}