/***********************
Ticket# 234(Sub Painter enhancement functionality)
Date: 21/08/2018
Developed by: Partha
Method: fetchDealerDepot_ParentPainter
Function: to fetch dealer and depot based on painter look up
**********************/
if (Xrm.Page.getAttribute("ber_parentpainter") != null && Xrm.Page.getAttribute("ber_parentpainter") != undefined) {
    var globalber_parentpainter = Xrm.Page.getAttribute("ber_parentpainter").getValue();
}

function fetchDealerDepot_ParentPainter() {

    if (Xrm.Page.getAttribute("ber_parentpainter").getValue() != null && Xrm.Page.getAttribute("ber_parentpainter") != undefined) {

        var ParentPainterId = (Xrm.Page.getAttribute("ber_parentpainter").getValue())[0].id;
        var modifiedParentPainterId = ParentPainterId.replace("{", "").replace("}", "");

        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=ber_customertype,_ber_dealerid_value,_ber_preferredlanguage1_value,_ber_preferredlanguage2_value,_ber_depotid_value,contactid&$filter=contactid eq " + modifiedParentPainterId, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,_ber_dealerid_value,contactid,fullname,mobilephone,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and ber_customertype eq 278290001 and (ber_subdealer eq false or ber_subdealer eq null) and  _ber_parentpainter_value eq null and _ownerid_value eq " + modifiedcurrentUser, false);

        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send();
        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            try {
                if (result != null) {
                    //no duplicate record should be allowed
                    if (result.value.length == 1) {
                        //for (var i = 0; i < results.value.length; i++) {
                        var ber_customertype = result.value[0]["ber_customertype"];
                        var ber_customertype_formatted = result.value[0]["ber_customertype@OData.Community.Display.V1.FormattedValue"];

                        var _ber_dealerid_value = result.value[0]["_ber_dealerid_value"];
                        var _ber_dealerid_value_formatted = result.value[0]["_ber_dealerid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_dealerid_value_lookuplogicalname = result.value[0]["_ber_dealerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                        var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_preferredlanguage1_value = result.value[0]["_ber_preferredlanguage1_value"];
                        var _ber_preferredlanguage1_value_formatted = result.value[0]["_ber_preferredlanguage1_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_preferredlanguage1_value_lookuplogicalname = result.value[0]["_ber_preferredlanguage1_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_preferredlanguage2_value = result.value[0]["_ber_preferredlanguage2_value"];
                        var _ber_preferredlanguage2_value_formatted = result.value[0]["_ber_preferredlanguage2_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_preferredlanguage2_value_lookuplogicalname = result.value[0]["_ber_preferredlanguage2_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var contactid = result.value[0]["contactid"];

                        var DepotArray = new Array();
                        DepotArray[0] = new Object();
                        DepotArray[0].id = _ber_depotid_value;
                        DepotArray[0].name = _ber_depotid_value_formatted;
                        DepotArray[0].entityType = _ber_depotid_value_lookuplogicalname;

                        var DealerArray = new Array();
                        DealerArray[0] = new Object();
                        DealerArray[0].id = _ber_dealerid_value;
                        DealerArray[0].name = _ber_dealerid_value_formatted;
                        DealerArray[0].entityType = _ber_dealerid_value_lookuplogicalname;

                        var Language1Array = new Array();
                        Language1Array[0] = new Object();
                        Language1Array[0].id = _ber_preferredlanguage1_value;
                        Language1Array[0].name = _ber_preferredlanguage1_value_formatted;
                        Language1Array[0].entityType = _ber_preferredlanguage1_value_lookuplogicalname;

                        var Language2Array = new Array();
                        Language2Array[0] = new Object();
                        Language2Array[0].id = _ber_preferredlanguage2_value;
                        Language2Array[0].name = _ber_preferredlanguage2_value_formatted;
                        Language2Array[0].entityType = _ber_preferredlanguage2_value_lookuplogicalname;


                        Xrm.Page.getAttribute("ber_dealerid").setValue(DealerArray);
                        Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_depotid").setValue(DepotArray);
                        Xrm.Page.getAttribute("ber_depotid").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_preferredlanguage1").setValue(Language1Array);
                        Xrm.Page.getAttribute("ber_preferredlanguage1").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_preferredlanguage2").setValue(Language2Array);
                        Xrm.Page.getAttribute("ber_preferredlanguage2").setSubmitMode("always");

                    }
                }

            }
            catch (err) {
                alert("Please communicate system administrator in HO for error: " + err);
            }

        }
    }


    else {

        Xrm.Page.getAttribute("ber_dealerid").setValue(null);
        Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        Xrm.Page.getAttribute("ber_depotid").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_preferredlanguage1").setValue(null);
        Xrm.Page.getAttribute("ber_preferredlanguage1").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_preferredlanguage2").setValue(null);
        Xrm.Page.getAttribute("ber_preferredlanguage2").setSubmitMode("always");

    }
}








/***********************
Ticket# 234(Sub Painter enhancement functionality)
Date: 21/08/2018
Developed by: Partha
Method: fetchDealerDepot_ParentPainter
Function: Fetch dealer depot from mobile numbe of painter
**********************/


function GetContactDetails_PainterMobileNumber() {

    if (Xrm.Page.getAttribute("ber_mobilenoofpainter").getValue() != null && Xrm.Page.getAttribute("ber_mobilenoofpainter") != undefined) {
        var telephone = Xrm.Page.getAttribute("ber_mobilenoofpainter").getValue();
        var currentUser = Xrm.Page.context.getUserId();
        var modifiedcurrentUser = currentUser.replace("{", "").replace("}", "");
        //  alert(modifiedcurrentUser);

        var req = new XMLHttpRequest();
        //   req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname&$filter=mobilephone eq '" + telephone + "' and  _ownerid_value eq " + modifiedcurrentUser, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname,mobilephone,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and _ownerid_value eq " + modifiedcurrentUser, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$filter=mobilephone eq '1234567890' and  ber_customertype eq 278290001 and  ber_subdealer eq false and  _ber_parentpainter_value eq null", true);
        if (UserHasRole(("Depot User") || ("Depot Home Decor User"))) {

            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,_ber_dealerid_value,contactid,fullname,mobilephone,_ber_preferredlanguage1_value,_ber_preferredlanguage2_value,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and ber_customertype eq 278290001 and (ber_subdealer eq false or ber_subdealer eq null) and  _ber_parentpainter_value eq null and _ownerid_value eq " + modifiedcurrentUser, false);

        }

        else if (UserHasRole("System Administrator")) {
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,_ber_dealerid_value,contactid,fullname,mobilephone,_ber_preferredlanguage1_value,_ber_preferredlanguage2_value,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and ber_customertype eq 278290001 and (ber_subdealer eq false or ber_subdealer eq null) and  _ber_parentpainter_value eq null", false);

        }
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.send();

        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            try {
                if (result != null) {
                    //no duplicate record should be allowed
                    if (result.value.length == 1) {
                        // alert(result.value.length);
                        //for (var i = 0; i < results.value.length; i++) 
                        //{
                        //  var _ber_depotid_value = result.value[0]["_ber_depotid_value"];

                        var contactid = result.value[0]["contactid"];
                        var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                        var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_dealerid_value = result.value[0]["_ber_dealerid_value"];
                        var _ber_dealerid_value_formatted = result.value[0]["_ber_dealerid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_dealerid_value_lookuplogicalname = result.value[0]["_ber_dealerid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_preferredlanguage1_value = result.value[0]["_ber_preferredlanguage1_value"];
                        var _ber_preferredlanguage1_value_formatted = result.value[0]["_ber_preferredlanguage1_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_preferredlanguage1_value_lookuplogicalname = result.value[0]["_ber_preferredlanguage1_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        var _ber_preferredlanguage2_value = result.value[0]["_ber_preferredlanguage2_value"];
                        var _ber_preferredlanguage2_value_formatted = result.value[0]["_ber_preferredlanguage2_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_preferredlanguage2_value_lookuplogicalname = result.value[0]["_ber_preferredlanguage2_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

                        if (result.value[0]["fullname"] != null) {
                            var fullname = result.value[0]["fullname"];
                        }
                        else {
                            var fullname = " ";
                        }
                        var _ber_contactid_value_lookuplogicalname = "contact"

                        var ContactArray = new Array();
                        ContactArray[0] = new Object();
                        ContactArray[0].id = contactid;
                        ContactArray[0].name = fullname;
                        ContactArray[0].entityType = _ber_contactid_value_lookuplogicalname;


                        var DepotArray = new Array();
                        DepotArray[0] = new Object();
                        DepotArray[0].id = _ber_depotid_value;
                        DepotArray[0].name = _ber_depotid_value_formatted;
                        DepotArray[0].entityType = _ber_depotid_value_lookuplogicalname;

                        var DealerArray = new Array();
                        DealerArray[0] = new Object();
                        DealerArray[0].id = _ber_dealerid_value;
                        DealerArray[0].name = _ber_dealerid_value_formatted;
                        DealerArray[0].entityType = _ber_dealerid_value_lookuplogicalname;

                        var Language1Array = new Array();
                        Language1Array[0] = new Object();
                        Language1Array[0].id = _ber_preferredlanguage1_value;
                        Language1Array[0].name = _ber_preferredlanguage1_value_formatted;
                        Language1Array[0].entityType = _ber_preferredlanguage1_value_lookuplogicalname;

                        var Language2Array = new Array();
                        Language2Array[0] = new Object();
                        Language2Array[0].id = _ber_preferredlanguage2_value;
                        Language2Array[0].name = _ber_preferredlanguage2_value_formatted;
                        Language2Array[0].entityType = _ber_preferredlanguage2_value_lookuplogicalname;

                        Xrm.Page.getAttribute("ber_parentpainter").setValue(ContactArray);
                        Xrm.Page.getAttribute("ber_parentpainter").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_dealerid").setValue(DealerArray);
                        Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_depotid").setValue(DepotArray);
                        Xrm.Page.getAttribute("ber_depotid").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_preferredlanguage1").setValue(Language1Array);
                        Xrm.Page.getAttribute("ber_preferredlanguage1").setSubmitMode("always");

                        Xrm.Page.getAttribute("ber_preferredlanguage2").setValue(Language2Array);
                        Xrm.Page.getAttribute("ber_preferredlanguage2").setSubmitMode("always");
                        //Xrm.Page.getAttribute("ber_parentpainter").setValue(ContactArray);
                    }

                    else {
                        alert("Please enter the mobile no of the painter specific to this depot");
                        Xrm.Page.getAttribute("ber_mobilenoofpainter").setValue(null);
                    }
                }
            }

            catch (err) {
                alert("Please communicate system administrator in HO for error: " + err);
            }

        }
        // }
    }

    else {

    }
}


/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
Method: focusMobile
Functionality: Keep focus on mobile number while changing the master painter attached with the sub painter
***************/


function focusMobile() {
    if (Xrm.Page.getAttribute("ber_depot").getValue() != null && Xrm.Page.getAttribute("ber_depot") != undefined) {
        if (Xrm.Page.getAttribute("ber_mobilenumber") != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
            Xrm.Page.getControl("ber_mobilenumber").setFocus();
            Xrm.Page.getControl("ber_mobilenumber").setDisabled(false);
            Xrm.Page.getAttribute("ber_mobilenumber").setRequiredLevel("required");
        }
    }

}



/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
Method: ValidateNumber
Functionality: Validate the mobile number must be numaric and of 10 digit
***************/

function ValidateNumber() {

    if (Xrm.Page.getAttribute("ber_mobilenoofpainter").getValue() != null && Xrm.Page.getAttribute("ber_mobilenoofpainter") != undefined) {
        //get the mobile number being entered
        var contactNumber = Xrm.Page.getAttribute("ber_mobilenoofpainter").getValue();
        var n = contactNumber.length;

        var i;
        var returnString = "";

        if (typeof (contactNumber) != "undefined" && contactNumber != null) {
            var filteredValues = "1234567890";

            for (i = 0; i < contactNumber.length; i++) {
                var c = contactNumber.charAt(i);
                if (filteredValues.indexOf(c) != -1) {
                    returnString += c;
                }
            }
            Xrm.Page.getAttribute("ber_mobilenoofpainter").setValue(returnString);

            if (returnString.length == contactNumber.length) {

                if (n == 10) {

                    GetContactDetails_PainterMobileNumber();
                }
                else {
                    alert("Mobile Number should be of 10 digits");
                    Xrm.Page.getAttribute("ber_mobilenoofpainter").setValue("");
                }

            }
            else {
                Xrm.Page.getAttribute("ber_mobilenoofpainter").setValue("");
                alert('Only Numeric values are allowed');
            }

        }

    }

    else {

        //  Xrm.Page.getAttribute("ber_originator").setValue(null);
        //  Xrm.Page.getAttribute("ber_originator").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_dealerid").setValue(null);
        Xrm.Page.getAttribute("ber_dealerid").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        Xrm.Page.getAttribute("ber_depotid").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_parentpainter").setValue(null);
        Xrm.Page.getAttribute("ber_parentpainter").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_preferredlanguage1").setValue(null);
        Xrm.Page.getAttribute("ber_preferredlanguage1").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_preferredlanguage2").setValue(null);
        Xrm.Page.getAttribute("ber_preferredlanguage2").setSubmitMode("always");

    }
}




/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
Method: AsssignAsMasterPainter
Functionality: Converting to Master Painter 
***************/



// JavaScript source code
function AsssignAsMasterPainter() {

    // if (Xrm.Page.getAttribute("ber_parentpainter") != null && Xrm.Page.getAttribute("ber_parentpainter") != undefined) {
    //      var ParentPainterValue = Xrm.Page.getAttribute("ber_parentpainter").getValue();
    //  }
    var ParentPainter = Xrm.Page.getAttribute("ber_parentpainter");
    if (Xrm.Page.getAttribute("ber_changetomasterpainter").getValue() == true) {
        if (ParentPainter != null) {
            ParentPainter.setValue(null);
            ParentPainter.setSubmitMode("always");
            // Xrm.Page.ui.controls.get("ber_changetomasterpainter").setDisabled(false);
            Xrm.Page.ui.controls.get("ber_converttomasterpainter").setDisabled(true);

        }
    }
    else if (Xrm.Page.getAttribute("ber_changetomasterpainter").getValue() == false) {
        //  alert(ParentPainterValue);
        ParentPainter.setValue(globalber_parentpainter);
        ParentPainter.setSubmitMode("always");
        //   Xrm.Page.ui.controls.get("ber_changetomasterpainter").setDisabled(false);
        Xrm.Page.ui.controls.get("ber_converttomasterpainter").setDisabled(false);
    }
    // }

}




/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: DeAssociatedMasterPainter
functionality: Changing Master painter 
***************/

function DeAssociatedMasterPainter() {
    if (Xrm.Page.getAttribute("ber_converttomasterpainter").getValue() != false && Xrm.Page.getAttribute("ber_converttomasterpainter") != undefined) {
        //alert('OK I am here for DeAssociatedMasterPainter');
        var Enableparentpainter = Xrm.Page.ui.controls.get("ber_parentpainter");
        // Enablechangetomasterpainter.setDisabled(true);
        Enableparentpainter.setDisabled(true);
        alert("Enter the painters mobile no to change the association");
        Xrm.Page.getControl("ber_mobilenoofpainter").setFocus();
        Xrm.Page.getControl("ber_mobilenoofpainter").setDisabled(false);
        Xrm.Page.getAttribute("ber_mobilenoofpainter").setRequiredLevel("required");
        Xrm.Page.ui.controls.get("ber_changetomasterpainter").setDisabled(true);
    }

    else if (Xrm.Page.getAttribute("ber_converttomasterpainter").getValue() == false || Xrm.Page.getAttribute("ber_converttomasterpainter") == undefined) {
        //  Xrm.Page.getControl("ber_mobilenoofpainter").setFocus();
        Xrm.Page.getControl("ber_mobilenoofpainter").setDisabled(true);
        Xrm.Page.getAttribute("ber_mobilenoofpainter").setRequiredLevel("none");
        Xrm.Page.ui.controls.get("ber_changetomasterpainter").setDisabled(false);
    }
}




/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: ValidateSubPainterNumber
functionality: Mobile numbervalidation for sub painter 
***************/

function ValidateSubPainterNumber() {

    var contactNumber = Xrm.Page.getAttribute("mobilephone").getValue();
    var n = contactNumber.length;

    var i;
    var returnString = "";

    if (typeof (contactNumber) != "undefined" && contactNumber != null) {
        filteredValues = "1234567890";

        for (i = 0; i < contactNumber.length; i++) {
            var c = contactNumber.charAt(i);
            if (filteredValues.indexOf(c) != -1) {
                returnString += c;
            }
        }
        Xrm.Page.getAttribute("mobilephone").setValue(returnString);

        if (returnString.length != contactNumber.length) {
            Xrm.Page.getAttribute("mobilephone").setValue("");
            alert('Only Integers are allowed');
            Xrm.Page.getControl("mobilephone").setFocus(true);
            Xrm.Page.getControl("mobilephone").setFocus(true);

        }
    }
    if (n != 10) {
        alert("Mobile Number should be of 10 digits");
        Xrm.Page.getAttribute("mobilephone").setValue("");
        Xrm.Page.getControl("mobilephone").setFocus(true);
        Xrm.Page.getControl("mobilephone").setFocus(true);
    }
}


/////////////////////////////////////////////////////////

/**************
Developer : Partha
Date: 21/08/2018
Ticket: =#234(Sub Painter functionality)
method: CaptureConvertToMPDate
functionality: Capture Date while converting to master painter 
***************/


function CaptureConvertToMPDate() {

    if (Xrm.Page.getAttribute("ber_changetomasterpainter") != null && Xrm.Page.getAttribute("ber_changetomasterpainter") != undefined) {
        if (Xrm.Page.getAttribute("ber_changetomasterpainter").getValue() == true) {
            var today = getServerTime();
            if (Xrm.Page.getAttribute("ber_parentpainter").getValue() == null) {

                var CaptureDate = Xrm.Page.getAttribute("ber_converttompdate").setValue(today);
                Xrm.Page.getAttribute("ber_converttompdate").setSubmitMode("always");

            }

        }

        else if (Xrm.Page.getAttribute("ber_changetomasterpainter").getValue() == false) {
            var CaptureDate = Xrm.Page.getAttribute("ber_converttompdate").setValue(null);
            Xrm.Page.getAttribute("ber_converttompdate").setSubmitMode("always");

        }
    }

}


var xmlHttp;
function getServerTime() {
    try {
        //FF, Opera, Safari, Chrome
        xmlHttp = new XMLHttpRequest();
    }
    catch (err1) {
        //IE
        try {
            xmlHttp = new ActiveXObject('Msxml2.XMLHTTP');
        }
        catch (err2) {
            try {
                xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            catch (eerr3) {
                //AJAX not supported, use CPU time.
                alert("AJAX not supported");
            }
        }
    }
    xmlHttp.open('HEAD', window.location.href.toString(), false);
    xmlHttp.setRequestHeader("Content-Type", "text/html");
    xmlHttp.send('');
    // addMinutes(xmlHttp.getResponseHeader("Date"), 330)
    var addmin = addMinutes(xmlHttp.getResponseHeader("Date"));

    return addmin
}

function addMinutes(date) {
    var d = new Date(date);
    // alert(typeof (d));
    //return new Date(d.getTime() + 330 * 60000);
    //d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000);
    return d.setTime(d.getTime() + (d.getTimezoneOffset() + 330) * 60 * 1000)

}




