function SetDepotMandatory() {
    if (Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'End Customer - Generic') {
        //alert(Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name);
        Xrm.Page.getAttribute("ber_depot").setRequiredLevel("required");

    }
    else {
        Xrm.Page.getAttribute("ber_depot").setRequiredLevel("none");
    }
}


function preventSave(executionObj) {
    if (Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'End Customer - Generic') {

        if (Xrm.Page.getAttribute("ber_depot").getValue() == null) {
            executionObj.getEventArgs().preventDefault();
            alert("Please enter the depot");
        }
    }
}