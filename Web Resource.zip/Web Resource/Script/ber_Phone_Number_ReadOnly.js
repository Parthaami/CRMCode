function phoneReadOnly() {
    var IsAdmin = UserHasRole("System Administrator");

    if (Xrm.Page.getAttribute("ber_customertype") != null && Xrm.Page.getAttribute("ber_customertype").getValue() != null) {
        var paintertype = Xrm.Page.getAttribute("ber_customertype").getSelectedOption().text;


        if (IsAdmin && (paintertype == "DG" || paintertype == "BDO")) {
            //Nothing
        }
        else {
            Xrm.Page.ui.controls.get("mobilephone").setDisabled(true);

        }


    }

}
function HideRibbonControl() {
    var saveButtonID = "contact|NoRelationship|Form|Mscrm.Form.contact.Save-Large";
    alert(saveButtonID);
    HideARibbonButton(saveButtonID);

}

function HideARibbonButton(nameOfButton) {
    var btn = window.top.document.getElementById(nameOfButton);
    var intervalId = window.setInterval(function () {
        if (btn != null) {
            window.clearInterval(intervalId);
            btn.disabled = true;
        }
    }, 50);
}




/*

function XPDateReadOnly() {
    var IsAdmin = UserHasRole("System Administrator");

    //if (Xrm.Page.getAttribute("ber_customertype") != null && Xrm.Page.getAttribute("ber_customertype").getValue() != null  && (Xrm.Page.getAttribute("ber_xpcreationdate") != null ) {
        //var paintertype = Xrm.Page.getAttribute("ber_customertype").getSelectedOption().text;


        if (IsAdmin) {
            //Nothing
          // Xrm.Page.ui.controls.get("ber_xpcreationdate").setDisabled(false);

        }
        else {
             Xrm.Page.ui.controls.get("ber_xpcreationdate").setDisabled(true);

        }


    //}

     }

     */

function XPDateReadOnly() {
         if (UserHasRole("System Administrator")) {
             Xrm.Page.ui.controls.get("ber_xpcreationdate").setDisabled(false);
             Xrm.Page.ui.controls.get("ber_pxpcreationdate").setDisabled(false);
         }
         else {
             Xrm.Page.ui.controls.get("ber_xpcreationdate").setDisabled(true);
             Xrm.Page.ui.controls.get("ber_pxpcreationdate").setDisabled(true);
            // var PickListControl = Xrm.Page.getControl("ber_reconciliationstatus");
             //PickListControl.removeOption(2);

         }
     }















////////////////////////////////////////////////



function SetvisibleHotlist()

{
var CustomerType = Xrm.Page.getAttribute("ber_customertype").getValue();
    var Hotlist = Xrm.Page.getAttribute("ber_hotlistpainter").getValue();

    if (CustomerType != 278290001) {
        Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(false);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);
    }

    else if (CustomerType == 278290001) {

        Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(true);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);

    }

    else {

    }

}


//////////////////////////////////////

function CheckHotlist() {

    var CustomerType = Xrm.Page.getAttribute("ber_customertype").getValue();
    var Hotlist = Xrm.Page.getAttribute("ber_hotlistpainter").getValue();
   

    if (Hotlist != null && Hotlist == 1 && CustomerType == 278290001) {

       // Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(true);
        Xrm.Page.ui.controls.get("ber_reason").setVisible(true);
        Xrm.Page.data.entity.attributes.get("ber_reason").setRequiredLevel("required");

    }
   
    else {

        Xrm.Page.ui.controls.get("ber_reason").setVisible(false);
       // Xrm.Page.ui.controls.get("ber_hotlistpainter").setVisible(false);

    }

    }












/////////////////////////////////////






function FieldsReadOnlyforDepot() {

    if (UserHasRole("Depot User") || UserHasRole("Depot Home Decor User")) {

        Xrm.Page.ui.controls.get("ber_customertype").setDisabled(true);
        Xrm.Page.ui.controls.get("ber_bdterritory").setDisabled(true);

    }
    else {

    }
}




///////////////////////////////////////