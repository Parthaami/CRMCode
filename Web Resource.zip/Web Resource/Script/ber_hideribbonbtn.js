function HideReactiveCaseRibbonBtn()
{
var ResolutionType = Xrm.Page.getAttribute("pcl_resolutiontype").getValue();
if(ResolutionType == 798330001)
{
return false;
}
else
{
return true;
}
}