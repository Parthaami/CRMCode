function CalulateTotalAmount()
{
	var RegPoint = 0;
	var VolBonus = 0;
	var GrpBonus = 0;
	var BPoint = 0;

	if(Xrm.Page.getAttribute("ber_regularpoints").getValue() != null)
	{
		RegPoint = Xrm.Page.getAttribute("ber_regularpoints").getValue();
	}
	if(Xrm.Page.getAttribute("ber_volumebonus").getValue() != null)
	{
		VolBonus = Xrm.Page.getAttribute("ber_volumebonus").getValue();
	}
	if(Xrm.Page.getAttribute("ber_groupbonus").getValue() != null)
	{
		GrpBonus = Xrm.Page.getAttribute("ber_groupbonus").getValue();
	}
	if(Xrm.Page.getAttribute("ber_benefitpoints").getValue() != null)
	{
		BPoint = Xrm.Page.getAttribute("ber_benefitpoints").getValue();
	}
	
	var totalpoints = RegPoint + VolBonus + GrpBonus + BPoint;
	Xrm.Page.getAttribute("ber_totalpointmeet").setValue(totalpoints);	
}