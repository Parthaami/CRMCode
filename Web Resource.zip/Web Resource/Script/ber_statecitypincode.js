function citystate()
{
//debugger;
	if(Xrm.Page.getAttribute("ber_cityid").getValue() != null)
	{
		//Xrm.Page.getControl("ber_cityid").setDisabled(true);
                                         //Xrm.Page.getAttribute("ber_cityid").setValue(null);
	}
	if(Xrm.Page.getAttribute("ber_pincodeid").getValue() != null)
	{
		//Xrm.Page.getControl("ber_pincodeid").setDisabled(true);
	}	
}

function onchangestate()
{

	if(Xrm.Page.getAttribute("ber_stateid").getValue() == null)
	{		
		//Xrm.Page.getControl("ber_cityid").setDisabled(true);		
	}
	else
	{
		//Xrm.Page.getControl("ber_cityid").setDisabled(false);		
	}
	Xrm.Page.getAttribute("ber_cityid").setValue(null);
	Xrm.Page.getAttribute("ber_pincodeid").setValue(null);
	//Xrm.Page.getControl("ber_pincodeid").setDisabled(true);
}
function onchangecity()
{
	if(Xrm.Page.getAttribute("ber_cityid").getValue() == null)
	{		
		//Xrm.Page.getControl("ber_pincodeid").setDisabled(true);
	}
	else
	{
		//Xrm.Page.getControl("ber_pincodeid").setDisabled(false);
	}
	//Xrm.Page.getAttribute("ber_pincodeid").setValue(null);
}