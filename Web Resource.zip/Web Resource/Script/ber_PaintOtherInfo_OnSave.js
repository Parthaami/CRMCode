/**************
Developer : Madhumita
Date : 06/08/2018
Ticket: =#233(Key contractor functionality)
Method: check if any painter other infor record exist with same mobile number
***************/

function retrieveMobileNumber(executionObj) {

    var FormType = Xrm.Page.ui.getFormType();
    if (FormType != null) {
        if (FormType == 1) {
            if (Xrm.Page.getAttribute("ber_mobilenumber").getValue() != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
                var telephone = Xrm.Page.getAttribute("ber_mobilenumber").getValue();

                var req = new XMLHttpRequest();
                req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_painterotherinfos?$select=ber_mobilenumber,ber_type,statecode&$filter=ber_mobilenumber eq '" + telephone + "' and  statecode eq 0", false);
                req.setRequestHeader("OData-MaxVersion", "4.0");
                req.setRequestHeader("OData-Version", "4.0");
                req.setRequestHeader("Accept", "application/json");
                req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
                req.send();

                if (req.response != null && req.response != "") {
                    var result = JSON.parse(req.response);
                    // var results = JSON.parse(this.response);
                    try {
                        if (result != null) {
                            // if duplicate record exist with same mobile number
                            if (result.value.length > 0) {
                                var ber_mobilenumber = result.value[0]["ber_mobilenumber"];
                                var ber_type = result.value[0]["ber_type"];
                                var ber_type_formatted = result.value[0]["ber_type@OData.Community.Display.V1.FormattedValue"];
                                var statecode = result.value[0]["statecode"];
                                var statecode_formatted = result.value[0]["statecode@OData.Community.Display.V1.FormattedValue"];
                                alert("A record with same mobile number already exist");
                                executionObj.getEventArgs().preventDefault();
                                //   set all the pre-filled attributes null
                                Xrm.Page.getAttribute("ber_originator").setValue(null);
                                Xrm.Page.getAttribute("ber_originator").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_name").setValue(null);
                                Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_depot").setValue(null);
                                Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_mobilenumber").setValue(null);
                                Xrm.Page.getAttribute("ber_mobilenumber").setSubmitMode("always");
                                Xrm.Page.getAttribute("ber_type").setValue(null);
                                Xrm.Page.getAttribute("ber_type").setSubmitMode("always");
                            }

                        }
                    }

                    catch (err) {

                        alert("Please communicate system administrator in HO for error: " + err);

                    }
                }

            }
        }

    }
}




function OnSaveValidation(executionObj) {
    // Note: Form type codes: Create (1), Update (2), Read Only (3), Disabled (4), Bulk Edit (6)
    var FormType = Xrm.Page.ui.getFormType();
    //  if (FormType == 1) {
    var Asian = Xrm.Page.getAttribute("ber_asianpoints").getValue();
    var Nerolac = Xrm.Page.getAttribute("ber_nerolacpoints").getValue();
    var ICI = Xrm.Page.getAttribute("ber_icipoints").getValue();
    var Other = Xrm.Page.getAttribute("ber_otherpoints").getValue();
    if (Asian == null && Nerolac == null && ICI == null && Other == null) {
        executionObj.getEventArgs().preventDefault();
        alert("Unable to save because neither of the TY points have been inserted. Please enter atleast one TY Points");
        Xrm.Page.ui.controls.get("ber_asianpoints").setFocus();
        // event.preventDefault();
        //   }
    }
}