function load() {
    Xrm.Page.getAttribute("ber_mobilephone").setSubmitMode("Always");
    Xrm.Page.getControl("ber_mobilephone").setDisabled(true);

}



function ShowNewPainter(showDataValue, HideDataValue) {
    if (Xrm.Page.getAttribute("ber_adhocpainter")) {

        if (Xrm.Page.getAttribute("ber_adhocpainter").getValue()) {
            if (showDataValue != "") {
                var vals = new Array();
                vals = decodeURIComponent(showDataValue).split(",");
                for (var i = 0; i < vals.length; i++) {
                    Xrm.Page.getAttribute(vals[i]).setRequiredLevel("required");
                }
            }

            if (HideDataValue != "") {
                var Hidevals = new Array();
                Hidevals = decodeURIComponent(HideDataValue).split(",");
                for (var i = 0; i < Hidevals.length; i++) {
                    Xrm.Page.getAttribute(Hidevals[i]).setRequiredLevel("none");
                }
            }
            Xrm.Page.ui.tabs.get("general").sections.get("Address").setVisible(true);
        }
        else {
            Xrm.Page.ui.tabs.get("general").sections.get("Address").setVisible(true);
        }
    }
}

function setEnable(DataValue) {
    if (DataValue != "") {
        var vals = new Array();
        vals = decodeURIComponent(DataValue).split(",");
        for (var i = 0; i < vals.length; i++) {
            Xrm.Page.getControl(vals[i]).setDisabled(false);
        }
    }

}


//----------------------------------------------------------------------------------------------------------------------


function findCity() {

    var Pincode = Xrm.Page.getAttribute("ber_pincode").getValue();
    if (Pincode != null) {
        //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
        var serverUrl = window.location.protocol + "//" + window.location.host;
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_pincodeSet?$filter=ber_name eq '" + Pincode[0].name + "'"
            + "&$select=ber_CityId";

        var retrieveRecordsReq = new XMLHttpRequest();
        var ODataPath = odataSelect;
        retrieveRecordsReq.open('GET', ODataPath, false);
        retrieveRecordsReq.setRequestHeader("Accept", "application/json");
        retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        retrieveRecordsReq.send(null);
        var data = JSON.parse(retrieveRecordsReq.responseText).d;

        if (data.results.length > 0) {
            //var tokenTypeValue = GetTokenType(data.results[0].ber_CityID.Id);
            Xrm.Page.getAttribute("ber_city").setValue([{ id: data.results[0].ber_CityId.Id, name: data.results[0].ber_CityId.Name, entityType: 'ber_city' }]);
            findDepo(data.results[0].ber_CityId.Id);
        }
    }
    else {
        Xrm.Page.getAttribute("ber_city").setValue(null);
        Xrm.Page.getAttribute("ber_state").setValue(null);
        Xrm.Page.getAttribute("ber_depot").setValue(null);
        Xrm.Page.getAttribute("ownerid").setValue(null);
    }
}

function GetDepoFromCity() {
    var city = Xrm.Page.getAttribute("ber_city").getValue();
    if (city != null) {
        findDepo(city[0].id);
    }
    else {
        Xrm.Page.getAttribute("ber_state").setValue(null);
        Xrm.Page.getAttribute("ber_depot").setValue(null);
        Xrm.Page.getAttribute("ownerid").setValue(null);
    }
}

function findDepo(cityID) {

    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_citySet?$filter=ber_cityId eq(guid'" + cityID + "')"
     + "&$select=ber_DefaultDepotId,ber_StateId";

    var retrieveRecordsReq = new XMLHttpRequest();
    var ODataPath = odataSelect;
    retrieveRecordsReq.open('GET', ODataPath, false);
    retrieveRecordsReq.setRequestHeader("Accept", "application/json");
    retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    retrieveRecordsReq.send(null);
    var data = JSON.parse(retrieveRecordsReq.responseText).d;

    if (data.results.length > 0) {
        //var tokenTypeValue = GetTokenType(data.results[0].ber_DefaultDepotId.Id);
        Xrm.Page.getAttribute("ber_depot").setValue([{ id: data.results[0].ber_DefaultDepotId.Id, name: data.results[0].ber_DefaultDepotId.Name, entityType: 'ber_depot' }]);
        if (data.results[0].ber_StateId)
            Xrm.Page.getAttribute("ber_state").setValue([{ id: data.results[0].ber_StateId.Id, name: data.results[0].ber_StateId.Name, entityType: 'ber_state' }]);
        // setOwner(data.results[0].ber_DefaultDepotId.Id);
    }


}

function setOwner(depoID) {

    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_depotSet?$filter=ber_depotId eq(guid'" + depoID + "')"
     + "&$select=OwnerId";

    var retrieveRecordsReq = new XMLHttpRequest();
    var ODataPath = odataSelect;
    retrieveRecordsReq.open('GET', ODataPath, false);
    retrieveRecordsReq.setRequestHeader("Accept", "application/json");
    retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    retrieveRecordsReq.send(null);
    var data = JSON.parse(retrieveRecordsReq.responseText).d;

    if (data.results.length > 0) {
        //var tokenTypeValue = GetTokenType(data.results[0].OwnerId.Id);
        Xrm.Page.getAttribute("ownerid").setValue([{ id: data.results[0].OwnerId.Id, name: data.results[0].OwnerId.Name, entityType: 'systemuser' }]);
    }



}

//-------------------------------------------------------------------------------
function GetTokenType(tokenTypeId) {
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_tokentypemasterSet?$filter=ber_tokentypemasterId eq(guid'" + tokenTypeId + "')"
        + "&$select=ber_CustomerType";
    var retrieveRecordsReq = new XMLHttpRequest();
    var ODataPath = odataSelect;
    retrieveRecordsReq.open('GET', ODataPath, false);
    retrieveRecordsReq.setRequestHeader("Accept", "application/json");
    retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    retrieveRecordsReq.send(null);
    var data = JSON.parse(retrieveRecordsReq.responseText).d;
    if (data.results.length > 0) {
        return data.results[0].ber_CustomerType.Value;
    }
    else {
        alert("Invalid token number");
        Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_token").setValue(null);
        return null;
    }
}



function CheckToken() {

    var tokenkey = Xrm.Page.getAttribute("ber_tokennumbertext").getValue();
    if (tokenkey != null) {
        //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
        var serverUrl = window.location.protocol + "//" + window.location.host;
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_tokenmasterSet?$filter=ber_TokenKeyNo eq '" + tokenkey + "'"
            + "&$select=ber_product,ber_tokenmasterId,statuscode,ber_TokenType,ber_ExpireDate";

        var retrieveRecordsReq = new XMLHttpRequest();
        var ODataPath = odataSelect;
        retrieveRecordsReq.open('GET', ODataPath, false);
        retrieveRecordsReq.setRequestHeader("Accept", "application/json");
        retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        retrieveRecordsReq.send(null);
        var data = JSON.parse(retrieveRecordsReq.responseText).d;

        if (data.results.length > 0) {
            var tokenTypeValue = GetTokenType(data.results[0].ber_TokenType.Id);

            if (tokenTypeValue == null) {
                alert("Invalid token number");
                Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_tokennumber").setValue(null);
                return;
            }


            if (tokenTypeValue != 2) {
                alert("Invalid token number, Token type is for Dealer");
                Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_tokennumber").setValue(null);
                return;
            }


            if (data.results[0].statuscode.Value != 1) {
                alert("Token is already consumed");
                Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_tokennumber").setValue(null);
            }
            var expireDate = new Date(parseInt(data.results[0].ber_ExpireDate.substr(6)));
            if (expireDate > new Date()) {
                Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_tokennumber").setValue([{ id: data.results[0].ber_tokenmasterId, name: data.results[0].ber_product, entityType: 'ber_tokenmaster' }]);
            }
            else {
                alert("Token is already Expired");
                Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_tokennumber").setValue(null);
            }
        }
        else {
            alert("Invalid token number");
            Xrm.Page.getAttribute("ber_tokennumber").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_tokennumber").setValue(null);
        }
    }
}


function setDepotOnDealer() {
    //debugger;
    var dealer = null;
    dealer = Xrm.Page.getAttribute("ber_dealer");
    if (dealer != null && dealer.getValue() != null) {
        var DealerGUID = dealer.getValue()[0].id.replace("{", "").replace("}", "");
        /*
            var columns = ['ber_DepotId'];
            var dealerEntity = CrmRestKit.Retrieve('Account', DealerGUID, columns);
        */
        var dealerEntity;
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts?$select=_ber_depotid_value&$filter=accountid eq " + DealerGUID,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: false,
            success: function (data, textStatus, xhr) {
                dealerEntity = data;
                for (var i = 0; i < dealerEntity.value.length; i++) {
                    var _ber_depotid_value = dealerEntity.value[i]["_ber_depotid_value"];
                    var _ber_depotid_value_formatted = dealerEntity.value[i]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                    var _ber_depotid_value_lookuplogicalname = dealerEntity.value[i]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });

        if (dealerEntity != null && dealerEntity.value != null && dealerEntity.value.length > 0) {
            var DepotEntity = new Array();
            DepotEntity[0] = new Object();

            //DepotEntity[0].id = dealerEntity.ber_DepotId.Id;
            //DepotEntity[0].name = dealerEntity.ber_DepotId.Name;
            //DepotEntity[0].entityType = dealerEntity.ber_DepotId.LogicalName;

            DepotEntity[0].id = dealerEntity.value[0]["_ber_depotid_value"];
            DepotEntity[0].name = dealerEntity.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
            DepotEntity[0].entityType = dealerEntity.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

            Xrm.Page.getAttribute("ber_depot").setValue(DepotEntity);
        }
    }
    else
        Xrm.Page.getAttribute("ber_depot").setValue(null);
}



//-------------------------------------------------------------------------------


function disableFormFields(onOff) {
    Xrm.Page.data.entity.attributes.forEach(function (attribute, index) {
        var control = Xrm.Page.getControl(attribute.getName());
        if (control) {
            control.setDisabled(onOff)
        }
    });
}
//-------------------------------------------------------------------------------------------


//Disable form

function DisableForm() {
    if (Xrm.Page.ui.getFormType() != 1) {

        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = GetRoleName(userRoleId);
            if (userRoleName == "System Administrator") {
                disableFormFields(false);
                return true;
            }
        }
        disableFormFields(true);
    }
    Xrm.Page.getControl("ber_tokennumber").setDisabled(true);

}


//Get Rolename based on RoleId
function GetRoleName(roleId) {
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var serverUrl = window.location.protocol + "//" + window.location.host;
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
    var roleName = null;
    $.ajax(
        {
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                roleName = data.d.results[0].Name;
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
        }
    );
    return roleName;
}

//------------------------------------------------------------------------------------------------------------------