// JScript source code
function ConvertToButton(fieldname, buttontext, buttonwidth, clickevent, title) {

    //check if object exists; else return
    if (document.getElementById(fieldname) == null) {
        return;
    }


    functiontocall = clickevent;
    crmForm.all[fieldname].DataValue = buttontext;
    crmForm.all[fieldname].readOnly = true;
    crmForm.all[fieldname].style.borderRight = "#3366cc 1px solid";
    crmForm.all[fieldname].style.paddingRight = "5px";
    crmForm.all[fieldname].style.borderTop = "#3366cc 1px solid";
    crmForm.all[fieldname].style.paddingLeft = "5px";
    crmForm.all[fieldname].style.fontSize = "11px";
    crmForm.all[fieldname].style.backgroundImage = "url(/_imgs/btn_rest.gif)";
    crmForm.all[fieldname].style.borderLeft = "#3366cc 1px solid";
    crmForm.all[fieldname].style.width = buttonwidth;
    crmForm.all[fieldname].style.cursor = "hand";
    crmForm.all[fieldname].style.lineHeight = "18px";
    crmForm.all[fieldname].style.borderBottom = "#3366cc 1px solid";
    crmForm.all[fieldname].style.backgroundRepeat = "repeat-x";
    crmForm.all[fieldname].style.fontFamily = "Tahoma";
    crmForm.all[fieldname].style.height = "20px";
    crmForm.all[fieldname].style.backgroundColor = "#cee7ff";
    crmForm.all[fieldname].style.textAlign = "center";
    crmForm.all[fieldname].style.overflow = "hidden";
    crmForm.all[fieldname].attachEvent("onmousedown", push_button);
    crmForm.all[fieldname].attachEvent("onmouseup", release_button);
    crmForm.all[fieldname].attachEvent("onclick", functiontocall);
    crmForm.all[fieldname].style.lineHeight = "14px";
    crmForm.all[fieldname + '_c'].style.visibility = 'hidden';
    crmForm.all[fieldname].title = title;
    // window.focus();


    function push_button() {
        window.event.srcElement.style.borderWidth = "2px";
        window.event.srcElement.style.borderStyle = "groove ridge ridge groove";
        window.event.srcElement.style.borderColor = "#3366cc #4080f0 #4080f0 #3366cc";
    }

    function release_button() {
        window.event.srcElement.style.border = "1px solid #3366cc";
    }
}



// now the definition of the function to call on button click

function FunctionName() {

    //Xrm.Page.data.entity.save('saveandnew');
    Xrm.Page.data.entity.save('save');

    //window.location.reload(true);
    //window.parent.location.reload(true);
    //alert(parent.parent.window.location.href);

    parent.parent.window.location.reload(true);
}




function hideribbonbar() {

    if (parent.parent.window.document.forms[0] != null) {
        parent.document.getElementById("crmTopBar").style.display="none";
        document.getElementById("crmNavBar").parentElement.style.display = "none";  //hiding left side nav
        document.getElementById("tdAreas").parentElement.parentElement.parentElement.parentElement.colSpan = 2;
        document.getElementById("recordSetToolBar").parentElement.style.display = "none";  //Hiding tool bar
        document.getElementById("crmFormFooter").parentElement.style.display = "none";

        ConvertToButton('ber_buttonfield', 'Save And New', '100px', FunctionName, 'Button Label');


        parent.parent.window.focus();
       parent.parent.window.document.forms["crmForm"].elements["ber_dealerid"].disabled = true;

    }
}





function populateNameField() {
    var ProductType = Xrm.Page.getAttribute("ber_producttype").getValue();
    if (ProductType == 278290000 ) { 
        Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_homepaintingproductid").getValue()[0].name + '\\' + Xrm.Page.getAttribute("ber_shadecardid").getValue()[0].name + '\\' + Xrm.Page.getAttribute("ber_shadecodeid").getValue()[0].name);
    }
   else if(ProductType == 278290001 || ProductType == 278290002)
  {
           Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_homepaintingproductid").getValue()[0].name);
   }
    else {
        if (Xrm.Page.getAttribute("ber_uom").getValue() == 278290000)
            Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_product").getValue() + '\\' + Xrm.Page.getAttribute("ber_quantity").getValue() + ' Ltr');
        else if (Xrm.Page.getAttribute("ber_uom").getValue() == 278290001)
            Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_product").getValue() + '\\' + Xrm.Page.getAttribute("ber_quantity").getValue() + ' Kg');
        else if (Xrm.Page.getAttribute("ber_uom").getValue() == 278290002)
            Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_product").getValue() + '\\' + Xrm.Page.getAttribute("ber_quantity").getValue() + ' PC');
    }

    Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
}


///Product Type OnChange
function ProductTypeOnChange() {
    if (Xrm.Page.getAttribute("ber_producttype") != null && Xrm.Page.getAttribute("ber_producttype").getValue() != null) {
        var ProductType = Xrm.Page.getAttribute("ber_producttype").getValue();
        if (ProductType == 278290000) {
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section1").setVisible(false);
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section2").setVisible(true);
                        
            Xrm.Page.getControl("ber_shadecardid").setDisabled(false);
            Xrm.Page.getControl("ber_shadecodeid").setDisabled(false);

            Xrm.Page.getAttribute("ber_homepaintingproductid").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_shadecardid").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_shadecodeid").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_product").setRequiredLevel("none");
        }
        else if (ProductType == 278290001 || ProductType == 278290002) {
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section1").setVisible(false);
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section2").setVisible(true);

            Xrm.Page.getAttribute("ber_homepaintingproductid").setRequiredLevel("required");
            Xrm.Page.getControl("ber_homepaintingproductid").setVisible(true);

            Xrm.Page.getAttribute("ber_shadecardid").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_shadecodeid").setRequiredLevel("none");
        
            Xrm.Page.getControl("ber_shadecardid").setDisabled(true);
            Xrm.Page.getControl("ber_shadecodeid").setDisabled(true); 
        }
        else if (ProductType == 278290003) {
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section2").setVisible(false);
            Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section1").setVisible(true);
            Xrm.Page.getAttribute("ber_homepaintingproductid").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_shadecardid").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_shadecodeid").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_product").setRequiredLevel("required");
        }
    }
    else {
        Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section1").setVisible(false);
        Xrm.Page.ui.tabs.get("Tab_General").sections.get("General_Section2").setVisible(false);
        Xrm.Page.getAttribute("ber_homepaintingproductid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_shadecardid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_shadecodeid").setRequiredLevel("none");
        Xrm.Page.getAttribute("ber_product").setRequiredLevel("none");
    }
}

function FilterProducts() {

 var Product = Xrm.Page.getAttribute("ber_producttype");
 if (Product != null) {
     var ProductType = Xrm.Page.getAttribute("ber_producttype").getValue();

     //Filter lookup for Products based on Product Type
     var viewId = "{1DFB2B35-B07C-44D1-868D-258DEEAB88E2}";
     var entityName = "ber_homepaintingproducts";

     var viewDisplayName = "";
     if (ProductType == "278290000")
         viewDisplayName = "Paint Products";
     else if (ProductType == "278290001")
         viewDisplayName = "Primer Products";
     else if (ProductType == "278290002")
         viewDisplayName = "Putty Products";



     var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                                           "<entity name='ber_homepaintingproducts'>" +
                                           "<attribute name='ber_homepaintingproductsid'/>" +
                                           "<attribute name='ber_name'/>" +
                                           "<order attribute='ber_name' descending='false'/>" +
                                           "<filter type='and'>" +
                                           "<condition attribute='ber_producttype' operator='eq' value='" + ProductType + "'/>" +
                                           "</filter>" +
                                           "</entity>" +
                                           "</fetch>";

     var layoutXml = "<grid name='resultset' object='10036' jump='ber_name' select='1' icon='1' preview='1'>" +
                                            "<row name='result' id='ber_homepaintingproductsid'>" +
                                            "<cell name='ber_productcode' width='100' />" +
                                            "<cell name='ber_name' width='300' />" +
                                            "<cell name='ber_primer' width='100' />" +
                                            "</row>" +
                                            "</grid>";

     document.getElementById("ber_homepaintingproductid").setAttribute("lookuptypes", "10036");
     Xrm.Page.getControl("ber_homepaintingproductid").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);
     Xrm.Page.getControl("ber_homepaintingproductid").setDefaultView(viewId);     
 }
}

                            

                       
                            