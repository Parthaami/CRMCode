function CheckManditoryPresent() {
    if (Xrm.Page.getAttribute("ber_associatedtsiid") != null && Xrm.Page.getAttribute("ber_associatedtsiid").getValue() == null) {
        alert("You must provide a value for Associated Tsi.");
        event.returnValue = false;
    }
}