function SaveReadOnlyFields() {

    if (Xrm.Page.getAttribute("ber_depositiondate").getValue() != null && Xrm.Page.getAttribute("ber_collectiondate").getValue() != null && Xrm.Page.getAttribute("ber_amount").getValue() != null && Xrm.Page.getAttribute("ber_clearancedate").getValue() != null) {
    Xrm.Page.getAttribute("ber_depositiondate").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_collectiondate").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_amount").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_clearancedate").setSubmitMode("always");

   // Xrm.Page.getAttribute("ber_bank_credit").setSubmitMode("always");
   // Xrm.Page.getAttribute("ber_creditamount").setSubmitMode("always");
   // Xrm.Page.getAttribute("ber_creditcardnumber").setSubmitMode("always");
}

}

function populateNameField() {

    if (Xrm.Page.getAttribute("ber_bank").getValue() != null && Xrm.Page.getAttribute("ber_amount").getValue() != null) {
    Xrm.Page.getAttribute("ber_name").setValue(Xrm.Page.getAttribute("ber_bank").getValue().toString() + '\\' + Xrm.Page.getAttribute("ber_amount").getValue().toString());
    Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
    }
}