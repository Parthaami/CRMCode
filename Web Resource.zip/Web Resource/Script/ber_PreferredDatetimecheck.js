function PrefferedDateTime1() {
           if (UserHasRole("Call Center User")) {
            Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("none");
            Xrm.Page.ui.controls.get("ber_preferreddatetime").setDisabled(true);

        }
        else {
            Xrm.Page.getAttribute("ber_preferreddatetime").setRequiredLevel("required");
        }

 
}