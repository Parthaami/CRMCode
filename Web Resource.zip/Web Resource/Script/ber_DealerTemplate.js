function DealerTemplate() {

    if (Xrm.Page.getAttribute("pcl_srtypeid") != undefined && Xrm.Page.getAttribute("pcl_srtypeid").getValue() != null && Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name == 'Dealer - General') {

        // To get the elkad details

        var SRType = Xrm.Page.getAttribute("pcl_srtypeid").getValue();
        //  var Dealer = Xrm.Page.getAttribute("ber_dealer").getValue();
        //    var Dealerid = Dealer[0].id;
        var SRtypename = Xrm.Page.getAttribute("pcl_srtypeid").getValue()[0].name;

        if (SRtypename != null && SRtypename != undefined) {
            if (SRtypename == 'Dealer - General') {
                // Xrm.Page.getAttribute("description").setValue("Caller Name :  " + "\r\n" + "Lead Creation Date :  " + "\r\n" + "Customer Name :  " + "\r\n" + "Customer Contact Number :  " + "\r\n" "Customer Calling Number :  "\r\n"  +  " + Depot + "\r\n" + "Customer Complaint :  " + "\r\n" + "Painter Name :  " + "\r\n" + "Painter Mobile number :  " + "\r\n" + "CE Name :  " + CE + "\r\n" + "CE Contact Number :  " + phoneDG + "\r\n" + "TSI :  " + "\r\n" + "TSI Mobile Number :  " + "\r\n");
                Xrm.Page.getAttribute("description").setValue("Caller Name : " + "\r\n" + "Contact Number:" + "\r\n" + "Alt Contact Number: " + "\r\n" + "Pin Code : " + "\r\n" + "T Number (yes/no): If Yes - Capture the GST No: " + "\r\n" + "Shop Name : If GST Number is Yes - Capture the shop Name: " + "\r\n" + "Address : If GST Number is Yes - Capture shop address: " + "\r\n" + "Address : If GST Number is No - Capture home address: " + "\r\n" + "E-mail ID  : " + "\r\n" + "Currently dealer for which segments (Paints/Hardware/Sanitaryware/Pipes&Fittings/Other) - if other, capture the segment: " + "\r\n" + "Currently Dealing with which brands in Paints : If Yes for Paints: " + "\r\n" + "Currently Dealing with which brands in Hardware : If Yes for Hardware: " + "\r\n" + "Currently Dealing with which brands in Sanitaryware : If Yes for Sanitaryware " + "\r\n" + "Currently Dealing with which brands in Pipes & Fittings: If Yes for Pipes & Fittings: " + "\r\n" + "Shop Sales Value per month in Rs Lakh: " + "\r\n" + "Target Date/ month for opening paints dealing with Berger: " + "\r\n" + "Currently Dealing with which brands in 'Other' : If Yes for 'Other': ");




                Xrm.Page.getAttribute("description").setSubmitMode("always");
            }
        }
    }
}