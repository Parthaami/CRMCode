/// <reference path="XrmPageTemplate.js" />
//Show Shop Name when dealer type is subdealer/UT subdealer
function DealerTypeOnchange()
{
    var dealertype = Xrm.Page.getAttribute("ber_dealertype").getValue();
    if (dealertype != null)
    {
        if (dealertype == 278290003 || dealertype == 278290005)
        {
            Xrm.Page.getAttribute("ber_shopname").setRequiredLevel('required');
            return;
        }
    }
    Xrm.Page.getAttribute("ber_shopname").setRequiredLevel('none');
}

function GetRequestObject() {
    if (window.XMLHttpRequest) {
        return new window.XMLHttpRequest;
    }
    else {
        try {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex) {
            return null;
        }
    }
};


function AutoPopulateDepot()
{
    var Dealer = Xrm.Page.getAttribute("ber_dealerid");
    var DealerValue, DealerId;
    var Cols = ['*'];

    if (Dealer != null)
    {
        DealerValue = Dealer.getValue();

        if (DealerValue != null)
        {
            DealerId = DealerValue[0].id;
            var Depot = CrmRestKit.Retrieve('Account', DealerId, Cols);

            if (Depot != null)
            {
                if (Depot.ber_DepotId != null)
                {
                    var DepotLookup = new Array();
                    DepotLookup[0] = new Object();
                    DepotLookup[0].id = Depot.ber_DepotId.Id;
                    DepotLookup[0].name = Depot.ber_DepotId.Name;
                    DepotLookup[0].entityType = Depot.ber_DepotId.LogicalName;

                    Xrm.Page.getAttribute("ber_depot").setValue(DepotLookup);
                    return;
                }
            }
        }
    }
    Xrm.Page.getAttribute("ber_depot").setValue(null);
}

function fnOnFormSave()
{
    onchangeadvancedamount();
    Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_bookingstatus").setSubmitMode("always");
    Xrm.Page.getAttribute("ber_totalcostofmachine").setSubmitMode("always");
    var dealertype = Xrm.Page.getAttribute("ber_dealertype").getValue();

    var DispenserChecked = Xrm.Page.getAttribute("ber_dispenser").getValue();

    if (!DispenserChecked)
    {
        Xrm.Page.getAttribute("ber_brand").setValue(null);
        Xrm.Page.getAttribute("ber_autosemiauto").setValue(null);
    }

}

function LoadMain()
{
    var bookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();

    //Hide Stock Stransfer Left Navigation till Status is not Booked
    if (bookingStatus < 4)
    {
        document.getElementById('nav_ber_ber_installationrequest_ber_stocktransfer').style.display = 'none';
    }
    //Disable Machine Detail Section after staus is Booked
    if (bookingStatus >= 4)
    {
        var ctrl = Xrm.Page.getControl("ber_dispenser");
        if (ctrl != null)
        {
            var section = ctrl.getParent();
            Xrm.Page.ui.controls.forEach(function (control, index)
            {
                if (control.getParent() === section)
                {
                    control.setDisabled(true);
                }
            }); 
        }
    }
    else
    {
       onDispenderSelectChange();
    }

    ApplyUserAccess();
     LoadBookingItemGrid();
     DealerTypeOnchange();
    Xrm.Page.getAttribute("ber_advancedamountold").setValue(Xrm.Page.getAttribute("ber_advancedamount").getValue());
}

function ApplyUserAccess()
{
       var BookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();

//     Depot Color Bank
//     RDC ColorBank User
//     HO Color Bank

      if (UserHasRole('RDC ColorBank User')) 
     {
        DisableForm();
        return;
    }

    if (BookingStatus > 0) 
    {
        if (UserHasRole('Depot Color Bank')) 
        {
            DisableForm();
            return;
        }

    }
}

function OnInstallationRequestLoad()
{
    /*window.parent.location = "http://192.168.1.109:5555/BergerDev/_forms/print/print.aspx?allsubgridspages=false&formid=d089f338-36c1-4ff0-a653-6fee375b964e&id=%7b40E6EB5D-CC07-E211-8243-18A90548E1D3%7d&objectType=10022&title=Installation%20Request%3a%20WF%20Assignment%20Test%20-%20Microsoft%20Dynamics%20CRM";*/
}

//Hide Shop Board Required Section
function ShopBoardOnchange()
{
    var shopboard = Xrm.Page.getAttribute("ber_shopboardrequired").getValue();
    if (shopboard == 278290000)
    {
        Xrm.Page.ui.tabs.get("Tab_bookinginformation").sections.get("shop_board_section").setVisible(true);
    }
    else
    {
        Xrm.Page.ui.tabs.get("Tab_bookinginformation").sections.get("shop_board_section").setVisible(false);
    }
}


function LoadBookingItemGrid()
{
    var bookingStatus = Xrm.Page.getAttribute("ber_bookingstatus").getValue();

    if (bookingStatus == null || bookingStatus < 3)
    {
           document.getElementById('IFRAME_StockTransfer_d').parentElement.parentElement.style.display = 'none';
           return;
    }

    /////////// Load Booking Items Grid//////////////////
    var serverURL = window.location.protocol + "//" + window.location.host;
    var _orgName = Xrm.Page.context.getOrgUniqueName();

    if (Xrm.Page.ui.getFormType() != 1)
    {
        var context;
        var objectId;
        var orgName;
        //var userId;
        var hostName;
        var rdcId, dlrId, rdc, dlr;
        var RO = "";

        context = Xrm.Page.context;
        objectId = Xrm.Page.data.entity.getId();
        orgName = context.getOrgUniqueName();
        //userId = context.getUserId();
        hostName = window.location.hostname;

        objectId = objectId.replace("{", "");
        objectId = objectId.replace("}", "");

        //Read Only Grid if Status crossed Booked Status
        if (bookingStatus >= 4)
        {
            RO = "&RO=1";
        }

        var BookingItemGrid = serverURL + "/ISV/" + _orgName + "/ColorBank/BookingItems.aspx?Id=" + objectId + RO;

        if (document.all.IFRAME_StockTransfer != null)
        {
            document.all.IFRAME_StockTransfer.src = BookingItemGrid;
        }

    }
}

function onDispenderSelectChange()
{
    var DispenserChecked = Xrm.Page.getAttribute("ber_dispenser").getValue();

    if (DispenserChecked)
    {
        Xrm.Page.getControl("ber_autosemiauto").setDisabled(false);
        Xrm.Page.getControl("ber_brand").setDisabled(false);
        Xrm.Page.getAttribute("ber_brand").setRequiredLevel('required');
        Xrm.Page.getAttribute("ber_autosemiauto").setRequiredLevel('required');
    }
    else
    {
        Xrm.Page.getControl("ber_autosemiauto").setDisabled(true);
        Xrm.Page.getControl("ber_brand").setDisabled(true);
        Xrm.Page.getAttribute("ber_brand").setRequiredLevel('none');
        Xrm.Page.getAttribute("ber_autosemiauto").setRequiredLevel('none');
    }
}

function onchangeadvancedamount()
{
    var TotalValue = Xrm.Page.getAttribute("ber_totalcostofmachine").getValue() + Xrm.Page.getAttribute("ber_advancedamount").getValue() - Xrm.Page.getAttribute("ber_advancedamountold").getValue();
    Xrm.Page.getAttribute("ber_totalcostofmachine").setValue(TotalValue);
}

function onchangestate()
{

    if (Xrm.Page.getAttribute("ber_state").getValue() == null)
    {
        Xrm.Page.getControl("ber_city").setDisabled(true);
    }
    else
    {
        Xrm.Page.getControl("ber_city").setDisabled(false);
    }
    Xrm.Page.getAttribute("ber_city").setValue(null);
    Xrm.Page.getAttribute("ber_pincode").setValue(null);
    Xrm.Page.getControl("ber_pincode").setDisabled(true);
}

function onchangecity()
{
    if (Xrm.Page.getAttribute("ber_city").getValue() == null)
    {
        Xrm.Page.getControl("ber_pincode").setDisabled(true);
    }
    else
    {
        Xrm.Page.getControl("ber_pincode").setDisabled(false);
    }
    Xrm.Page.getAttribute("ber_pincode").setValue(null);
}

function citystate()
{
    if (Xrm.Page.getAttribute("ber_city").getValue() == null)
    {
        Xrm.Page.getControl("ber_city").setDisabled(true);
    }
    if (Xrm.Page.getAttribute("ber_pincode").getValue() == null)
    {
        Xrm.Page.getControl("ber_pincode").setDisabled(true);
    }
}