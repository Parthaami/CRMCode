// Carpenter filtered list



function filterCarpenterDefaultDepot() {
    if (Xrm.Page.getAttribute("ber_depot").getValue() != null && Xrm.Page.getAttribute("ber_depot").getValue() != undefined) {
        var _depotId = (Xrm.Page.getAttribute("ber_depot").getValue())[0].id;
        if (Xrm.Page.getAttribute("ber_otherpaintertype") != null && Xrm.Page.getAttribute("ber_otherpaintertype") != undefined) {
            var OtherPainterType = Xrm.Page.getAttribute("ber_otherpaintertype").getValue();
            var view_PaintersByDepotDisplayname = "Filtered Painter list";
            // var view_PaintersByDepotId = GetuniqueGuid();
            var view_PaintersByDepotId = "{a76b2c46-c28e-4e5e-9ddf-951b71202c9d}";
            var IsDefaultView = true;

            layoutxml_PaintersByDepot = '<grid name="resultset" object="1" jump="fullname" select="1" icon="1" preview="1">' +
                    '<row name="result" id="contactid">' +
                    '<cell name="fullname" width="100" />' +
                    '<cell name="ber_exteriorpainterrating" width="100" />' +
                    '<cell name="ber_corepainterscp" width="100" />' +
                    '<cell name="ber_paintertype" width="100" />' +
                    '<cell name="ber_epstatus" width="100" />' +
                    '<cell name="ber_painterrating" width="100" />' +
                    '<cell name="ber_havesander" width="100" />' +
                    '<cell name="ber_dealerid" width="100" />' +
                    '<cell name="ber_depotid" width="100" />' +
                    '<cell name="mobilephone" width="100" />' +
                    '<cell name="ber_preferredlanguage1" width="100" />' +
                    '<cell name="ber_preferredlanguage2" width="100" />' +
              '</row>' +
              '</grid>';

            fetchxml_PaintersByDepot = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">' +
                  '<entity name="contact">' +
                    '<attribute name="fullname" />' +
                    '<attribute name="contactid" />' +
                    '<attribute name="ber_corepainterscp" />' +
                    '<attribute name="ber_preferredlanguage2" />' +
                    '<attribute name="ber_preferredlanguage1" />' +
                    '<attribute name="ber_painterrating" />' +
                    '<attribute name="ber_paintertype" />' +
                     '<attribute name="ber_exteriorpainterrating" />' +
                    '<attribute name="ber_depotid" />' +
                    '<attribute name="ber_dealerid" />' +
                    '<attribute name="ber_epstatus" />' +
                    '<attribute name="mobilephone" />' +
                    '<attribute name="ber_havesander" />' +
                    '<order attribute="ber_corepainterscp" descending="false" />' +
                    '<filter type="and">' +
                    '<condition attribute="statecode" operator="eq" value="0" />' +
                      '<condition attribute="ber_customertype" operator="eq" value="278290001" />' +
                       '<condition attribute="ber_hotlistpainter" value="1" operator="ne"/>' +
                      '<condition attribute="ber_epstatus" operator="in">' +
                        '<value>278290003</value>' +
                        '<value>278290000</value>' +
                      '</condition>' +
                      ' <condition attribute="ber_havesander" operator="eq" value="1" />' +
                       '<condition attribute="ber_paintertype" operator="eq" value="' + OtherPainterType + '" />' +
                      '<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="' + _depotId + '" />' +
                    '</filter>' +
                  '</entity>' +
                '</fetch>';
            Xrm.Page.getControl("ber_otherpainterassignment").addCustomView(view_PaintersByDepotId, "contact", view_PaintersByDepotDisplayname, fetchxml_PaintersByDepot, layoutxml_PaintersByDepot, IsDefaultView);
            Xrm.Page.getControl("ber_otherpainterassignment").setDefaultView(view_PaintersByDepotId);
            document.getElementById("ber_otherpainterassignment").disableViewPicker = 1;


        }
    }



}

function onloaddisablefields() {
    var FormType = Xrm.Page.ui.getFormType();
    if (FormType == 2) {

        Xrm.Page.ui.controls.get("ber_otherpaintertype").setDisabled(true);

    }

    else if (FormType == 1) {

        Xrm.Page.ui.controls.get("ber_otherpaintertype").setDisabled(false);
        Xrm.Page.ui.controls.get("ber_otherpainterassignment").setDisabled(true);
    }
}


function SetDisableOtherPainterType() {

    if (Xrm.Page.getAttribute("ber_otherpaintertype").getValue() != null && Xrm.Page.getAttribute("ber_otherpaintertype") != undefined) {

        Xrm.Page.ui.controls.get("ber_otherpainterassignment").setDisabled(false);

    }
}

function SetOtherPainterNull() {

    if (Xrm.Page.getAttribute("ber_otherpaintertype").getValue() != null && Xrm.Page.getAttribute("ber_otherpaintertype") != undefined) {

       // Xrm.Page.ui.controls.get("ber_carpenter").setDisabled(false);

        Xrm.Page.getAttribute("ber_otherpainterassignment").setValue(null);
        Xrm.Page.getAttribute("ber_otherpainterallocationdate").setValue(null);

        Xrm.Page.getAttribute("ber_otherpainterassignment").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_otherpainterallocationdate").setSubmitMode("always");
    }
}