function Apply_DealerLookupFilter() 
{
   // debugger;

	if(Xrm.Page.getAttribute("ber_meet").getValue() != null)
 {
    var meettypeid =new Array();
    meettypeid[0]=new Object();
    var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;
    var columns = ['ber_Type'];
    var filter = "ber_meetId eq (Guid'" + MeetId + "')";
    var collection = CrmRestKit.RetrieveMultiple('ber_meet', columns, filter);
     if (collection != null && collection.results != null && collection.results.length > 0) 
        {
         var PMType=collection.results[0].ber_Type.Value;   
   }
                     viewDisplayName = null;
                viewId = null;
                isDefaultView = true;
				fetchxml=null;
               layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">'
		+'<row name="result" id="accountid">'
		+'<cell name="accountnumber" width="100"/><cell name="name" width="125"/>'
		+'<cell name="customertypecode" width="100"/>'
		+'<cell name="ber_taxcategory" width="100"/>'
		+'<cell name="ber_depotid" width="100"/>'
		+'<cell name="territoryid" width="100"/>'
		+'<cell name="ber_associatedtsiid" width="100"/>'
		+'</row></grid>';
							
		if(PMType==278290001)//color bank
		  {
		     fetchxml='<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
					+ ' <entity name="account">'
					+  '  <attribute name="name" />'
					+   ' <attribute name="accountnumber" />'
					+    '<attribute name="customertypecode" />'
					+    '<attribute name="ber_taxcategory" />'
					+ '   <attribute name="ber_depotid" />'
					 +'   <attribute name="territoryid" />'
					 +'   <attribute name="ber_associatedtsiid" />'
					 +'   <attribute name="accountid" />'
					 +'   <order attribute="name" descending="false" />'
					 +'   <filter type="and">'
		 +'     <condition attribute="customertypecode" operator="eq" value="5" />'
		 +'     <condition attribute="statecode" operator="eq" value="0" />'
		 + '    <condition attribute="parentaccountid" operator="null" />'
		 +'     <condition attribute="ber_colorbank" operator="eq" value="1" />'
		
					 + '  </filter>    '
					 + '</entity>'
					+'</fetch>';
		  }
         else if(PMType==278290005)//gold silver
		  {
		       fetchxml='<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
						+'  <entity name="account">'
						 +'   <attribute name="name" />'
						  +'  <attribute name="accountnumber" />'
						  +'  <attribute name="customertypecode" />'
						 +'   <attribute name="ber_taxcategory" />'
						+'    <attribute name="ber_depotid" />'
						 +'   <attribute name="territoryid" />'
						  +'  <attribute name="ber_associatedtsiid" />'
			  +'  <attribute name="accountid" />'
			  +'  <order attribute="name" descending="false" />'
			 +'   <filter type="and">'
			  +'    <condition attribute="customertypecode" operator="eq" value="5" />'
			  +'    <condition attribute="statecode" operator="eq" value="0" />'
			  +'    <condition attribute="parentaccountid" operator="null" />'
			  +'    <condition attribute="accountcategorycode" operator="ne" value="278290002" />'

			  +'  </filter>  </entity></fetch>';
		  } 
		 
		  else //if(other)
		   {
		fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
		+'<entity name="account"><attribute name="name"/><attribute name="accountnumber"/>'
		+'<attribute name="customertypecode"/><attribute name="ber_taxcategory"/>'
		+'<attribute name="ber_depotid"/><attribute name="territoryid"/>'
		+'<attribute name="ber_associatedtsiid"/><attribute name="accountid"/>'
		+'<order attribute="name" descending="false"/>'
		+'<filter type="and">'
		+'<condition attribute="customertypecode" operator="eq" value="5"/>'
		+'<condition attribute="statecode" operator="eq" value="0"/>'
		+'<condition attribute="parentaccountid" operator="null"/>'
		+'<condition attribute="accountcategorycode" operator="eq" value="278290002"/>'

		+'</filter>'
		+'</entity></fetch>';
            }

            viewDisplayName = 'Related Dealer (Dealer-Meet Type Connection)';
            viewId = "{634B6CAC-03FB-4FB8-AA4C-6D566275BA11}"; //GetuniqueGuid();

            Xrm.Page.getControl('ber_dealer').addCustomView(viewId, 'account', viewDisplayName, fetchxml, layoutxml,   isDefaultView);
            Xrm.Page.getControl('ber_dealer').setDefaultView(viewId);

        }
    }


function GetuniqueGuid() 
{

    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };

    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';

};