//-----------------------------------------------------------------------------------
function GetTokenType(tokenTypeId) {
    var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_tokentypemasterSet?$filter=ber_tokentypemasterId eq(guid'" + tokenTypeId + "')"
        + "&$select=ber_CustomerType";
    var retrieveRecordsReq = new XMLHttpRequest();
    var ODataPath = odataSelect;
    retrieveRecordsReq.open('GET', ODataPath, false);
    retrieveRecordsReq.setRequestHeader("Accept", "application/json");
    retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    retrieveRecordsReq.send(null);
    var data = JSON.parse(retrieveRecordsReq.responseText).d;
    if (data.results.length > 0) {
        return data.results[0].ber_CustomerType.Value;
    }
    else {
        alert("Invalid token number");
        Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_token").setValue(null);
        return null;
    }
}



function CheckToken() {
    var tokenkey = Xrm.Page.getAttribute("ber_tokennumber").getValue();
    if (tokenkey != null) {
        var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ber_tokenmasterSet?$filter=ber_TokenKeyNo eq '" + tokenkey + "'"
            + "&$select=ber_product,ber_tokenmasterId,statuscode,ber_TokenType";

        var retrieveRecordsReq = new XMLHttpRequest();
        var ODataPath = odataSelect;
        retrieveRecordsReq.open('GET', ODataPath, false);
        retrieveRecordsReq.setRequestHeader("Accept", "application/json");
        retrieveRecordsReq.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        retrieveRecordsReq.send(null);
        var data = JSON.parse(retrieveRecordsReq.responseText).d;

        if (data.results.length > 0) {
            var tokenTypeValue = GetTokenType(data.results[0].ber_TokenType.Id);

            if (tokenTypeValue == null) {
                alert("Invalid token number");
                Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_token").setValue(null);
                return;
            }

            if (Xrm.Page.getAttribute("ber_dealer").getValue() != null) {
                if (tokenTypeValue != 1) {
                    alert("Invalid token number");
                    Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
                    Xrm.Page.getAttribute("ber_token").setValue(null);
                    return;
                }
            }
            else if (Xrm.Page.getAttribute("ber_painter").getValue() != null) {
                if (tokenTypeValue != 2) {

                    alert("Invalid token number");
                    Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
                    Xrm.Page.getAttribute("ber_token").setValue(null);
                    return;
                }
            }

            if (data.results[0].statuscode.Value != 1) {
                alert("Token is already consumed");
                Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_token").setValue(null);
            }
            else {
                Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
                Xrm.Page.getAttribute("ber_token").setValue([{ id: data.results[0].ber_tokenmasterId, name: data.results[0].ber_product, entityType: 'ber_tokenmaster' }]);
            }
        }
        else {
            alert("Invalid token number");
            Xrm.Page.getAttribute("ber_token").setSubmitMode("always");
            Xrm.Page.getAttribute("ber_token").setValue(null);
        }
    }
}
//-------------------------------------------------------------------------------




//-----------------------------------------------------------------------------------
function GetDealer() {
    if (Xrm.Page.getAttribute("ber_painter").getValue() != null) {
        var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
        var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "ContactSet?$filter=ContactId eq(guid'" + Xrm.Page.getAttribute("ber_painter").getValue()[0].id + "')"
            + "&$select=ber_DealerId";


        var roleName = null;
        $.ajax(
            {
                type: "GET",
                async: false,
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: odataSelect,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data, textStatus, XmlHttpRequest) {
                    Xrm.Page.getAttribute("ber_linkeddealer").setValue([{ id: data.d.results[0].ber_DealerId.Id, name: data.d.results[0].ber_DealerId.Name, entityType: 'account' }]);
                },
                error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
            }
        );
    }
}
//-------------------------------------------------------------------------------


function disableFormFields(onOff) {
    Xrm.Page.data.entity.attributes.forEach(function (attribute, index) {
        var control = Xrm.Page.getControl(attribute.getName());
        if (control) {
            control.setDisabled(onOff)
        }
    });
}
//-------------------------------------------------------------------------------------------


//Disable form

function DisableForm() {
    if (Xrm.Page.ui.getFormType() != 1 || Xrm.Page.getAttribute("ber_name").getValue() != null) {

        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = GetRoleName(userRoleId);
            if (userRoleName == "System Administrator") {
                disableFormFields(false);
                return true;
            }
        }
        disableFormFields(true);
    }
}

//Get Rolename based on RoleId
function GetRoleName(roleId) {
    var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$filter=RoleId eq guid'" + roleId + "'";
    var roleName = null;
    $.ajax(
        {
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                roleName = data.d.results[0].Name;
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
        }
    );
    return roleName;
}






//-----------------------------------------------------------------------------------------------------------------------------

function filterPainterMeetLookup() {

    if (Xrm.Page.getAttribute("ber_painter").getValue() != null && Xrm.Page.getAttribute("ber_painter").getValue() != undefined) {
        var contact = Xrm.Page.getAttribute("ber_painter").getValue();
        if (contact != null && contact != undefined && contact[0].id != null) {
            // Xrm.Page.getControl("ber_meetpainter").setDisabled(false);
            var contactId = contact[0].id;
            var contactType = contact[0].entityType;
            var viewDisplayName = null;
            var viewId = null;
            var isDefaultView = true;
            var layoutxml = '<grid name="resultset" object="10052" jump="ber_name" select="1" icon="1" preview="1">' +
                        '<row name="result" id="ber_paintermeetid">' +
                        '<cell name="ber_name" width="200"/>' +
                        '<cell name="ber_depot" width="150"/>' +
                        '<cell name="ab.ber_type" width="150" disableSorting="1"/>' +
                        '<cell name="createdon" width="100"/>' +
                        '</row></grid>';

            var today = new Date();
            var month = today.getMonth() + 1;
            var todaydate = today.getFullYear() + '-' + month + '-' + today.getDate();

            fetchxml =
                '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                '<entity name="ber_paintermeet">' +
                '<attribute name="ber_name" />' +
                '<attribute name="createdon" />' +
                '<attribute name="ber_depot" />' +
                '<attribute name="ber_dealer" />' +
                '<attribute name="ber_paintermeetid" />' +
                '<order attribute="ber_name" descending="false" />' +
                '<link-entity name="ber_paintermeetcontact" from="ber_paintermeet" to="ber_paintermeetid" alias="aa">' +
                '<filter type="and">' +
                '<condition attribute="statecode" operator="eq" value="0" />' +
                '<condition attribute="ber_contact" operator="eq" value="' + contact[0].id + '" />' +
                '</filter>' +
                '</link-entity>' +
                '<link-entity name="ber_meet" from="ber_meetid" to="ber_meet" alias="ab">' +
                '<attribute name="ber_type"/>' +
                '<filter type="and">' +
                '<condition attribute="ber_paintercall" operator="eq" value="1" />' +
                '<condition attribute="ber_schemerequired" operator="eq" value="1" />' +
                '<filter type="or">' +
                '<condition attribute="ber_finalpointcalculationdate" operator="gt" value="' + todaydate + '" />' +
                '<condition attribute="ber_finalpointcalculationdate" operator="null" />' +
                '</filter></filter>' +
                '</link-entity>' +
                '</entity>' +
                '</fetch>';

            viewDisplayName = 'Related PainterMeet (Contact-PainterMeet)';
            viewId = GetuniqueGuid();
            Xrm.Page.getControl('ber_paintermeet').addCustomView(viewId, 'ber_paintermeet', viewDisplayName, fetchxml, layoutxml, isDefaultView);
            // Xrm.Page.getControl('ber_meetpainter').setDefaultView(viewId);

        }
        else {
            //If painter is not selected disable painter meet lookup as well.
            //  Xrm.Page.getControl("ber_meetpainter'").setDisabled(true);
        }
    }
    else {
        //If painter is not selected disable painter meet lookup as well.
        // Xrm.Page.getControl("ber_meetpainter'").setDisabled(true);
    }
}


function filterDealerLookup() {
    //debugger;
    if (Xrm.Page.getAttribute("ber_paintermeet").getValue() != null && Xrm.Page.getAttribute("ber_paintermeet").getValue() != undefined) {
        var MeetPlanningLookup = Xrm.Page.getAttribute("ber_paintermeet").getValue();
        var meetPlanningColumns = ['ber_Depot'];
        var meetPlanningFilter = "ber_paintermeetId eq guid'" + MeetPlanningLookup[0].id + "'";
        var meetPlanningCollection = CrmRestKit.RetrieveMultiple('ber_paintermeet', meetPlanningColumns, meetPlanningFilter);
        if (meetPlanningCollection != null && meetPlanningCollection.results != null && meetPlanningCollection.results.length > 0) {
            if (meetPlanningCollection.results[0].ber_Depot != null && meetPlanningCollection.results[0].ber_Depot.Id != null) {
                var depotColumns = ['ber_CityId'];
                var depotFilter = "ber_depotId eq guid'" + meetPlanningCollection.results[0].ber_Depot.Id + "'";
                var depotCollection = CrmRestKit.RetrieveMultiple('ber_depot', depotColumns, depotFilter);
                if (depotCollection != null && depotCollection.results != null && depotCollection.results.length > 0) {
                    if (depotCollection.results[0].ber_CityId != null && depotCollection.results[0].ber_CityId.Id != null) {
                        var painterCityId = depotCollection.results[0].ber_CityId.Id;
                        viewDisplayName = null;
                        viewId = null;
                        isDefaultView = true;

                        layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">' +
                        '<row name="result" id="accountid">' +
					    '<cell name="name" width="200" />' +
                        '<cell name="accountnumber" width="100" />' +
						'<cell name="accountcategorycode" width="100" />' +
                        '<cell name="telephone1" width="100" />' +
                        '<cell name="customertypecode" width="100" />' +
                        '<cell name="ber_depotid" width="100" />' +
                        '<cell name="address1_city" width="100" />' +
					    '<cell name="address1_line2" width="150" />' +
                        '<cell name="address1_line3" width="150" />' +
                        '</row>' +
					    '</grid>';


                        fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">' +
                        '<entity name="account">' +
                        '<attribute name="name" />' +
                        '<attribute name="accountnumber" />' +
                        '<attribute name="telephone1" />' +
                        '<attribute name="customertypecode" />' +
						'<attribute name="accountcategorycode" />' +
                        '<attribute name="ber_depotid" />' +
                        '<attribute name="accountid" />' +
                        '<attribute name="address1_line2" />' +
                        '<attribute name="address1_line3" />' +
                        '<attribute name="address1_city" />' +
                        '<order attribute="name" descending="false" />' +
                        '<filter type="and">' +
                        '<condition attribute="parentaccountid" operator="null" />' +
                        '</filter>' +
                        '<filter type="and">' +
                        '<condition attribute="statecode" operator="eq" value="0"/>' +
                        '</filter>' +
						'<filter type="and">' +
                        '<condition attribute="accountclassificationcode" operator="eq" value="1"/>' +
                        '</filter>' +
						'<filter type="and">' +
							'<condition attribute="ber_mpdealer" operator="eq" value="1" />' +
						'</filter>' +
                        '<link-entity name="ber_depot" from="ber_depotid" to="ber_depotid" alias="d">' +
                        '<attribute name="ber_cityid" />' +
                        '<filter type="and">' +
                        '<condition attribute="ber_cityid" operator="eq" uitype="ber_city" value="' + painterCityId + '" />' +
                        '</filter>' +
                        '</link-entity>' +
                        '</entity>' +
                        '</fetch>';


                        viewDisplayName = 'Dealers';
                        viewId = GetuniqueGuid();

                        Xrm.Page.getControl('ber_linkeddealer').addCustomView(viewId, 'account', viewDisplayName, fetchxml, layoutxml, isDefaultView);
                        Xrm.Page.getControl('ber_linkeddealer').setDefaultView(viewId);
                        Xrm.Page.getControl("ber_linkeddealer").setDisabled(false);
                    }
                }
            }
        }
    }
    else {
        Xrm.Page.getControl("ber_linkeddealer").setDisabled(true);
    }
}



function GetuniqueGuid() {
    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };
    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';
};


function CheckType() {
    if (Xrm.Page.ui.getFormType() != 1 || Xrm.Page.getAttribute("ber_name").getValue() != null) {

        if (Xrm.Page.getAttribute("ber_dealer").getValue()) {
            Xrm.Page.ui.controls.get("ber_paintermeet").setVisible(false);
            Xrm.Page.ui.controls.get("ber_painter").setVisible(false);
            Xrm.Page.ui.controls.get("ber_linkeddealer").setVisible(false);
            Xrm.Page.ui.controls.get("ber_dealer").setVisible(true);
            Xrm.Page.ui.controls.get("ber_subpainter").setVisible(false);

        }
        else {
            Xrm.Page.ui.controls.get("ber_dealer").setVisible(false);
            Xrm.Page.ui.controls.get("ber_paintermeet").setVisible(true);
            Xrm.Page.ui.controls.get("ber_painter").setVisible(true);
            Xrm.Page.ui.controls.get("ber_linkeddealer").setVisible(true);
            Xrm.Page.ui.controls.get("ber_subpainter").setVisible(true);
        }
    }
    else
        Xrm.Page.getAttribute("ber_subpainter").setValue(null);


    if (Xrm.Page.getAttribute("ber_dealer").getValue()) {
        Xrm.Page.ui.controls.get("ber_paintermeet").setVisible(false);
        Xrm.Page.ui.controls.get("ber_painter").setVisible(false);
        Xrm.Page.ui.controls.get("ber_linkeddealer").setVisible(false);
        Xrm.Page.ui.controls.get("ber_dealer").setVisible(true);
        Xrm.Page.ui.controls.get("ber_subpainter").setVisible(false);
    }
}