function HideBudget() {
    if (Xrm.Page.getAttribute("ber_bdbudget") != undefined) {
        if (UserHasRole("Depot BD User") || UserHasRole("Depot Scheme Manager") || UserHasRole("Depot User") || UserHasRole("Depot Home Decor User")) {

            Xrm.Page.getControl("ber_bdbudget").setVisible(false);

        }

else if (UserHasRole("System Administrator")){

 Xrm.Page.getControl("ber_bdbudget").setVisible(true);

}

 else{
  Xrm.Page.getControl("ber_bdbudget").setVisible(false);

}

    }
}