function StockTransferOnChange() {
    var TransferType = Xrm.Page.getAttribute("ber_type").getValue();

    if (TransferType != null) {
        if (TransferType == 278290001) { // Transfer
            Xrm.Page.getAttribute("ber_from").setRequiredLevel("none");
            Xrm.Page.getControl("ber_from").setDisabled(true);

            Xrm.Page.getControl("ber_installationrequestid").setVisible(true);
            Xrm.Page.getControl("ber_schemeid").setVisible(true);
            Xrm.Page.getControl("ber_installationrequestid").setDisabled(false);
            Xrm.Page.getControl("ber_schemeid").setDisabled(false);

            var instReq = Xrm.Page.getAttribute("ber_installationrequestid").getValue();
            var Scheme = Xrm.Page.getAttribute("ber_schemeid").getValue();

            if (instReq != null) {
                Xrm.Page.getControl("ber_to").setDisabled(true);
                Xrm.Page.getAttribute("ber_to").setRequiredLevel("none");
                Xrm.Page.getControl("ber_schemeid").setDisabled(true);
            }
            else if (Scheme != null) {
                Xrm.Page.getControl("ber_to").setDisabled(false);
                Xrm.Page.getAttribute("ber_to").setRequiredLevel("required");

                Xrm.Page.getControl("ber_installationrequestid").setDisabled(true);
                Xrm.Page.getAttribute("ber_installationrequestid").setRequiredLevel("none");
            }
            else if(instReq == null && Scheme == null) 
            {
                Xrm.Page.getControl("ber_to").setDisabled(true);
                Xrm.Page.getAttribute("ber_to").setRequiredLevel("none"); 
             }

            Xrm.Page.getAttribute("ber_adjustmentreason").setValue(null);
            Xrm.Page.getControl("ber_adjustmentreason").setVisible(false);
            Xrm.Page.getAttribute("ber_adjustmentreason").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_purchaseorderid").setValue(null);
            Xrm.Page.getControl("ber_purchaseorderid").setVisible(false);
            Xrm.Page.getAttribute("ber_parentstocktransfer").setValue(null);
            Xrm.Page.getControl("ber_parentstocktransfer").setVisible(false);

        }
        else if (TransferType == 278290000) {//Adjustment

            Xrm.Page.getAttribute("ber_from").setRequiredLevel("none");
            Xrm.Page.getAttribute("ber_to").setRequiredLevel("none");

            Xrm.Page.getControl("ber_from").setDisabled(true);
            Xrm.Page.getControl("ber_to").setDisabled(true);

            Xrm.Page.getAttribute("ber_installationrequestid").setValue(null);
            Xrm.Page.getAttribute("ber_schemeid").setValue(null);

            Xrm.Page.getControl("ber_installationrequestid").setVisible(false);
            Xrm.Page.getControl("ber_schemeid").setVisible(false);
            Xrm.Page.getControl("ber_idtp").setVisible(false);

            Xrm.Page.getControl("ber_adjustmentreason").setVisible(true);
            Xrm.Page.getAttribute("ber_adjustmentreason").setRequiredLevel("required");
        }
        else if (TransferType == 278290002) { //HO Transfer
            Xrm.Page.getAttribute("ber_from").setRequiredLevel("required");
            Xrm.Page.getAttribute("ber_to").setRequiredLevel("required");

            Xrm.Page.getControl("ber_from").setDisabled(false);
            Xrm.Page.getControl("ber_to").setDisabled(false);

            Xrm.Page.getControl("ber_installationrequestid").setVisible(true);
            Xrm.Page.getControl("ber_schemeid").setVisible(true);

            Xrm.Page.getControl("ber_installationrequestid").setDisabled(true);
            Xrm.Page.getControl("ber_schemeid").setDisabled(true);

            Xrm.Page.getControl("ber_adjustmentreason").setVisible(false);
            Xrm.Page.getAttribute("ber_adjustmentreason").setRequiredLevel("none");
        }
    }
}