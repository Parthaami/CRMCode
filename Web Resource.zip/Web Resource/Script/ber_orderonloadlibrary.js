function orderOnLoad() {

    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");

    if (isCrmForMobile) {
        validateTSI();
        return;
    }

    if (Xrm.Page.ui.getFormType() == 1) {
        //Function to fill Price list on order on Order creation time
        FillPriceList();
        if (Xrm.Page.getAttribute("pricelevelid") != null && Xrm.Page.getAttribute("pricelevelid").getValue() != null)
            Xrm.Page.getControl("pricelevelid").setDisabled(true);

        //Function to fill Depot & TSI on Order Creation
        FillDepoAndTsi();
    }
    if (Xrm.Page.ui.getFormType() != 1) {
        Xrm.Page.ui.tabs.get(0).addTabStateChange(function () {
            if (Xrm.Page.ui.tabs.get("general").getDisplayState() == "expanded") {
                if (Xrm.Page.getAttribute("ber_paymentmode").getSelectedOption() != null) {
                    var paymentmodetext = Xrm.Page.getAttribute("ber_paymentmode").getSelectedOption().text;

                    if (paymentmodetext != null) {
                        if (paymentmodetext == "Cheque") {
                            chequemap();
                        }
                    }
                }
            }
        })
    }

    if (Xrm.Page.ui.getFormType() == 2 || Xrm.Page.getAttribute("ordernumber").getValue() != null) {
        if (!isCrmForMobile) {
            Xrm.Page.ui.tabs.get("tab_6").setDisplayState("expanded");
            Xrm.Page.ui.tabs.get("notes").setDisplayState("expanded");
            Xrm.Page.ui.tabs.get("general").setDisplayState("collapsed");
        }
    }



}



function FillPriceList() {
    $.ajax({
        type: "GET",
        async: false,
        url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/pricelevels?$select=pricelevelid,name&$filter=statecode eq 0",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processdata: false,
        crossDomain: true,
        success: function (msg) {
            Pricelistcollection = msg;

        },
        error: function (msg) {
            alert('error fetching the price level from crm organization');
        },
    });

    if (Pricelistcollection != null && Pricelistcollection.value != null && Pricelistcollection.value[0] != null) {
        var pricelist = new Array();
        pricelist[0] = new Object();
        pricelist[0].id = Pricelistcollection.value[0].pricelevelid;
        pricelist[0].name = Pricelistcollection.value[0].name;
        pricelist[0].entityType = "pricelevel";
        Xrm.Page.getAttribute("pricelevelid").setValue(pricelist);
    }
}

function FillDepoAndTsi() {

    if (Xrm.Page.getAttribute("ber_billto") != null && Xrm.Page.getAttribute("ber_billto").getValue() != null && Xrm.Page.getAttribute("ber_billto").getValue() != "") {
        Xrm.Page.getControl("ber_depotid").setDisabled(false);
        Xrm.Page.getControl("ber_associatedtsiid").setDisabled(false);
        var BillToId = Xrm.Page.getAttribute("ber_billto").getValue()[0].id;
        BillToId = BillToId.replace("{", "").replace("}", "");

        $.ajax({
            type: "GET",
            async: false,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + BillToId + ")?$select=paymenttermscode,customertypecode,_ber_depotid_value,_ber_associatedtsiid_value",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processdata: false,
            crossDomain: true,
            success: function (msg) {

                collection = msg;

            },
            error: function (msg) {
                alert('error fetching the accounts information from crm organization');
            },
        });



        if (collection != null) {

            var depoName = collection["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
            var depotid = collection["_ber_depotid_value"];
            var depotlogicalname = collection["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

            var associatedtsiid = collection["_ber_associatedtsiid_value"];
            var associatedtsiidname = collection["_ber_associatedtsiid_value@OData.Community.Display.V1.FormattedValue"];
            var associatedtsiidlogicalname = collection["_ber_associatedtsiid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];

            //var customertypecode = collection["customertypecode"];
            var customertypecode = collection["customertypecode"]; //collection["customertypecode@OData.Community.Display.V1.FormattedValue"];
            //var paymenttermscode = collection["paymenttermscode"];
            var paymenttermscode = collection["paymenttermscode"];//collection["paymenttermscode@OData.Community.Display.V1.FormattedValue"];

            if (depotid != null && depotid != "") {
                var depo = new Array();
                depo[0] = new Object();
                depo[0].id = depotid;
                depo[0].name = depoName;
                depo[0].entityType = depotlogicalname;
                Xrm.Page.getAttribute("ber_depotid").setValue(depo);
            }
            else {
                Xrm.Page.getAttribute("ber_depotid").setValue(null);
                Xrm.Page.getAttribute("ber_depotid").setRequiredLevel("required");
            }


            if (associatedtsiid != null && associatedtsiid != "") {

                var tsi = new Array();
                tsi[0] = new Object();
                tsi[0].id = associatedtsiid;
                tsi[0].name = associatedtsiidname;
                tsi[0].entityType = associatedtsiidlogicalname;
                Xrm.Page.getAttribute("ber_associatedtsiid").setValue(tsi);
            }
            else {
                Xrm.Page.getAttribute("ber_associatedtsiid").setValue(null);
                Xrm.Page.getAttribute("ber_associatedtsiid").setRequiredLevel("required");
            }

            if (paymenttermscode != null && paymenttermscode != "") {
                var n = null;
                if (depoName != null)
                    n = depoName.split(":");

                var PaymentTerm = paymenttermscode;
                if (PaymentTerm == 278290000)//MAPD2
                {
                    Xrm.Page.getAttribute("discountpercentage").setValue(5.25);
                }
                else if (PaymentTerm == 4)//MAPD
                {
                    if (n[0] == "036" || n[0] == "032" || n[0] == "125" || n[0] == "096" || n[0] == "111" || n[0] == "091")
                        Xrm.Page.getAttribute("discountpercentage").setValue(3.5);
                    else
                        Xrm.Page.getAttribute("discountpercentage").setValue(5);
                }
                else {
                    Xrm.Page.getAttribute("discountpercentage").setValue(0);
                }
            }

            var PaymentTerm = null;
            var CustomerType = null;
            if (paymenttermscode != null && paymenttermscode != "")
                PaymentTerm = paymenttermscode;

            if (customertypecode != null && customertypecode != "")
                CustomerType = customertypecode;
            //Sort DFF Items and display Required DFF Items Only
            setValidDFF(PaymentTerm, CustomerType);
        }

        Xrm.Page.getControl("ber_depotid").setDisabled(true);
        Xrm.Page.getControl("ber_associatedtsiid").setDisabled(true);
    }
    else {
        Xrm.Page.getAttribute("ber_depotid").setValue(null);
        Xrm.Page.getAttribute("ber_associatedtsiid").setValue(null);
        Xrm.Page.getAttribute("discountpercentage").setValue(null);
        Xrm.Page.getAttribute("ber_dff").setValue(null);
        //DFFOnChange();
    }
}


function CustomerOnChange() {
    Xrm.Page.getAttribute("ber_billto").setValue(null);
    FillDepoAndTsi();
}

/*
Hide "Mobile Order Details" Subgrid in case opened from non mobile device
*/


function showHideSectionForMobile() {
    var Mobile_Order_Details = Xrm.Page.ui.tabs.get("tab_6").sections.get("Mobile_Order_Details");
    var tab_6_section_1 = Xrm.Page.ui.tabs.get("tab_6").sections.get("tab_6_section_1");

    var isCrmForMobile = (Xrm.Page.context.client.getClient() == "Mobile");
    if (!isCrmForMobile)
        Mobile_Order_Details.setVisible(false);
    else
        tab_6_section_1.setVisible(false);

}

function setValidDFF(PaymentTerm, CustomerType) {
    //Xrm.Page.getAttribute("ber_dff").setValue(null);

    //Xrm.Page.getControl("ber_dff").removeOption("1");
    if ((PaymentTerm == 278290000 || PaymentTerm == 4) && (CustomerType == 4 || CustomerType == 8)) //if((MAPD||MAPD2)&&(Prolink||Contractor))----ADD SOUMEN-290216
    {
        Xrm.Page.getAttribute("ber_dff").setRequiredLevel("required");
        //var DFF = document.getElementById('ber_dff');
        //DFF[1].disabled = true;
        //DFF[2].disabled = true;
        //DFF[3].disabled = true;
        //DFF[4].disabled = false;
        //DFF[5].disabled = false;
        //DFF[6].disabled = true;
        //DFF[7].disabled = true;
        Xrm.Page.getControl("ber_dff").removeOption("1");
        Xrm.Page.getControl("ber_dff").removeOption("2");
        Xrm.Page.getControl("ber_dff").removeOption("3");
        Xrm.Page.getControl("ber_dff").removeOption("6");
        Xrm.Page.getControl("ber_dff").removeOption("7");
    }
    else if (PaymentTerm == 278290000 || PaymentTerm == 4 || PaymentTerm == 278290002)//if(MAPD||MAPD2||MAPD_58)
    {
        Xrm.Page.getAttribute("ber_dff").setRequiredLevel("required");
        //var DFF = document.getElementById('ber_dff');
        //DFF[1].disabled = true;
        //DFF[2].disabled = false;
        //DFF[3].disabled = true;
        //DFF[4].disabled = true;
        //DFF[5].disabled = false;
        //DFF[6].disabled = true;
        //DFF[7].disabled = true;

        Xrm.Page.getControl("ber_dff").removeOption("1");
        Xrm.Page.getControl("ber_dff").removeOption("3");
        Xrm.Page.getControl("ber_dff").removeOption("4");
        Xrm.Page.getControl("ber_dff").removeOption("6");
        Xrm.Page.getControl("ber_dff").removeOption("7");

    }
    else if (PaymentTerm = 3 && (CustomerType == 4 || CustomerType == 8))//If(APD &&(Prolink||Contractor))
    {
        Xrm.Page.getAttribute("ber_dff").setRequiredLevel("required");
        //var DFF = document.getElementById('ber_dff');
        //DFF[1].disabled = true;
        //DFF[2].disabled = true;
        //DFF[3].disabled = true;
        //DFF[4].disabled = true;
        //DFF[5].disabled = true;
        //DFF[6].disabled = false;
        //DFF[7].disabled = false;

        Xrm.Page.getControl("ber_dff").removeOption("1");
        Xrm.Page.getControl("ber_dff").removeOption("2");
        Xrm.Page.getControl("ber_dff").removeOption("3");
        Xrm.Page.getControl("ber_dff").removeOption("4");
        Xrm.Page.getControl("ber_dff").removeOption("5");
    }
    else {
        Xrm.Page.getAttribute("ber_dff").setRequiredLevel("none");
        //var DFF = document.getElementById('ber_dff');
        //DFF[1].disabled = false;
        //DFF[2].disabled = true;
        //DFF[3].disabled = true;
        //DFF[4].disabled = true;
        //DFF[5].disabled = true;
        //DFF[6].disabled = true;
        //DFF[7].disabled = true;
        Xrm.Page.getControl("ber_dff").addOption({ value: 1, text: "Consignee Details" })
        Xrm.Page.getControl("ber_dff").removeOption("2");
        Xrm.Page.getControl("ber_dff").removeOption("3");
        Xrm.Page.getControl("ber_dff").removeOption("4");
        Xrm.Page.getControl("ber_dff").removeOption("5");
        Xrm.Page.getControl("ber_dff").removeOption("6");
        Xrm.Page.getControl("ber_dff").removeOption("7");
    }
}


function BillChange() {
    Xrm.Page.getAttribute("ber_dff").setValue(null);
    // DFFOnChange();
}

function SavePercentage() {
    Xrm.Page.getAttribute("discountpercentage").setSubmitMode("always");
}

// Function to set Book By field based on logon user type.If user is depot user set Book By as Depot*
function SetOrderBookBy() {

    var LogonUserId = Xrm.Page.context.getUserId();
    LogonUserId = LogonUserId.replace("{", "").replace("}", "");



    $.ajax({
        type: "GET",
        async: false,
        url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/systemusers(" + LogonUserId + ")?$select=preferredaddresscode",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        processdata: false,
        crossDomain: true,
        success: function (msg) {
            collection = msg;

        },
        error: function (msg) {
            alert('error fetching the price level from crm organization');
        },
    });


    if (collection != null) {
        //if User Type is Depot User set Book By Field
        if (collection["preferredaddresscode"] != null && collection["preferredaddresscode"] != "") {
            var UserType = collection["preferredaddresscode"];
            if (UserType == 278290001)//Depot User
            {
                Xrm.Page.getAttribute("ber_bookby").setValue(278290002);
                Xrm.Page.getAttribute("ber_bookby").setSubmitMode("always");
                Xrm.Page.getControl("ber_bookby").setDisabled(true);
            }
        }
    }
}

function PopulateChequeForAccount() {
    //Get account number against bill to
    var AccNo = null;
    var BilltoId = Xrm.Page.getAttribute("ber_billto").getValue();
    var MultipleChequeNumber = "";
    if (BilltoId != null && BilltoId != "" && BilltoId != undefined) {

        var AccId = Xrm.Page.getAttribute("ber_billto").getValue()[0].id;
        AccId = AccId.replace("{", "").replace("}", "");

        $.ajax({
            type: "GET",
            async: false,
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/accounts(" + AccId + ")?$select=accountnumber",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            processdata: false,
            crossDomain: true,
            success: function (msg) {
                AccNo = msg["accountnumber"];

            },
            error: function (msg) {
                return 'error fetching the cheque from crm organization';
            },
        });
    }
    var chequearray = new Array();
    var i = 0;
    var textstring = "";

    if (AccNo != null && AccNo != "" && AccNo != undefined) {
        //Get checque numbers against account number from oracle

        $.ajax({
            type: "GET",
            async: false,
            url: 'https://bpilcrm.bergerindia.com:6525/oracleconnect.asmx/ChequeInv?siteid=' + AccNo + '&isSiteId=true',
            contentType: "application/xml; charset=utf-8",
            dataType: "xml",
            processdata: false,
            crossDomain: true,
            success: function (msg) {
                $(msg).find('Table').each(function () {

                    var chequenumber = $(this).find('Cheque_x0020__x0023_').text();
                    var status = $(this).find('Status').text();
                    var type = $(this).find('Type').text();
                    var site = $(this).find('SiteId').text();

                    chequearray[i] = new Object();
                    chequearray[i].chequedetail = "Cheque: " + chequenumber + " || Status: " + status + " || Type: " + type + " || Site: " + site + "\r\n";
                    textstring = textstring + chequearray[i].chequedetail;
                    i++;
                });

            },
            error: function (msg) {
                alert('error fetching the cheque from oracle');
            },
        });

        Xrm.Page.getAttribute("ber_chequenumbermobile").setValue(textstring);

    }
}

function validateTSI() {
    var user = Xrm.Page.context.getUserId();
    user = user.replace("{", "").replace("}", "");
    var TerritoryCollection;

    $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        datatype: "json",
        url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis?$select=_ber_terr_code_value&$filter=_ber_tsiuserid_value eq " + user,
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
            XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
            XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        },
        async: false,
        success: function (data, textStatus, xhr) {
            TerritoryCollection = data;
        },
        error: function (xhr, textStatus, errorThrown) {
            Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
        }
    });

    if (TerritoryCollection != null && TerritoryCollection.value != null && TerritoryCollection.value[0] != null) {

        var Territory = TerritoryCollection.value[0]["_ber_terr_code_value"];
        var lookupItem = Xrm.Page.getAttribute("ber_associatedtsiid").getValue();
        var ordertsiid;
        var _ber_terr_code_value;
        if (lookupItem != null) {
            ordertsiid = lookupItem[0].id;
            ordertsiid = ordertsiid.replace("{", "").replace("}", "");
        }
        $.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_tsis(" + ordertsiid + ")?$select=_ber_terr_code_value",
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("OData-MaxVersion", "4.0");
                XMLHttpRequest.setRequestHeader("OData-Version", "4.0");
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
                XMLHttpRequest.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            },
            async: true,
            success: function (data, textStatus, xhr) {
                var result = data;
                _ber_terr_code_value = result["_ber_terr_code_value"];

            },
            error: function (xhr, textStatus, errorThrown) {
                Xrm.Utility.alertDialog(textStatus + " " + errorThrown);
            }
        });

        if (Territory != _ber_terr_code_value) {
            Xrm.Utility.alertDialog("Territory is not same, order can not be displayed");
            Xrm.Page.ui.close();
        }
    }

}

