function CaptureDate() {
    if (Xrm.Page.getAttribute("ber_otherpainterassignment").getValue() != null && Xrm.Page.getAttribute("ber_otherpainterassignment") != undefined) {
        var today = new Date();
        var Carpenter = Xrm.Page.getAttribute("ber_otherpainterassignment").getValue();
        if (Xrm.Page.getAttribute("ber_otherpainterallocationdate") != undefined && Xrm.Page.getAttribute("ber_otherpainterallocationdate") !== null) {
            var CaptureDate = Xrm.Page.getAttribute("ber_otherpainterallocationdate").setValue(today);
            Xrm.Page.getAttribute("ber_otherpainterallocationdate").setSubmitMode("always");

        }
    }

    /*
    if (Xrm.Page.getAttribute("ber_polisher").getValue() != null && Xrm.Page.getAttribute("ber_polisher") != undefined) {
    var today = new Date();
    var Carpenter = Xrm.Page.getAttribute("ber_polisher").getValue();
    if (Xrm.Page.getAttribute("ber_capturepolisherallocation") != undefined && Xrm.Page.getAttribute("ber_capturepolisherallocation") !== null) {
    var CaptureDate = Xrm.Page.getAttribute("ber_capturepolisherallocation").setValue(today);
    Xrm.Page.getAttribute("ber_capturepolisherallocation").setSubmitMode("always");

    }

        
    }
    */
}