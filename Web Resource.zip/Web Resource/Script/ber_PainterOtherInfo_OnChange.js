/**************
Developmer : Madhumita
Date : 06/08/2018
Ticket: =#233(Key contractor functionality)
Method: retrieve the specific contact based on mobile number and the owner of the contact
***************/

function GetContactDetails() {

    if (Xrm.Page.getAttribute("ber_mobilenumber").getValue() != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
        var telephone = Xrm.Page.getAttribute("ber_mobilenumber").getValue();
        var currentUser = Xrm.Page.context.getUserId();

        //   if (Xrm.Page.getAttribute("ber_depot").getValue() != null && Xrm.Page.getAttribute("ber_depot") != undefined) {
        // var depot = (Xrm.Page.getAttribute("ber_depot").getValue())[0].id;
        var modifiedcurrentUser = currentUser.replace("{", "").replace("}", "");


        var req = new XMLHttpRequest();
        //   req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname&$filter=mobilephone eq '" + telephone + "' and  _ownerid_value eq " + modifiedcurrentUser, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname,mobilephone,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and _ownerid_value eq " + modifiedcurrentUser, false);
        // req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$filter=mobilephone eq '1234567890' and  ber_customertype eq 278290001 and  ber_subdealer eq false and  _ber_parentpainter_value eq null", true);

        if (UserHasRole(("Depot User") || ("Depot Home Decor User"))) {
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname,mobilephone,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and ber_customertype eq 278290001 and (ber_subdealer eq false or ber_subdealer eq null) and  _ber_parentpainter_value eq null and _ownerid_value eq " + modifiedcurrentUser, false);
        }
            //System Administrator
        else if (UserHasRole("System Administrator")) {
            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/contacts?$select=_ber_depotid_value,contactid,fullname,mobilephone,_ownerid_value&$filter=mobilephone eq '" + telephone + "' and  statecode eq 0 and ber_customertype eq 278290001 and (ber_subdealer eq false or ber_subdealer eq null) and  _ber_parentpainter_value eq null", false);

        }

        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");

        req.send();

        if (req.response != null && req.response != "") {
            var result = JSON.parse(req.response);
            try {
                if (result != null) {
                    //no duplicate record should be allowed
                    if (result.value.length == 1) {
                        // alert(result.value.length);
                        //for (var i = 0; i < results.value.length; i++) 
                        //{
                        //  var _ber_depotid_value = result.value[0]["_ber_depotid_value"];

                        var contactid = result.value[0]["contactid"];

                        //If Code 
                        if (IsExistContactidByGuid(contactid) == true) {
                            alert("A record with same mobile number already exist");
                            return;
                        }

                        var _ber_depotid_value = result.value[0]["_ber_depotid_value"];
                        var _ber_depotid_value_formatted = result.value[0]["_ber_depotid_value@OData.Community.Display.V1.FormattedValue"];
                        var _ber_depotid_value_lookuplogicalname = result.value[0]["_ber_depotid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];


                        if (result.value[0]["fullname"] != null) {
                            var fullname = result.value[0]["fullname"];
                        }
                        else {
                            var fullname = " ";
                        }
                        var _ber_contactid_value_lookuplogicalname = "contact"

                        var ContactArray = new Array();
                        ContactArray[0] = new Object();
                        ContactArray[0].id = contactid;
                        ContactArray[0].name = fullname;
                        ContactArray[0].entityType = _ber_contactid_value_lookuplogicalname;


                        var DepotArray = new Array();
                        DepotArray[0] = new Object();
                        DepotArray[0].id = _ber_depotid_value;
                        DepotArray[0].name = _ber_depotid_value_formatted;
                        DepotArray[0].entityType = _ber_depotid_value_lookuplogicalname;

                        Xrm.Page.getAttribute("ber_originator").setValue(ContactArray);
                        Xrm.Page.getAttribute("ber_originator").setSubmitMode("always");
                        Xrm.Page.getAttribute("ber_name").setValue(fullname);
                        Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
                        Xrm.Page.getAttribute("ber_depot").setValue(DepotArray);
                        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
                        //Xrm.Page.getAttribute("ber_parentpainter").setValue(ContactArray);
                    }

                    else {
                        alert("Please  provide a valid mobile number");
                        Xrm.Page.getAttribute("ber_mobilenumber").setValue(null);
                    }
                }
            }

            catch (err) {
                alert("Please communicate system administrator in HO for error: " + err);
            }

        }
        // }
    }

    else {

    }
}





function focusMobile() {
    if (Xrm.Page.getAttribute("ber_depot").getValue() != null && Xrm.Page.getAttribute("ber_depot") != undefined) {
        if (Xrm.Page.getAttribute("ber_mobilenumber") != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
            Xrm.Page.getControl("ber_mobilenumber").setFocus();
            Xrm.Page.getControl("ber_mobilenumber").setDisabled(false);
            Xrm.Page.getAttribute("ber_mobilenumber").setRequiredLevel("required");
        }
    }

}



/**************
Developmer : Madhumita
Date : 06/08/2018
Ticket: =#233(Key contractor functionality)
Method: Validate the mobile number must be numaric and of 10 digit
***************/

function ValidateNumber() {

    if (Xrm.Page.getAttribute("ber_mobilenumber").getValue() != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
        //get the mobile number being entered
        var contactNumber = Xrm.Page.getAttribute("ber_mobilenumber").getValue();
        var n = contactNumber.length;

        var i;
        var returnString = "";

        if (typeof (contactNumber) != "undefined" && contactNumber != null) {
            var filteredValues = "1234567890";

            for (i = 0; i < contactNumber.length; i++) {
                var c = contactNumber.charAt(i);
                if (filteredValues.indexOf(c) != -1) {
                    returnString += c;
                }
            }
            Xrm.Page.getAttribute("ber_mobilenumber").setValue(returnString);

            if (returnString.length == contactNumber.length) {

                if (n == 10) {

                    GetContactDetails();
                }
                else {
                    alert("Mobile Number should be of 10 digits");
                    Xrm.Page.getAttribute("ber_mobilenumber").setValue("");
                }

            }
            else {
                Xrm.Page.getAttribute("ber_mobilenumber").setValue("");
                alert('Only Numeric values are allowed');
            }

        }

    }

    else {

        Xrm.Page.getAttribute("ber_originator").setValue(null);
        Xrm.Page.getAttribute("ber_originator").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_name").setValue(null);
        Xrm.Page.getAttribute("ber_name").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_depot").setValue(null);
        Xrm.Page.getAttribute("ber_depot").setSubmitMode("always");
        Xrm.Page.getAttribute("ber_type").setValue(null);
        Xrm.Page.getAttribute("ber_type").setSubmitMode("always");

    }
}

/**
 * 
 * @param {type} contactid
 * @returns {type} 
 */
function IsExistContactidByGuid(contactid) {

    var returnValue = false;
    var FormType = Xrm.Page.ui.getFormType();
    if (FormType != null) {
        if (FormType == 1) {
            //if (Xrm.Page.getAttribute("ber_mobilenumber").getValue() != null && Xrm.Page.getAttribute("ber_mobilenumber") != undefined) {
            //    var telephone = Xrm.Page.getAttribute("ber_mobilenumber").getValue();

            var req = new XMLHttpRequest();
            //req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_painterotherinfos?$select=ber_mobilenumber,ber_type,statecode&$filter=ber_mobilenumber eq '" + telephone + "' and  statecode eq 0", false);

            req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v8.2/ber_painterotherinfos?$select=ber_mobilenumber,ber_type,statecode&$filter=_ber_originator_value eq " + contactid + " and  statecode eq 0", false);


            req.setRequestHeader("OData-MaxVersion", "4.0");
            req.setRequestHeader("OData-Version", "4.0");
            req.setRequestHeader("Accept", "application/json");
            req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
            req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
            req.send();

            if (req.response != null && req.response != "") {
                var result = JSON.parse(req.response);
                // var results = JSON.parse(this.response);
                try {
                    if (result != null) {
                        // if duplicate record exist with same mobile number
                        if (result.value.length > 0) {

                            returnValue = true;

                            //var ber_mobilenumber = result.value[0]["ber_mobilenumber"];
                            //var ber_type = result.value[0]["ber_type"];
                            //var ber_type_formatted = result.value[0]["ber_type@OData.Community.Display.V1.FormattedValue"];
                            //var statecode = result.value[0]["statecode"];
                            //var statecode_formatted = result.value[0]["statecode@OData.Community.Display.V1.FormattedValue"];
                            //alert("A record with same mobile number already exist");
                        }
                    }
                }
                catch (err) {
                    alert("Please communicate system administrator in HO for error: " + err);
                    returnValue = false;
                }
            }

            //}
        }
    }
    return returnValue;
}