function setpaintermeetformreadonly() 
{
 //  debugger;
    if (Xrm.Page.ui.getFormType() == 2)
	{
     var approvestatus = Xrm.Page.getAttribute("ber_approvalstatus").getValue();
         if(approvestatus==278290001)//pending for approval
{
       //  var isDepotUser=UserHasRole("Depot User");
          if(UserHasRole("HO User"))
         {
                   disableFormFields("ber_approvalstatus", approvestatus , "true")
         }
}

      //  var approvestatus = Xrm.Page.getAttribute("ber_approvalstatus").getValue();

        if (approvestatus == 278290002 || approvestatus == 278290007 || approvestatus == 278290005 || approvestatus == 278290006||approvestatus == 278290003)
		{
           disableFormFields("ber_approvalstatus", approvestatus , "true")
	   }
    }
}



function disableFormFields(fieldname, fieldvalue, onOff)
 {
    var value = Xrm.Page.getAttribute(fieldname).getValue();

    if (value != null)
	{
        var fieldtype = Xrm.Page.getControl(fieldname).getControlType();
        if (fieldtype == "optionset") 
		{
            value = Xrm.Page.getAttribute(fieldname).getSelectedOption().value;
        }
        if (fieldtype == "lookup") 
		{
            value = value[0].name;
        }
        if (value == fieldvalue) 
		{
            Xrm.Page.ui.controls.forEach
			(function (control, index)
			{
                if (doesControlHaveAttribute(control))
				{
                    control.setDisabled(onOff);
                }
            });
        }
    }
}

function doesControlHaveAttribute(control)
 {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}





function Apply_DealerLookupFilter() 
{
   // debugger;

    if (Xrm.Page.getAttribute("ber_depot").getValue() != null && Xrm.Page.getAttribute("ber_depot").getValue() != undefined) 
	{
	if(Xrm.Page.getAttribute("ber_meet").getValue() != null)
 {
    var meettypeid =new Array();
    meettypeid[0]=new Object();
    var MeetId = Xrm.Page.getAttribute("ber_meet").getValue()[0].id;
    var columns = ['ber_Type'];
    var filter = "ber_meetId eq (Guid'" + MeetId + "')";
    var collection = CrmRestKit.RetrieveMultiple('ber_meet', columns, filter);
     if (collection != null && collection.results != null && collection.results.length > 0) 
        {
         var PMType=collection.results[0].ber_Type.Value;
       
   }
        var DepotId = Xrm.Page.getAttribute("ber_depot").getValue();

                viewDisplayName = null;
                viewId = null;
                isDefaultView = true;
				fetchxml=null;
               layoutxml = '<grid name="resultset" object="1" jump="name" select="1" icon="1" preview="1">'
		+'<row name="result" id="accountid">'
		+'<cell name="accountnumber" width="100"/><cell name="name" width="125"/>'
		+'<cell name="customertypecode" width="100"/>'
		+'<cell name="ber_taxcategory" width="100"/>'
		+'<cell name="ber_depotid" width="100"/>'
		+'<cell name="territoryid" width="100"/>'
		+'<cell name="ber_associatedtsiid" width="100"/>'
		+'</row></grid>';
							
		if(PMType==278290001)//color bank
		  {
		     fetchxml='<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
					+ ' <entity name="account">'
					+  '  <attribute name="name" />'
					+   ' <attribute name="accountnumber" />'
					+    '<attribute name="customertypecode" />'
					+    '<attribute name="ber_taxcategory" />'
					+ '   <attribute name="ber_depotid" />'
					 +'   <attribute name="territoryid" />'
					 +'   <attribute name="ber_associatedtsiid" />'
					 +'   <attribute name="accountid" />'
					 +'   <order attribute="name" descending="false" />'
					 +'   <filter type="and">'
		 +'     <condition attribute="customertypecode" operator="eq" value="5" />'
		 +'     <condition attribute="statecode" operator="eq" value="0" />'
		 + '    <condition attribute="parentaccountid" operator="null" />'
		 +'     <condition attribute="ber_colorbank" operator="eq" value="1" />'
		 +'     <condition attribute="ber_depotid" operator="eq"  uitype="ber_depot" value="'+DepotId[0].id +'" />'
					 + '  </filter>    '
					 + '</entity>'
					+'</fetch>';
		  }
         else if(PMType==278290005)//gold silver
		  {
		       fetchxml='<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
						+'  <entity name="account">'
						 +'   <attribute name="name" />'
						  +'  <attribute name="accountnumber" />'
						  +'  <attribute name="customertypecode" />'
						 +'   <attribute name="ber_taxcategory" />'
						+'    <attribute name="ber_depotid" />'
						 +'   <attribute name="territoryid" />'
						  +'  <attribute name="ber_associatedtsiid" />'
			  +'  <attribute name="accountid" />'
			  +'  <order attribute="name" descending="false" />'
			 +'   <filter type="and">'
			  +'    <condition attribute="customertypecode" operator="eq" value="5" />'
			  +'    <condition attribute="statecode" operator="eq" value="0" />'
			  +'    <condition attribute="parentaccountid" operator="null" />'
			  +'    <condition attribute="accountcategorycode" operator="ne" value="278290002" />'
			  +'    <condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="'+DepotId[0].id +'" />'
			  +'  </filter>  </entity></fetch>';
		  } 
		 
		  else //if(other)
		   {
		fetchxml = '<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="false">'
		+'<entity name="account"><attribute name="name"/><attribute name="accountnumber"/>'
		+'<attribute name="customertypecode"/><attribute name="ber_taxcategory"/>'
		+'<attribute name="ber_depotid"/><attribute name="territoryid"/>'
		+'<attribute name="ber_associatedtsiid"/><attribute name="accountid"/>'
		+'<order attribute="name" descending="false"/>'
		+'<filter type="and">'
		+'<condition attribute="customertypecode" operator="eq" value="5"/>'
		+'<condition attribute="statecode" operator="eq" value="0"/>'
		+'<condition attribute="parentaccountid" operator="null"/>'
		+'<condition attribute="accountcategorycode" operator="eq" value="278290002"/>'
		+'<condition attribute="ber_depotid" operator="eq" uitype="ber_depot" value="'+DepotId[0].id +'"/>'
		+'</filter>'
		+'</entity></fetch>';
            }

            viewDisplayName = 'Related Dealer (Dealer-Scheme Connection)';
            viewId = GetuniqueGuid();

            Xrm.Page.getControl('ber_dealer').addCustomView(viewId, 'account', viewDisplayName, fetchxml, layoutxml,   isDefaultView);
            Xrm.Page.getControl('ber_dealer').setDefaultView(viewId);

        }
    }

}


function GetuniqueGuid() 
{

    var getFragment = function () { return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1); };

    return '{' + (getFragment() + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + "-" + getFragment() + getFragment() + getFragment()) + '}';

};




function GuidsAreEqual(guid1, guid2)
{
    var isEqual = false;

    if (guid1 == null || guid2 == null)
    {
        isEqual = false;
    }
    else
    {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
}
function UserHasRole(roleName)
{
//   debugger;
    var serverUrl = Xrm.Page.context.getServerUrl();
    serverUrl=window.location.protocol + "//" + window.location.host + "/" + Xrm.Page.context.getOrgUniqueName();

    var oDataEndpointUrl = serverUrl + "/XRMServices/2011/OrganizationData.svc/";
    oDataEndpointUrl += "RoleSet?$top=1&$filter=Name eq '" + roleName + "'";

    var service = GetRequestObject();

    if (service != null)
    {
        service.open("GET", oDataEndpointUrl, false);
        service.setRequestHeader("X-Requested-Width", "XMLHttpRequest");
        service.setRequestHeader("Accept", "application/json, text/javascript, */*");
        service.send(null);

        var requestResults = eval('(' + service.responseText + ')').d;

       if (requestResults != null && requestResults.results.length == 1)
      {
          var role = requestResults.results[0]; 

            var id = role.RoleId;
                   id=   role.ParentRoleId.Id;

            var currentUserRoles = Xrm.Page.context.getUserRoles();

            for (var i = 0; i < currentUserRoles.length; i++)
            {
                var userRole = currentUserRoles[i];

                if (GuidsAreEqual(userRole, id))
                {
                    return true;
                }
            }
        }
    }

    return false;
}


function GetRequestObject()
{
    if (window.XMLHttpRequest)
    {
        return new window.XMLHttpRequest;
    }
    else
    {
        try
        {
            return new ActiveXObject("MSXML2.XMLHTTP.3.0");
        }
        catch (ex)
        {
            return null;
        }
    }
}


function GuidsAreEqual(guid1, guid2)
{
    var isEqual = false;

    if (guid1 == null || guid2 == null)
    {
        isEqual = false;
    }
    else
    {
        isEqual = guid1.replace(/[{}]/g, "").toLowerCase() == guid2.replace(/[{}]/g, "").toLowerCase();
    }

    return isEqual;
}