// FUNCTION: formOnLoad
function formOnLoad() {
//Xrm.Page.getControl("ber_oldamount").setVisible(false);
    setDealerLookup(false);
 }
 
// FUNCTION: setLookup
	function setDealerLookup(resetSelection) {
	    // Get the selected Estimate Id
	    var estimate = Xrm.Page.getAttribute("ber_estimateid").getValue();
	    var defaultViewId = Xrm.Page.getControl("ber_dealer").getDefaultView();
	    if (estimate != null) {
	        var estimateid = estimate[0].id;
	        var estimatename = estimate[0].name;

	        if (resetSelection == true) {
	            // reset old selection for Dealer
	            Xrm.Page.getAttribute("ber_dealer").setValue(null);
	        }

	        // use randomly generated GUID Id for our new view
	        var viewId = "{1DFB2B35-B07C-44D1-868D-258DEEAB88E2}";
	        var entityName = "account";

	        // give the custom view a name
	        var viewDisplayName = "Estimate Dealers";

	        // find all Dealers where [Estimate] = [Estimate indicated by EstimateId]

	        var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                   "<entity name='account'>" +
                   "<attribute name='name'/>" +
                   "<attribute name='accountnumber'/>" +
                   "<attribute name='customertypecode'/>" +
                   "<attribute name='accountid'/>" +
                   "<order attribute='name' descending='false'/>" +
                   "<link-entity name='ber_materialrequisition' from='ber_dealerid' to='accountid' alias='aa'>" +
                   "<link-entity name='ber_estimatedetails' from='ber_estimatedetailsid' to='ber_estimatedetailsid' alias='ab'>" +
                   "<filter type='and'>" +
                   "<condition attribute='ber_estimatedetailsid' operator='eq' uitype='ber_estimatedetails' value='" + estimateid + "'/>" +
                   "</filter></link-entity></link-entity></entity></fetch>";

	        // build Grid Layout
	        var layoutXml = "<grid name='resultset' object='1' jump='name' select='1' icon='1' preview='1'>" +
                    "<row name='result' id='accountid'>" +
                     "<cell name='accountnumber' width='100'/>" +
                     "<cell name='name' width='125'/>" +
                     "<cell name='customertypecode' width='100'/>" +
                     "</row></grid>";

	        // add the Custom View to the indicated [lookupFieldName] Control
	        Xrm.Page.getControl("ber_dealer").addCustomView(viewId, entityName, viewDisplayName, fetchXml, layoutXml, true);
	    }
	    else {
	        // no Account selected, reset Contact Lookup View to the default view such that all Contacts are displayed for selection
	        Xrm.Page.getControl("ber_dealer").setDefaultView(defaultViewId);
     }
}


/// Bill Amount Change.
function CalculatePendingAmt() {
    if (Xrm.Page.ui.getFormType() == 1) {
        Xrm.Page.getAttribute("ber_pendingamount").setValue(Xrm.Page.getAttribute("ber_amount").getValue());
        Xrm.Page.getAttribute("ber_pendingamount").setSubmitMode("always");

        Xrm.Page.getAttribute("ber_oldamount").setValue(Xrm.Page.getAttribute("ber_amount").getValue());
        Xrm.Page.getAttribute("ber_oldamount").setSubmitMode("always");
    }
   else if (Xrm.Page.ui.getFormType() != 1) {
        if (Xrm.Page.getAttribute("ber_amount").getValue() != null && Xrm.Page.getAttribute("ber_oldamount").getValue() != null) {
            if (Xrm.Page.getAttribute("ber_amount").getValue() != Xrm.Page.getAttribute("ber_oldamount").getValue()) {
                var OldNewDiff = Xrm.Page.getAttribute("ber_amount").getValue() - Xrm.Page.getAttribute("ber_oldamount").getValue();

                Xrm.Page.getAttribute("ber_pendingamount").setValue(Xrm.Page.getAttribute("ber_pendingamount").getValue() + OldNewDiff);
                Xrm.Page.getAttribute("ber_pendingamount").setSubmitMode("always");

                Xrm.Page.getAttribute("ber_oldamount").setValue(Xrm.Page.getAttribute("ber_amount").getValue());
                Xrm.Page.getAttribute("ber_oldamount").setSubmitMode("always");
            }
        }
    }    
}