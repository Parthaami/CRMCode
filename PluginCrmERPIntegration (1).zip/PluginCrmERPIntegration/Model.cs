﻿using Newtonsoft.Json;

namespace PluginCrmERPIntegration
{

    public class ApiConfigSettings
    {
        [JsonProperty("dpc_name")]
        public string ApiName { get; set; }
        [JsonProperty("dpc_apiurl")]
        public string ApiURL { get; set; }
        [JsonProperty("dpc_methodtype")]
        public string MethodType { get; set; }
        [JsonProperty("dpc_key")]
        public string ApiKey { get; set; }
        [JsonProperty("new_authenticationtype")]
        public string AuthenticationType { get; set; }
    }

    public class Account
    {
        [JsonProperty("accountid")]
        public string AccountGUID { get; set; }
        [JsonProperty("parentaccountid")]
        public string ParentAccountID { get; set; }
        [JsonProperty("primarycontactid")]
        public string PrimaryContactId { get; set; }
        [JsonProperty("msdyn_billingaccount")]
        public string BillingAccount { get; set; }
        [JsonProperty("masterid")]
        public string MasterID { get; set; }
    }

    public class Quote
    {
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("contactid")]
        public string ContactID { get; set; }
        [JsonProperty("msdyn_account")]
        public string MsDynAccount { get; set; }
        [JsonProperty("accountid")]
        public string AccountID { get; set; }
        [JsonProperty("mah_contractor")]
        public string MahContractor { get; set; }
        [JsonProperty("pwc_contractor")]
        public string PwcContractor { get; set; }
    }

    public class QuoteDetail
    {
        [JsonProperty("quotedetailid")]
        public string QuoteDetailId { get; set; }
        [JsonProperty("parentbundleidref")]
        public string ParentBundleIdRef { get; set; }
        [JsonProperty("quoteid")]
        public string QuoteID { get; set; }
        [JsonProperty("msdyn serviceaccount")]
        public string MsDynServiceAccount  { get; set; }
    }

    public class Contact
    {
        [JsonProperty("contactid")]
        public string ContactID { get; set; }
        [JsonProperty("parentcontactid")]
        public string ParentContactID { get; set; }
        [JsonProperty("pwcmanager")]
        public string PwcManager { get; set; }
        [JsonProperty("masterid")]
        public string MasterID { get; set; }
        [JsonProperty("accountid")]
        public string AccountID { get; set; }
    }

}
