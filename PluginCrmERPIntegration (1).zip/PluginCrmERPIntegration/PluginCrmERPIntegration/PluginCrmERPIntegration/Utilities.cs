﻿using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;

namespace PluginCrmERPIntegration
{
    public static class Utilities
    {
        /// <summary>
        /// GetAttributeValues (Retrieve Any Type Of (Entity) Attribute Value)
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="FieldSchemaName"></param>
        /// <param name="FormattedValue"></param>
        /// <returns>Attribute Value</returns>
        private static string GetAttributeValues(Entity entity, string FieldSchemaName, bool FormattedValue = true)
        {
            if (entity.Contains(FieldSchemaName))
            {
                var EntityAttribute = entity.Attributes[FieldSchemaName];
                string AttributeTypeName = EntityAttribute.GetType().Name;
                if (AttributeTypeName.Equals("AliasedValue"))
                {
                    EntityAttribute = ((AliasedValue)entity.Attributes[FieldSchemaName]).Value;
                    AttributeTypeName = EntityAttribute.GetType().Name;
                }
                string AttributeValueGUID = "";
                string AttributeValueName = "";
                if (AttributeTypeName.Equals("OptionSetValue"))
                {
                    OptionSetValue AttributeReference = (OptionSetValue)EntityAttribute;
                    AttributeValueGUID = AttributeReference.Value.ToString();
                }
                if (AttributeTypeName.Equals("EntityReference"))
                {
                    EntityReference AttributeReference = (EntityReference)EntityAttribute;
                    AttributeValueGUID = AttributeReference.Id.ToString();
                    AttributeValueName = AttributeReference.Name;
                }
                else if (AttributeTypeName.Equals("Guid"))
                {
                    AttributeValueGUID = "" + EntityAttribute;
                }
                else
                {
                    AttributeValueName = "" + EntityAttribute;
                }

                if (FormattedValue)
                {
                    if (AttributeValueName.Trim() == "")
                        return AttributeValueGUID;
                    else
                        return AttributeValueName;
                }
                else
                {
                    return AttributeValueGUID;
                }
            }
            else
            {
                return string.Empty;
            }
        }

        /// <summary>
        /// GetJsonArrayFromFetchXML
        /// </summary>
        /// <param name="FetchedRecordsCollection"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returnsJSON Array As String & Populate All Field Values Of objSchemaMappingClass></returns>
        public static string GetJsonArrayFromFetchXML(
              EntityCollection FetchedRecordsCollection
            , object objSchemaMappingClass
            )
        {
            JObject ObjJSON = new JObject();
            try
            {
                if (FetchedRecordsCollection == null)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                if (FetchedRecordsCollection.Entities.Count < 1)
                {
                    ObjJSON.Add("message", "No Data Found!");
                    return ObjJSON.ToString();
                }
                else
                {
                    List<dynamic> ObjList = new List<dynamic>();
                    PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                    .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                    foreach (Entity objEntity in FetchedRecordsCollection.Entities)
                    {
                        ObjJSON = new JObject();
                        foreach (PropertyInfo Attribute in ClasProperties)
                        {
                            string AttributeName = Attribute.Name;
                            string EntityAttributeName = Attribute.Name;
                            if (Attribute.GetCustomAttributesData().Count > 0)
                            {
                                var EntityAttributeCollection = Attribute.GetCustomAttributesData()[0].ConstructorArguments;
                                if (EntityAttributeCollection.Count > 0)
                                {
                                    EntityAttributeName = "" + EntityAttributeCollection[0].Value;
                                }
                            }
                            string EntityAttributeValue = "" + GetAttributeValues(objEntity, EntityAttributeName, true);
                            Attribute.SetMethod.Invoke(objSchemaMappingClass, new object[] { EntityAttributeValue });
                            //Attribute.GetValue(objSchemaMappingClass, null);
                            ObjJSON.Add(AttributeName, EntityAttributeValue);
                        }

                        ObjList.Add(JsonConvert.DeserializeObject<dynamic>(ObjJSON.ToString()));
                    }

                    return JsonConvert.SerializeObject(ObjList, Formatting.Indented);
                }
            }
            catch (Exception ex)
            {
                ObjJSON.Add("Error", ex.Message);
                return ObjJSON.ToString();
            }

        }


        /// <summary>
        /// GetAPIResult
        /// </summary>
        /// <param name="strBaseAddress"></param>
        /// <param name="AccessTypeHeader"></param>
        /// <param name="strAccessToken"></param>
        /// <param name="strMethodName"></param>
        /// <param name="strJsonInput"></param>
        /// <param name="responseObject"></param>
        /// <param name="strResult"></param>
        /// <param name="TotalRecords"></param>
        /// <param name="Exception"></param>
        /// <returns></returns>
        public static string GetAPIResult(string strBaseAddress,
                                     string AccessTypeHeader,
                                     string strAccessToken,
                                     string strJsonInput
                                     )
        {
            MemoryStream ResponseStream = new MemoryStream();
            try
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3
                | SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
                HttpWebRequest postRequest = (HttpWebRequest)WebRequest.Create(strBaseAddress);
                postRequest.ContentType = "application/json";
                postRequest.Method = "POST";
                postRequest.Timeout = 50000;
                postRequest.Headers.Add(AccessTypeHeader, strAccessToken);
                StreamWriter requeststream = new StreamWriter(postRequest.GetRequestStream());
                dynamic inputData = JsonConvert.DeserializeObject(strJsonInput);
                var json = JsonConvert.SerializeObject(inputData);
                requeststream.Write(json);
                requeststream.Close();
                try
                {
                     HttpWebResponse getResponse = (HttpWebResponse)postRequest.GetResponse();
                    return "" + getResponse;
                }
                catch (WebException ex)
                {
                    return "" + ex.Response + Environment.NewLine + ex.Message;
                }
                
            }
            catch (Exception ex)
            {
                return ex.Message;
            }

            return "";
        }


    }
}
