﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PluginCrmERPIntegration
{
    public class CrmERPIntegration : IPlugin
    {
 
        public void Execute(IServiceProvider serviceProvider)
        {
            try
            {
                IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                IOrganizationService service = ((IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(new Guid?(context.UserId));
                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is EntityReference))
                {             
                    Entity Quote = (Entity)context.InputParameters["Target"];
                    if (Quote != null && Quote.Attributes.Count() > 0)
                    {
                       string JsonQuote =  Data.JsonGetQuote(service, Quote.Id);
                       string JsonQuoteDeatil =  Data.JsonGetQuoteDetail(service, Quote.Id);
                        Guid _accountid = Guid.Parse("" + Quote["accountid"]);
                       string JsonAccount =  Data.JsonGetAccount(service, _accountid);
                        Guid _contactid = Guid.Parse("" + Quote["contactid"]);
                        string JsonContact =  Data.JsonGetContact(service, _accountid, _contactid);

                        List<dynamic> listApiConfigs = Data.GetApiConfigurations(service, new ApiConfigSettings());
                        foreach (ApiConfigSettings _ApiConfig in listApiConfigs)
                        {
                            string Apiname = _ApiConfig.ApiName;
                            string ApiURL = _ApiConfig.ApiURL;
                            string ApiKey = _ApiConfig.ApiKey;
                            string AuthenticationType = _ApiConfig.AuthenticationType;

                            string ApiExecutionResult = "";
                            if (Apiname == "ErpAccountAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonAccount);
                            }
                            if (Apiname == "ErpContactAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonContact);
                            }
                            if (Apiname == "ErpQuoteAPI")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonQuote);
                            }
                            if (Apiname == "ErpQuoteProductApi")
                            {
                                ApiExecutionResult = Utilities.GetAPIResult(ApiURL, AuthenticationType, ApiKey, JsonQuoteDeatil);
                            }


                        }

                    }
                }
            }
            catch (Exception ex)
            {
              //  oLogger.Log("UpdateQuotationItem", "Execute", "Error on Delete of Quotation Item", ex.Message.ToString());
            }
        }
    }
}
