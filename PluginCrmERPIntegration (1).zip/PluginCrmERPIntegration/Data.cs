﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PluginCrmERPIntegration
{
    public static class Data
    {

        /// <summary>
        /// GetApiConfigurations
        /// </summary>
        /// <param name="service"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>List<dynamic></returns>
        public static List<dynamic> GetApiConfigurations(IOrganizationService service, object objSchemaMappingClass)
        {
            try
            {
                var query = new QueryExpression("dpc_crmerpsettings");
                query.ColumnSet = new ColumnSet();               
                List<ApiConfigSettings> ObjList = new List<ApiConfigSettings>();
                PropertyInfo[] ClasProperties = objSchemaMappingClass.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                EntityCollection ec = service.RetrieveMultiple(query);
                List<dynamic> ListOutputClass = ec.Entities.ToList<dynamic>();
                return ListOutputClass;
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        /// <summary>
        /// JsonGetAccount
        /// </summary>
        /// <param name="service"></param>
        /// <param name="AccountId"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>Json String</returns>
        public static string JsonGetAccount(IOrganizationService service, Guid AccountId)
        {
            try
            {
                var query = new QueryExpression("account");
                query.ColumnSet = new ColumnSet();
                Account _OutputDataModel = new Account();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("accountid", ConditionOperator.Equal, AccountId);
                EntityCollection ec = service.RetrieveMultiple(query);                
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch(Exception ex)
            {
               
            }
            return "";
        }

        /// <summary>
        /// JsonGetContact
        /// </summary>
        /// <param name="service"></param>
        /// <param name="AccountId"></param>
        /// <param name="ContactID"></param>
        /// <param name="objSchemaMappingClass"></param>
        /// <returns>Json String</returns>
        public static string JsonGetContact(IOrganizationService service, Guid AccountId, Guid ContactID)
        {
            try
            {
                var query = new QueryExpression("contact");
                query.ColumnSet = new ColumnSet();
                Account _OutputDataModel = new Account();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("accountid", ConditionOperator.Equal, AccountId);
                query.Criteria.AddCondition("contactid", ConditionOperator.Equal, ContactID);
                EntityCollection ec = service.RetrieveMultiple(query);               
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuote
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuote(IOrganizationService service, Guid QuoteID)
        {
            try
            {
                var query = new QueryExpression("quote");
                query.ColumnSet = new ColumnSet();
                Quote _OutputDataModel = new Quote();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);
                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

        /// <summary>
        /// JsonGetQuoteDetail
        /// </summary>
        /// <param name="service"></param>
        /// <param name="QuoteID"></param>
        /// <returns></returns>
        public static string JsonGetQuoteDetail(IOrganizationService service, Guid QuoteID)
        {
            try
            {
                var query = new QueryExpression("quotedetail");
                query.ColumnSet = new ColumnSet();
                QuoteDetail _OutputDataModel = new QuoteDetail();
                PropertyInfo[] ClasProperties = _OutputDataModel.GetType()
                                                .GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (PropertyInfo Attribute in ClasProperties)
                {
                    string AttributeName = Attribute.Name;
                    query.ColumnSet.Columns.Add(AttributeName);
                }
                query.Criteria = new FilterExpression();
                query.Criteria.AddCondition("quoteid", ConditionOperator.Equal, QuoteID);
                EntityCollection ec = service.RetrieveMultiple(query);
                string JSON_Output = Utilities.GetJsonArrayFromFetchXML(ec, _OutputDataModel);
                return JSON_Output;
            }
            catch (Exception ex)
            {

            }
            return "";
        }

    }
}
